<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
	$_SESSION['intern_page_current'] = "manage_semester";
		include "./parts/main_logcheck.php";
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	if ( $_POST['btnsave'] ) {
		$value = $_POST['value'];
		$errn = 0;
		$errmsg = "";
		if ( trim($value) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Semester required. ";
		}
		$ec = 0;
		$sql = " select * from tbl_semester  where semester='$value' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			$ec = $ec + 1;
		}
		if ( trim($ec) > 0 ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Semester already exist. ";
		}
		if ( $errn <= 0 ) {
			//SAVE DATA
			$sql = " insert into tbl_semester 
						(semester)
						values
						('$value')
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
			echo "
				<script>
					alert('$errmsg');
				</script>
			";
		}
	}
	//
	if ( $_POST['btnsaveEdit'] ) {
		$cid = $_POST['txtid'];
		//
		$value = $_POST['value'];
		$errn = 0;
		$errmsg = "";
		if ( trim($value) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Semester required. ";
		}
		if ( $errn <= 0 ) {
			//SAVE DATA
			$sql = " update tbl_semester set 
						semester='$value' 
							where sem_id='$cid'
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
			echo "
				<script>
					alert('$errmsg');
				</script>
			";
		}
	}
	if ( $_POST['btnsaveDelete'] ) {
		$cid = $_POST['txtid'];
		//
		$errn = 0;
		if ( $errn <= 0 ) {
			//SAVE DATA
			$sql = " delete from tbl_semester 
						where sem_id='$cid'
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
			echo "
				<script>
					alert('$errmsg');
				</script>
			";
		}
	}
	//
	if ( trim($logun)=="" || strtolower(trim($logutype))==strtolower(trim("student")) ) {
		exit;
	}
?>

<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>


</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">Semester</h3>
					<div class="row">

<!-- ====================== MODAL ============================================== -->

    <div id="modalAddSemester" class="modal fade" role="dialog">
      <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add Semester</h4>
      </div>
          <form method="post" action="">
      <div class="modal-body">
        <p>
          <div class="form-group">
              <?php echo $_SESSION['intern_disp_err']; $_SESSION['intern_disp_err'] = ""; ?>
            </div>
            <div class="form-group div01">
              <label for="sem" class="control-label sr-only">Semester</label>
              <input type="text" name="value" class="form-control txt01" id="sem" placeholder="Semester"
                <?php
                  $value = $_POST['value'];
                  echo " value='$value' ";
                ?>
              >
            </div>
        </p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <input type="submit" name="btnsave" class="btn btn-primary btn-lg btn01" value="SAVE">
      </div>
          </form>
      </div>

      </div>
    </div>

<!-- ====================== MODAL ============================================== -->


						<div class="col-md-12">
							<!-- BASIC TABLE -->
							<div class="row">
							<div class="col-md-9">
							<h5 class="ss">Search:</h5>
							</div>
						
							
							<div class="col-md-3">
							<div class="form-group pull-right">
							<input type="text" id="myInput1" value="" class="search form-control" placeholder="What you looking for">
							<!--	<span class="counter pull-right"><button type="button" class="btn btn-primary">Search</button></span>-->
								</div>
									<span class="counter pull-right"></span>
									</div>
						</div>
						<hr>

					<a href="" data-toggle="modal" data-target="#modalAddSemester" class="btn btn-success btn-md">+ ADD YEAR</a>
					<br/>
					<br/>
				
							<!-- RECENT PURCHASES -->
							<div class="panel">
					
								<div class="table-responsive">
									<table class="table">
										<thead>
											<tr>
												<th></th>
												<th>ID</th>
												<th>Semester</th>
											</tr>
										</thead>
										<tbody id="myTable1">
											<?php
												//
												$nn = 0;
												//
												include "./data/connect.php";
												$sql = " select sem_id,semester from tbl_semester  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$nn = $nn + 1;
													echo "
														<tr>
															<td>
															
																<div class='dropdown'>
																  <a class='btn_action_01' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu'>
																    <li><a href='#' data-toggle='modal' data-target='#modalEdit_$nn'>Edit</a></li>
																    <li><a href='#' data-toggle='modal' data-target='#modalDelete_$nn'>Delete</a></li>
																  </ul>
																</div>

																    <div id='modalEdit_$nn' class='modal fade' role='dialog'>
																      <div class='modal-dialog'>
																      <!-- Modal content-->
																      <div class='modal-content'>
																      <div class='modal-header'>
																        <button type='button' class='close' data-dismiss='modal'>&times;</button>
																        <h4 class='modal-title'>Update</h4>
																      </div>
																          <form method='post' action=''>
																      <div class='modal-body'>
																        <p>
																					<input type='hidden' name='txtid' value='$dat[0]'/>
																          <div class='form-group'>
																             
																            </div>
																            <div class='form-group div01'>
																              <label for='add-value' class='control-label sr-only'>Semester</label>
																              <input type='text' name='value' class='form-control txt01' id='add-value' placeholder='Semester'
																                 value='$dat[1]' 
																              >
																            </div>
																        </p>
																      </div>
																      <div class='modal-footer'>
																        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																        <input type='submit' name='btnsaveEdit' class='btn btn-primary btn-lg btn01' value='SAVE'>
																      </div>
																          </form>
																      </div>

																      </div>
																    </div>

																		<div id='modalDelete_$nn' class='modal fade' role='dialog'>
																			<div class='modal-dialog'>
																			<!-- Modal content-->
																			<div class='modal-content'>
																			<div class='modal-header'>
																				<button type='button' class='close' data-dismiss='modal'>&times;</button>
																				<h4 class='modal-title'>Delete</h4>
																			</div>
																					<form method='post' action=''>
																			<div class='modal-body'>
																				<p>
																					<input type='hidden' name='txtid' value='$dat[0]'/>
																					Delete semester?
																				</p>
																			</div>
																			<div class='modal-footer'>
																				<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																				<input type='submit' name='btnsaveDelete' class='btn btn-primary btn-lg btn01' value='DELETE'>
																			</div>
																					</form>
																			</div>

																			</div>
																		</div>

															</td>
															<td>
																".trim($dat[0])."
															</td>
															<td>
																".trim($dat[1])."
															</td>
														</tr>
													";
												}
											?>
											
										</tbody>
									</table>
								</div>
							</div>
					
							<!-- END TABLE NO PADDING -->
						</div>
					</div>
								
					
				
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>

	<script >
	$(document).ready(function(){
  $("#myInput1").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable1 tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
	</script>


<?php
	include "./parts/btm_script.php";
?>

</body>

</html>
