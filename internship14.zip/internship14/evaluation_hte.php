<?php session_start(); error_reporting( E_ALL ^ E_NOTICE );
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$_SESSION['intern_page_current'] = "evaluation_hte";
		include "./parts/main_logcheck.php";
	include "./parts/sys_hte_raterank_updater.php";
	//
	if ( trim($logun)=="" || strtolower(trim($logutype))!=strtolower(trim("zx")) ) {
		echo "<META HTTP-EQUIV='Refresh' Content='0; URL=./cpanel.php'>";
		exit;
	}
?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>

</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">Host Training Establishment Evaluation</h3>
					<div class="row">
						
						<div class="">

							<div class="panel">
					
								<div class="table-responsive">
									<table class="table">
										<thead>
											<tr>
												<th>HTE</th>
												<th>Address</th>
												<th># of Students</th>
												<th>Evalutaion Result</th>

											</tr>
										</thead>
										<tbody id="myTable1">
											<?php
												include "./data/connect.php";
												$sql = " select hte_id,total_rate from tbl_hte_raterank  order by total_rate desc ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$rate = getHTERate2($dat[0]);
													$nos = getCountHTEInterns2($dat[0]);
													$id = trim($dat[0]);
													$hte = "";
													$addr = "";
													//$nos = "";
														$sql1 = " select hte_id,dsn,name,address,no_students from tbl_hte  where hte_id='$id'  ";
														$qry1 = mysqli_query($conn,$sql1);
														while($dat1=mysqli_fetch_array($qry1)) {
															$hte = "<a class='' href='page_hte.php?id=$dat1[0]'>".trim($dat1[2])."</a>";
															$addr = trim($dat1[3]);
															//$nos = trim($dat1[4]);
														}
													echo "
														<tr>
															<td>
																$hte
															</td>
															<td>
																$addr
															</td>
															<td>
																$nos
															</td>
															<td>
																$rate
															</td>
														</tr>
													";
												}
											?>
											
										</tbody>
									</table>
								</div>
							</div>
					

							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Overall HTE Evaluation </h3>
								</div>
								<div class="panel-body">
									<div id="demo-bar-chart" class="ct-chart"></div>
								</div>
								<div class="row1">
									<h5>Legend:</h5>
										<div class="col-md-4">
											<h5>1st Evaluation</h5>
											<div class="box lnr lnr-chart-bars"></div>
										</div>
										<div class="col-md-4">
											<h5>2nd Evaluation</h5>
											<div class="box1 lnr lnr-chart-bars"></div>
										</div>
								</div>
							</div>
						</div>
					</div>

					<div class="">
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Overall Evaluation per Year</h3>
								</div>
								<div class="panel-body">
									<div id="demo-line-chart" class="ct-chart"></div>
								</div>
							</div>
						</div>
					<div class="row">
						<div class="col-md-6">
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Area Chart</h3>
								</div>
								<div class="panel-body">
									<div id="demo-area-chart" class="ct-chart"></div>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Multiple Chart</h3>
								</div>
								<div class="panel-body">
									<div id="multiple-chart" class="ct-chart"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/vendor/chartist/js/chartist.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>
	<script>
	$(function() {
		var options;

		var data = {
			labels: ['5', '4', '3', '2', '1'],
			series: [{
				name: 'series-Eva1',
				data:[20, 40, 20, 15, 5], 
			
		},{
				name: 'series-Eva2',
				data:[25, 35, 25, 12, 3],
			}]
		};

		// bar chart
		options = {
			height: "300px",
			axisX: {
				showGrid: false
			},
		};

		new Chartist.Bar('#demo-bar-chart', data, options);


		var data2 = {
			labels: ['2015', '2016', '2017', '2018'],
			series: [{
				data:[4.0, 3.5, 4.2, 4.7],
			}
			
		]
		};

		// line chart
		options = {
			height: "300px",
			showPoint: true,
			axisX: {
				showGrid: false
			},
			lineSmooth: false,
		};

		new Chartist.Line('#demo-line-chart', data2, options);
		
		
		

		// area chart
		options = {
			height: "270px",
			showArea: true,
			showLine: false,
			showPoint: false,
			axisX: {
				showGrid: false
			},
			lineSmooth: false,
		};

		new Chartist.Line('#demo-area-chart', data, options);


		// multiple chart
		var data = {
			labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
			series: [{
				name: 'series-real',
				data: [200, 380, 350, 320, 410, 450, 570, 400, 555, 620, 750, 900],
			}, {
				name: 'series-projection',
				data: [240, 350, 360, 380, 400, 450, 480, 523, 555, 600, 700, 800],
			}]
		};

		var options = {
			fullWidth: true,
			lineSmooth: false,
			height: "270px",
			low: 0,
			high: 'auto',
			series: {
				'series-projection': {
					showArea: true,
					showPoint: false,
					showLine: false
				},
			},
			axisX: {
				showGrid: false,

			},
			axisY: {
				showGrid: false,
				onlyInteger: true,
				offset: 0,
			},
			chartPadding: {
				left: 20,
				right: 20
			}
		};

		new Chartist.Line('#multiple-chart', data, options);

	});
	</script>


<?php
	include "./parts/btm_script.php";
?>


</body>

</html>
