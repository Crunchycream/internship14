<?php
	function generateCode($count) {
		//
		$chars1 = array();
		$chars2 = array();
		//
		//
		$n = -1;
		//
		$n += 1;
		$chars1[$n] = "A";
		$n += 1;
		$chars1[$n] = "a";
		$n += 1;
		$chars1[$n] = "B";
		$n += 1;
		$chars1[$n] = "b";
		$n += 1;
		$chars1[$n] = "C";
		$n += 1;
		$chars1[$n] = "c";
		$n += 1;
		$chars1[$n] = "D";
		$n += 1;
		$chars1[$n] = "d";
		$n += 1;
		$chars1[$n] = "E";
		$n += 1;
		$chars1[$n] = "e";
		$n += 1;
		$chars1[$n] = "F";
		$n += 1;
		$chars1[$n] = "f";
		$n += 1;
		$chars1[$n] = "G";
		$n += 1;
		$chars1[$n] = "g";
		$n += 1;
		$chars1[$n] = "H";
		$n += 1;
		$chars1[$n] = "h";
		$n += 1;
		$chars1[$n] = "I";
		$n += 1;
		$chars1[$n] = "i";
		$n += 1;
		$chars1[$n] = "J";
		$n += 1;
		$chars1[$n] = "j";
		$n += 1;
		$chars1[$n] = "K";
		$n += 1;
		$chars1[$n] = "k";
		$n += 1;
		$chars1[$n] = "L";
		$n += 1;
		$chars1[$n] = "l";
		$n += 1;
		$chars1[$n] = "M";
		$n += 1;
		$chars1[$n] = "m";
		$n += 1;
		$chars1[$n] = "N";
		$n += 1;
		$chars1[$n] = "n";
		$n += 1;
		$chars1[$n] = "O";
		$n += 1;
		$chars1[$n] = "o";
		$n += 1;
		$chars1[$n] = "P";
		$n += 1;
		$chars1[$n] = "p";
		$n += 1;
		$chars1[$n] = "Q";
		$n += 1;
		$chars1[$n] = "q";
		$n += 1;
		$chars1[$n] = "R";
		$n += 1;
		$chars1[$n] = "r";
		$n += 1;
		$chars1[$n] = "S";
		$n += 1;
		$chars1[$n] = "s";
		$n += 1;
		$chars1[$n] = "T";
		$n += 1;
		$chars1[$n] = "t";
		$n += 1;
		$chars1[$n] = "U";
		$n += 1;
		$chars1[$n] = "u";
		$n += 1;
		$chars1[$n] = "V";
		$n += 1;
		$chars1[$n] = "v";
		$n += 1;
		$chars1[$n] = "W";
		$n += 1;
		$chars1[$n] = "w";
		$n += 1;
		$chars1[$n] = "X";
		$n += 1;
		$chars1[$n] = "x";
		$n += 1;
		$chars1[$n] = "Y";
		$n += 1;
		$chars1[$n] = "y";
		$n += 1;
		$chars1[$n] = "Z";
		$n += 1;
		$chars1[$n] = "z";
		//
		//
		$n = -1;
		$n += 1;
		$chars2[$n] = "1";
		$n += 1;
		$chars2[$n] = "2";
		$n += 1;
		$chars2[$n] = "3";
		$n += 1;
		$chars2[$n] = "4";
		$n += 1;
		$chars2[$n] = "5";
		$n += 1;
		$chars2[$n] = "6";
		$n += 1;
		$chars2[$n] = "7";
		$n += 1;
		$chars2[$n] = "8";
		$n += 1;
		$chars2[$n] = "9";
		$n += 1;
		$chars2[$n] = "0";
		//
		//
		//GENERATE
		//
		$val = "";
		//
		for ( $i=1 ; $i<=$count ; $i++ ) {
			//
			$t = 0;
			$t = rand(1,2);
			//
			if ( $t == 1 ) {
				//LETTERS
				$r = rand(0,count($chars1)-1);
				//
				$val = trim($val) . trim($chars1[$r]);
			}else{
				//NUMBERS
				$r = rand(0,count($chars2)-1);
				//
				$val = trim($val) . trim($chars2[$r]);
			}
			//
		}
		//
		//
		return $val;
		//
	}
?>