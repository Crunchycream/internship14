		<div id="modalChangePhoto" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Change Profile Photo</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-md" value="Save" name="btnProfilePhotoChange">
			</div>
					</form>
			</div>

			</div>
		</div>
		<div id="modalChangeCoverPhoto" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Change Cover Photo</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-md" value="Save" name="btnProfileCoverPhotoChange">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqResume" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update Resume</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF / Image files only.<br/>
					<input type="hidden" name="action" value="resume">
					<input type="file" name="fileUP" id="fileUP">
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-md" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqAppLet" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update Application Letter</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF / Image files only.<br/>
					<input type="hidden" name="action" value="appletter">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-md" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqMOA" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update MOA</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF / Image files only.<br/>
					<input type="hidden" name="action" value="moa">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-md" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqMOU" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update MOU</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF / Image files only.<br/>
					<input type="hidden" name="action" value="mou">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-md" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqCertAcc" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update Certificatin of Acceptance</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF / Image files only.<br/>
					<input type="hidden" name="action" value="certacc">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-md" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqWForm" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update White Form</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF / Image files only.<br/>
					<input type="hidden" name="action" value="wform">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-md" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqRecLet" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update Recommendation Letter</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF / Image files only.<br/>
					<input type="hidden" name="action" value="reclet">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-md" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqWaiver" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update Waiver</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF / Image files only.<br/>
					<input type="hidden" name="action" value="waiver">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-md" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqParCon" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update Parent's Consent</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF / Image files only.<br/>
					<input type="hidden" name="action" value="parcon">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-md" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqMedCert" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update Medical Certificate</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF / Image files only.<br/>
					<input type="hidden" name="action" value="medcert">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-md" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqCertApp" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update Certificate of Appreciation</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF / Image files only.<br/>
					<input type="hidden" name="action" value="certapp">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-md" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqCertCom" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update Certificate of Completion</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF / Image files only.<br/>
					<input type="hidden" name="action" value="certcom">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-md" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqOJTImg" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update OJT Image</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF / Image files only.<br/>
					<input type="hidden" name="action" value="ojtimg">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-md" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<!-- ================================================================================================= -->
		<!-- ====================== ADD RATE 2 ============================== -->
		<div id="modalInternEval" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content eval_modal01">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Student Evaluation</h4>
			</div>
					<form action="" method="post">
			<div class="modal-body">
				<p>
					<?php include "./data/connect.php";
						//
							$uid = $_GET['id'];
						//
						$cursy = trim($_SESSION['intern_data_active_sy']);
						//
						//
						$rateopt = "";
						$rateopt = "
									<option value='1'>1</option>
									<option value='2'>2</option>
									<option value='3' selected='true'>3</option>
									<option value='4'>4</option>
									<option value='5'>5</option>
						";
						//
						//
						//
						$majoropt = "";
						$semopt = "";
						$syopt = "";
						$deptopt = "";
						//
						$majoropt = $majoropt . "<option value='none'>None</option>";
						//
						$sql = " select major from tbl_major order by major asc  ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" ) {
								$majoropt = $majoropt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
							}
						}
						//
						$sql = " select semester from tbl_semester order by semester asc  ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" ) {
								$semopt = $semopt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
							}
						}
						//
						$sql = " select sy from tbl_sy order by sy asc  ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" ) {
								$syopt = $syopt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
							}
						}
						//
						$sql = " select department from tbl_department order by department asc  ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" ) {
								$deptopt = $deptopt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
							}
						}
						//
						//
						$tcrit = array();
						$n = 0;
						//GET CRITERIA
						$sql = " select name,sy,adate from tbl_interns_eval_criteria where  sy='$cursy' ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" ) {
								$tcrit[$n] = trim($dat[0]);
								$n += 1;
							}
						}
						//
						//
						$crsid = "";
						$crsn = "";
						$deptid = "";
						$deptn = "";
						//
						//GET COURSE
						$sql = " select course from tbl_interns where studentid='$uid' ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							$crsid = $dat[0];
						}
						//GET COURSE NAME
						$sql = " select course_id,course from tbl_course where course_id='$crsid' ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							$crsn = $dat[1];
						}
						//GET DEPT
						$sql = " select department_id from tbl_department_courses where course_id='$crsid' ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							$deptid = $dat[0];
						}
						//GET DEPT NAME
						$sql = " select department_id,department from tbl_department where department_id='$deptid' ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							$deptn = $dat[1];
						}
						//
						$opt1 = "
								<table width='100%;'>
									<tr>
										<td class='eval_td01'>
											<b>Major:</b>
											<span>
												<select class='form-control txt01 span02' name='major'>
													$majoropt
												</select>
											</span>
										</td>
										<td class='eval_td01'>
											<span>
												<b>Semester:</b>
												<select class='form-control txt01 span02' name='semester'>
													$semopt
												</select>
											</span>
										</td>
									</tr>
									<tr>
										<td class='eval_td01'>
											<span>
												<b>S.Y.:</b>
												<select class='form-control txt01 span02' name='sy'>
													$syopt
												</select>
											</span>
										</td>
										<td class='eval_td01'>
											<span>
												<b>Department:</b>
												<select class='form-control txt01 span02' name='dept'>
													$deptopt
												</select>

												<input type='' name='crs' value='$crsid' />
												<input type='' name='crsn' value='$crsn' />

												<input type='' name='dept' value='$deptid' />
												<input type='' name='deptn' value='$deptn' />

											</span>
										</td>
									</tr>
								</table>

						";
						//
						//
						echo "
							<div class='table-responsive'>
								<table>
									<thead>
										<tr>
											<td class='eval_td01'>

											</td>
											<td class='eval_td01'>
												<b>Program Competences</b>
											</td>
											<td class='eval_td01'>
												<b>Number of Hours</b>
											</td>
											<td class='eval_td01'>
												<b>Evaluation Rating</b>
											</td>
										</tr>
									</thead>
									<tbody>";
							if ( count($tcrit)>0 && count($tcrit)>=1 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>1.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp1' readonly='true'>$tcrit[0]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp1hrs' value='10' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp1rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=2 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>2.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp2' readonly='true'>$tcrit[1]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp2hrs' value='10' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp2rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=3 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>3.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp3' readonly='true'>$tcrit[2]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp3hrs' value='10' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp3rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=4 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>4.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp4' readonly='true'>$tcrit[3]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp4hrs' value='10' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp4rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=5 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>5.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp5' readonly='true'>$tcrit[4]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp5hrs' value='10' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp5rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=6 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>6.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp6' readonly='true'>$tcrit[5]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp6hrs' value='10' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp6rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=7 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>7.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp7' readonly='true'>$tcrit[6]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp7hrs' value='10' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp7rate' value='3' />
											</td>
										</tr>";
							}
									
								echo "
									</tbody>
								</table>
							</div>
						";
						//
						echo "
								<br/>
								<br/>
						";
						//
						echo "
							<div class='table-responsive'>
								<table width='100%'>
										<tr>
											<td class='eval_td02'>
												<b>Professionalism</b><br/>
												<span class='eval_span01'>
													punctuality, commitment, knowledgeable, skillful, follows instruction, respectful
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit1'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td02'>
												<b>Job maturity</b><br/>
												<span class='eval_span01'>
													positive work disposition, open to suggestions and feedback, exercises self-management
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit2'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td02'>
												<b>Communication skills</b><br/>
												<span class='eval_span01'>
													able to communicate well in formula and vernacular language, proficient written and spoken English, technical writing skills
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit3'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td02'>
												<b>Productivity</b><br/>
												<span class='eval_span01'>
													work efficiency and effectiveness, accomplished assigned task, demonstrated satisfactory outputs
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit4'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td02'>
												<b>Leadership</b><br/>
												<span class='eval_span01'>
													takes initiative, provides direction in a group
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit5'>
													$rateopt
												</select>
											</td>
										</tr>
								</table>
								<br/>
								<table width='100%'>
										<tr>
											<td class='eval_td02'>
												<b>Demonstration of University core values</b><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
											</td>
										</tr>
										<tr>
											<td class='eval_td02'>
												<span class='eval_span02'>Excellence</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit2_1'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td02'>
												<span class='eval_span02'>Honesty & Integrity</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit2_2'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td02'>
												<span class='eval_span02'>Innovation</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit2_3'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td02'>
												<span class='eval_span02'>Teamwork</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit2_4'>
													$rateopt
												</select>
											</td>
										</tr>
								</table>
								<br/>
								<b>Comments:</b><br/>
								<textarea class='form-control span02' name='comments'></textarea>
							</div>
						";
					?>
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-sm" value="Save" name="btnAddInternEval">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ====================== ADD RATE 2 ============================== -->
		<!-- ====================== ADD RATE 2 ============================== -->
		<div id="modalEval22" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content eval_modal01">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">HTE Evaluation</h4>
			</div>
					<form action="" method="post">
			<div class="modal-body">
				<p>
					<?php include "./data/connect.php";
						//
							$uid = $_GET['id'];
						//
						$cursy = trim($_SESSION['intern_data_active_sy']);
						//
						//
						$rateopt = "";
						$rateopt = "
									<option value='1'>1</option>
									<option value='2'>2</option>
									<option value='3'>3</option>
									<option value='4'>4</option>
									<option value='5'>5</option>
						";
						//
						$majoropt = "";
						$semopt = "";
						$syopt = "";
						$deptopt = "";
						//
						$majoropt = $majoropt . "<option value='none'>None</option>";
						//
						$sql = " select major from tbl_major order by major asc  ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" ) {
								$majoropt = $majoropt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
							}
						}
						//
						$sql = " select semester from tbl_semester order by semester asc  ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" ) {
								$semopt = $semopt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
							}
						}
						//
						$sql = " select sy from tbl_sy order by sy asc  ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" ) {
								$syopt = $syopt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
							}
						}
						//
						$sql = " select department from tbl_department order by department asc  ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" ) {
								$deptopt = $deptopt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
							}
						}
						//
						$tcrit = array();
						$n = 0;
						//GET CRITERIA
						$sql = " select name,sy,adate from tbl_hte_eval_criteria where hte_id='$uid' and sy='$cursy' ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" ) {
								$tcrit[$n] = trim($dat[0]);
								$n += 1;
							}
						}
						//
						echo "
							<div class='table-responsive'>
								<table width='100%;'>
									<tr>
										<td class='eval_td01'>
											<b>Major:</b>
											<span>
												<select class='form-control txt01 span02' name='major'>
													$majoropt
												</select>
											</span>
										</td>
										<td class='eval_td01'>
											<span>
												<b>Semester:</b>
												<select class='form-control txt01 span02' name='semester'>
													$semopt
												</select>
											</span>
										</td>
									</tr>
									<tr>
										<td class='eval_td01'>
											<span>
												<b>S.Y.:</b>
												<select class='form-control txt01 span02' name='sy'>
													$syopt
												</select>
											</span>
										</td>
										<td class='eval_td01'>
											<span>
												<b>Department:</b>
												<select class='form-control txt01 span02' name='dept'>
													$deptopt
												</select>
											</span>
										</td>
									</tr>
								</table>
								<br/>
								<table>
									<thead>
										<tr>
											<td class='eval_td01'>

											</td>
											<td class='eval_td01'>
												<b>Program Competences</b>
											</td>
											<td class='eval_td01'>
												<b>Number of Hours</b>
											</td>
											<td class='eval_td01'>
												<b>Evaluation Rating</b>
											</td>
										</tr>
									</thead>
									<tbody>";
							if ( count($tcrit)>0 && count($tcrit)>=1 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>1.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp1' readonly='true'>$tcrit[0]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp1hrs' value='0' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp1rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=2 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>2.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp2' readonly='true'>$tcrit[1]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp2hrs' value='0' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp2rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=3 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>3.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp3' readonly='true'>$tcrit[2]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp3hrs' value='0' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp3rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=4 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>4.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp4' readonly='true'>$tcrit[3]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp4hrs' value='0' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp4rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=5 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>5.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp5' readonly='true'>$tcrit[4]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp5hrs' value='0' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp5rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=6 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>6.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp6' readonly='true'>$tcrit[5]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp6hrs' value='0' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp6rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=7 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>7.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp7' readonly='true'>$tcrit[6]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp7hrs' value='0' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp7rate' value='3' />
											</td>
										</tr>";
							}
									
								echo "
									</tbody>
								</table>
							</div>
						";
					?>
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-sm" value="Save" name="btnAddHTEEval">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ====================== ADD RATE 2 ============================== -->
		<!-- ====================== MANAGE RATE CRITERIA ============================== -->
		<div id="modalEvalCriteria" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content eval_modal01">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Manage Evaluation Criteria</h4>
			</div>
					<form action="" method="post">
			<div class="modal-body">
				<p>
					<?php include "./data/connect.php";
						//
						//
						echo "
							<b>1.</b> <textarea class='form-control span02 txt_disp01' name='comp1'></textarea><br/>
							<b>2.</b> <textarea class='form-control span02 txt_disp01' name='comp2'></textarea><br/>
							<b>3.</b> <textarea class='form-control span02 txt_disp01' name='comp3'></textarea><br/>
							<b>4.</b> <textarea class='form-control span02 txt_disp01' name='comp4'></textarea><br/>
							<b>5.</b> <textarea class='form-control span02 txt_disp01' name='comp5'></textarea><br/>
							<b>6.</b> <textarea class='form-control span02 txt_disp01' name='comp6'></textarea><br/>
							<b>7.</b> <textarea class='form-control span02 txt_disp01' name='comp7'></textarea><br/>
						";
					?>
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-sm" value="Save" name="btnAddEvalCriteria">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ====================== MANAGE RATE CRITERIA ============================== -->