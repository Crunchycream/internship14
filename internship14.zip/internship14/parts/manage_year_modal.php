    <div id="modalAddYear" class="modal fade" role="dialog">
      <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add Year</h4>
      </div>
          <form method="post" action="">
      <div class="modal-body">
        <p>
          <div class="form-group">
              <?php echo $_SESSION['intern_disp_err']; $_SESSION['intern_disp_err'] = ""; ?>
            </div>
            <div class="form-group div01">
              <label for="stud-add-value" class="control-label sr-only">Year</label>
              <input type="text" name="value" class="form-control txt01" id="stud-add-value" placeholder="Year"
                <?php
                  $value = $_POST['value'];
                  echo " value='$value' ";
                ?>
              >
            </div>
        </p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <input type="submit" name="btnsave" class="btn btn-primary btn-lg btn01" value="SAVE">
      </div>
          </form>
      </div>

      </div>
    </div>