<?php include "./data/connect.php";
	$uid = $_GET['id'];
	//
$memid =  $_SESSION['intern_data_cun'];
$memtype = $_SESSION['intern_data_utype'];
$logun = $memid;
$logutype = $memtype;
	//
	//
	$cursy = trim($_SESSION['intern_data_active_sy']);
	//
	if ( trim($uid)!="" && ( ( strtolower(trim($memtype))==strtolower(trim("admin")) ) || ( strtolower(trim($uid))==strtolower(trim($memid)) && strtolower(trim($memtype))==strtolower(trim("student")) ) ) ) {
		$target_dir = "uploads/";
		$foname = basename($_FILES["fileUP"]["name"]);
		$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
		$target_file = $target_dir . $foname;
		$target_file2 = "";
		$uploadOk = 1;
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		// Check if image file is a actual image or fake image
		if(isset($_POST["btnProfilePhotoChange"])) {
		    // Check file size
			if ($_FILES["fileUP"]["size"] > 500000) {
			    //echo "Sorry, your file is too large.";
			    //$uploadOk = 0;
			}
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" && $imageFileType != "bmp" && $imageFileType != "ico"
			 ) {
			    $uploadOk = 0;
			}
			if ($uploadOk == 0) {
			    //echo "Sorry, your file was not uploaded.";
			} else {
				//GET NEW NAME
				$fln = "file_".$date_month."_".$date_day."_".$date_year."__".$date_hour."_".$date_minute."_".$date_second.".".$imageFileType;
			    $target_file2 = $target_dir . "$fln";
			    if (move_uploaded_file($_FILES["fileUP"]["tmp_name"], $target_file2)) {
			        //echo "The file ". basename( $_FILES["fileUP"]["name"]). " has been uploaded.";
			        //UPDATE TO USER
			        $sql = " update tbl_interns set prof_img='$target_file2'  where studentid='$uid' ";
					$qry = mysqli_query($conn,$sql);
					//SAVE TO UPLOADED FILES
			        $sql = " insert into tbl_upfiles
			        			 (name,location,date_uploaded)
			        		 values
			        		 	 ('$foname','$target_file2','$cdate') ";
					$qry = mysqli_query($conn,$sql);
			    } else {
			        //echo "Sorry, there was an error uploading your file.";
			    }
			}
		}
		if(isset($_POST["btnProfileCoverPhotoChange"])) {
		    // Check file size
			if ($_FILES["fileUP"]["size"] > 500000) {
			    //echo "Sorry, your file is too large.";
			    //$uploadOk = 0;
			}
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" && $imageFileType != "bmp" && $imageFileType != "ico" ) {
			    $uploadOk = 0;
			}
			if ($uploadOk == 0) {
			    //echo "Sorry, your file was not uploaded.";
			} else {
				//GET NEW NAME
				$fln = "file_".$date_month."_".$date_day."_".$date_year."__".$date_hour."_".$date_minute."_".$date_second.".".$imageFileType;
			    $target_file2 = $target_dir . "$fln";
			    if (move_uploaded_file($_FILES["fileUP"]["tmp_name"], $target_file2)) {
			        //echo "The file ". basename( $_FILES["fileUP"]["name"]). " has been uploaded.";
			        //UPDATE TO USER
			        $sql = " update tbl_interns set prof_backimg='$target_file2'  where studentid='$uid' ";
					$qry = mysqli_query($conn,$sql);
					//SAVE TO UPLOADED FILES
			        $sql = " insert into tbl_upfiles
			        			 (name,location,date_uploaded)
			        		 values
			        		 	 ('$foname','$target_file2','$cdate') ";
					$qry = mysqli_query($conn,$sql);
			    } else {
			        //echo "Sorry, there was an error uploading your file.";
			    }
			}
		}
		//===========================================================================================================
		//REQUIREMENTS
		//===========================================================================================================
		if(isset($_POST["btnReqSave"])) {
			$errn = 0;
			$act = $_POST['action'];
			//echo "$act";
			$tsn = "";
			$tsn = "resume";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			$tsn = "appletter";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			$tsn = "moa";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			$tsn = "mou";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			$tsn = "certacc";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			//
			//
			$tsn = "wform";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			$tsn = "reclet";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			$tsn = "waiver";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			$tsn = "parcon";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			$tsn = "medcert";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			$tsn = "certapp";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			$tsn = "certcom";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			$tsn = "ojtimg";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			//
			//
			if ( $errn > 0 ) {
				// Check file size
				if ($_FILES["fileUP"]["size"] > 500000) {
				    //echo "Sorry, your file is too large.";
				    //$uploadOk = 0;
				}
				if( $imageFileType != "doc" && $imageFileType != "docx" && $imageFileType != "pdf" && 
					$imageFileType != "png" && $imageFileType != "jpg" && $imageFileType != "gif"  && 
					$imageFileType != "jpeg" && $imageFileType != "bmp" && $imageFileType != "ico" 
				  ) {
				    $uploadOk = 0;
				}
				if ($uploadOk == 0) {
				    //echo "Sorry, your file was not uploaded.";
				} else {
					//GET NEW NAME
					$fln = "file_".$date_month."_".$date_day."_".$date_year."__".$date_hour."_".$date_minute."_".$date_second.".".$imageFileType;
				    $target_file2 = $target_dir . "$fln";
				    if (move_uploaded_file($_FILES["fileUP"]["tmp_name"], $target_file2)) {
				        //echo "The file ". basename( $_FILES["fileUP"]["name"]). " has been uploaded.";
				        $rtype = "";
				        $rname = "";
						$tsn = "resume";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "Resume";
							$rtype = "requirement:resume";
						}
						$tsn = "appletter";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "Application Letter";
							$rtype = "requirement:application_letter";
						}
						$tsn = "moa";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "MOA";
							$rtype = "requirement:moa";
						}
						$tsn = "mou";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "MOU";
							$rtype = "requirement:mou";
						}
						$tsn = "certacc";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "Certification of Acceptance";
							$rtype = "requirement:certification_of_acceptance";
						}
						//
						//
						$tsn = "wform";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "White Form";
							$rtype = "requirement:white_form";
						}
						$tsn = "reclet";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "Recommendation Letter";
							$rtype = "requirement:recommendation_letter";
						}
						$tsn = "waiver";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "Waiver";
							$rtype = "requirement:waiver";
						}
						$tsn = "parcon";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "Parent Consent";
							$rtype = "requirement:parent_consent";
						}
						$tsn = "medcert";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "Medical Certificate";
							$rtype = "requirement:medical_certificate";
						}
						$tsn = "certapp";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "Certificate of Appreciation";
							$rtype = "requirement:certificate_of_appreciation";
						}
						$tsn = "certcom";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "Certificate of Completion";
							$rtype = "requirement:certificate_of_completion";
						}
						$tsn = "ojtimg";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "OJT Photo";
							$rtype = "requirement:ojt_photo";
						}
						//
						//
				        //UPDATE TO USER
				        $sql = " insert into tbl_user_requirements 
				        			(name,req_type,req_file,date_added,studentid)
				        		values
				        			('$rname','$rtype','$target_file2','$cdate','$uid')
				         ";
						$qry = mysqli_query($conn,$sql);
						//SAVE TO UPLOADED FILES
				        $sql = " insert into tbl_upfiles
				        			 (name,location,date_uploaded,upby_id,upby_type,utype,uloc_id,uloc_type)
				        		 values
				        		 	 ('$foname','$target_file2','$cdate','$memid','$memtype','Requirement','$uid','student') ";
						$qry = mysqli_query($conn,$sql);
				    } else {
				        //echo "Sorry, there was an error uploading your file.";
				    }
				}
			}
		}
	}
	//

		//
		if ( $_POST['btnsaveSendMessage'] ) {
			//$rcv_id = $_POST['txtid'];
			//$rcv_type = $_POST['txttype'];
			$rcv_id = $_GET['id'];
			$rcv_type = "student";
			//
			$snd_id = $_SESSION['intern_data_cun'];
			$snd_type = $_SESSION['intern_data_utype'];
			//
			$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
			//
			$msg = $_POST['msg'];
			//
			$errmsg = "";
			$errn = 0;
			if ( trim($msg) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Enter a message. ";
			}
			if ( $errn <= 0 ) {
				//SAVE DATA
				if ( trim($rcv_id)!="" && trim($snd_id)!="" && ($msg)!="" ) {
					//
					//GET GRROUP ID, IF NONE CREATE AND GET
					$tgid = "";
					//
					//                    0       1     2    3    4     5     6      7
					$sql = " select msgs_group_id,mem1_id,mem1_type,mem2_id,mem2_type from tbl_messages_group where ( mem1_id='$rcv_id' and mem1_type='$rcv_type' and mem2_id='$snd_id' and mem2_type='$snd_type' ) or ( mem1_id='$snd_id' and mem1_type='$snd_type' and mem2_id='$rcv_id' and mem2_type='$rcv_type' ) ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						$tgid = trim($dat[0]);
					}
					//
					if ( trim($tgid)=="" ) {
						//CREATE
						$sql = " insert into tbl_messages_group
									( mem1_id,mem1_type,mem2_id,mem2_type )
								values
									( '$rcv_id','$rcv_type','$snd_id','$snd_type' )
						 ";
							$qry = mysqli_query($conn,$sql);
					}
					//GET
					//                    0       1     2    3    4     5     6      7
					$sql = " select msgs_group_id,mem1_id,mem1_type,mem2_id,mem2_type from tbl_messages_group where ( mem1_id='$rcv_id' and mem1_type='$rcv_type' and mem2_id='$snd_id' and mem2_type='$snd_type' ) or ( mem1_id='$snd_id' and mem1_type='$snd_type' and mem2_id='$rcv_id' and mem2_type='$rcv_type' ) ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						$tgid = trim($dat[0]);
					}
					//
					//
					//FOR SENDER
					$sql = "
							insert into tbl_messages
								(rcv_id,rcv_type,snd_id,snd_type,message,date_sent,own_id,own_type,msgs_group_id) 
							values 
								('$rcv_id','$rcv_type','$snd_id','$snd_type','$msg','$cdate','$snd_id','$snd_type','$tgid') 
							";
					$qry = mysqli_query($conn,$sql);
					//FOR RECEIVER
					$sql = "
							insert into tbl_messages
								(rcv_id,rcv_type,snd_id,snd_type,message,date_sent,own_id,own_type,msgs_group_id) 
							values 
								('$rcv_id','$rcv_type','$snd_id','$snd_type','$msg','$cdate','$rcv_id','$rcv_type','$tgid') 
							";
					$qry = mysqli_query($conn,$sql);
				}
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
			}
		}
	//
	if ( $_POST['btnsaveUpdateInfo'] ) {
		$studid = $_POST['studid'];
		$fname = $_POST['fname'];
		$mname = $_POST['mname'];
		$lname = $_POST['lname'];
		$gender = $_POST['gender'];
		$address = $_POST['address'];
		$course = $_POST['course'];
		$year = $_POST['year'];
		$contactno = $_POST['contactno'];
		$email = $_POST['email'];
		$nohrs = $_POST['nohrs'];
		$dstart = $_POST['dstart'];
		$dend = $_POST['dend'];
		$eval1 = "";
		$eval2 = "";
		$reqstats = "";
		$regstats = "";
		$errn = 0;
		$errmsg = "";
		if ( trim($studid)=="" ){
			//$errn = $errn + 1;
			//$errmsg = $errmsg . "Please enter Student ID. ";
		}
		$sql = " select * from tbl_interns where studentid='$studid' ";
		$qry = mysqli_query($conn,$sql);
		$scn = 0;
		while($dat=mysqli_fetch_array($qry)) {
			//$scn = $scn + 1;
		}
		if ( $scn > 0 ) {
			//$errn = $errn + 1;
			//$errmsg = $errmsg . "Invalid Student ID. ";
		}
		if ( trim($fname)=="" ){
			$errn = $errn + 1;
			$errmsg = $errmsg . "Please enter Firstname. ";
		}
		if ( trim($lname)=="" ){
			$errn = $errn + 1;
			$errmsg = $errmsg . "Please enter Lastname. ";
		}
		$sql = " select * from tbl_interns where firstname='$fname' and lastname='$lname' ";
		$qry = mysqli_query($conn,$sql);
		$scn = 0;
		while($dat=mysqli_fetch_array($qry)) {
			//$scn = $scn + 1;
		}
		if ( $scn > 0 ) {
			//$errn = $errn + 1;
			//$errmsg = $errmsg . "Name already registered. ";
		}
		if ( trim($address)=="" ){
			//$errn = $errn + 1;
			//$errmsg = $errmsg . "Address required. ";
		}
		if ( trim($email)=="" ){
			//$errn = $errn + 1;
			//$errmsg = $errmsg . "Email required. ";
		}
		if ( trim($contactno)=="" ){
			//$errn = $errn + 1;
			//$errmsg = $errmsg . "Contact # required. ";
		}
		if ( $errn <= 0 ) {
			//SAVE
			$sql = " update tbl_interns set 
						firstname='$fname',middlename='$mname',lastname='$lname',address='$address',gender='$gender',course='$course',year='$year',contact_no='$contactno',email='$email',no_hours='$nohrs',date_start='$dstart',date_end='$dend'  
						where studentid='$studid' 
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
		}
	}
	//
	if ( $_POST['btnsaveUpdateInfoPassword'] ) {
		$studid = $_POST['studid'];
		//
		$npass1 = "";
		$npass2 = "";
		//
		$opass = $_POST['opass'];
		$npass1 = $_POST['npass1'];
		$npass2 = $_POST['npass2'];
		//
		$errn = 0;
		$errmsg = "";
		//
		if ( trim($npass1)=="" ){
			$errn = $errn + 1;
			$errmsg = $errmsg . "Password must not be empty. ";
		}
		if ( $npass1 != $npass2 ){
			$errn = $errn + 1;
			$errmsg = $errmsg . "New passwords don't match. ";
		}
		if ( strlen($npass1) < 4 ){
			$errn = $errn + 1;
			$errmsg = $errmsg . "Password must be greater than or equal to 4 characters. ";
		}
		$sql = " select password from tbl_interns where studentid='$studid' ";
		$qry = mysqli_query($conn,$sql);
		$scn = 0;
		while($dat=mysqli_fetch_array($qry)) {
			if ( $dat[0]==$opass ) {
				$scn += 1;
			}
		}
		if ( $scn <= 0 ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Invalid current password. ";
		}
		//
		if ( $errn <= 0 ) {
			//SAVE
			$sql = " update tbl_interns set 
						password='$npass1'  
						where studentid='$studid' 
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
				echo "
					<script>
						alert('Password successfully changed');
					</script>
				";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
		}
	}
	//
//========= EVAL ===========================================================================
		if ( $_POST['btnAddInternEval'] ) {
			//
			//
			if ( trim($uid)!="" && trim($memid)!="" ) {
				//
				//
				$sy = $cursy;
				//
				$errmsg = "";
				$errn = 0;
				//
				//
				$major = $_POST['major'];
				$sem = $_POST['semester'];
				//$sy = $_POST['sy'];
				$dept = $_POST['dept'];
				//
				$dept_id="";
				$dept_n="";
				$crs_id = "";
				$crs = "";
				$college = "UMDC";
				//GET STUDENT INFO
				//                 0           1       2         3        4
				$sql = " select studentid,firstname,middlename,lastname,course from tbl_interns  where  studentid='$uid' ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					$crs_id = trim($dat[4]);
				}
				//
				//GET CRS NAME
				//                 0         1      
				$sql = " select course_id,course from tbl_course  where  course_id='$crs_id' ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					$crs = trim($dat[4]);
				}
				//
						//GET DEPT
						$sql = " select department_id from tbl_department_courses where course_id='$crs_id' ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							$dept_id = $dat[0];
						}
						//GET DEPT NAME
						$sql = " select department_id,department from tbl_department where department_id='$dept_id' ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							$dept_n = $dat[1];
						}
				//
				//
				$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
				//
				//
				$comp1 = trim( htmlspecialchars( $_POST['comp1'] , ENT_QUOTES ) );
				$comp1hrs = trim( $_POST['comp1hrs'] );
				$comp1rate = trim( $_POST['comp1rate'] );
				//
				$comp2 = trim( htmlspecialchars( $_POST['comp2'] , ENT_QUOTES ) );
				$comp2hrs = trim( $_POST['comp2hrs'] );
				$comp2rate = trim( $_POST['comp2rate'] );
				//
				$comp3 = trim( htmlspecialchars( $_POST['comp3'] , ENT_QUOTES ) );
				$comp3hrs = trim( $_POST['comp3hrs'] );
				$comp3rate = trim( $_POST['comp3rate'] );
				//
				$comp4 = trim( htmlspecialchars( $_POST['comp4'] , ENT_QUOTES ) );
				$comp4hrs = trim( $_POST['comp4hrs'] );
				$comp4rate = trim( $_POST['comp4rate'] );
				//
				$comp5 = trim( htmlspecialchars( $_POST['comp5'] , ENT_QUOTES ) );
				$comp5hrs = trim( $_POST['comp5hrs'] );
				$comp5rate = trim( $_POST['comp5rate'] );
				//
				$comp6 = trim( htmlspecialchars( $_POST['comp6'] , ENT_QUOTES ) );
				$comp6hrs = trim( $_POST['comp6hrs'] );
				$comp6rate = trim( $_POST['comp6rate'] );
				//
				$comp7 = trim( htmlspecialchars( $_POST['comp7'] , ENT_QUOTES ) );
				$comp7hrs = trim( $_POST['comp7hrs'] );
				$comp7rate = trim( $_POST['comp7rate'] );
				//
				$tcomp =  array(
						array($comp1,$comp1hrs,$comp1rate),
						array($comp2,$comp2hrs,$comp2rate),
						array($comp3,$comp3hrs,$comp3rate),
						array($comp4,$comp4hrs,$comp4rate),
						array($comp5,$comp5hrs,$comp5rate),
						array($comp6,$comp6hrs,$comp6rate),
						array($comp7,$comp7hrs,$comp7rate)
					);
				//
				//
				$errmsg = "";
				$errn = 0;
				//
				if ( trim($sem) == "" ) {
					//$errn = $errn + 1;
					//$errmsg = $errmsg . "Semester required. ";
				}
				if ( trim($sy) == "" ) {
					//$errn = $errn + 1;
					//$errmsg = $errmsg . "School Year required. ";
				}
				if ( trim($sem) == "" ) {
					//$errn = $errn + 1;
					//$errmsg = $errmsg . "Semester required. ";
				}
				//
				if ( 
					trim($comp1) == "" &&
					trim($comp2) == "" &&
					trim($comp3) == "" &&
					trim($comp4) == "" &&
					trim($comp5) == "" &&
					trim($comp6) == "" &&
					trim($comp7) == ""
					) {
					$errn = $errn + 1;
					$errmsg = $errmsg . "You must have at least 1 Program Competences. ";
				}
				//
				//
				//
				//
				$comment = trim( htmlspecialchars( $_POST['comments'] , ENT_QUOTES ) );
				//
				$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
				//
				//$sy = "2016-2017";
				//
				$sup_id = "";
				$coord_id = "";
				//
				$crit1 = trim( $_POST['crit1'] );
				$crit2 = trim( $_POST['crit2'] );
				$crit3 = trim( $_POST['crit3'] );
				$crit4 = trim( $_POST['crit4'] );
				$crit5 = trim( $_POST['crit5'] );
				//
				$crit2_1 = trim( $_POST['crit2_1'] );
				$crit2_2 = trim( $_POST['crit2_2'] );
				$crit2_3 = trim( $_POST['crit2_3'] );
				$crit2_4 = trim( $_POST['crit2_4'] );
				//
				//
				//$errmsg = "";
				//$errn = 0;
				//
				//
				//
				if ( $errn <= 0 ) {
					//SAVE DATA
					$sql = "
							insert into tbl_interns_eval2_group 
								(studentid,college,course,major,semester,sy,department,eval_date,evaluator_id,evaluator_type,comments,supervisor_id,coordinator_id) 
							values 
								('$uid','$college','$crs_id','$major','$sem','$sy','$dept_id','$cdate','$logun','$logutype','$comment','$sup_id','$coord_id') 
							";
					$qry = mysqli_query($conn,$sql);
					//
					//GET CURRENT EVAL ID
					$cur_eid = "";
					//                 0        
					$sql = " select interns_eval_group_id from tbl_interns_eval2_group  where  studentid='$uid' and eval_date='$cdate' and sy='$sy' and evaluator_id='$logun' and evaluator_type='$logutype' ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						$cur_eid = trim($dat[0]);
					}
					//
					//SAVE PROGRAM COMPETENCES
					if ( trim($cur_eid)!="" ) {
						for ( $i = 0 ; $i < count($tcomp) ; $i++ ) {
							if ( trim($tcomp[$i][0])!="" ) {
								$sql = "
										insert into tbl_interns_eval2_2 
											(interns_eval_group_id,prog_comp,num_hours,eval_rate,sy,studentid) 
										values 
											('".$cur_eid."','".$tcomp[$i][0]."','".$tcomp[$i][1]."','".$tcomp[$i][2]."','$sy','$uid') 
										";
								$qry = mysqli_query($conn,$sql);
							}
						}
					}
					//SAVE DATA
					//
					$sql = "
							insert into tbl_interns_eval2 
								(interns_eval_group_id,studentid,evaluator_id,evaluator_type,eval_date,professionalism,job_maturity,comm_skills,productivity,leadership,excellence,honesty_integrity,innovation,teamwork,sy,comments,supervisor_id,coordinator_id,course_id,department_id) 
							values 
								('$cur_eid','$uid','$logun','$logutype','$cdate','$crit1','$crit2','$crit3','$crit4','$crit5','$crit2_1','$crit2_2','$crit2_3','$crit2_4','$sy','$comment','$sup_id','$coord_id','$crs_id','$dept_id') 
							";
					$qry = mysqli_query($conn,$sql);
					//
					//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
					//
				}else{
					//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
					echo "
						<script>
							alert('$errmsg');
						</script>
					";
				}
			}
		}
//========= EVAL ===========================================================================
//========= EVAL CRITERIA ===========================================================================
		if ( $_POST['btnAddEvalCriteria'] ) {
			//
			//
			if ( trim($uid)!="" && trim($memid)!="" ) {
				//
				$sy = $cursy;
				//
				//
				//
				$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
				//
				//
				$comp1 = trim( htmlspecialchars( $_POST['comp1'] , ENT_QUOTES ) );
				//
				$comp2 = trim( htmlspecialchars( $_POST['comp2'] , ENT_QUOTES ) );
				//
				$comp3 = trim( htmlspecialchars( $_POST['comp3'] , ENT_QUOTES ) );
				//
				$comp4 = trim( htmlspecialchars( $_POST['comp4'] , ENT_QUOTES ) );
				//
				$comp5 = trim( htmlspecialchars( $_POST['comp5'] , ENT_QUOTES ) );
				//
				$comp6 = trim( htmlspecialchars( $_POST['comp6'] , ENT_QUOTES ) );
				//
				$comp7 = trim( htmlspecialchars( $_POST['comp7'] , ENT_QUOTES ) );
				//
				$tcomp =  array($comp1,$comp2,$comp3,$comp4,$comp5,$comp6,$comp7
					);
				//
				//
				$errmsg = "";
				$errn = 0;
				//
				//
				if ( 
					trim($comp1) == "" &&
					trim($comp2) == "" &&
					trim($comp3) == "" &&
					trim($comp4) == "" &&
					trim($comp5) == "" &&
					trim($comp6) == "" &&
					trim($comp7) == ""
					) {
					$errn = $errn + 1;
					$errmsg = $errmsg . "You must have at least 1 Criteria. ";
				}
				//
				//
				if ( $errn <= 0 ) {
					//REMOVE ADDED CRITERIA THIS SY
					$sql = "
							delete from  tbl_interns_eval_criteria 
								where  studentid='$uid' and  sy='$sy'
							";
					$qry = mysqli_query($conn,$sql);
					//
					//SAVE DATA
					//
						for ( $i = 0 ; $i < count($tcomp) ; $i++ ) {
							if ( trim($tcomp[$i])!="" ) {
								$sql = "
										insert into tbl_interns_eval_criteria 
											(name,sy,adate,studentid) 
										values 
											('".$tcomp[$i]."','$sy','$cdate','$uid') 
										";
								$qry = mysqli_query($conn,$sql);
							}
						}
					//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
					//
					echo "
						<script>
							alert('Criteria saved.');
						</script>
					";
				}else{
					//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
					echo "
						<script>
							alert('$errmsg');
						</script>
					";
				}
			}
		}
//========= EVAL CRITERIA ===========================================================================
	//MSGS LOG UPDATER
	include "./parts/msgs_logupdater.php";
?>