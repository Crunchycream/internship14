<script>$(".messages_cs01").animate({ scrollTop: $(document).height() }, "fast");

$("#profile-img_cs01").click(function() {
	$("#status-options_cs01").toggleClass("active");
});

$(".expand-button_cs01").click(function() {
  $("#profile_cs01").toggleClass("expanded_cs01");
	$("#contacts_cs01").toggleClass("expanded_cs01");
});

$("#status-options_cs01 ul li").click(function() {
	$("#profile-img_cs01").removeClass();
	$("#status-online_cs01").removeClass("active");
	$("#status-away_cs01").removeClass("active");
	$("#status-busy_cs01").removeClass("active");
	$("#status-offline_cs01").removeClass("active");
	$(this).addClass("active");
	
	if($("#status-online_cs01").hasClass("active")) {
		$("#profile-img_cs01").addClass("online");
	} else if ($("#status-away_cs01").hasClass("active")) {
		$("#profile-img_cs01").addClass("away");
	} else if ($("#status-busy_cs01").hasClass("active")) {
		$("#profile-img_cs01").addClass("busy");
	} else if ($("#status-offline_cs01").hasClass("active")) {
		$("#profile-img_cs01").addClass("offline");
	} else {
		$("#profile-img_cs01").removeClass();
	};
	
	$("#status-options_cs01").removeClass("active");
});

function newMessage() {
	message = $(".message-input_cs01 input").val();
	if($.trim(message) == '') {
		return false;
	}
	$('<li class="sent"><img src="./assets/img/user3.png" alt="" /><p>' + message + '</p></li>').appendTo($('.messages_cs01 ul'));
	$('.message-input_cs01 input').val(null);
	$('.contact_cs01.active .preview_cs01').html('<span>You: </span>' + message);
	$(".messages_cs01").animate({ scrollTop: $(document).height() }, "fast");
};

$('.submit').click(function() {
  //newMessage();
});

$(window).on('keydown', function(e) {
  if (e.which == 13) {
    //newMessage();
    return false;
  }
});
//# sourceURL=pen.js
</script>