<?php include "./data/connect.php";
	function calcDTime($id,$csy) {
			//
			include "./data/connect.php";
			//GET USER INFO
			//
			//OVER ALL
			$ovtothrs = 0;
			$ovremhrs = 0;
			//
			$uthrs = 0;
			$utatthrs = 0;
			$utattmin = 0;
			//
			$sql = " select no_hours from tbl_interns  where studentid='$id' ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				$uthrs = strval(trim($dat[0]));
			}
			//GET USER TOTAL HRS USING ATTENDANCE
			//
			$tmp_date1 = "";
			$tmp_mae1 = "";
			$tmp_atype1 = "IN";
			$tmp_hr1 = "0";
			$tmp_min1 = "0";
			//
			$tmp_date2 = "";
			$tmp_mae2 = "";
			$tmp_atype2 = "OUT";
			$tmp_hr2 = "0";
			$tmp_min2 = "0";
			//
			$ccy = "";
			$ccm = "";
			$ccd = "";
			//
			$tty = "";
			$ttm = "";
			$ttd = "";
			//
			$clog = "";
			//                   0            1       2   3       4        5       6        7       8      9      10
			$sql = " select interns_dtr_id,studentid,sy,att_mae,att_type,dt_year,dt_month,dt_day,dt_hour,dt_min,dt_sec from tbl_interns_dtr  where studentid='$id' and sy='$csy' ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				//
				//
				$tmae = trim($dat[3]);
				$tat = trim($dat[4]);
				//
				$tdate = trim($dat[5])."-".trim($dat[6])."-".trim($dat[7])."T".trim($dat[8]).":".trim($dat[9]).":".trim($dat[10]);
				//
				//
				$nen = 0;
				//
				$tty = trim($dat[5]);
				$ttm = trim($dat[6]);
				$ttd = trim($dat[7]);
				//
				if ( (trim($ccy)=="" || trim($ccm)=="" || trim($ccd)=="") || 
					( strtolower(trim($ccy))!=strtolower(trim($tty)) || strtolower(trim($ccm))!=strtolower(trim($ttm)) || strtolower(trim($ccd))!=strtolower(trim($ttd)) )
				) {
					//
					$ccy = $tty;
					$ccm = $ttm;
					$ccd = $ttd;
					//
					$nen += 1;
					//
				}
				//
				if ( $nen > 0 ) {
					//CLEAR
					$tmp_date1 = "";
					$tmp_mae1 = "";
					$tmp_hr1 = "0";
					$tmp_min1 = "0";
					//
					$tmp_date2 = "";
					$tmp_mae2 = "";
					$tmp_hr2 = "0";
					$tmp_min2 = "0";
					//
				}
				//$clog = $clog . $tdate . $tmae . $tat;
				//
				if ( 
						(strtolower(trim($tmp_atype1))==strtolower(trim($tat))) && 
						(trim($tmp_date1)=="" || strtolower(trim($tmp_date1))!=strtolower(trim($tdate))) && 
						(trim($tmp_mae1)=="" || strtolower(trim($tmp_mae1))!=strtolower(trim($tmae)))
					) {
					$tmp_date1 = $tdate;
					$tmp_mae1 = $tmae;
					$tmp_hr1 = trim($dat[8]);
					$tmp_min1 = trim($dat[9]);
				}
				//
				if ( 
						(strtolower(trim($tmp_atype2))==strtolower(trim($tat))) && 
						(trim($tmp_date2)=="" || strtolower(trim($tmp_date2))!=strtolower(trim($tdate))) && 
						(trim($tmp_mae2)=="" || strtolower(trim($tmp_mae2))!=strtolower(trim($tmae)))
					) {
					$tmp_date2 = $tdate;
					$tmp_mae2 = $tmae;
					$tmp_hr2 = trim($dat[8]);
					$tmp_min2 = trim($dat[9]);
				}
				//
				if ( trim($tmp_date1)!="" && trim($tmp_date2)!="" ) {
					$date1 = new DateTime(trim($tmp_date1));
					$date2 = new DateTime(trim($tmp_date2));
					//
					$diff = $date2->diff($date1);
					//
					$utatthrs = $diff->h;
					$utatthrs = $utatthrs + ($diff->days*24);
					//
					$diff2 = $date2->diff($date1);
					//
					$utattmin = $diff2->i;
					$utattmin = $utattmin + ($diff2->minutes*60);
					//
					//CLEAR
					$tmp_date1 = "";
					$tmp_mae1 = "";
					$tmp_hr1 = "0";
					$tmp_min1 = "0";
					//
					$tmp_date2 = "";
					$tmp_mae2 = "";
					$tmp_hr2 = "0";
					$tmp_min2 = "0";
					//
					//$clog = $clog . $utatthrs . "==" . $utattmin;
				//
				$tv = strval($utatthrs . "." . $utattmin);
				//
				$ovtothrs = $ovtothrs + strval($tv);
				}
			}
			//
			//$fcuhrs = $utatthrs . "." . $utattmin;
			$fcuhrs = $ovtothrs;
			//
			//echo "$fcuhrs";
			//
			$tremhrs = strval(trim($uthrs)) - strval(trim($fcuhrs));
			if ( $tremhrs < 0 ) {
				$tremhrs = 0;
			}
			//UPDATE USER TOTAL HOURS
				$sql = "
						update tbl_interns_totalhrs set 
							total_hrs='$uthrs',used_hrs='$fcuhrs',rem_hrs='$tremhrs'  
								where studentid='$id' and sy='$csy' 
						";
				$qry = mysqli_query($conn,$sql);
			//
	}
?>