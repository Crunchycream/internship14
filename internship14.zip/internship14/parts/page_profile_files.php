		<div class="row" align="center">
			<div class="col-md-12">
				<div class="panel">
					<!-- TABBED CONTENT -->
					<div class="custom-tabs-line tabs-line-bottom left-aligned">
						<ul class="nav" role="tablist">
							<li class="active"><a href="#tab-bottom-stats" role="tab" data-toggle="tab">Statistics</a></li>
							<li class=""><a href="#tab-bottom-info" role="tab" data-toggle="tab">Info</a></li>
							<li class=""><a href="#tab-bottom-reflections" role="tab" data-toggle="tab">Reflections</a></li>
							<li class=""><a href="#tab-bottom-others" role="tab" data-toggle="tab">Others</a></li>
						</ul>
					</div>
					<div class="tab-content">
						<div class="tab-pane fade in" id="tab-bottom-info">
							<div class="profile-pdf">

								<?php include "./data/connect.php";
									$sid = $_GET['id'];
									$req_resume = "";
									$fd = "";
									$tsn = "requirement:resume";
									$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										if ( trim($dat[4]) != "" ){
											$req_resume = trim($dat[4]);
										}
									}
									if ( trim($req_resume)!="" && pathinfo($req_resume,PATHINFO_EXTENSION)=="pdf" ) {
										$fd = "
											<iframe src='$req_resume' width='100%' height='90%'>
											This browser does not support PDFs. Please download the PDF to view it: <a href='assets/pdf/resume.pdf'>Download PDF</a>
											</iframe>
										";
									}
									if ( trim($req_resume)!="" ) {
										if ( pathinfo($req_resume,PATHINFO_EXTENSION)=="jpg" ||
											 pathinfo($req_resume,PATHINFO_EXTENSION)=="jpeg" ||
											 pathinfo($req_resume,PATHINFO_EXTENSION)=="png" ||
											 pathinfo($req_resume,PATHINFO_EXTENSION)=="gif" ||
											 pathinfo($req_resume,PATHINFO_EXTENSION)=="bmp"
										 ) {
											$fd = "
												<img class='page_prof_img01' src='$req_resume' />
											";
										}
									}
									echo "$fd";
								?>

								
							</div>
						</div>

						<div class="tab-pane fade" id="tab-bottom-others">
							
						</div>

						<div class="tab-pane fade in active" id="tab-bottom-stats">
							<div class="table-responsive" align="center">
								<div id="stat-bar-chart" class="ct-chart chart_01"></div>
							</div>
						</div>

						<div class="tab-pane fade" id="tab-bottom-reflections">
							<a id="areflection"></a>
								


								<div class="table-responsive">
								
									<table class="table table-hover results">
										<thead>
											<tr>
												<th></th>
												<th>Submitted By</th>
												<th>Submitted In</th>
												<th>File Name</th>
												<th>Location</th>
												<th>Date Submitted</th>
												<th>Submitted As</th>
												<th>Status</th>
											</tr>
											<tr class="warning no-result">
      											<td><i class="fa fa-warning"></i> No result</td>
   											</tr>
										</thead>
										<tbody id="myTable">
											<?php
												include "./data/connect.php";
												//
												$cid = trim($_GET['id']);
												//
												$ctype = trim($_GET['type']);
												if ( trim($ctype)=="" ) {
													$ctype = "reflection";
												}
												//
												$nn = "";
												//               0  1     2        3             4        5       6      7        8        9        10
												$sql = " select no,name,location,date_uploaded,upby_id,upby_type,utype,uloc_id,uloc_type,uloc2_id,ap_status from tbl_upfiles where utype='reflection' and upby_type='student' and upby_id='$cid'  order by date_uploaded desc  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													
													$lnk = "";
													//
													$nn = trim($dat[0]);
													//
													$name = "";
													$file = "";
													$fln = trim($dat[2]);
													if ( trim($fln)!="" ) {
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
															//IMAGE
															$file = "
																		<a class='' target='_blank' href='#' data-toggle='modal' data-target='#modalPrevImage_$nn'>$fln</a>
																		<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																			<img class='ann_img02' src='".trim($fln)."'/>
																		</div>
																	";
														}else{
															//NOT IMAGE
															$file = "<a target='_blank' href='".trim($fln)."'>".trim($fln)."</a>";
														}
													}
													//
													$locname = "";
													$loclink = "";
													//
													$apstat = trim($dat[10]);
													$tfstat = "";
														if ( trim($apstat)=="" ) {
															$tfstat = "<span class='label label-warning label-md'>Pending</span>";
														}else{
															if ( strtolower(trim($apstat))==strtolower(trim("approved")) ) {
																$tfstat = "<span class='label label-success label-md'>Approved</span>";
															}else{
																$tfstat = "<span class='label label-danger label-md'>Dis-Approved</span>";
															}
														}
													//
													$sql2 = "";
													//
													if ( trim($dat[5])!="" ) {
														if ( strtolower(trim($dat[5]))==strtolower(trim("coordinator")) ) {
															$lnk = "page_profile_employee.php";
															//
															$sql2 = " select firstname,middlename,lastname from tbl_employee where employee_id='$dat[4]'  ";
																$qry2 = mysqli_query($conn,$sql2);
																while($dat2=mysqli_fetch_array($qry2)) {
																	$name = trim($dat2[2]).", ".trim($dat2[0])." ".trim($dat2[1]);
																}
														}
														if ( strtolower(trim($dat[5]))==strtolower(trim("student")) ) {
															$lnk = "page_profile.php";
															//
															$sql2 = " select firstname,middlename,lastname from tbl_interns where studentid='$dat[4]'  ";
																$qry2 = mysqli_query($conn,$sql2);
																while($dat2=mysqli_fetch_array($qry2)) {
																	$name = trim($dat2[2]).", ".trim($dat2[0])." ".trim($dat2[1]);
																}														}
														if ( trim($dat[4])!="" ) {
															//GET NAME
														}
													}
													//
													if ( trim($dat[7])!="" ) {
														if ( strtolower(trim($dat[8]))==strtolower(trim("class")) ) {
															$loclink = "page_class.php";
															//
															$sql2 = " select class_id,name from tbl_class where class_id='$dat[7]'  ";
																$qry2 = mysqli_query($conn,$sql2);
																while($dat2=mysqli_fetch_array($qry2)) {
																	$locname = trim($dat2[1]);
																}
														}
													}
													//
													//
													echo "
														<tr>
															<td>

																<div class='dropdown'>
																  <a class='btn_action_01' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu'>
																    <li>
																  		<form method='post' action=''>
																  			<input type='hidden' name='txtid' value='$dat[0]' />
																  			<input type='hidden' name='txtval' value='Approved' />
																    	<input type='submit' name='btnupdateAStat' class='btn_opt01' value='Approve' />
																    	</form>
																    </li>
																    <li class='divider'></li>
																    <li>
																  		<form method='post' action=''>
																  			<input type='hidden' name='txtid' value='$dat[0]' />
																  			<input type='hidden' name='txtval' value='Dis-Approved' />
																    	<input type='submit' name='btnupdateAStat' class='btn_opt01' value='Dis-Approve' />
																    	</form>
																    </li>
																  </ul>
																</div>

															</td>
															<td>
																<a href='".$lnk."?id=".trim($dat[4])."'>
																<span class='span02'>".trim($name)."</span>
																</a>
															</td>
															<td>
																<a href='".$loclink."?id=".trim($dat[7])."'>
																<span class='span02'>".trim($locname)."</span>
																</a>
															</td>
															<td>
																".trim($dat[1])."
															</td>
															<td>
																$file
															</td>
															<td>
																".trim($dat[3])."
															</td>
															<td>
																".trim($dat[6])."
															</td>
															<td>
																$tfstat
															</td>
														</tr>
													";
												}
											?>
											
											
										</tbody>
									</table>
								</div>
							

						</div>

					</div>
					<!-- END TABBED CONTENT -->
					
				</div>
			</div>
		</div>
