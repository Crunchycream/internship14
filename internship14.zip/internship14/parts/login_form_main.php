
							<div class="header">
								<div class="logo text-center"></div>
								<p class="lead">Login to your account</p>
							</div>
							<form class="form-auth-small" action="./login_check.php" method="post">
								<div class="form-group">
									<?php echo $_SESSION['intern_disp_err']; $_SESSION['intern_disp_err'] = ""; ?>
								</div>
								<div class="form-group">
									<label for="signin-email" class="control-label sr-only">Username</label>
									<input type="username" name="username" class="form-control" id="signin-email" placeholder="Username"
										<?php
											$value = $_POST['username'];
											//
											$lpage = $_SESSION['intern_page_lastpage'];
											//
											if (strtolower(trim($lpage))==strtolower(trim("login_check")) ) {
												$value = $_SESSION['intern_login_tempn'];
												//
												$_SESSION['intern_login_tempn'] = "";
												//$_SESSION['intern_login_templt'] = "";
												$_SESSION['intern_page_lastpage'] = "";
											}
											echo " value='$value' ";
										?>
									>
								</div>
								<div class="form-group">
									<label for="signin-password" class="control-label sr-only">Password</label>
									<input type="password" name="password" class="form-control" id="signin-password" value="" placeholder="Password">
								</div>
								
								<?php
									//
									$logt = $_SESSION['intern_login_templt'];
									//
									//
									$sf = 0;
									//
									$ckd = "";
									//
								if ( $sf != 0 ) {
									echo "

										<table width=''>
											<tr>
												<td>";
									//
									$ckd = "";
									//
									if ( trim($logt)=="" || strtolower(trim($logt))==strtolower(trim("student")) ) {
										$ckd = "checked";
									}
									//
									echo "
													<div class='leftspace_01'>
													<label class='fancy-radio disp_inline01'>
														<input name='logtype' value='student' type='radio' $ckd>
														<span><i></i><b>Student</b></span>
													</label>
													</div>";
									echo "
												</td>
												<td>";
									//
									$ckd = "";
									//
									if ( strtolower(trim($logt))==strtolower(trim("staff")) || strtolower(trim($logt))==strtolower(trim("employee")) ) {
										$ckd = "checked";
									}
									//echo "$logt";
									//
									echo "
													<div class='leftspace_01'>
													<label class='fancy-radio disp_inline01'>
														<input name='logtype' value='staff' type='radio' $ckd>
														<span><i></i><b>Staff</b></span>
													</label>
													</div>";
									echo "
												</td>
											</tr>
										</table>

									";
								}
								?>

								<input type="submit" name="btnlogin" class="btn btn-primary btn-lg btn-block" value="LOGIN">
								
								<div class="bottom">
									<span class="helper-text"><i class="fa fa-lock"></i> <input type="submit" name="btnloginlostpass" class="btn_lostpass01" value="Forgot password?"></span>
								</div>

								

							</form>