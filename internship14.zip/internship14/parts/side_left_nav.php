<nav>
<ul class="nav">
	<?php  include "./data/connect.php";
		$logun = $_SESSION['intern_data_cun'];
		$logutype = $_SESSION['intern_data_utype'];
		/////
		$cpage=$_SESSION['intern_page_current'];
		$cpage2=$_SESSION['intern_page_current2'];
		$cpage3=$_GET['type'];
		$tsn = "";
		$cls = "";
		$cls2 = "";
		//
		//
if ( strtolower(trim($logun))!=strtolower(trim("admin")) ) {
		echo "<li>";
			$tsn = "cpanel";
			$cls = "class=''";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "class='active'";
			}
		echo "<a href='cpanel.php' $cls ><i class='lnr lnr-home'></i> <span>Dashboard</span></a>";
		echo "</li>";
}
//======= JOB POSTS ====================================================================
if ( strtolower(trim($logun))!="" && strtolower(trim($logun))!=strtolower(trim("admin")) ) {
		echo "<li>";
			$tsn = "page_jobposts";
			$cls = "class=''";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "class='active'";
			}
			//
				$count = 0;
				//
				//GET  COUNT
				$sql2 = " select * from tbl_jobpost   ";
				$qry2 = mysqli_query($conn,$sql2);
				while($dat2=mysqli_fetch_array($qry2)) {
					$count = $count + 1;
				}
			//
		echo "<a href='./page_jobposts.php' $cls ><i class='lnr lnr-bookmark'></i> <span>Jobs</span> <span class='badge'>$count</span></a>";
		echo "</li>";
}
//======= JOB POSTS ====================================================================
//======= Announcement ====================================================================
if ( strtolower(trim($logun))!="" && strtolower(trim($logutype))!="" && strtolower(trim($logun))!=strtolower(trim("admin")) ) {
		echo "<li>";
			$cls = "collapsed";
			$cls2 = "collapse";
			if ( strtolower(trim($cpage))==strtolower(trim("page_announcement")) 
				) {
				$cls = "active";
				$cls2 = "collapse in";
			}
		echo "<a href='#subPagesAnnouncement' data-toggle='collapse' class='$cls'><i class='lnr lnr-bookmark'></i> <span>Announcement</span> <i class='icon-submenu lnr lnr-chevron-left'></i></a>";
		echo "<div id='subPagesAnnouncement' class='$cls2 '>";
		echo "	<ul class='nav'>";
			$sq1 = "";
			$sq2 = "";
			//GET 
			if ( strtolower(trim($logutype))!=strtolower(trim("admin")) ) {
				$sql1 = " select course from tbl_interns  where studentid='$logun' ";
				$qry1 = mysqli_query($conn,$sql1);
				while($dat1=mysqli_fetch_array($qry1)) {
					if ( trim($dat1[0]) != "" ) {
						if ( trim($sq1)=="" ) {
							$sq1 = " where course_id='".trim($dat1[0])."' ";
						}else{
							$sq1 = $sq1 . " || course_id='".trim($dat1[0])."' ";
						}
					}
				}
			}
			if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
				$sql1 = " select course from tbl_interns  group by course ";
				$qry1 = mysqli_query($conn,$sql1);
				while($dat1=mysqli_fetch_array($qry1)) {
					if ( trim($dat1[0]) != "" ) {
						if ( trim($sq1)=="" ) {
							$sq1 = " where course_id='".trim($dat1[0])."' ";
						}else{
							$sq1 = $sq1 . " || course_id='".trim($dat1[0])."' ";
						}
					}
				}
			}
			if ( strtolower(trim($logutype))==strtolower(trim("employee")) ) {
				$sql1 = " select crs_id from tbl_crs_staff  where staff_type='$logutype' and staff_id='$logun' ";
				$qry1 = mysqli_query($conn,$sql1);
				while($dat1=mysqli_fetch_array($qry1)) {
					if ( trim($dat1[0]) != "" ) {
						if ( trim($sq1)=="" ) {
							$sq1 = " where course_id='".trim($dat1[0])."' ";
						}else{
							$sq1 = $sq1 . " || course_id='".trim($dat1[0])."' ";
						}
					}
				}
			}
			//
			//
			if ( trim($sq1)!="" ) {
				//GET  DATA
				$sql1 = " select course_id,course from tbl_course  $sq1  order by course asc ";
				$qry1 = mysqli_query($conn,$sql1);
				while($dat1=mysqli_fetch_array($qry1)) {
					if ( trim($dat1[0]) != "" && trim($dat1[1]) != "" ) {
						$link = "./page_announcement.php?aid=".trim($dat1[0])."&atype=".trim("course");
						$name = trim($dat1[1]);
						//
						$tsn = "page_announcement_course_".trim($dat1[0]);
						$cls = "";
						if ( strtolower(trim($cpage))==strtolower(trim("page_announcement")) 
							) {
							if ( strtolower(trim($cpage2))==strtolower(trim($tsn)) ) {
								$cls = "active";
							}
						}
						//
						$count = 0;
						//
						//GET  COUNT
						$sql2 = " select* from tbl_announcement  where ann_id='$dat1[0]' and ann_type='course'  ";
						$qry2 = mysqli_query($conn,$sql2);
						while($dat2=mysqli_fetch_array($qry2)) {
							$count = $count + 1;
						}
						//
						echo "<li><a href='$link' class='$cls'><i class='lnr lnr-bookmark'></i> <span class='span02'>$name</span> <span class='badge'>$count</span></a></li>";
					}
				}
			}
			//
			//////
			//
			$sq1 = "";
			$sq2 = "";
			//GET 
			if ( strtolower(trim($logutype))!=strtolower(trim("admin")) ) {
				$sql1 = " select hte_id from tbl_hte_members  where member_id='$logun' ";
				$qry1 = mysqli_query($conn,$sql1);
				while($dat1=mysqli_fetch_array($qry1)) {
					if ( trim($dat1[0]) != "" ) {
						if ( trim($sq1)=="" ) {
							$sq1 = " where hte_id='".trim($dat1[0])."' ";
						}else{
							$sq1 = $sq1 . " || hte_id='".trim($dat1[0])."' ";
						}
					}
				}
			}
			//GET 
			if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
				$sql1 = " select hte_id from tbl_hte_members   ";
				$qry1 = mysqli_query($conn,$sql1);
				while($dat1=mysqli_fetch_array($qry1)) {
					if ( trim($dat1[0]) != "" ) {
						if ( trim($sq1)=="" ) {
							$sq1 = " where hte_id='".trim($dat1[0])."' ";
						}else{
							$sq1 = $sq1 . " || hte_id='".trim($dat1[0])."' ";
						}
					}
				}
			}
			if ( strtolower(trim($logutype))==strtolower(trim("employee")) ) {
				$sql1 = " select hte_id from tbl_hte_staff where staff_type='$logutype' and staff_id='$logun'   ";
				$qry1 = mysqli_query($conn,$sql1);
				while($dat1=mysqli_fetch_array($qry1)) {
					if ( trim($dat1[0]) != "" ) {
						if ( trim($sq1)=="" ) {
							$sq1 = " where hte_id='".trim($dat1[0])."' ";
						}else{
							$sq1 = $sq1 . " || hte_id='".trim($dat1[0])."' ";
						}
					}
				}
			}
			//
			//
			if ( trim($sq1)!="" ) {
				//GET  DATA
				$sql1 = " select hte_id,name from tbl_hte $sq1  order by name asc ";
				$qry1 = mysqli_query($conn,$sql1);
				while($dat1=mysqli_fetch_array($qry1)) {
					if ( trim($dat1[0]) != "" && trim($dat1[1]) != "" ) {
						$link = "./page_announcement.php?aid=".trim($dat1[0])."&atype=".trim("hte");
						$name = trim($dat1[1]);
						//
						$tsn = "page_announcement_hte_".trim($dat1[0]);
						$cls = "";
						if ( strtolower(trim($cpage))==strtolower(trim("page_announcement")) 
							) {
							if ( strtolower(trim($cpage2))==strtolower(trim($tsn)) ) {
								$cls = "active";
							}
						}
						//
						$count = 0;
						//
						//GET  COUNT
						$sql2 = " select* from tbl_announcement  where ann_id='$dat1[0]' and ann_type='hte'  ";
						$qry2 = mysqli_query($conn,$sql2);
						while($dat2=mysqli_fetch_array($qry2)) {
							$count = $count + 1;
						}
						//
						echo "<li><a href='$link' class='$cls'><i class='lnr lnr-bookmark'></i> <span class='span02'>$name</span> <span class='badge'>$count</span></a></li>";
					}
				}
			}
		echo "	</ul>";
		echo "</div>";
		echo "</li>";
}
//======= Announcement ====================================================================
		//EVALUATE
if ( strtolower(trim($logutype))==strtolower(trim("employee")) ) {
	//
	$dnn = 0;
	//
	//
	if ( strtoupper(trim($logutype))==strtoupper(trim("employee")) ) {
	//echo "$logun $logutype";
		$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff where staff_id='$logun' and staff_type='$logutype' and position='Supervisor' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			$dnn += 1;
		}
	}
	//
	//
	if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
		//$dnn += 1;
	}
	//
	if ( $dnn > 0 ) {
		echo "<li>";
			$tsn = "page_evaluate";
			$cls = "class=''";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "class='active'";
			}
		echo "<a href='./page_evaluate.php' $cls ><i class='lnr lnr-chart-bars'></i> <span>Evaluation</span></a>";
		echo "</li>";
	}
}
//=======  ====================================================================
if ( strtolower(trim($logutype))!=strtolower(trim("student")) && strtolower(trim($logun))!=strtolower(trim("admin")) ) {
	//
	$dnn = 0;
	//
	//
	if ( strtoupper(trim($logutype))==strtoupper(trim("employee")) ) {
	//echo "$logun $logutype";
		$sql = " select crs_staff_id,crs_id,staff_id,staff_type,position from tbl_crs_staff where staff_id='$logun' and staff_type='$logutype' and position='admin' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			//$dnn += 1;
		}
	}
	//
	//
	if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
		$dnn += 1;
	}
	//
	if ( $dnn > 0 ) {
		echo "<li>";
			$cls = "collapsed";
			$cls2 = "collapse";
			if ( strtolower(trim($cpage))==strtolower(trim("page_interns_list")) || strtolower(trim($cpage))==strtolower(trim("page_hte_list")) ) {
				$cls = "active";
				$cls2 = "collapse in";
			}
		echo "<a href='#subPages' data-toggle='collapse' class='$cls'><i class='lnr lnr-file-empty'></i> <span>Pages</span> <i class='icon-submenu lnr lnr-chevron-left'></i></a>";
		echo "<div id='subPages' class='$cls2'>";
		echo "	<ul class='nav'>";
			$tsn = "page_interns_list";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='./page_interns_list.php' class='$cls'><i class='lnr lnr-users'></i><span>Interns</span></a></li>";
			$tsn = "page_hte_list";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='./page_hte_list.php' class='$cls'><i class='lnr lnr-apartment'></i><span>HTE</span> </a></li>";
		echo "	</ul>";
		echo "</div>";
		echo "</li>";
	}
}
		///
if ( strtolower(trim($logutype))!=strtolower(trim("student")) ) {
		echo "<li>";
			$cls = "collapsed";
			$cls2 = "collapse";
			if ( strtolower(trim($cpage))==strtolower(trim("manage_interns")) || 
				 strtolower(trim($cpage))==strtolower(trim("manage_hte")) ||
				 strtolower(trim($cpage))==strtolower(trim("manage_department")) ||
				 strtolower(trim($cpage))==strtolower(trim("manage_department_courses")) ||
				 strtolower(trim($cpage))==strtolower(trim("manage_course")) ||
				 strtolower(trim($cpage))==strtolower(trim("manage_year")) ||
				 strtolower(trim($cpage))==strtolower(trim("manage_staff_position")) ||
				 strtolower(trim($cpage))==strtolower(trim("manage_employee")) ||
				 strtolower(trim($cpage))==strtolower(trim("manage_coordinator")) ||
				 strtolower(trim($cpage))==strtolower(trim("manage_staffs")) ||
				 strtolower(trim($cpage))==strtolower(trim("manage_class")) ||
				 strtolower(trim($cpage))==strtolower(trim("manage_rate_scores")) ||
				 strtolower(trim($cpage))==strtolower(trim("manage_evalinfo_hte")) ||
				 strtolower(trim($cpage))==strtolower(trim("manage_evalinfo_intern")) ||
				 strtolower(trim($cpage))==strtolower(trim("manage_major")) ||
				 strtolower(trim($cpage))==strtolower(trim("manage_semester")) ||
				 strtolower(trim($cpage))==strtolower(trim("manage_sy")) ||
				 strtolower(trim($cpage))==strtolower(trim("manage_attcode"))
				) {
				$cls = "active";
				$cls2 = "collapse in";
			}
		//
		if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
				$cls = "active";
				$cls2 = "collapse in";
		}
		//
		echo "<a href='#subPages1' data-toggle='collapse' class='$cls'><i class='lnr lnr-pencil'></i> <span>Manage</span> <i class='icon-submenu lnr lnr-chevron-left'></i></a>";
		echo "<div id='subPages1' class='$cls2 '>";
		echo "	<ul class='nav'>";
		//
	//
	$dnn = 0;
	//
	if ( strtolower(trim($logutype))!=strtolower(trim("student")) || strtolower(trim($logutype))==strtolower(trim("employee")) ) {
		//
		if ( strtoupper(trim($logutype))==strtoupper(trim("employee")) ) {
		//echo "$logun $logutype";
			$sql = " select crs_staff_id,crs_id,staff_id,staff_type,position from tbl_crs_staff where staff_id='$logun' and staff_type='$logutype' and position='admin' ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				$dnn += 1;
			}
		}
	}
	//
	if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
		$dnn += 1;
	}
	//
	if ( $dnn > 0 ) {
			$tsn = "manage_interns";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_interns.php' class='$cls'><i class='lnr lnr-users'></i><span>Interns</span></a></li>";
	}
	if ( strtolower(trim($logutype))!=strtolower(trim("employee")) ) {
			$tsn = "manage_hte";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_hte.php' class='$cls'><i class='lnr lnr-apartment'></i><span>HTE</span> </a></li>";
			$tsn = "manage_department";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_department.php' class='$cls'><i class='lnr lnr-pencil'></i><span>Department</span> </a></li>";
			$tsn = "manage_department_courses";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_department_courses.php' class='$cls'><i class='lnr lnr-pencil'></i><span>Department Courses</span> </a></li>";
			$tsn = "manage_course";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_course.php' class='$cls'><i class='lnr lnr-pencil'></i><span>Course</span> </a></li>";
			$tsn = "manage_year";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_year.php' class='$cls'><i class='lnr lnr-pencil'></i><span>Year</span> </a></li>";
			$tsn = "manage_staff_position";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_staff_position.php' class='$cls'><i class='lnr lnr-pencil'></i><span>Staff Position</span> </a></li>";
			$tsn = "manage_employee";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_employee.php' class='$cls'><i class='lnr lnr-pencil'></i><span>Staff Info</span> </a></li>";
			$tsn = "manage_coordinator";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		//echo "		<li><a href='manage_coordinator.php' class='$cls'><i class='lnr lnr-pencil'></i><span>Staffs</span> </a></li>";
////////////////////////////////////////////////
		//
			$xt = trim($_GET['type']);
		//
			$tsn = "manage_staffs";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) && strtolower(trim($xt))==strtolower(trim("hte")) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_staffs.php?type=hte' class='$cls'><i class='lnr lnr-pencil'></i><span>Staff: HTE Supervisor</span> </a></li>";
		//
			$tsn = "manage_staffs";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) && strtolower(trim($xt))==strtolower(trim("course")) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_staffs.php?type=course' class='$cls'><i class='lnr lnr-pencil'></i><span>Staff: Course Admin</span> </a></li>";
////////////////////////////////////////////////
			$tsn = "manage_class";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_class.php' class='$cls'><i class='lnr lnr-pencil'></i><span>Class</span> </a></li>";
			$tsn = "manage_rate_scores";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_rate_scores.php' class='$cls'><i class='lnr lnr-pencil'></i><span>Rate Scores</span> </a></li>";
			$tsn = "manage_evalinfo_hte";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_evalinfo.php?type=hte' class='$cls'><i class='lnr lnr-pencil'></i><span>HTE Evaluation Info</span> </a></li>";
			$tsn = "manage_evalinfo_intern";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_evalinfo.php?type=intern' class='$cls'><i class='lnr lnr-pencil'></i><span>Intern Evaluation Info</span> </a></li>";
			$tsn = "manage_major";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_major.php' class='$cls'><i class='lnr lnr-pencil'></i><span>Major</span> </a></li>";
			$tsn = "manage_semester";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_semester.php' class='$cls'><i class='lnr lnr-pencil'></i><span>Semester</span> </a></li>";
			$tsn = "manage_sy";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_sy.php' class='$cls'><i class='lnr lnr-pencil'></i><span>School Year</span> </a></li>";
	}
	if ( strtolower(trim($logutype))!=strtolower(trim("student")) || strtolower(trim($logutype))==strtolower(trim("employee")) ) {
			$tsn = "manage_attcode";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='manage_attcode.php' class='$cls'><i class='lnr lnr-pencil'></i><span>Attendance Code</span> </a></li>";
		//
	}
		echo "	</ul>";
		echo "</div>";
		echo "</li>";
}
//======= EVAL ====================================================================
		///
if ( strtolower(trim($logutype))=="zx" ) {
		echo "<li>";
			$cls = "collapsed";
			$cls2 = "collapse";
			if ( strtolower(trim($cpage))==strtolower(trim("evaluation_interns")) || 
				 strtolower(trim($cpage))==strtolower(trim("evaluation_hte"))
				) {
				$cls = "active";
				$cls2 = "collapse in";
			}
		echo "<a href='#subPages2' data-toggle='collapse' class='$cls'><i class='lnr lnr-chart-bars'></i> <span>Evaluation</span> <i class='icon-submenu lnr lnr-chevron-left'></i></a>";
		echo "<div id='subPages2' class='$cls2 '>";
		echo "	<ul class='nav'>";
			$tsn = "evaluation_interns";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='./evaluation_interns.php' class='$cls'><i class='lnr lnr-users'></i><span>Interns</span></a></li>";
			$tsn = "evaluation_hte";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='./evaluation_hte.php' class='$cls'><i class='lnr lnr-apartment'></i><span>HTE</span> </a></li>";
		echo "	</ul>";
		echo "</div>";
		echo "</li>";
}
//======= EVAL ====================================================================
//======= RANKING ====================================================================
		///
if ( strtolower(trim($logutype))!="student" && strtolower(trim($logun))!=strtolower(trim("admin")) ) {
		echo "<li>";
			$cls = "collapsed";
			$cls2 = "collapse";
			if ( strtolower(trim($cpage))==strtolower(trim("ranking")) 
				) {
				$cls = "active";
				$cls2 = "collapse in";
			}
		echo "<a href='#subPagesRanking' data-toggle='collapse' class='$cls'><i class='lnr lnr-chart-bars'></i> <span>Ranking</span> <i class='icon-submenu lnr lnr-chevron-left'></i></a>";
		echo "<div id='subPagesRanking' class='$cls2 '>";
		echo "	<ul class='nav'>";
		//
	//
	$dnn = 0;
	//
	//
	if ( strtoupper(trim($logutype))==strtoupper(trim("employee")) ) {
	//echo "$logun $logutype";
		$sql = " select crs_staff_id,crs_id,staff_id,staff_type,position from tbl_crs_staff where staff_id='$logun' and staff_type='$logutype' and position='admin' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			$dnn += 1;
		}
	}
	//
	//
	if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
		$dnn += 1;
	}
	//
	if ( $dnn > 0 ) {
			$tsn = "ranking_intern";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim("ranking")) && strtolower(trim($cpage2))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='./ranking.php?type=intern' class='$cls'><i class='lnr lnr-users'></i><span>Interns</span></a></li>";
	}
	//
			$tsn = "ranking_hte";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim("ranking")) && strtolower(trim($cpage2))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='./ranking.php?type=hte' class='$cls'><i class='lnr lnr-apartment'></i><span>HTE</span> </a></li>";
		echo "	</ul>";
		echo "</div>";
		echo "</li>";
}
//======= RANKING ====================================================================
//======= RECORDS ====================================================================
if ( strtolower(trim($logutype))!=strtolower(trim("student")) && strtolower(trim($logun))!=strtolower(trim("admin")) ) {
	//
	$dnn = 0;
	//
	//
	if ( strtoupper(trim($logutype))==strtoupper(trim("employee")) ) {
	//echo "$logun $logutype";
		$sql = " select crs_staff_id,crs_id,staff_id,staff_type,position from tbl_crs_staff where staff_id='$logun' and staff_type='$logutype' and position='admin' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			$dnn += 1;
		}
	}
	//
	//
	if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
		$dnn += 1;
	}
	//
	if ( $dnn > 0 ) {
		echo "<li>";
			$cls = "collapsed";
			$cls2 = "collapse";
			if ( strtolower(trim($cpage))==strtolower(trim("file_records")) ||
				 strtolower(trim($cpage))==strtolower(trim("user_activity")) ||
				 strtolower(trim($cpage))==strtolower(trim("class_files")) ||
				 strtolower(trim($cpage))==strtolower(trim("page_subacts"))
				) {
				$cls = "active";
				$cls2 = "collapse in";
			}
		echo "<a href='#subPagesRecords' data-toggle='collapse' class='$cls'><i class='lnr lnr-chart-bars'></i> <span>Records</span> <i class='icon-submenu lnr lnr-chevron-left'></i></a>";
		echo "<div id='subPagesRecords' class='$cls2 '>";
		echo "	<ul class='nav'>";
			$tsn = "class_files";
			$tsn2 = "reflection";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) && strtolower(trim($cpage3))==strtolower(trim($tsn2)) ) {
				$cls = "active";
			}
		echo "		<li><a href='./class_files.php?type=reflection' class='$cls'><i class='lnr lnr-chart-bars'></i><span>Submitted Reflections</span> </a></li>";
			$tsn = "class_files";
			$tsn2 = "requirement";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) && strtolower(trim($cpage3))==strtolower(trim($tsn2)) ) {
				$cls = "active";
			}
		echo "		<li><a href='./class_files.php?type=requirement' class='$cls'><i class='lnr lnr-chart-bars'></i><span>Submitted Requirements</span> </a></li>";
			$tsn = "page_subacts";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='./page_subacts.php' class='$cls'><i class='lnr lnr-chart-bars'></i><span>Activity Tracking</span> </a></li>";
			$tsn = "file_records";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='./file_records.php' class='$cls'><i class='lnr lnr-chart-bars'></i><span>Uploaded Files</span> </a></li>";
			$tsn = "user_activity";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "		<li><a href='./user_activity.php' class='$cls'><i class='lnr lnr-chart-bars'></i><span>User Activity</span> </a></li>";
		echo "	</ul>";
		echo "</div>";
		echo "</li>";
	}
}
//======= RECORDS ====================================================================
if ( strtolower(trim($logutype))!=strtolower(trim("student")) && strtolower(trim($logun))!=strtolower(trim("admin")) ) {
	//
	$dnn = 0;
	//
	//
	if ( strtoupper(trim($logutype))==strtoupper(trim("employee")) ) {
	//echo "$logun $logutype";
		$sql = " select crs_staff_id,crs_id,staff_id,staff_type,position from tbl_crs_staff where staff_id='$logun' and staff_type='$logutype' and position='admin' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			$dnn += 1;
		}
	}
	//
	//
	if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
		$dnn += 1;
	}
	//
	if ( $dnn > 0 ) {
		echo "<li>";
			$tsn = "page_stats";
			$cls = "class=''";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "class='active'";
			}
		echo "<a href='page_stats.php' $cls ><i class='lnr lnr-chart-bars'></i> <span>Statistics</span></a>";
		echo "</li>";
	}
}
//======= CLASS ====================================================================
if ( strtolower(trim($logutype))==strtolower(trim("student")) && strtolower(trim($logun))!=strtolower(trim("admin")) ) {
		echo "<li>";
			$cls = "collapsed";
			$cls2 = "collapse";
			if ( strtolower(trim($cpage))==strtolower(trim("page_class")) 
				) {
				$cls = "active";
				$cls2 = "collapse in";
			}
		echo "<a href='#subPagesClass' data-toggle='collapse' class='$cls'><i class='lnr lnr-user'></i> <span>My Groups</span> <i class='icon-submenu lnr lnr-chevron-left'></i></a>";
		echo "<div id='subPagesClass' class='$cls2 '>";
		echo "	<ul class='nav'>";
	$sq1 = "";
	$sq2 = "";
	//GET MEMBER HTE
	$sql1 = " select hte_id,member_id from tbl_hte_members  where member_id='$logun' ";
	$qry1 = mysqli_query($conn,$sql1);
	while($dat1=mysqli_fetch_array($qry1)) {
		if ( trim($dat1[0]) != "" && trim($dat1[1]) != "" ) {
			if ( trim($sq1)=="" ) {
				$sq1 = " hte_id='".trim($dat1[0])."' ";
			}else{
				$sq1 = $sq1 . " || hte_id='".trim($dat1[0])."' ";
			}
		}
	}
	if ( trim($sq1)!="" ) {
		//GET HTE CLASS
		$sql1 = " select class_id,hte_id from tbl_class_member_hte  where $sq1 ";
		$qry1 = mysqli_query($conn,$sql1);
		while($dat1=mysqli_fetch_array($qry1)) {
			if ( trim($dat1[0]) != "" && trim($dat1[1]) != "" ) {
				if ( trim($sq2)=="" ) {
					$sq2 = " class_id='".trim($dat1[0])."' ";
				}else{
					$sq2 = $sq2 . " || class_id='".trim($dat1[0])."' ";
				}
			}
		}
		if ( trim($sq2)!="" ) {
			//GET CLASS DATA
			$sql1 = " select class_id,name from tbl_class  where $sq2  order by name asc ";
			$qry1 = mysqli_query($conn,$sql1);
			while($dat1=mysqli_fetch_array($qry1)) {
				if ( trim($dat1[0]) != "" && trim($dat1[1]) != "" ) {
					$link = "./page_class.php?id=".trim($dat1[0]);
					$name = trim($dat1[1]);
					echo "<li><a href='$link' class=''><i class='lnr lnr-bookmark'></i> <span class='span02'>$name</span></a></li>";
				}
			}
		}
	}
		echo "	</ul>";
		echo "</div>";
		echo "</li>";
}
//
if ( strtolower(trim($logutype))==strtolower(trim("employee")) && strtolower(trim($logun))!=strtolower(trim("admin")) ) {
		echo "<li>";
			$cls = "collapsed";
			$cls2 = "collapse";
			if ( strtolower(trim($cpage))==strtolower(trim("page_class")) 
				) {
				$cls = "active";
				$cls2 = "collapse in";
			}
		echo "<a href='#subPagesClass' data-toggle='collapse' class='$cls'><i class='lnr lnr-user'></i> <span>My Groups</span> <i class='icon-submenu lnr lnr-chevron-left'></i></a>";
		echo "<div id='subPagesClass' class='$cls2 '>";
		echo "	<ul class='nav'>";
	$sq1 = "";
	$sq2 = "";
	//GET MEMBER HTE
	$sql1 = " select class_id,staff_id from tbl_class_staff  where staff_type='$logutype' and staff_id='$logun' ";
	$qry1 = mysqli_query($conn,$sql1);
	while($dat1=mysqli_fetch_array($qry1)) {
		if ( trim($dat1[0]) != "" && trim($dat1[1]) != "" ) {
			if ( trim($sq1)=="" ) {
				$sq1 = " class_id='".trim($dat1[0])."' ";
			}else{
				$sq1 = $sq1 . " || class_id='".trim($dat1[0])."' ";
			}
		}
	}
	if ( trim($sq1)!="" ) {
		//GET HTE CLASS
		$sql1 = " select class_id,hte_id from tbl_class_member_hte  where $sq1 ";
		$qry1 = mysqli_query($conn,$sql1);
		while($dat1=mysqli_fetch_array($qry1)) {
			if ( trim($dat1[0]) != "" && trim($dat1[1]) != "" ) {
				if ( trim($sq2)=="" ) {
					$sq2 = " class_id='".trim($dat1[0])."' ";
				}else{
					$sq2 = $sq2 . " || class_id='".trim($dat1[0])."' ";
				}
			}
		}
		if ( trim($sq2)!="" ) {
			//GET CLASS DATA
			$sql1 = " select class_id,name from tbl_class  where $sq2  order by name asc ";
			$qry1 = mysqli_query($conn,$sql1);
			while($dat1=mysqli_fetch_array($qry1)) {
				if ( trim($dat1[0]) != "" && trim($dat1[1]) != "" ) {
					$link = "./page_class.php?id=".trim($dat1[0]);
					$name = trim($dat1[1]);
					echo "<li><a href='$link' class=''><i class='lnr lnr-bookmark'></i> <span class='span02'>$name</span></a></li>";
				}
			}
		}
	}
		echo "	</ul>";
		echo "</div>";
		echo "</li>";
}
//======= CLASS ====================================================================
//======= HTE ====================================================================
if ( strtolower(trim($logutype))=="student" && strtolower(trim($logun))!=strtolower(trim("admin")) ) {
		echo "<li>";
			$cls = "collapsed";
			$cls2 = "collapse";
			if ( strtolower(trim($cpage))==strtolower(trim("page_hte")) 
				) {
				$cls = "active";
				$cls2 = "collapse in";
			}
		echo "<a href='#subPagesMyHTE' data-toggle='collapse' class='$cls'><i class='lnr lnr-bookmark'></i> <span>My HTE</span> <i class='icon-submenu lnr lnr-chevron-left'></i></a>";
		echo "<div id='subPagesMyHTE' class='$cls2 '>";
		echo "	<ul class='nav'>";
	$sq1 = "";
	$sq2 = "";
	//GET MEMBER HTE
	$sql1 = " select hte_id,member_id from tbl_hte_members  where member_id='$logun' ";
	$qry1 = mysqli_query($conn,$sql1);
	while($dat1=mysqli_fetch_array($qry1)) {
		if ( trim($dat1[0]) != "" && trim($dat1[1]) != "" ) {
			if ( trim($sq1)=="" ) {
				$sq1 = " hte_id='".trim($dat1[0])."' ";
			}else{
				$sq1 = $sq1 . " || hte_id='".trim($dat1[0])."' ";
			}
		}
	}
	if ( trim($sq1)!="" ) {
		//GET CLASS DATA
		$sql1 = " select hte_id,name from tbl_hte  where $sq1  order by name asc ";
		$qry1 = mysqli_query($conn,$sql1);
		while($dat1=mysqli_fetch_array($qry1)) {
			if ( trim($dat1[0]) != "" && trim($dat1[1]) != "" ) {
				$link = "./page_hte.php?id=".trim($dat1[0]);
				$name = trim($dat1[1]);
				echo "<li><a href='$link' class=''><i class='lnr lnr-bookmark'></i> <span class='span02'>$name</span></a></li>";
			}
		}
	}
		echo "	</ul>";
		echo "</div>";
		echo "</li>";
}
//======= HTE EMPLOYEE ====================================================================
if ( strtolower(trim($logutype))==strtolower(trim("employee")) && strtolower(trim($logun))!=strtolower(trim("admin")) ) {
		echo "<li>";
			$cls = "collapsed";
			$cls2 = "collapse";
			if ( strtolower(trim($cpage))==strtolower(trim("page_hte")) 
				) {
				$cls = "active";
				$cls2 = "collapse in";
			}
		echo "<a href='#subPagesMyHTE' data-toggle='collapse' class='$cls'><i class='lnr lnr-bookmark'></i> <span>My HTE</span> <i class='icon-submenu lnr lnr-chevron-left'></i></a>";
		echo "<div id='subPagesMyHTE' class='$cls2 '>";
		echo "	<ul class='nav'>";
	$sq1 = "";
	$sq2 = "";
	//GET MEMBER HTE
	$sql1 = " select hte_staff_id,hte_id,staff_id,staff_type from tbl_hte_staff  where staff_id='$logun' and staff_type='$logutype' ";
	$qry1 = mysqli_query($conn,$sql1);
	while($dat1=mysqli_fetch_array($qry1)) {
		if ( trim($dat1[0]) != "" && trim($dat1[1]) != "" ) {
			if ( trim($sq1)=="" ) {
				$sq1 = " hte_id='".trim($dat1[1])."' ";
			}else{
				$sq1 = $sq1 . " || hte_id='".trim($dat1[1])."' ";
			}
		}
	}
	if ( trim($sq1)!="" ) {
		//echo "$sq1";
		//GET CLASS DATA
		$sql1 = " select hte_id,name from tbl_hte  where $sq1  order by name asc ";
		$qry1 = mysqli_query($conn,$sql1);
		while($dat1=mysqli_fetch_array($qry1)) {
			if ( trim($dat1[0]) != "" && trim($dat1[1]) != "" ) {
				$link = "./page_hte.php?id=".trim($dat1[0]);
				$name = trim($dat1[1]);
				echo "<li><a href='$link' class=''><i class='lnr lnr-bookmark'></i> <span class='span02'>$name</span></a></li>";
			}
		}
	}
		echo "	</ul>";
		echo "</div>";
		echo "</li>";
}
//======= HTE ====================================================================
//======= DTR ====================================================================
if ( strtolower(trim($logun))!="" && strtolower(trim($logutype))==strtolower(trim("student")) && strtolower(trim($logun))!=strtolower(trim("admin")) ) {
		echo "<li>";
			$tsn = "page_dtr";
			$cls = "class=''";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "class='active'";
			}
		echo "<a href='./page_dtr.php' $cls ><i class='lnr lnr-bookmark'></i> <span>My DTR</span></a>";
		echo "</li>";
}
//======= DTR ====================================================================
if ( strtolower(trim($logun))!=strtolower(trim("admin")) ) {
			$tsn = "page_map";
			$cls = "";
			if ( strtolower(trim($cpage))==strtolower(trim($tsn)) ) {
				$cls = "active";
			}
		echo "<li><a href='./page_map.php' class='$cls'><i class='lnr lnr-select'></i> <span>Map</span></a></li>";
}
	?>
	
</ul>
</nav>