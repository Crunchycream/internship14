<?php include "./data/connect.php"; include "./parts/sys_functions_02.php";
	$uid = $_GET['id'];
	$idname = "";
	//
$memid =  $_SESSION['intern_data_cun'];
$memtype = $_SESSION['intern_data_utype'];
//
$logun = $memid;
$logutype = $memtype;
//
	//
	$cursy = trim($_SESSION['intern_data_active_sy']);
	//
	if ( trim($uid)!="" ) {
		$sql = " select hte_id,name from tbl_hte  where hte_id='$uid' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			$idname = trim($dat[1]);
		}
	}
	if ( trim($uid)!="" ) {
		if(isset($_POST["btnProfileCoverPhotoChange"])) {
			$target_dir = "uploads/";
			$foname = basename($_FILES["fileUP"]["name"]);
			$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
			$target_file = $target_dir . $foname;
			$target_file2 = "";
			$uploadOk = 1;
			$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
			// Check if image file is a actual image or fake image
		    // Check file size
			if ($_FILES["fileUP"]["size"] > 500000) {
			    //echo "Sorry, your file is too large.";
			    //$uploadOk = 0;
			}
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" && $imageFileType != "bmp" && $imageFileType != "ico" ) {
			    $uploadOk = 0;
			}
			if ($uploadOk == 0) {
			    //echo "Sorry, your file was not uploaded.";
			} else {
				//GET NEW NAME
				$fln = "file_".$date_month."_".$date_day."_".$date_year."__".$date_hour."_".$date_minute."_".$date_second.".".$imageFileType;
			    $target_file2 = $target_dir . "$fln";
			    if (move_uploaded_file($_FILES["fileUP"]["tmp_name"], $target_file2)) {
			        //echo "The file ". basename( $_FILES["fileUP"]["name"]). " has been uploaded.";
			        //UPDATE TO USER
			        $sql = " update tbl_hte set prof_backimg='$target_file2'  where dsn='$uid' ";
					$qry = mysqli_query($conn,$sql);
					//SAVE TO UPLOADED FILES
			        $sql = " insert into tbl_upfiles
			        			 (name,location,date_uploaded,upby_id,upby_type)
			        		 values
			        		 	 ('$foname','$target_file2','$cdate','$memid','$memtype') ";
					$qry = mysqli_query($conn,$sql);
					//NOTIFICATION
					$notif_ttl = "Cover photo changed.";
					$notif_lnk = "";
					$notif_cont = "$idname: Cover photo updated.";
					$notif_locid = "$uid";
					$notif_loctype = "hte";
					$notif_tarsn = "page_hte";
					$notif_status = "unseen";
					addNotification($memid,$memtype,$notif_ttl,$notif_lnk,$notif_cont,$notif_locid,$notif_loctype,$notif_tarsn,$notif_status);
			    } else {
			        //echo "Sorry, there was an error uploading your file.";
			    }
			}
		}
	}
		//
		//
		if(isset($_POST["btnsaveEdit"])) {
			//
			$did = $_POST['txtid'];
			$subj = htmlspecialchars( $_POST['txtsubject'] , ENT_QUOTES );
			$msg = htmlspecialchars( $_POST['txtmsg'] , ENT_QUOTES );
			echo "
				<script>
					//alert('$did $msg');
				</script>
			";
			//
			$target_dir = "uploads/";
			$foname = basename($_FILES["fileUP"]["name"]);
			$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
			$target_file = $target_dir . $foname;
			$target_file2 = "";
			$uploadOk = 1;
			$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
			// Check if image file is a actual image or fake image
		    // Check file size
			if ($_FILES["fileUP"]["size"] > 500000) {
			    //echo "Sorry, your file is too large.";
			    //$uploadOk = 0;
			}
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" && $imageFileType != "bmp" && $imageFileType != "ico"
			&& $imageFileType != "doc" && $imageFileType != "docx" && $imageFileType != "pdf" ) {
			    $uploadOk = 0;
			}
			if ($uploadOk == 0) {
			    //echo "Sorry, your file was not uploaded.";
			} else {
				//GET NEW NAME
				$fln = "file_".$date_month."_".$date_day."_".$date_year."__".$date_hour."_".$date_minute."_".$date_second.".".$imageFileType;
			    $target_file2 = $target_dir . "$fln";
			    if (move_uploaded_file($_FILES["fileUP"]["tmp_name"], $target_file2)) {
			        //echo "The file ". basename( $_FILES["fileUP"]["name"]). " has been uploaded.";
			        //SAVE ANNOUNCE MENT
			        $sql = " update tbl_announcement set 
			        			 subject='$subj',msg='$msg',cfile='$target_file2' 
			        		 	where announcement_id='$did' 
			        		  ";
					$qry = mysqli_query($conn,$sql);
					//SAVE TO UPLOADED FILES
			        $sql = " insert into tbl_upfiles
			        			 (name,location,date_uploaded,upby_id,upby_type,utype,uloc_id,uloc_type)
			        		 values
			        		 	 ('$foname','$target_file2','$cdate','$memid','$memtype','announcement','$uid','$uidtype') ";
					$qry = mysqli_query($conn,$sql);
			    } else {
			        //echo "Sorry, there was an error uploading your file.";
			    }
			}
			if ( trim($foname)=="" ) {
				if ( trim($msg)!="" ) {
			        //SAVE ANNOUNCE MENT
			        $sql = " update tbl_announcement set 
			        			 subject='$subj',msg='$msg' 
			        		 	where announcement_id='$did' 
			        		  ";
					$qry = mysqli_query($conn,$sql);
				}
			}
		}
		//
		//
		if(($_POST["btnsaveDelete"])) {
			//
			$did = $_POST['txtid'];
			//
			if ( trim($did)!="" ) {
			        //DELETE
			        $sql = " delete from tbl_announcement 
			        		 	where announcement_id='$did' 
			        		  ";
					$qry = mysqli_query($conn,$sql);
			}
		}
	//
	//
	//
	if ( trim($uid)!="" ) {
		if ( $_POST['btnAddJob'] ) {
			$name = htmlspecialchars( $_POST['jobname'] , ENT_QUOTES );
			$desc = htmlspecialchars( $_POST['jobdesc'] , ENT_QUOTES );
			$errmsg = "";
			$errn = 0;
			if ( trim($name) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Job Name required. ";
			}
			$ec = 0;
			$sql = " select * from tbl_hte_jobs  where  hte_id='$uid' and name='$name' ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				$ec = $ec + 1;
			}
			if ( trim($ec) > 0 ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Job Name already added. ";
			}
			if ( $errn <= 0 ) {
				//SAVE DATA
				$sql = " insert into tbl_hte_jobs
							(hte_id,name,description)
							values
							('$uid','$name','$desc')
						";
				$qry = mysqli_query($conn,$sql);
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
					//NOTIFICATION
					$notif_ttl = "New Job.";
					$notif_lnk = "";
					$notif_cont = "$idname: New job added.";
					$notif_locid = "$uid";
					$notif_loctype = "hte";
					$notif_tarsn = "page_hte";
					$notif_status = "unseen";
					addNotification($memid,$memtype,$notif_ttl,$notif_lnk,$notif_cont,$notif_locid,$notif_loctype,$notif_tarsn,$notif_status);
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
			}
		}
		//
		if ( $_POST['btnsaveJobEdit'] ) {
			$cid = $_POST['txtid'];
			//
			$name = htmlspecialchars( $_POST['jobname'] , ENT_QUOTES );
			$desc = htmlspecialchars( $_POST['jobdesc'] , ENT_QUOTES );
			$errmsg = "";
			$errn = 0;
			if ( trim($name) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Job Name required. ";
			}
			if ( $errn <= 0 ) {
				//SAVE DATA
				$sql = " update tbl_hte_jobs set 
							name='$name',description='$desc' 
								where hte_job_id='$cid' 
						";
				$qry = mysqli_query($conn,$sql);
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
			}
		}
		if ( $_POST['btnsaveJobDelete'] ) {
			$cid = $_POST['txtid'];
			//
			$errmsg = "";
			$errn = 0;
			if ( $errn <= 0 ) {
				//SAVE DATA
				$sql = " delete from tbl_hte_jobs  
							where hte_job_id='$cid' 
						";
				$qry = mysqli_query($conn,$sql);
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
			}
		}
//=================================================================================================
		if ( $_POST['btnAddIntern'] ) {
			$studid = $_POST['studid'];
			$errmsg = "";
			$errn = 0;
			if ( trim($studid) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Name required. ";
			}
			$ec = 0;
			$sql = " select * from tbl_hte_members  where  hte_id='$uid' and member_id='$studid' ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				$ec = $ec + 1;
			}
			if ( trim($ec) > 0 ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Name already added. ";
			}
			if ( $errn <= 0 ) {
				//SAVE DATA
				$sql = " insert into tbl_hte_members 
							(hte_id,member_id)
							values
							('$uid','$studid')
						";
				$qry = mysqli_query($conn,$sql);
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
					//NOTIFICATION
					$notif_ttl = "New Intern.";
					$notif_lnk = "";
					$notif_cont = "$idname: New intern joined.";
					$notif_locid = "$uid";
					$notif_loctype = "hte";
					$notif_tarsn = "page_hte";
					$notif_status = "unseen";
					addNotification($memid,$memtype,$notif_ttl,$notif_lnk,$notif_cont,$notif_locid,$notif_loctype,$notif_tarsn,$notif_status);
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
			}
		}
		if ( $_POST['btnAddRate'] ) {
			$value = trim($_POST['value']);
			//$memid = "1234";
			$errmsg = "";
			$errn = 0;
			if ( trim($value) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Rate Score required. ";
			}
			if ( $errn <= 0 ) {
				//SAVE DATA
				$sql = " insert into tbl_hte_rating 
							(hte_id,member_id,rate)
							values
							('$uid','$memid','$value')
						";
				$qry = mysqli_query($conn,$sql);
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
					//NOTIFICATION
					$notif_ttl = "New Rate.";
					$notif_lnk = "";
					$notif_cont = "$idname: New rate added.";
					$notif_locid = "$uid";
					$notif_loctype = "hte";
					$notif_tarsn = "page_hte";
					$notif_status = "unseen";
					addNotification($memid,$memtype,$notif_ttl,$notif_lnk,$notif_cont,$notif_locid,$notif_loctype,$notif_tarsn,$notif_status);
					//
					if ( strtolower(trim($memtype))==strtolower(trim("student")) ) {
						$msg = " evaluated ".trim($idname).".";
						$msgt = "1";
						addUserActivityLog($memid,$memtype,$msg,$msgt);
					}
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
			}
		}
//====================================================================================
		if ( $_POST['btnsaveInternSendMessage'] ) {
			$rcv_id = $_POST['txtstudid'];
			$rcv_type = $_POST['txtstudtype'];
			//
			$snd_id = $_SESSION['intern_data_cun'];
			$snd_type = $_SESSION['intern_data_utype'];
			//
			$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
			//
			$msg = htmlspecialchars( $_POST['msg'] , ENT_QUOTES );
			//
			$errmsg = "";
			$errn = 0;
			if ( trim($msg) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Enter a message. ";
			}
			if ( $errn <= 0 ) {
				//SAVE DATA
				if ( trim($rcv_id)!="" && trim($snd_id)!="" && ($msg)!="" ) {
					//
					//GET GRROUP ID, IF NONE CREATE AND GET
					$tgid = "";
					//
					//                    0       1     2    3    4     5     6      7
					$sql = " select msgs_group_id,mem1_id,mem1_type,mem2_id,mem2_type from tbl_messages_group where ( mem1_id='$rcv_id' and mem1_type='$rcv_type' and mem2_id='$snd_id' and mem2_type='$snd_type' ) or ( mem1_id='$snd_id' and mem1_type='$snd_type' and mem2_id='$rcv_id' and mem2_type='$rcv_type' ) ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						$tgid = trim($dat[0]);
					}
					//
					if ( trim($tgid)=="" ) {
						//CREATE
						$sql = " insert into tbl_messages_group
									( mem1_id,mem1_type,mem2_id,mem2_type )
								values
									( '$rcv_id','$rcv_type','$snd_id','$snd_type' )
						 ";
							$qry = mysqli_query($conn,$sql);
					}
					//GET
					//                    0       1     2    3    4     5     6      7
					$sql = " select msgs_group_id,mem1_id,mem1_type,mem2_id,mem2_type from tbl_messages_group where ( mem1_id='$rcv_id' and mem1_type='$rcv_type' and mem2_id='$snd_id' and mem2_type='$snd_type' ) or ( mem1_id='$snd_id' and mem1_type='$snd_type' and mem2_id='$rcv_id' and mem2_type='$rcv_type' ) ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						$tgid = trim($dat[0]);
					}
					//
					//
					//FOR SENDER
					$sql = "
							insert into tbl_messages
								(rcv_id,rcv_type,snd_id,snd_type,message,date_sent,own_id,own_type,msgs_group_id) 
							values 
								('$rcv_id','$rcv_type','$snd_id','$snd_type','$msg','$cdate','$snd_id','$snd_type','$tgid') 
							";
					$qry = mysqli_query($conn,$sql);
					//FOR RECEIVER
					$sql = "
							insert into tbl_messages
								(rcv_id,rcv_type,snd_id,snd_type,message,date_sent,own_id,own_type,msgs_group_id) 
							values 
								('$rcv_id','$rcv_type','$snd_id','$snd_type','$msg','$cdate','$rcv_id','$rcv_type','$tgid') 
							";
					$qry = mysqli_query($conn,$sql);
				}
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
			}
		}
//====================================================================================
//========= EVAL ===========================================================================
		if ( $_POST['btnAddHTEEval'] ) {
			//
			//
			if ( trim($uid)!="" && trim($memid)!="" ) {
				//
				$major = $_POST['major'];
				$sem = $_POST['semester'];
				$sy = $_POST['sy'];
				$dept = $_POST['dept'];
				//
				$crs_id = "";
				$crs = "";
				$college = "UMDC";
				//GET STUDENT INFO
				//                 0           1       2         3        4
				$sql = " select studentid,firstname,middlename,lastname,course from tbl_interns  where  studentid='$memid' ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					$crs_id = trim($dat[4]);
				}
				//
				//GET CRS NAME
				//                 0         1      
				$sql = " select course_id,course from tbl_course  where  course_id='$crs_id' ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					$crs = trim($dat[4]);
				}
				//
				$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
				//
				//
				$comp1 = trim( htmlspecialchars( $_POST['comp1'] , ENT_QUOTES ) );
				$comp1hrs = trim( $_POST['comp1hrs'] );
				$comp1rate = trim( $_POST['comp1rate'] );
				//
				$comp2 = trim( htmlspecialchars( $_POST['comp2'] , ENT_QUOTES ) );
				$comp2hrs = trim( $_POST['comp2hrs'] );
				$comp2rate = trim( $_POST['comp2rate'] );
				//
				$comp3 = trim( htmlspecialchars( $_POST['comp3'] , ENT_QUOTES ) );
				$comp3hrs = trim( $_POST['comp3hrs'] );
				$comp3rate = trim( $_POST['comp3rate'] );
				//
				$comp4 = trim( htmlspecialchars( $_POST['comp4'] , ENT_QUOTES ) );
				$comp4hrs = trim( $_POST['comp4hrs'] );
				$comp4rate = trim( $_POST['comp4rate'] );
				//
				$comp5 = trim( htmlspecialchars( $_POST['comp5'] , ENT_QUOTES ) );
				$comp5hrs = trim( $_POST['comp5hrs'] );
				$comp5rate = trim( $_POST['comp5rate'] );
				//
				$comp6 = trim( htmlspecialchars( $_POST['comp6'] , ENT_QUOTES ) );
				$comp6hrs = trim( $_POST['comp6hrs'] );
				$comp6rate = trim( $_POST['comp6rate'] );
				//
				$comp7 = trim( htmlspecialchars( $_POST['comp7'] , ENT_QUOTES ) );
				$comp7hrs = trim( $_POST['comp7hrs'] );
				$comp7rate = trim( $_POST['comp7rate'] );
				//
				$tcomp =  array(
						array($comp1,$comp1hrs,$comp1rate),
						array($comp2,$comp2hrs,$comp2rate),
						array($comp3,$comp3hrs,$comp3rate),
						array($comp4,$comp4hrs,$comp4rate),
						array($comp5,$comp5hrs,$comp5rate),
						array($comp6,$comp6hrs,$comp6rate),
						array($comp7,$comp7hrs,$comp7rate)
					);
				//
				//
				$errmsg = "";
				$errn = 0;
				//
				if ( trim($sem) == "" ) {
					$errn = $errn + 1;
					$errmsg = $errmsg . "Semester required. ";
				}
				if ( trim($sy) == "" ) {
					$errn = $errn + 1;
					$errmsg = $errmsg . "School Year required. ";
				}
				if ( trim($sem) == "" ) {
					$errn = $errn + 1;
					$errmsg = $errmsg . "Semester required. ";
				}
				//
				if ( 
					trim($comp1) == "" &&
					trim($comp2) == "" &&
					trim($comp3) == "" &&
					trim($comp4) == "" &&
					trim($comp5) == "" &&
					trim($comp6) == "" &&
					trim($comp7) == ""
					) {
					$errn = $errn + 1;
					$errmsg = $errmsg . "You must have at least 1 Program Competences. ";
				}
				//
				//
				if ( $errn <= 0 ) {
					//SAVE DATA
					$sql = "
							insert into tbl_hte_eval 
								(studentid,college,course,major,semester,sy,hte_id,department,eval_date) 
							values 
								('$memid','$college','$crs_id','$major','$sem','$sy','$uid','$dept','$cdate') 
							";
					$qry = mysqli_query($conn,$sql);
					//
					//GET CURRENT EVAL ID
					$cur_eid = "";
					//                 0        
					$sql = " select hte_eval_id from tbl_hte_eval  where  studentid='$memid' and hte_id='$uid' and eval_date='$cdate' ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						$cur_eid = trim($dat[0]);
					}
					//
					//SAVE PROGRAM COMPETENCES
					if ( trim($cur_eid)!="" ) {
						for ( $i = 0 ; $i < count($tcomp) ; $i++ ) {
							if ( trim($tcomp[$i][0])!="" ) {
								$sql = "
										insert into tbl_hte_eval_progcomp 
											(hte_eval_id,prog_comp,num_hours,eval_rate,sy,hte_id) 
										values 
											('$cur_eid','".$tcomp[$i][0]."','".$tcomp[$i][1]."','".$tcomp[$i][2]."','$sy','$uid') 
										";
								$qry = mysqli_query($conn,$sql);
							}
						}
					}
					//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
					//
					//NOTIFICATION
					$notif_ttl = "New Rate.";
					$notif_lnk = "";
					$notif_cont = "$idname: New rate added.";
					$notif_locid = "$uid";
					$notif_loctype = "hte";
					$notif_tarsn = "page_hte";
					$notif_status = "unseen";
					addNotification($memid,$memtype,$notif_ttl,$notif_lnk,$notif_cont,$notif_locid,$notif_loctype,$notif_tarsn,$notif_status);
					//
					if ( strtolower(trim($memtype))==strtolower(trim("student")) ) {
						$msg = " evaluated ".trim($idname).".";
						$msgt = "1";
						addUserActivityLog($memid,$memtype,$msg,$msgt);
					}
				}else{
					//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
					echo "
						<script>
							alert('$errmsg');
						</script>
					";
				}
			}
		}
//========= EVAL ===========================================================================
//========= EVAL 3 ===========================================================================
		if ( $_POST['btnAddHTEEval3'] ) {
			//
			//
			if ( trim($uid)!="" && trim($memid)!="" ) {
				//
				$sy = trim($_SESSION['intern_data_active_sy']);
				//
				//
				$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
				//
				$rate1_1 = "0";
				$rate1_2 = "0";
				$rate1_3 = "0";
				$rate1_4 = "0";
				$rate1_5 = "0";
				$rate1_6 = "0";
				$rate1_7 = "0";
				$rate1_8 = "0";
				//
				$rate2_1 = "0";
				$rate2_2 = "0";
				$rate2_3 = "0";
				$rate2_4 = "0";
				$rate2_5 = "0";
				$rate2_6 = "0";
				$rate2_7 = "0";
				$rate2_8 = "0";
				//
				$rate3_1 = "0";
				$rate3_2 = "0";
				$rate3_3 = "0";
				$rate3_4 = "0";
				$rate3_5 = "0";
				$rate3_6 = "0";
				//
				//
				$rate1_1 = trim( $_POST['crit1_1'] );
				$rate1_2 = trim( $_POST['crit1_2'] );
				$rate1_3 = trim( $_POST['crit1_3'] );
				$rate1_4 = trim( $_POST['crit1_4'] );
				$rate1_5 = trim( $_POST['crit1_5'] );
				$rate1_6 = trim( $_POST['crit1_6'] );
				$rate1_7 = trim( $_POST['crit1_7'] );
				$rate1_8 = trim( $_POST['crit1_8'] );
				//
				$rate2_1 = trim( $_POST['crit2_1'] );
				$rate2_2 = trim( $_POST['crit2_2'] );
				$rate2_3 = trim( $_POST['crit2_3'] );
				$rate2_4 = trim( $_POST['crit2_4'] );
				$rate2_5 = trim( $_POST['crit2_5'] );
				$rate2_6 = trim( $_POST['crit2_6'] );
				$rate2_7 = trim( $_POST['crit2_7'] );
				$rate2_8 = trim( $_POST['crit2_8'] );
				//
				$rate3_1 = trim( $_POST['crit3_1'] );
				$rate3_2 = trim( $_POST['crit3_2'] );
				$rate3_3 = trim( $_POST['crit3_3'] );
				$rate3_4 = trim( $_POST['crit3_4'] );
				$rate3_5 = trim( $_POST['crit3_5'] );
				$rate3_6 = trim( $_POST['crit3_6'] );
				//
				//
				$comments = trim( htmlspecialchars( $_POST['comments'] , ENT_QUOTES ) );
				//
				//
				$errmsg = "";
				$errn = 0;
				//
				//
				//
				if ( $errn <= 0 ) {
					//SAVE DATA
					$sql = "
							insert into tbl_hte_eval2 
								(hte_id,sy,adate,evaluator_id,evaluator_type,crit_1_1,crit_1_2,crit_1_3,crit_1_4,crit_1_5,crit_1_6,crit_1_7,crit_1_8,crit_2_1,crit_2_2,crit_2_3,crit_2_4,crit_2_5,crit_2_6,crit_2_7,crit_2_8,crit_3_1,crit_3_2,crit_3_3,crit_3_4,crit_3_5,crit_3_6,comments) 
							values 
								('$uid','$sy','$cdate','$logun','$logutype','$rate1_1','$rate1_2','$rate1_3','$rate1_4','$rate1_5','$rate1_6','$rate1_7','$rate1_8','$rate2_1','$rate2_2','$rate2_3','$rate2_4','$rate2_5','$rate2_6','$rate2_7','$rate2_8','$rate3_1','$rate3_2','$rate3_3','$rate3_4','$rate3_5','$rate3_6','$comments') 
							";
					$qry = mysqli_query($conn,$sql);
					//
					//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
					//
					//NOTIFICATION
					$notif_ttl = "New Rate.";
					$notif_lnk = "";
					$notif_cont = "$idname: New rate added.";
					$notif_locid = "$uid";
					$notif_loctype = "hte";
					$notif_tarsn = "page_hte";
					$notif_status = "unseen";
					addNotification($memid,$memtype,$notif_ttl,$notif_lnk,$notif_cont,$notif_locid,$notif_loctype,$notif_tarsn,$notif_status);
					//
					if ( strtolower(trim($memtype))==strtolower(trim("student")) ) {
						$msg = " evaluated ".trim($idname).".";
						$msgt = "1";
						addUserActivityLog($memid,$memtype,$msg,$msgt);
					}
				}else{
					//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
					echo "
						<script>
							alert('$errmsg');
						</script>
					";
				}
			}
		}
//========= EVAL 3 ===========================================================================
//========= EVAL CRITERIA ===========================================================================
		if ( $_POST['btnAddHTEEvalCriteria'] ) {
			//
			//
			if ( trim($uid)!="" && trim($memid)!="" ) {
				//
				$sy = $cursy;
				//
				//GET STUDENT INFO
				//                 0           1       2         3        4
				$sql = " select studentid,firstname,middlename,lastname,course from tbl_interns  where  studentid='$memid' ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					$crs_id = trim($dat[4]);
				}
				//
				//
				$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
				//
				//
				$comp1 = trim( htmlspecialchars( $_POST['comp1'] , ENT_QUOTES ) );
				//
				$comp2 = trim( htmlspecialchars( $_POST['comp2'] , ENT_QUOTES ) );
				//
				$comp3 = trim( htmlspecialchars( $_POST['comp3'] , ENT_QUOTES ) );
				//
				$comp4 = trim( htmlspecialchars( $_POST['comp4'] , ENT_QUOTES ) );
				//
				$comp5 = trim( htmlspecialchars( $_POST['comp5'] , ENT_QUOTES ) );
				//
				$comp6 = trim( htmlspecialchars( $_POST['comp6'] , ENT_QUOTES ) );
				//
				$comp7 = trim( htmlspecialchars( $_POST['comp7'] , ENT_QUOTES ) );
				//
				$tcomp =  array($comp1,$comp2,$comp3,$comp4,$comp5,$comp6,$comp7
					);
				//
				//
				$errmsg = "";
				$errn = 0;
				//
				//
				if ( 
					trim($comp1) == "" &&
					trim($comp2) == "" &&
					trim($comp3) == "" &&
					trim($comp4) == "" &&
					trim($comp5) == "" &&
					trim($comp6) == "" &&
					trim($comp7) == ""
					) {
					$errn = $errn + 1;
					$errmsg = $errmsg . "You must have at least 1 Criteria. ";
				}
				//
				//
				if ( $errn <= 0 ) {
					//REMOVE ADDED CRITERIA THIS SY
					$sql = "
							delete from  tbl_hte_eval_criteria 
								where  hte_id='$uid' and  sy='$sy'
							";
					$qry = mysqli_query($conn,$sql);
					//
					//SAVE DATA
					//
						for ( $i = 0 ; $i < count($tcomp) ; $i++ ) {
							if ( trim($tcomp[$i])!="" ) {
								$sql = "
										insert into tbl_hte_eval_criteria 
											(name,sy,adate,hte_id) 
										values 
											('".$tcomp[$i]."','$sy','$cdate','$uid') 
										";
								$qry = mysqli_query($conn,$sql);
							}
						}
					//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
					//
					echo "
						<script>
							alert('Criteria saved.');
						</script>
					";
				}else{
					//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
					echo "
						<script>
							alert('$errmsg');
						</script>
					";
				}
			}
		}
//========= EVAL CRITERIA ===========================================================================

		if ( $_POST['btnsaveStaff'] ) {
			$staff = trim($_POST['txtemployee']);
			$position = trim($_POST['txtposition']);
			//$memid = "1234";
			$errmsg = "";
			$errn = 0;
			//
			if ( trim($memid) == "" || strtolower(trim($memtype))==strtolower(trim("student")) ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "";
			}
			//
			if ( trim($staff) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Staff required. ";
			}
			if ( trim($position) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Position required. ";
			}
			//
			$ec = 0;
			$sql = " select * from tbl_hte_staff  where hte_id='$uid' and staff_id='$staff' and staff_type='employee' ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				$ec = $ec + 1;
			}
			if ( trim($ec) > 0 ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Staff already added. ";
			}
			//
			//
			if ( $errn <= 0 ) {
				//SAVE DATA
				$sql = " insert into tbl_hte_staff 
							(hte_id,staff_id,staff_type,position)
							values
							('$uid','$staff','employee','$position')
						";
				$qry = mysqli_query($conn,$sql);
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
			}
		}

		if ( $_POST['btnsaveStaffRemove'] ) {
			$id = trim($_POST['txtid']);
			//
			$errmsg = "";
			$errn = 0;
			//
			if ( trim($memid) == "" || strtolower(trim($memtype))==strtolower(trim("student")) ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "";
			}
			//
			if ( trim($id) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "";
			}
			//
			//
			if ( $errn <= 0 ) {
				//SAVE DATA
				$sql = " delete from tbl_hte_staff  
							where hte_staff_id='$id' 
						";
				$qry = mysqli_query($conn,$sql);
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				//echo "
				//	<script>
				//		alert('$errmsg');
				//	</script>
				//";
			}
		}
		
//====================================================================================
	}
	//MSGS LOG UPDATER
	include "./parts/msgs_logupdater.php";
?>