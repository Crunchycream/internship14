<div class="container-fluid">
	<p class="copyright">&copy; 2018 <a href="#" target="">UMDC</a>. All Rights Reserved.</p>
</div>