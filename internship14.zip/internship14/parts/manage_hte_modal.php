    <div id="modalAddHTE" class="modal fade" role="dialog">
      <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add New HTE</h4>
      </div>
          <form method="post" action="">
      <div class="modal-body">
        <p>
          <div class="form-group">
              <?php echo $_SESSION['intern_disp_err']; $_SESSION['intern_disp_err'] = ""; ?>
            </div>
            <div class="form-group div01">
              <label for="stud-add-name" class="control-label sr-only">Name</label>
              <input type="text" name="name" class="form-control txt01" id="stud-add-name" placeholder="Name"
                <?php
                  $value = $_POST['name'];
                  echo " value='$value' ";
                ?>
              >
            </div>
            <div class="form-group div01">
              <label for="stud-add-address" class="control-label sr-only">Address</label>
              <input type="text" name="address" class="form-control txt01" id="stud-add-address" placeholder="Address"
                <?php
                  $value = $_POST['address'];
                  echo " value='$value' ";
                ?>
              >
            </div>
            <div class="form-group">
              <label for="stud-add-nostud" class="control-label sr-only"># of Students</label>
              <input type="text" name="nostud" class="form-control txt01" id="stud-add-nostud" placeholder="# of Hours"
                <?php
                  $value = $_POST['nostud'];
                  echo " value='$value' ";
                ?>
              >
            </div>
            
        </p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <input type="submit" name="btnsave" class="btn btn-primary btn-lg btn01" value="SAVE">
      </div>
          </form>
      </div>

      </div>
    </div>