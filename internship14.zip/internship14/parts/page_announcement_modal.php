
		<!-- ====================== ADD ANNOUNCEMENT ============================== -->
		<div id="modalAddAnnouncement" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Add Announcement</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					<div class="form-group div01">
						<label for="subject" class="control-label sr-only">Subject</label>
						<input type="text" name="txtsubject" class="form-control txt01" id="subject" placeholder="Subject"
							<?php
								$value = $_POST['txtsubject'];
								echo " value='$value' ";
							?>
						>
					</div>
					<div class="form-group div01">
						<label for="msg" class="control-label sr-only">Message</label>
						<textarea name="txtmsg" class="form-control txta01" id="msg" placeholder="Message"><?php $value = $_POST['studid']; echo "$value";?></textarea>
					</div>
					<div class="form-group div01">
						Attach file:
						<label for="fileUP" class="control-label sr-only">Attach File</label>
						<input type="file" name="fileUP" id="fileUP" placeholder="Attach File">
					</div>
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-md" value="POST" name="btnAddAnnouncement">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ====================== ADD ANNOUNCEMENT ============================== -->