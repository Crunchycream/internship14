<?php include "./data/connect.php";
	$uid = $_GET['id'];
	if ( trim($uid)!="" ) {
		$target_dir = "uploads/";
		$foname = basename($_FILES["fileUP"]["name"]);
		$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
		$target_file = $target_dir . $foname;
		$target_file2 = "";
		$uploadOk = 1;
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		// Check if image file is a actual image or fake image
		if(isset($_POST["btnProfilePhotoChange"])) {
		    // Check file size
			if ($_FILES["fileUP"]["size"] > 500000) {
			    //echo "Sorry, your file is too large.";
			    //$uploadOk = 0;
			}
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" && $imageFileType != "bmp" && $imageFileType != "ico" ) {
			    $uploadOk = 0;
			}
			if ($uploadOk == 0) {
			    //echo "Sorry, your file was not uploaded.";
			} else {
				//GET NEW NAME
				$fln = "file_".$date_month."_".$date_day."_".$date_year."__".$date_hour."_".$date_minute."_".$date_second.".".$imageFileType;
			    $target_file2 = $target_dir . "$fln";
			    if (move_uploaded_file($_FILES["fileUP"]["tmp_name"], $target_file2)) {
			        //echo "The file ". basename( $_FILES["fileUP"]["name"]). " has been uploaded.";
			        //UPDATE TO USER
			        $sql = " update tbl_employee set prof_img='$target_file2'  where employee_id='$uid' ";
					$qry = mysqli_query($conn,$sql);
					//SAVE TO UPLOADED FILES
			        $sql = " insert into tbl_upfiles
			        			 (name,location,date_uploaded)
			        		 values
			        		 	 ('$foname','$target_file2','$cdate') ";
					$qry = mysqli_query($conn,$sql);
			    } else {
			        //echo "Sorry, there was an error uploading your file.";
			    }
			}
		}
		if(isset($_POST["btnProfileCoverPhotoChange"])) {
		    // Check file size
			if ($_FILES["fileUP"]["size"] > 500000) {
			    //echo "Sorry, your file is too large.";
			    //$uploadOk = 0;
			}
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" && $imageFileType != "bmp" && $imageFileType != "ico" ) {
			    $uploadOk = 0;
			}
			if ($uploadOk == 0) {
			    //echo "Sorry, your file was not uploaded.";
			} else {
				//GET NEW NAME
				$fln = "file_".$date_month."_".$date_day."_".$date_year."__".$date_hour."_".$date_minute."_".$date_second.".".$imageFileType;
			    $target_file2 = $target_dir . "$fln";
			    if (move_uploaded_file($_FILES["fileUP"]["tmp_name"], $target_file2)) {
			        //echo "The file ". basename( $_FILES["fileUP"]["name"]). " has been uploaded.";
			        //UPDATE TO USER
			        $sql = " update tbl_employee set prof_backimg='$target_file2'  where employee_id='$uid' ";
					$qry = mysqli_query($conn,$sql);
					//SAVE TO UPLOADED FILES
			        $sql = " insert into tbl_upfiles
			        			 (name,location,date_uploaded)
			        		 values
			        		 	 ('$foname','$target_file2','$cdate') ";
					$qry = mysqli_query($conn,$sql);
			    } else {
			        //echo "Sorry, there was an error uploading your file.";
			    }
			}
		}
		//===========================================================================================================
		//REQUIREMENTS
		//===========================================================================================================
		if(isset($_POST["btnReqSave"])) {
			$errn = 0;
			$act = $_POST['action'];
			echo "$act";
			$tsn = "";
			$tsn = "resume";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			$tsn = "appletter";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			$tsn = "moa";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			$tsn = "mou";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			$tsn = "certacc";
			if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
				$errn = $errn + 1;
			}
			if ( $errn > 0 ) {
				// Check file size
				if ($_FILES["fileUP"]["size"] > 500000) {
				    //echo "Sorry, your file is too large.";
				    //$uploadOk = 0;
				}
				if($imageFileType != "doc" && $imageFileType != "docx" && $imageFileType != "pdf" ) {
				    $uploadOk = 0;
				}
				if ($uploadOk == 0) {
				    //echo "Sorry, your file was not uploaded.";
				} else {
					//GET NEW NAME
					$fln = "file_".$date_month."_".$date_day."_".$date_year."__".$date_hour."_".$date_minute."_".$date_second.".".$imageFileType;
				    $target_file2 = $target_dir . "$fln";
				    if (move_uploaded_file($_FILES["fileUP"]["tmp_name"], $target_file2)) {
				        //echo "The file ". basename( $_FILES["fileUP"]["name"]). " has been uploaded.";
				        $rtype = "";
				        $rname = "";
						$tsn = "resume";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "Resume";
							$rtype = "requirement:resume";
						}
						$tsn = "appletter";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "Application Letter";
							$rtype = "requirement:application_letter";
						}
						$tsn = "moa";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "MOA";
							$rtype = "requirement:moa";
						}
						$tsn = "mou";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "MOU";
							$rtype = "requirement:mou";
						}
						$tsn = "certacc";
						if ( strtolower(trim($act))==strtolower(trim($tsn)) ) {
							$rname = "Certification of Acceptance";
							$rtype = "requirement:certification_of_acceptance";
						}
				        //UPDATE TO EMPLOYEE
				        $sql = " insert into tbl_employee_requirements 
				        			(name,req_type,req_file,date_added,employee_id)
				        		values
				        			('$rname','$rtype','$target_file2','$cdate','$uid')
				         ";
						$qry = mysqli_query($conn,$sql);
						//SAVE TO UPLOADED FILES
				        $sql = " insert into tbl_upfiles
				        			 (name,location,date_uploaded)
				        		 values
				        		 	 ('$foname','$target_file2','$cdate') ";
						$qry = mysqli_query($conn,$sql);
				    } else {
				        //echo "Sorry, there was an error uploading your file.";
				    }
				}
			}
		}
		//
		if ( $_POST['btnsaveSendMessage'] ) {
			$rcv_id = $_POST['txtid'];
			$rcv_type = $_POST['txttype'];
			//
			$snd_id = $_SESSION['intern_data_cun'];
			$snd_type = $_SESSION['intern_data_utype'];
			//
			$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
			//
			$msg = $_POST['msg'];
			//
			$errmsg = "";
			$errn = 0;
			if ( trim($msg) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Enter a message. ";
			}
			if ( $errn <= 0 ) {
				//SAVE DATA
				if ( trim($rcv_id)!="" && trim($snd_id)!="" && ($msg)!="" ) {
					$sql = "
							insert into tbl_messages
								(rcv_id,rcv_type,snd_id,snd_type,message,date_sent) 
							values 
								('$rcv_id','$rcv_type','$snd_id','$snd_type','$msg','$cdate') 
							";
					$qry = mysqli_query($conn,$sql);
				}
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
			}
		}
	}
	//
	//
	//
	if ( $_POST['btnsaveUpdateInfo'] ) {
		$cid = $_POST['txtid'];
		//
		$id = $_POST['employee_id'];
		$fname = $_POST['fname'];
		$mname = $_POST['mname'];
		$lname = $_POST['lname'];
		$gender = $_POST['gender'];
		$position = $_POST['position'];
		$email = $_POST['email'];
		$contact_no = $_POST['contactno'];
		$address = $_POST['address'];
		$errn = 0;
		$errmsg = "";
		if ( trim($id) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Employee ID required. ";
		}
		if ( trim($fname) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Firstname required. ";
		}
		if ( trim($lname) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Lastname required. ";
		}
		if ( trim($position) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Position required. ";
		}
		if ( trim($email) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "E-mail required. ";
		}
		if ( trim($contact_no) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Contact # required. ";
		}
		if ( trim($address) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Address required. ";
		}
		if ( $errn <= 0 ) {
			//SAVE DATA
			$sql = " update  tbl_employee  set  
						employee_id='$id',firstname='$fname',middlename='$mname',lastname='$lname',gender='$gender',position='$position',email='$email',contact_no='$contact_no',address='$address' 
							where employee_id='$cid' 
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
			echo "
				<script>
					alert('$errmsg');
				</script>
			";
		}
	}
	//
	if ( $_POST['btnsaveUpdateInfoPassword'] ) {
		$curid = $_POST['txtid'];
		//
		$npass1 = "";
		$npass2 = "";
		//
		$opass = $_POST['opass'];
		$npass1 = $_POST['npass1'];
		$npass2 = $_POST['npass2'];
		//
		$errn = 0;
		$errmsg = "";
		//
		if ( trim($npass1)=="" ){
			$errn = $errn + 1;
			$errmsg = $errmsg . "Password must not be empty. ";
		}
		if ( $npass1 != $npass2 ){
			$errn = $errn + 1;
			$errmsg = $errmsg . "New passwords don't match. ";
		}
		if ( strlen($npass1) < 4 ){
			$errn = $errn + 1;
			$errmsg = $errmsg . "Password must be greater than or equal to 4 characters. ";
		}
		$sql = " select password from tbl_employee where employee_id='$curid' ";
		$qry = mysqli_query($conn,$sql);
		$scn = 0;
		while($dat=mysqli_fetch_array($qry)) {
			if ( $dat[0]==$opass ) {
				$scn += 1;
			}
		}
		if ( $scn <= 0 ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Invalid current password. ";
		}
		//
		if ( $errn <= 0 ) {
			//SAVE
			$sql = " update tbl_employee set 
						password='$npass1'  
						where studentid='$curid' 
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
				echo "
					<script>
						alert('Password successfully changed');
					</script>
				";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
		}
	}
	//
	//
	//MSGS LOG UPDATER
	include "./parts/msgs_logupdater.php";
?>