<?php include "./data/connect.php"; include "./parts/sys_functions_02.php";
	$uid = $_GET['aid'];
	$uidtype = $_GET['atype'];
	//
	$idname = "";
	//
$memid =  $_SESSION['intern_data_cun'];
$memtype = $_SESSION['intern_data_utype'];
//
	if ( trim($uid)!="" ) {
		$sql = " select hte_id,name from tbl_hte  where hte_id='$uid' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			$idname = trim($dat[1]);
		}
	}
	if ( trim($uid)!="" ) {
		//
		if(isset($_POST["btnAddAnnouncement"])) {
			//
			$subj = htmlspecialchars( $_POST['txtsubject'] , ENT_QUOTES );
			$msg = htmlspecialchars( $_POST['txtmsg'] , ENT_QUOTES );
			//
			$target_dir = "uploads/";
			$foname = basename($_FILES["fileUP"]["name"]);
			$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
			$target_file = $target_dir . $foname;
			$target_file2 = "";
			$uploadOk = 1;
			$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
			// Check if image file is a actual image or fake image
		    // Check file size
			if ($_FILES["fileUP"]["size"] > 500000) {
			    //echo "Sorry, your file is too large.";
			    //$uploadOk = 0;
			}
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" && $imageFileType != "bmp" && $imageFileType != "ico"
			&& $imageFileType != "doc" && $imageFileType != "docx" && $imageFileType != "pdf" ) {
			    $uploadOk = 0;
			}
			if ($uploadOk == 0) {
			    //echo "Sorry, your file was not uploaded.";
			} else {
				//GET NEW NAME
				$fln = "file_".$date_month."_".$date_day."_".$date_year."__".$date_hour."_".$date_minute."_".$date_second.".".$imageFileType;
			    $target_file2 = $target_dir . "$fln";
			    if (move_uploaded_file($_FILES["fileUP"]["tmp_name"], $target_file2)) {
			        //echo "The file ". basename( $_FILES["fileUP"]["name"]). " has been uploaded.";
			        //SAVE ANNOUNCE MENT
			        $sql = " insert into tbl_announcement
			        			 (ann_id,ann_type,pdate,subject,msg,cfile,by_id,by_type)
			        		 values
			        		 	 ('$uid','$uidtype','$cdate','$subj','$msg','$target_file2','$memid','$memtype') ";
					$qry = mysqli_query($conn,$sql);
					//SAVE TO UPLOADED FILES
			        $sql = " insert into tbl_upfiles
			        			 (name,location,date_uploaded,upby_id,upby_type,utype,uloc_id,uloc_type)
			        		 values
			        		 	 ('$foname','$target_file2','$cdate','$memid','$memtype','announcement','$uid','$uidtype') ";
					$qry = mysqli_query($conn,$sql);
					//NOTIFICATION
					$notif_ttl = "Announcement posted.";
					$notif_lnk = "";
					$notif_cont = "$idname: Announcement posted.";
					$notif_locid = "$uid";
					$notif_loctype = "$uidtype";
					$notif_tarsn = "page_announcement";
					$notif_status = "unseen";
					addNotification($memid,$memtype,$notif_ttl,$notif_lnk,$notif_cont,$notif_locid,$notif_loctype,$notif_tarsn,$notif_status);
			    } else {
			        //echo "Sorry, there was an error uploading your file.";
			    }
			}
			if ( trim($foname)=="" ) {
				if ( trim($msg)!="" ) {
			        //SAVE ANNOUNCE MENT
			        $sql = " insert into tbl_announcement
			        			 (ann_id,ann_type,pdate,subject,msg,cfile,by_id,by_type)
			        		 values
			        		 	 ('$uid','$uidtype','$cdate','$subj','$msg','$target_file2','$memid','$memtype') ";
					$qry = mysqli_query($conn,$sql);
					//NOTIFICATION
					$notif_ttl = "Announcement posted.";
					$notif_lnk = "";
					$notif_cont = "$idname: Announcement posted.";
					$notif_locid = "$uid";
					$notif_loctype = "$uidtype";
					$notif_tarsn = "page_announcement";
					$notif_status = "unseen";
					addNotification($memid,$memtype,$notif_ttl,$notif_lnk,$notif_cont,$notif_locid,$notif_loctype,$notif_tarsn,$notif_status);
				}
			}
		}
		//
		//
		if(isset($_POST["btnsaveEdit"])) {
			//
			$did = $_POST['txtid'];
			$subj = htmlspecialchars( $_POST['txtsubject'] , ENT_QUOTES );
			$msg = htmlspecialchars( $_POST['txtmsg'] , ENT_QUOTES );
			echo "
				<script>
					//alert('$did $msg');
				</script>
			";
			//
			$target_dir = "uploads/";
			$foname = basename($_FILES["fileUP"]["name"]);
			$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
			$target_file = $target_dir . $foname;
			$target_file2 = "";
			$uploadOk = 1;
			$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
			// Check if image file is a actual image or fake image
		    // Check file size
			if ($_FILES["fileUP"]["size"] > 500000) {
			    //echo "Sorry, your file is too large.";
			    //$uploadOk = 0;
			}
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" && $imageFileType != "bmp" && $imageFileType != "ico"
			&& $imageFileType != "doc" && $imageFileType != "docx" && $imageFileType != "pdf" ) {
			    $uploadOk = 0;
			}
			if ($uploadOk == 0) {
			    //echo "Sorry, your file was not uploaded.";
			} else {
				//GET NEW NAME
				$fln = "file_".$date_month."_".$date_day."_".$date_year."__".$date_hour."_".$date_minute."_".$date_second.".".$imageFileType;
			    $target_file2 = $target_dir . "$fln";
			    if (move_uploaded_file($_FILES["fileUP"]["tmp_name"], $target_file2)) {
			        //echo "The file ". basename( $_FILES["fileUP"]["name"]). " has been uploaded.";
			        //SAVE ANNOUNCE MENT
			        $sql = " update tbl_announcement set 
			        			 subject='$subj',msg='$msg',cfile='$target_file2' 
			        		 	where announcement_id='$did' 
			        		  ";
					$qry = mysqli_query($conn,$sql);
					//SAVE TO UPLOADED FILES
			        $sql = " insert into tbl_upfiles
			        			 (name,location,date_uploaded,upby_id,upby_type,utype,uloc_id,uloc_type)
			        		 values
			        		 	 ('$foname','$target_file2','$cdate','$memid','$memtype','announcement','$uid','$uidtype') ";
					$qry = mysqli_query($conn,$sql);
			    } else {
			        //echo "Sorry, there was an error uploading your file.";
			    }
			}
			if ( trim($foname)=="" ) {
				if ( trim($msg)!="" ) {
			        //SAVE ANNOUNCE MENT
			        $sql = " update tbl_announcement set 
			        			 subject='$subj',msg='$msg' 
			        		 	where announcement_id='$did' 
			        		  ";
					$qry = mysqli_query($conn,$sql);
				}
			}
		}
		//
		//
		if(($_POST["btnsaveDelete"])) {
			//
			$did = $_POST['txtid'];
			//
			if ( trim($did)!="" ) {
			        //DELETE
			        $sql = " delete from tbl_announcement 
			        		 	where announcement_id='$did' 
			        		  ";
					$qry = mysqli_query($conn,$sql);
			}
		}
	}
	if ( trim($uid)!="" ) {
//=================================================================================================
		//
//====================================================================================
		if ( $_POST['btnsaveSendMessage'] ) {
			$rcv_id = $_POST['txtstudid'];
			$rcv_type = $_POST['txtstudtype'];
			//
			$snd_id = $_SESSION['intern_data_cun'];
			$snd_type = $_SESSION['intern_data_utype'];
			//
			$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
			//
			$msg = htmlspecialchars( $_POST['msg'] , ENT_QUOTES );
			//
			$errmsg = "";
			$errn = 0;
			if ( trim($msg) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Enter a message. ";
			}
			if ( $errn <= 0 ) {
				//SAVE DATA
				if ( trim($rcv_id)!="" && trim($snd_id)!="" && ($msg)!="" ) {
					$sql = "
							insert into tbl_messages
								(rcv_id,rcv_type,snd_id,snd_type,message,date_sent) 
							values 
								('$rcv_id','$rcv_type','$snd_id','$snd_type','$msg','$cdate') 
							";
					$qry = mysqli_query($conn,$sql);
				}
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
			}
		}
//====================================================================================
//====================================================================================
		//GET MEMBER COUNT
		function getMemberCount($id,$idtype) {
			include "./data/connect.php";
			//
			$fval = 0;
			//
			$sql = " select coordinator_id,employee_id,course_id from tbl_coordinator  where course_id='$id'  group by employee_id ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				if ( trim($dat[1]) != "" ) {
					$fval = $fval + 1;
				}
			}
			//
			$sql = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns  where course='$id' and reg_status='registered' order by firstname asc ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				if ( trim($dat[0]) != "" ) {
					$fval = $fval + 1;
				}
			}
			//
			return $fval;
		}
//====================================================================================
//====================================================================================

		if ( $_POST['btnsaveStaff'] ) {
			$staff = trim($_POST['txtemployee']);
			$position = trim($_POST['txtposition']);
			//$memid = "1234";
			$errmsg = "";
			$errn = 0;
			//
			if ( trim($memid) == "" || strtolower(trim($memtype))==strtolower(trim("student")) ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "";
			}
			//
			if ( trim($staff) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Staff required. ";
			}
			if ( trim($position) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Position required. ";
			}
			//
			$ec = 0;
			$sql = " select * from tbl_crs_staff  where crs_id='$uid' and staff_id='$staff' and staff_type='employee' ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				$ec = $ec + 1;
			}
			if ( trim($ec) > 0 ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Staff already added. ";
			}
			//
			//
			if ( $errn <= 0 ) {
				//SAVE DATA
				$sql = " insert into tbl_crs_staff 
							(crs_id,staff_id,staff_type,position)
							values
							('$uid','$staff','employee','$position')
						";
				$qry = mysqli_query($conn,$sql);
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
			}
		}

		if ( $_POST['btnsaveStaffRemove'] ) {
			$id = trim($_POST['txtid']);
			//
			$errmsg = "";
			$errn = 0;
			//
			if ( trim($memid) == "" || strtolower(trim($memtype))==strtolower(trim("student")) ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "";
			}
			//
			if ( trim($id) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "";
			}
			//
			//
			if ( $errn <= 0 ) {
				//SAVE DATA
				$sql = " delete from tbl_crs_staff  
							where crs_staff_id='$id' 
						";
				$qry = mysqli_query($conn,$sql);
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				//echo "
				//	<script>
				//		alert('$errmsg');
				//	</script>
				//";
			}
		}
		


		if ( $_POST['btnsaveHTEStaff'] ) {
			$staff = trim($_POST['txtemployee']);
			$position = trim($_POST['txtposition']);
			//$memid = "1234";
			$errmsg = "";
			$errn = 0;
			//
			if ( trim($memid) == "" || strtolower(trim($memtype))==strtolower(trim("student")) ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "";
			}
			//
			if ( trim($staff) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Staff required. ";
			}
			if ( trim($position) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Position required. ";
			}
			//
			$ec = 0;
			$sql = " select * from tbl_hte_staff  where hte_id='$uid' and staff_id='$staff' and staff_type='employee' ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				$ec = $ec + 1;
			}
			if ( trim($ec) > 0 ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Staff already added. ";
			}
			//
			//
			if ( $errn <= 0 ) {
				//SAVE DATA
				$sql = " insert into tbl_hte_staff 
							(hte_id,staff_id,staff_type,position)
							values
							('$uid','$staff','employee','$position')
						";
				$qry = mysqli_query($conn,$sql);
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
			}
		}

		if ( $_POST['btnsaveHTEStaffRemove'] ) {
			$id = trim($_POST['txtid']);
			//
			$errmsg = "";
			$errn = 0;
			//
			if ( trim($memid) == "" || strtolower(trim($memtype))==strtolower(trim("student")) ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "";
			}
			//
			if ( trim($id) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "";
			}
			//
			//
			if ( $errn <= 0 ) {
				//SAVE DATA
				$sql = " delete from tbl_hte_staff  
							where hte_staff_id='$id' 
						";
				$qry = mysqli_query($conn,$sql);
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				//echo "
				//	<script>
				//		alert('$errmsg');
				//	</script>
				//";
			}
		}
//====================================================================================
	}
//====================================================================================
//====================================================================================
//====================================================================================
//====================================================================================
	//MSGS LOG UPDATER
	include "./parts/msgs_logupdater.php";
?>