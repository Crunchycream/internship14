
<link rel="stylesheet prefetch" href="./assets/scripts/chat_css.css">
<script src="./assets/scripts/chat_hoy3lrg.js"></script>
<style type="text/css">
  .tk-proxima-nova{font-family:"proxima-nova",sans-serif;}
</style>
<script>
  try{Typekit.load({ async: true });}catch(e){

  }
</script>
<link rel="stylesheet prefetch" href="./assets/scripts/chat_reset.css">
<link rel="stylesheet prefetch" href="./assets/scripts/chat_font-awesome.css">
<style class="cp-pen-styles">
ul {
  padding-left: 2px;
} 
.chat_mp01 {
  padding-left: 0px;
  margin-left: 0px;
  width: 100%;
}
.chat_mp01_cont {
  width: 100%;
}
#frame_cs01 {
  width: 100%;
  min-width: 360px;
  height: 87vh;
  min-height: 300px;
  max-height: 720px;
  background: #E6EAEA;
    margin-top: 86px;
}
@media screen and (max-width: 766px) {
  #frame_cs01 {
    width: 100%;
    height: 100vh;
    margin-top: 138px;
  }
}
#frame_cs01 #sidepanel_cs01 {
  float: left;
  min-width: 280px;
  max-width: 340px;
  width: 40%;
  height: 100%;
  background: #2c3e50;
  color: #f5f5f5;
  overflow: hidden;
  position: relative;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 {
    width: 58px;
    min-width: 58px;
  }
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 {
  width: 80%;
  margin: 25px auto;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #profile_cs01 {
    width: 100%;
    margin: 0 auto;
    padding: 5px 0 0 0;
    background: #32465a;
  }
}
#frame_cs01 #sidepanel_cs01 #profile_cs01.expanded_cs01 .wrap_cs01 {
  height: 210px;
  line-height: initial;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01.expanded_cs01 .wrap_cs01 p {
  margin-top: 20px;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01.expanded_cs01 .wrap_cs01 i.expand-button_cs01 {
  -moz-transform: scaleY(-1);
  -o-transform: scaleY(-1);
  -webkit-transform: scaleY(-1);
  transform: scaleY(-1);
  filter: FlipH;
  -ms-filter: "FlipH";
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 {
  height: 60px;
  line-height: 60px;
  overflow: hidden;
  -moz-transition: 0.3s height ease;
  -o-transition: 0.3s height ease;
  -webkit-transition: 0.3s height ease;
  transition: 0.3s height ease;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 {
    height: 55px;
  }
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 img {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  padding: 3px;
  border: 2px solid #e74c3c;
  float: left;
  cursor: pointer;
  -moz-transition: 0.3s border ease;
  -o-transition: 0.3s border ease;
  -webkit-transition: 0.3s border ease;
  transition: 0.3s border ease;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 img {
    width: 40px;
    height: 40px;
    margin-left: 4px;
  }
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 img.online {
  border: 2px solid #2ecc71;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 img.away {
  border: 2px solid #f1c40f;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 img.busy {
  border: 2px solid #e74c3c;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 img.offline {
  border: 2px solid #95a5a6;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 p {
  float: left;
  margin-left: 15px;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 p {
    display: none;
  }
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 i.expand-button_cs01 {
  float: right;
  margin-top: 23px;
  font-size: 0.8em;
  cursor: pointer;
  color: #435f7a;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 i.expand-button_cs01 {
    display: none;
  }
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 {
  position: absolute;
  opacity: 0;
  visibility: hidden;
  width: 150px;
  margin: 70px 0 0 0;
  border-radius: 6px;
  z-index: 99;
  line-height: initial;
  background: #435f7a;
  -moz-transition: 0.3s all ease;
  -o-transition: 0.3s all ease;
  -webkit-transition: 0.3s all ease;
  transition: 0.3s all ease;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 {
    width: 58px;
    margin-top: 57px;
  }
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01.active {
  opacity: 1;
  visibility: visible;
  margin: 75px 0 0 0;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01.active {
    margin-top: 62px;
  }
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01:before {
  content: '';
  position: absolute;
  width: 0;
  height: 0;
  border-left: 6px solid transparent;
  border-right: 6px solid transparent;
  border-bottom: 8px solid #435f7a;
  margin: -8px 0 0 24px;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01:before {
    margin-left: 23px;
  }
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul {
  overflow: hidden;
  border-radius: 6px;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li {
  padding: 15px 0 30px 18px;
  display: block;
  cursor: pointer;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li {
    padding: 15px 0 35px 22px;
  }
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li:hover {
  background: #496886;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li span.status-circle_cs01 {
  position: absolute;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  margin: 5px 0 0 0;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li span.status-circle_cs01 {
    width: 14px;
    height: 14px;
  }
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li span.status-circle_cs01:before {
  content: '';
  position: absolute;
  width: 14px;
  height: 14px;
  margin: -3px 0 0 -3px;
  background: transparent;
  border-radius: 50%;
  z-index: 0;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li span.status-circle_cs01:before {
    height: 18px;
    width: 18px;
  }
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li p {
  padding-left: 12px;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li p {
    display: none;
  }
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li#status-online_cs01 span.status-circle_cs01 {
  background: #2ecc71;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li#status-online_cs01.active span.status-circle_cs01:before {
  border: 1px solid #2ecc71;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li#status-away_cs01 span.status-circle_cs01 {
  background: #f1c40f;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li#status-away_cs01.active span.status-circle_cs01:before {
  border: 1px solid #f1c40f;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li#status-busy_cs01 span.status-circle_cs01 {
  background: #e74c3c;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li#status-busy_cs01.active span.status-circle_cs01:before {
  border: 1px solid #e74c3c;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li#status-offline_cs01 span.status-circle_cs01 {
  background: #95a5a6;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #status-options_cs01 ul li#status-offline_cs01.active span.status-circle_cs01:before {
  border: 1px solid #95a5a6;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #expanded_cs01 {
  padding: 100px 0 0 0;
  display: block;
  line-height: initial !important;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #expanded_cs01 label {
  float: left;
  clear: both;
  margin: 0 8px 5px 0;
  padding: 5px 0;
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #expanded_cs01 input {
  border: none;
  margin-bottom: 6px;
  background: #32465a;
  border-radius: 3px;
  color: #f5f5f5;
  padding: 7px;
  width: calc(100% - 43px);
}
#frame_cs01 #sidepanel_cs01 #profile_cs01 .wrap_cs01 #expanded_cs01 input:focus {
  outline: none;
  background: #435f7a;
}
#frame_cs01 #sidepanel_cs01 #search_cs01 {
  border-top: 1px solid #32465a;
  border-bottom: 1px solid #32465a;
  font-weight: 300;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #search_cs01 {
    display: none;
  }
}
#frame_cs01 #sidepanel_cs01 #search_cs01 label {
  position: absolute;
  margin: 10px 0 0 20px;
}
#frame_cs01 #sidepanel_cs01 #search_cs01 input {
  font-family: "proxima-nova",  "Source Sans Pro", sans-serif;
  padding: 10px 0 10px 46px;
  width: calc(100% - 2px);
  border: none;
  background: #32465a;
  color: #f5f5f5;
}
#frame_cs01 #sidepanel_cs01 #search_cs01 input:focus {
  outline: none;
  background: #435f7a;
}
#frame_cs01 #sidepanel_cs01 #search_cs01 input::-webkit-input-placeholder {
  color: #f5f5f5;
}
#frame_cs01 #sidepanel_cs01 #search_cs01 input::-moz-placeholder {
  color: #f5f5f5;
}
#frame_cs01 #sidepanel_cs01 #search_cs01 input:-ms-input-placeholder {
  color: #f5f5f5;
}
#frame_cs01 #sidepanel_cs01 #search_cs01 input:-moz-placeholder {
  color: #f5f5f5;
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01 {
  height: calc(100% - 177px);
  overflow-y: scroll;
  overflow-x: hidden;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #contacts_cs01 {
    height: calc(100% - 149px);
    overflow-y: scroll;
    overflow-x: hidden;
  }
  #frame_cs01 #sidepanel_cs01 #contacts_cs01::-webkit-scrollbar {
    display: none;
  }
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01.expanded_cs01 {
  height: calc(100% - 334px);
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01::-webkit-scrollbar {
  width: 8px;
  background: #2c3e50;
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01::-webkit-scrollbar-thumb {
  background-color: #243140;
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01 {
  position: relative;
  padding: 10px 0 15px 0;
  font-size: 0.9em;
  cursor: pointer;
  list-style-type:none;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01 {
    padding: 6px 0 46px 8px;
  }
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01:hover {
  background: #32465a;
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01.active {
  background: #32465a;
  border-right: 5px solid #435f7a;
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01.active span.contact-status_cs01 {
  border: 2px solid #32465a !important;
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01 .wrap_cs01 {
  width: 88%;
  margin: 0 auto;
  position: relative;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01 .wrap_cs01 {
    width: 100%;
  }
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01 .wrap_cs01 span {
  position: absolute;
  left: 0;
  margin: -2px 0 0 -2px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  border: 2px solid #2c3e50;
  background: #95a5a6;
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01 .wrap_cs01 span.online {
  background: #2ecc71;
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01 .wrap_cs01 span.away {
  background: #f1c40f;
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01 .wrap_cs01 span.busy {
  background: #e74c3c;
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01 .wrap_cs01 img {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  float: left;
  margin-right: 10px;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01 .wrap_cs01 img {
    margin-right: 0px;
  }
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01 .wrap_cs01 .meta_cs01 {
  padding: 5px 0 0 0;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01 .wrap_cs01 .meta_cs01 {
    display: none;
  }
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01 .wrap_cs01 .meta_cs01 .name_cs01 {
  font-weight: 600;
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01 .wrap_cs01 .meta_cs01 .preview_cs01 {
  margin: 5px 0 0 0;
  padding: 0 0 1px;
  font-weight: 400;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  -moz-transition: 1s all ease;
  -o-transition: 1s all ease;
  -webkit-transition: 1s all ease;
  transition: 1s all ease;
}
#frame_cs01 #sidepanel_cs01 #contacts_cs01 ul li.contact_cs01 .wrap_cs01 .meta_cs01 .preview_cs01 span {
  position: initial;
  border-radius: initial;
  background: none;
  border: none;
  padding: 0 2px 0 0;
  margin: 0 0 0 1px;
  opacity: .5;
}
#frame_cs01 #sidepanel_cs01 #bottom-bar_cs01 {
  position: absolute;
  width: 100%;
  bottom: 0;
}
#frame_cs01 #sidepanel_cs01 #bottom-bar_cs01 button {
  float: left;
  border: none;
  width: 50%;
  padding: 10px 0;
  background: #32465a;
  color: #f5f5f5;
  cursor: pointer;
  font-size: 0.85em;
  font-family: "proxima-nova",  "Source Sans Pro", sans-serif;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #bottom-bar_cs01 button {
    float: none;
    width: 100%;
    padding: 15px 0;
  }
}
#frame_cs01 #sidepanel_cs01 #bottom-bar_cs01 button:focus {
  outline: none;
}
#frame_cs01 #sidepanel_cs01 #bottom-bar_cs01 button:nth-child(1) {
  border-right: 1px solid #2c3e50;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #bottom-bar_cs01 button:nth-child(1) {
    border-right: none;
    border-bottom: 1px solid #2c3e50;
  }
}
#frame_cs01 #sidepanel_cs01 #bottom-bar_cs01 button:hover {
  background: #435f7a;
}
#frame_cs01 #sidepanel_cs01 #bottom-bar_cs01 button i {
  margin-right: 3px;
  font-size: 1em;
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #bottom-bar_cs01 button i {
    font-size: 1.3em;
  }
}
@media screen and (max-width: 735px) {
  #frame_cs01 #sidepanel_cs01 #bottom-bar_cs01 button span {
    display: none;
  }
}
#frame_cs01 .content_cs01 {
  float: right;
  width: 60%;
  height: 100%;
  overflow: hidden;
  position: relative;
}
@media screen and (max-width: 735px) {
  #frame_cs01 .content_cs01 {
    width: calc(100% - 58px);
    min-width: 300px !important;
  }
}
@media screen and (min-width: 900px) {
  #frame_cs01 .content_cs01 {
    width: calc(100% - 340px);
  }
}
#frame_cs01 .content_cs01 .contact-profile_cs01 {
  width: 100%;
  height: 60px;
  line-height: 60px;
  background: #f5f5f5;
}
#frame_cs01 .content_cs01 .contact-profile_cs01 img {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  float: left;
  margin: 9px 12px 0 9px;
}
#frame_cs01 .content_cs01 .contact-profile_cs01 p {
  float: left;
}
#frame_cs01 .content_cs01 .contact-profile_cs01 .social-media_cs01 {
  float: right;
}
#frame_cs01 .content_cs01 .contact-profile_cs01 .social-media_cs01 i {
  margin-left: 14px;
  cursor: pointer;
}
#frame_cs01 .content_cs01 .contact-profile_cs01 .social-media_cs01 i:nth-last-child(1) {
  margin-right: 20px;
}
#frame_cs01 .content_cs01 .contact-profile_cs01 .social-media_cs01 i:hover {
  color: #435f7a;
}
#frame_cs01 .content_cs01 .messages_cs01 {
  height: auto;
  min-height: calc(100% - 93px);
  max-height: calc(100% - 93px);
  overflow-y: scroll;
  overflow-x: hidden;
}
@media screen and (max-width: 735px) {
  #frame_cs01 .content_cs01 .messages_cs01 {
    max-height: calc(100% - 105px);
  }
}
#frame_cs01 .content_cs01 .messages_cs01::-webkit-scrollbar {
  width: 8px;
  background: transparent;
}
#frame_cs01 .content_cs01 .messages_cs01::-webkit-scrollbar-thumb {
  background-color: rgba(0, 0, 0, 0.3);
}
#frame_cs01 .content_cs01 .messages_cs01 ul li {
  display: inline-block;
  clear: both;
  float: left;
  margin: 15px 15px 5px 15px;
  width: calc(100% - 25px);
  font-size: 0.9em;
}
#frame_cs01 .content_cs01 .messages_cs01 ul li:nth-last-child(1) {
  margin-bottom: 20px;
}
#frame_cs01 .content_cs01 .messages_cs01 ul li.sent img {
  margin: 6px 8px 0 0;
}
#frame_cs01 .content_cs01 .messages_cs01 ul li.sent p {
  background: #435f7a;
  color: #f5f5f5;
}
#frame_cs01 .content_cs01 .messages_cs01 ul li.replies img {
  float: right;
  margin: 6px 0 0 8px;
}
#frame_cs01 .content_cs01 .messages_cs01 ul li.replies p {
  background: #f5f5f5;
  float: right;
}
#frame_cs01 .content_cs01 .messages_cs01 ul li img {
  width: 22px;
  border-radius: 50%;
  float: left;
}
#frame_cs01 .content_cs01 .messages_cs01 ul li p {
  display: inline-block;
  padding: 10px 15px;
  border-radius: 20px;
  max-width: 90%;
  line-height: 130%;
}
@media screen and (max-width: 766px) {
  #frame_cs01 .content_cs01 .messages_cs01 ul li p {
    max-width: 80%;
  }
}
#frame_cs01 .content_cs01 .message-input_cs01 {
  position: absolute;
  bottom: 0;
  width: 100%;
  z-index: 99;
}
#frame_cs01 .content_cs01 .message-input_cs01 .wrap_cs01 {
  position: relative;
}
#frame_cs01 .content_cs01 .message-input_cs01 .wrap_cs01 input {
  font-family: "proxima-nova",  "Source Sans Pro", sans-serif;
  float: left;
  border: none;
  width: calc(100% - 90px);
  padding: 11px 32px 15px 8px;
  font-size: 0.8em;
  color: #32465a;
}
@media screen and (max-width: 735px) {
  #frame_cs01 .content_cs01 .message-input_cs01 .wrap_cs01 input {
    padding: 15px 32px 16px 8px;
  }
}
#frame_cs01 .content_cs01 .message-input_cs01 .wrap_cs01 input:focus {
  outline: none;
}
#frame_cs01 .content_cs01 .message-input_cs01 .wrap_cs01 .attachment_cs01 {
  position: absolute;
  right: 60px;
  z-index: 4;
  margin-top: 10px;
  font-size: 1.1em;
  color: #435f7a;
  opacity: .5;
  cursor: pointer;
}
@media screen and (max-width: 735px) {
  #frame_cs01 .content_cs01 .message-input_cs01 .wrap_cs01 .attachment_cs01 {
    margin-top: 17px;
    right: 65px;
  }
}
#frame_cs01 .content_cs01 .message-input_cs01 .wrap_cs01 .attachment_cs01:hover {
  opacity: 1;
}
#frame_cs01 .content_cs01 .message-input_cs01 .wrap_cs01 button {
  float: right;
  border: none;
  width: 50px;
  padding: 12px 0;
  cursor: pointer;
  background: #32465a;
  color: #f5f5f5;
}
@media screen and (max-width: 735px) {
  #frame_cs01 .content_cs01 .message-input_cs01 .wrap_cs01 button {
    padding: 16px 0;
  }
}
#frame_cs01 .content_cs01 .message-input_cs01 .wrap_cs01 button:hover {
  background: #435f7a;
}
#frame_cs01 .content_cs01 .message-input_cs01 .wrap_cs01 button:focus {
  outline: none;
}
.chat_mp01_btn01 {
  float: right;
  border: none;
  width: 20px;
  min-width: 20px;
  max-width: 50px;
  padding: 0px;
  cursor: pointer;
  background: #32465a;
  color: #fff;
  position: absolute;
  font-size: 1em;
  right: 0px;
  display: inline;
  text-align: center;
}
@media screen and (max-width: 735px) {
  .chat_mp01_btn01 {
    padding: 16px 0;
  }
}
.chat_mp01_btn01:hover {
  background: #435f7a;
}
.chat_mp01_btn01:focus {
  outline: none;
}
.chat_mp01_btn01,.chat_mp01_btn01:active,.chat_mp01_btn01:focus,.chat_mp01_btn01:hover,.chat_mp01_btn01 a,.chat_mp01_btn01 a:hover {
  color: #ffffff;
}
.chat_mp01_link01,.chat_mp01_link01:hover,.chat_mp01_link01:visited,.chat_mp01_link01:active {
  color: #fff;
}
.msgs_img01212 {
  width: 50px;
  height: 50px;
}
</style>