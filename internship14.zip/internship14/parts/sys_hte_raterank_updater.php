<?php error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php"; include "./parts/sys_functions.php";
	//
	$sy = trim($_SESSION['intern_data_active_sy']);
	//
	$sql = " select hte_id,dsn,name,address from tbl_hte  group by hte_id  ";
	$qry = mysqli_query($conn,$sql);
	while($dat=mysqli_fetch_array($qry)) {
		$id = trim($dat[0]);
		if ( trim($id)!="" ) {
			$rate = getHTERate3_2($id,$sy);
			if ( getHTEisRated3($id,$sy)==false ) {
				//INSERT
				$sql01 = " 
							insert into tbl_hte_raterank
							(hte_id,total_rate,sy)
							values
							('$id','$rate','$sy')
				";
				$qry01 = mysqli_query($conn,$sql01);
			}else{
				//UPDATE
				$sql01 = " 
							update tbl_hte_raterank set 
							total_rate='$rate' 
								where hte_id='$id' and sy='$sy'
				";
				$qry01 = mysqli_query($conn,$sql01);
			}
		}
	}
//==============================================================
	$sql = " select studentid from tbl_interns  group by studentid  ";
	$qry = mysqli_query($conn,$sql);
	while($dat=mysqli_fetch_array($qry)) {
		$id = trim($dat[0]);
		if ( trim($id)!="" ) {
			$rate = getInternRate3($id,$sy);
			if ( getInternisRated3($id,$sy)==false ) {
				//INSERT
				$sql01 = " 
							insert into tbl_interns_raterank
							(studentid,total_rate,sy)
							values
							('$id','$rate','$sy')
				";
				$qry01 = mysqli_query($conn,$sql01);
			}else{
				//UPDATE
				$sql01 = " 
							update tbl_interns_raterank set 
							total_rate='$rate' 
							where studentid='$id' and sy='$sy'
				";
				$qry01 = mysqli_query($conn,$sql01);
			}
		}
	}
?>