
		<!-- ====================== ADD ANNOUNCEMENT ============================== -->
		<div id="modalAddJobPost" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header" align="left">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Post Jobs</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					<?php
						$cid = trim($_GET['id']);
						echo "<iframe class='div_jp_frame01' src='./s_jobposts_create.php?hte_id=' frameborder='0'></iframe>";
					?>
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ====================== ADD ANNOUNCEMENT ============================== -->