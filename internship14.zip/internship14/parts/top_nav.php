<?php
	//MSGS LOG UPDATER
	//include "./parts/msgs_logupdater.php";
?>
<script type="text/javascript">
	
</script>
<!-- === UPDATER =================================================================== -->
	<div id="msgcountc">
		<div id="msgcountcs">
			<?php include "./data/connect.php";
				//
				$logun = $_SESSION['intern_data_cun'];
				$logutype = $_SESSION['intern_data_utype'];
				//
				//
				$count = 0;
				//
				$sql2 = " select * from tbl_messages  ";
				$qry2 = mysqli_query($conn,$sql2);
				while($dat2=mysqli_fetch_array($qry2)) {
					$count += 1;
				}
				//
				echo "<input type='hidden' id='d_msgcount' value='$count' />";
			?>
		</div>
	</div>
	<div id="msglogsup">
		<div id="msglogsups">
			<?php include "./data/connect.php";
				include "./parts/msgs_logupdater.php";
			?>
		</div>
	</div>
<!-- === UPDATER =================================================================== -->

<nav class="navbar navbar-default navbar-fixed-top">
<div class="brand">
	<a href="./cpanel.php"><img src="assets/img/logo_oims.png" alt="Logo" class="img-responsive logo"></a>
</div>
<div class="container-fluid">
	<div class="navbar-btn">
		<button type="button" class="btn-toggle-fullwidth"><i class="lnr lnr-arrow-left-circle"></i></button>
	</div>
	<form class="navbar-form navbar-left" action="./page_search.php" method="get">
		<div class="input-group">
			<input type="text" name="search" class="form-control" placeholder="Search..." 
				<?php
					$val = $_GET['search'];
					echo " value='$val' ";
				?>
			/>
			<span class="input-group-btn"><button type="submit" class="btn btn-primary">Go</button></span>
		</div>
	</form>
<!-- navbar -->
	<div id="navbar-menu">
			<div id="topmsgl">
			<div id="topmsgls">
		<ul class="nav navbar-nav navbar-right">

<?php include "./data/connect.php";
	$curid = $_SESSION['intern_data_cun'];
	$curidtype = $_SESSION['intern_data_utype'];
	if ( strtolower(trim($curid))!=strtolower(trim("admin")) && strtolower(trim($curidtype))!=strtolower(trim("admin")) ) {
		echo "
			<li class='dropdown'>
				<a href='#' onclick='' class='dropdown-toggle icon-menu' data-toggle='dropdown'>
					<i class='lnr lnr-alarm'></i>
				</a>
				<ul class='dropdown-menu notifications'>
			";
					
						if ( trim($curid)!="" ) {
							//GET DATA
							$nn = 0;
							//                  0        1         2       3         4             5          6    7
							$sql = " select notif_id,date_added,user_id,user_type,location_id,location_type,title,content from tbl_notifications  where user_id='$curid'  order by date_added desc  limit 5 ";
							$qry = mysqli_query($conn,$sql);
							while($dat=mysqli_fetch_array($qry)) {
								if ( trim($dat[2])!="" ) {
									$link = "";
									$cont = trim($dat[7]);
									//
									$name = "";
									$img = "";
									//
									$tsn = "class";
									if ( strtolower(trim($tsn)) == strtolower(trim($dat[5])) ) {
										$link = "./page_class.php?id=" . trim($dat[4]);
										//GET INFO
										//                  0      1     2            3         4
										$sql2 = " select class_id,name,date_created,prof_img,prof_backimg from tbl_class  where class_id='$dat[4]'  ";
										$qry2 = mysqli_query($conn,$sql2);
										while($dat2=mysqli_fetch_array($qry2)) {
											$name = trim($dat2[1]);
											$img = trim($dat2[4]);
										}
									}
									//
									$tsn = "hte";
									if ( strtolower(trim($tsn)) == strtolower(trim($dat[5])) ) {
										$link = "./page_hte.php?id=" . trim($dat[4]);
										//GET INFO
										//                  0      1   2
										$sql2 = " select hte_id,name,prof_backimg from tbl_hte  where hte_id='$dat[4]'  ";
										$qry2 = mysqli_query($conn,$sql2);
										while($dat2=mysqli_fetch_array($qry2)) {
											$name = trim($dat2[1]);
											$img = trim($dat2[2]);
										}
									}
									//
									if ( trim($img)=="" ) {
										$img = "./assets/img/notif_empty.png";
									}
									echo "
										<li>
											<a href='$link' class='notification-item'>
											<table>
												<tr>
													<td>
														<img src='$img' class='msgnotif_img01' />
													</td>
													<td>
														<span class='span02'>
															<span class='msgnotif_ttl01'>$name</span>
															<br/>
															<span class='msgnotif_cont01'>$cont</span>
														</span>
													</td>
												</tr>
											</table>
											</a>
										</li>
									";
									$nn = $nn + 1;
								}
							}
							if ( $nn <= 0 ) {
									echo "
										<li>
											<a href='' class='notification-item'>
											<span class='dot bg-warning'></span><span class='span02'>No notifications yet.</span>
											</a>
										</li>
									";
							}else{
								echo "<li><a href='./notifications.php' class='more'>See all notifications</a></li>";
							}
						}
		echo "
				</ul>
			</li>
			<li class='dropdown'>
				<a href='#' class='dropdown-toggle icon-menu' data-toggle='dropdown'>
					<i class='lnr lnr-envelope'></i>
				</a>
				<ul class='dropdown-menu notifications'>
			";
						$curlog = $_SESSION['intern_data_cun'];
						$curlogtype = $_SESSION['intern_data_utype'];
					//
					$curid = trim($_GET['id']);
					//
					$nn = 0;
					//
					//
						$link = "";
						//
						$tmgid = "";
						//
						$name = "";
						$img = "";
						$msg = "";
						$msgby = "";
						$msgn = 0;
						//
						//GET LAST MESSAGE
						$msg = "";
						$msgby = "";
						$msgn = 0;
						$trcvid = "";
						$trcvidt = "";
						$tsndid = "";
						$tsndidt = "";
						$tmsg = "";
						$tdate = "";
						//
						$msggid = "";
						//
						//GET CURRENT USER MSGS ID
						$dgids = "";
						$sql2 = " select msgs_group_id,mem1_id,mem1_type,mem2_id,mem2_type from tbl_messages_group  where ( mem1_id='$curlog' and mem1_type='$curlogtype' ) or ( mem2_id='$curlog' and mem2_type='$curlogtype' ) ";
						$qry2 = mysqli_query($conn,$sql2);
						while($dat2=mysqli_fetch_array($qry2)) {
							if ( trim($dgids)=="" ) {
								$dgids = " msgs_group_id='$dat2[0]' ";
							}else{
								$dgids = $dgids . " or msgs_group_id='$dat2[0]' ";
							}
						}
						//
						if ( trim($dgids)!="" ) {
							$dgids = " where " . $dgids;
						}
						if ( trim($dgids)!="" ) {
				//==========================================================
							//
							//                   0     1       2       3       4        5        6       7       8
							$sql2 = " select rcv_id,rcv_type,snd_id,snd_type,message,date_sent,own_id,own_type,msgs_group_id from tbl_messages_log  $dgids order by date_sent desc ";
							$qry2 = mysqli_query($conn,$sql2);
							while($dat2=mysqli_fetch_array($qry2)) {
								//
								$link = "./page_messages.php";
								//
								$tmgid = trim($dat2[8]);
								//
								$name = "";
								$img = "";
								$msg = "";
								$msgby = "";
								$msgn = 0;
								//
								//GET LAST MESSAGE
								$msg = "";
								$msgby = "";
								$msgn = 0;
								$trcvid = "";
								$trcvidt = "";
								$tsndid = "";
								$tsndidt = "";
								$tmsg = "";
								$tdate = "";
								//
								if ( trim($dat2[0])!="" && trim($dat2[2])!="" ) {
									$msgn = 0;
									if ( $msgn <= 0 ) {
										$msg = $dat2[4];
										if ( strtolower(trim($curlog)) == strtolower(trim($dat2[2])) ) {
											//$msgby = "You:";
										}else{
											//$msgby = "";
										}
										$msgn = $msgn + 1;
										//FOR LOGS
										$trcvid = $dat2[0];
										$trcvidt = $dat2[1];
										$tsndid = $dat2[2];
										$tsndidt = $dat2[3];
										$tmsg = $dat2[4];
										$tdate = $dat2[5];
										//
									}
									//
									$tfid = "";
									$tfidt = "";
									//
									$tfid = $trcvid;
									$tfidt = $trcvidt;
									//
									if ( strtolower(trim($trcvidt)) == strtolower(trim($tsndidt)) ) {
										if ( strtolower(trim($trcvid)) != strtolower(trim($tsndid)) ) {
											if ( strtolower(trim($curlog))!=strtolower(trim($trcvid)) ) {
												$tfid = $trcvid;
												$tfidt = $trcvidt;
											}else{
												$tfid = $tsndid;
												$tfidt = $tsndidt;
											}
										}else{
											$tfid = $trcvid;
											$tfidt = $trcvidt;
										}
									}
										//
										//
										if ( strtolower(trim($trcvidt))==strtolower(trim("employee")) || strtolower(trim($tsndidt))==strtolower(trim("employee")) ) {

											if ( strtolower(trim($trcvid))!=strtolower(trim($tsndid)) && strtolower(trim($trcvidt))!=strtolower(trim($tsndidt)) ) {
												if ( strtolower(trim($curlog))!=strtolower(trim($tsndid)) && strtolower(trim($curlogtype))!=strtolower(trim($tsndidt)) &&
													 strtolower(trim($curlog))==strtolower(trim($trcvid)) && strtolower(trim($curlogtype))==strtolower(trim($trcvidt))
												 ) {

													$tfid = $tsndid;
													$tfidt = $tsndidt;

												}
												if ( strtolower(trim($curlog))==strtolower(trim($tsndid)) && strtolower(trim($curlogtype))==strtolower(trim($tsndidt)) &&
													 strtolower(trim($curlog))!=strtolower(trim($trcvid)) && strtolower(trim($curlogtype))!=strtolower(trim($trcvidt))
												 ) {

													$tfid = $trcvid;
													$tfidt = $trcvidt;

												}
											}else{
													$tfid = $trcvid;
													$tfidt = $trcvidt;
											}
											
										}
										//
									//
									if ( strtolower(trim($tfidt))==strtolower(trim("student")) ) {
										$sql = " select studentid,lastname,firstname,middlename,prof_img from tbl_interns where studentid='$tfid' order by lastname asc ";
										$qry = mysqli_query($conn,$sql);
										while($dat=mysqli_fetch_array($qry)) {
											if ( trim($dat[0])!="" && trim($dat[1])!="" && trim($dat[2])!="" ) {
												$dcid = trim($dat[0]);
												$name = "";
												$mname = "";
												$img = "";
												$css = "";
												if ( trim($dat[3])!="" ) {
													$mname = " " . trim($dat[3]);
												}
												$name = trim($dat[2]) . $mname . " " . trim($dat[1]);
												$img = trim($dat[4]);
												if ( trim($img)=="" ) {
													$img = "./assets/img/empty_user.png";
												}
												if ( strtolower(trim($dat[0]))==strtolower(trim($curid)) ) {
													$css = "active";
												}
												//
												$link = "./page_messages.php?id=$dcid&rtype=student";
											}
										}
									}
									if ( strtolower(trim($tfidt))==strtolower(trim("employee")) ) {
										$sql = " select employee_id,lastname,firstname,middlename,prof_img from tbl_employee where employee_id='$tfid' order by lastname asc ";
										$qry = mysqli_query($conn,$sql);
										while($dat=mysqli_fetch_array($qry)) {
											if ( trim($dat[0])!="" && trim($dat[1])!="" && trim($dat[2])!="" ) {
												$dcid = trim($dat[0]);
												$name = "";
												$mname = "";
												$img = "";
												$css = "";
												if ( trim($dat[3])!="" ) {
													$mname = " " . trim($dat[3]);
												}
												$name = trim($dat[2]) . $mname . " " . trim($dat[1]);
												$img = trim($dat[4]);
												if ( trim($img)=="" ) {
													$img = "./assets/img/empty_user.png";
												}
												if ( strtolower(trim($dat[0]))==strtolower(trim($curid)) ) {
													$css = "active";
												}
												//
												$link = "./page_messages.php?id=$dcid&rtype=employee";
											}
										}
									}
									//
									//GET MSG BY
									//
									$sndbyid = "";
									$sndbyidt = "";
									//
										$sql = " select snd_id,snd_type from tbl_messages where message='$tmsg' and date_sent='$tdate' and msgs_group_id='$dat2[8]'  limit 1 ";
										$qry = mysqli_query($conn,$sql);
										while($dat=mysqli_fetch_array($qry)) {
											$sndbyid = trim($dat[0]);
											$sndbyidt = trim($dat[1]);
										}
									//
										if ( strtolower(trim($curlog)) == strtolower(trim($sndbyid)) ) {
											$msgby = "$name";
											$msgby2 = "You: ";
										}else{
											$msgby = "$name:";
											$msgby2 = "";
										}
									//
									//
									echo "
											<li>
												<a href='$link' class='notification-item'>
												<table>
													<tr>
														<td>
															<img src='$img' class='msgnotif_img01' />
														</td>
														<td>
															<span class='span02'>
																<span class='msgnotif_ttl01'>$msgby</span>
																<br/>
																<span class='msgnotif_ttl01'>$msgby2</span>
																<span class='msgnotif_cont01'>$msg</span>
															</span>
														</td>
													</tr>
												</table>
												</a>
											</li>
										";
									//
									$nn += 1;
								}
							}
							//
				//==========================================================
						}
						//
						//
							if ( $nn <= 0 ) {
									echo "
										<li>
											<a href='./page_messages.php' class='notification-item'>
											<span class='dot bg-warning'></span><span class='span02'>No messages yet.</span>
											</a>
										</li>
									";
							}else{
								echo "<li><a href='./page_messages.php' class='more'>See all messages</a></li>";
							}

		echo "
				</ul>
			</li>
			";
	}
?>
			<li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
				<?php include "./data/connect.php";
					$logun = $_SESSION['intern_data_cun'];
					$logutype = $_SESSION['intern_data_utype'];
					//
					$dpn = "";
					$img = "";
					//
					if ( strtolower(trim($logutype))==strtolower(trim("student")) ) {
						$sql = " select no,studentid,firstname,middlename,lastname,prof_img,prof_backimg from tbl_interns where studentid='$logun' ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							$img = trim($dat[5]);
							$dpn = trim($dat[2]);
						}
					}
					//
					if ( strtolower(trim($logutype))==strtolower(trim("employee")) ) {
						$sql = " select no,employee_id,firstname,middlename,lastname,prof_img,prof_backimg from tbl_employee where employee_id='$logun' ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							$img = trim($dat[5]);
							$dpn = trim($dat[2]);
						}
					}
					//
					if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
						$img = "";
							$dpn = "Admin";
					}
					//
					//
					if ( trim($img) == "" ) {
						$img = "assets/img/empty_user.png";
					}
					echo "
							<img src='$img' class='img-circle img_prof_03' alt='Photo'>
							<span class='span02'>
								$dpn
							</span>
					";
				?>
				<i class="icon-submenu lnr lnr-chevron-down"></i></a>
				<ul class="dropdown-menu">
					<?php
						$logun = $_SESSION['intern_data_cun'];
						$logutype = $_SESSION['intern_data_utype'];
						//
						$link = "#";
						if ( strtolower(trim($logutype))==strtolower(trim("student")) ) {
							$link = "./page_profile.php?id=" . trim($logun);
						}
						if ( strtolower(trim($logutype))==strtolower(trim("employee")) ) {
							$link = "./page_profile_employee.php?id=" . trim($logun);
						}
						//
						if ( strtolower(trim($logun))!=strtolower(trim("admin")) && strtolower(trim($logutype))!=strtolower(trim("admin")) ) {
							echo "<li><a href='$link'><i class='lnr lnr-user'></i> <span>My Profile</span></a></li>";
							//
							echo "<li><a href='./page_messages.php'><i class='lnr lnr-envelope'></i> <span>Message</span></a></li>";
						}
						//
						if ( strtolower(trim($logutype))==strtolower(trim("student")) ) {
							echo "<li><a href='./attendance.php'><i class='lnr lnr-cog'></i> <span>Attendance</span></a></li>";
						}
						echo "<li><a href='cpanel.php?op=logout'><i class='lnr lnr-exit'></i> <span>Logout</span></a></li>";
						//
						//
					?>
				</ul>
			</li>
		</ul>
		</div>
		</div>
	</div>
</div>
</nav>