<?php  error_reporting( E_ALL ^ E_NOTICE );
	
	function getInternCount() {
		include "./data/connect.php";
		$uid = $_GET['id'];
		$nn = 0;
		$exc = "";
		//GET ADDED HTE
		$sql = " select hte_id from tbl_class_member_hte where class_id='$uid' group by hte_id  ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			if ( trim($dat[0]) != "" ) {
				if ( trim($exc)=="" ) {
					$exc = " where hte_id='$dat[0]' ";
				}else{
					$exc = $exc . " or hte_id='$dat[0]' ";
				}
			}
		}
		//echo "$exc";
		//GET GET HTE MEMBERS
		$sql = " select member_id from tbl_hte_members  $exc  group by member_id ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			if ( trim($dat[0]) != "" ) {
				$nn = $nn + 1;
			}
		}
		return $nn;
	}

	function getHTECount() {
		include "./data/connect.php";
		$uid = $_GET['id'];
		$nn = 0;
		//GET ADDED
		$sql = " select hte_id from tbl_class_member_hte where class_id='$uid'  ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			if ( trim($dat[0]) != "" ) {
				$nn = $nn + 1;
			}
		}
		return $nn;
	}

	function getHTEJobCount($uid) {
		include "./data/connect.php";
		$nn = 0;
		//GET ADDED
		$sql = " select hte_job_id,hte_id,name,description from tbl_hte_jobs  where hte_id='$uid' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			if ( trim($dat[1]) != "" ) {
				$nn = $nn + 1;
			}
		}
		return $nn;
	}

	function getCoordinatorCount() {
		include "./data/connect.php";
		$uid = $_GET['id'];
		$exc = "";
		$exc2 = "";
		//GET ADDED
		$sql = " select hte_id from tbl_class_member_hte where class_id='$uid' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			if ( trim($dat[0]) != "" ) {
				if ( trim($exc)=="" ) {
					$exc = " where hte_id='$dat[0]' ";
				}else{
					$exc = $exc . " or hte_id='$dat[0]' ";
				}
			}
		}
		//GET GET HTE COORDINATOR ID
		$sql = " select employee_id from tbl_coordinator  $exc   group by employee_id  ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			if ( trim($dat[0]) != "" ) {
				$nn = $nn + 1;
			}
		}
		return $nn;
	}

	function getHTERate() {
		include "./data/connect.php";
		$uid = $_GET['id'];
		$rate = 0;
		$tmpr = 0;
		$tmpn = 0;
		//GET ADDED
		$sql = " select rate from tbl_hte_rating where hte_id='$uid' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			if ( trim($dat[0]) != "" ) {
				$tmpn = $tmpn + 1;
				$tmpr = $tmpr + (trim($dat[0]));
			}
		}
		if ( $tmpr > 0 && $tmpn > 0 ) {
			$rate = $tmpr/$tmpn;
		}
		return $rate;
	}

//========================================================================
//========================================================================

	function getHTERate2($hteid) {
		include "./data/connect.php";
		$uid = $hteid;
		$rate = 0;
		$tmpr = 0;
		$tmpn = 0;
		//GET ADDED
		$sqlf1 = " select rate from tbl_hte_rating where hte_id='$uid' ";
		$qryf1 = mysqli_query($conn,$sqlf1);
		while($datf1=mysqli_fetch_array($qryf1)) {
			if ( trim($datf1[0]) != "" ) {
				$tmpn = $tmpn + 1;
				$tmpr = $tmpr + (trim($datf1[0]));
			}
		}
		if ( $tmpr > 0 && $tmpn > 0 ) {
			$rate = $tmpr/$tmpn;
		}
		return $rate;
	}

	function getHTEisRated2($hteid) {
		include "./data/connect.php";
		$uid = $hteid;
		$nn = 0;
		$stat = false;
		//GET ADDED
		$sqlf1 = " select hte_id,total_rate from tbl_hte_raterank where hte_id='$uid' group by hte_id ";
		$qryf1 = mysqli_query($conn,$sqlf1);
		while($datf1=mysqli_fetch_array($qryf1)) {
			if ( trim($datf1[0]) != "" && trim($datf1[1]) != "" ) {
				$nn = $nn + 1;
			}
		}
		if ( $nn <= 0 ) {
			$stat = false;
		}else{
			$stat = true;
		}
		return $stat;
	}

//========================================================================

	function getHTERate3($hteid,$csy) {
		include "./data/connect.php";
		//
		$cid = $hteid;
		$sy = $csy;
		//
		$rate = 0;
		$tmpr = 0;
		$tmpn = 0;

		//echo "$cid $sy";
		//
		$cname = array();
		$cval = array();
		$cvalcount = array();
		//
		$cn = 0;
		//
		if ( trim($cid)!="" ) {
			//GET CRITERIA BASED ON SY
			$xn = "";
			//                     0              1    2   3
			$sqlf1 = " select hte_eval_criteria_id,name,sy,adate from tbl_hte_eval_criteria  where hte_id='$cid' and sy='$sy' group by name order by hte_eval_criteria_id asc ";
			$qryf1 = mysqli_query($conn,$sqlf1);
			while($datf1=mysqli_fetch_array($qryf1)) {
				if ( trim($datf1[1])!="" ) {
					$cname[$cn] = trim($datf1[1]);
					$cn += 1;
					$xn = trim($datf1[1]);
				}
			}
			//
			$cn = 0;
			$vc = 0;
			//
			//GET CRITERIA POINTS
			for ( $i=0 ; $i<count($cname) ; $i++ ) {
				//GET RATING
					$tv = 0;
					$vc = 0;
				//                     0              1             2       3            4      5
				$sqlf1 = " select hte_eval_progcomp_id,hte_eval_id,prog_comp,num_hours,eval_rate,sy from tbl_hte_eval_progcomp  where hte_id='$cid' and prog_comp='".$cname[$i]."' and sy='$sy' order by hte_eval_progcomp_id asc ";
				$qryf1 = mysqli_query($conn,$sqlf1);
				while($datf1=mysqli_fetch_array($qryf1)) {
					$tv = $tv + strval(trim($datf1[4]));
					$vc += 1;
					//
				}
				//
				$cval[$i] = $tv;
				$cvalcount[$i] = $vc;
			}
			//echo " $cval[0] - $cvalcount[0]";
			//
			$cn = 0;
			$rate = 0;
			//
			for ( $i=0 ; $i<count($cname) ; $i++ ) {
				if ( trim($cname[$i])!="" ) {
					//
					$cn += 1;
					//
					$tv = 0;
					//
					$tv = strval($cval[$i]);
					//
					if ( strval($cvalcount[$i]) > 0 ) {
						$tv = strval($cval[$i]) / strval($cvalcount[$i]);
					}
					//
					$rate = $rate + $tv;
				}
			}
			//
			if ( $cn > 0 ) {
				$rate = $rate / $cn;
			}
		}
		//
		return $rate;
	}

	function getHTERate3_2($studid,$csy) {
		include "./data/connect.php";
		$uid = $studid;
		$sy = $csy;
		//
		$rate = 0;
		$tmpr = 0;
		$tmpn = 0;
		//
		$crit_1_1 = 0;
		$crit_1_2 = 0;
		$crit_1_3 = 0;
		$crit_1_4 = 0;
		$crit_1_5 = 0;
		$crit_1_6 = 0;
		$crit_1_7 = 0;
		$crit_1_8 = 0;
		//
		$crit_2_1 = 0;
		$crit_2_2 = 0;
		$crit_2_3 = 0;
		$crit_2_4 = 0;
		$crit_2_5 = 0;
		$crit_2_6 = 0;
		$crit_2_7 = 0;
		$crit_2_8 = 0;
		//
		$crit_3_1 = 0;
		$crit_3_2 = 0;
		$crit_3_3 = 0;
		$crit_3_4 = 0;
		$crit_3_5 = 0;
		$crit_3_6 = 0;
		//
		$cn = 0;
		//GET ADDED
		//                     0               1           2            3           4         5              6               7         8                       
		$sqlf1 = " select crit_1_1,crit_1_2,crit_1_3,crit_1_4,crit_1_5,crit_1_6,crit_1_7,crit_1_8,crit_2_1,crit_2_2,crit_2_3,crit_2_4,crit_2_5,crit_2_6,crit_2_7,crit_2_8,crit_3_1,crit_3_2,crit_3_3,crit_3_4,crit_3_5,crit_3_6 from tbl_hte_eval2 where hte_id='$uid' and sy='$sy' ";
		$qryf1 = mysqli_query($conn,$sqlf1);
		while($datf1=mysqli_fetch_array($qryf1)) {
			//
			$crit_1_1 = $crit_1_1 + strval(trim($datf1[0]));
			$crit_1_2 = $crit_1_2 + strval(trim($datf1[1]));
			$crit_1_3 = $crit_1_3 + strval(trim($datf1[2]));
			$crit_1_4 = $crit_1_4 + strval(trim($datf1[3]));
			$crit_1_5 = $crit_1_5 + strval(trim($datf1[4]));
			$crit_1_6 = $crit_1_6 + strval(trim($datf1[5]));
			$crit_1_7 = $crit_1_7 + strval(trim($datf1[6]));
			$crit_1_8 = $crit_1_8 + strval(trim($datf1[7]));
			//
			$crit_2_1 = $crit_2_1 + strval(trim($datf1[8]));
			$crit_2_2 = $crit_2_2 + strval(trim($datf1[9]));
			$crit_2_3 = $crit_2_3 + strval(trim($datf1[10]));
			$crit_2_4 = $crit_2_4 + strval(trim($datf1[11]));
			$crit_2_5 = $crit_2_5 + strval(trim($datf1[12]));
			$crit_2_6 = $crit_2_6 + strval(trim($datf1[13]));
			$crit_2_7 = $crit_2_7 + strval(trim($datf1[14]));
			$crit_2_8 = $crit_2_8 + strval(trim($datf1[15]));
			//
			$crit_3_1 = $crit_3_1 + strval(trim($datf1[16]));
			$crit_3_2 = $crit_3_2 + strval(trim($datf1[17]));
			$crit_3_3 = $crit_3_3 + strval(trim($datf1[18]));
			$crit_3_4 = $crit_3_4 + strval(trim($datf1[19]));
			$crit_3_5 = $crit_3_5 + strval(trim($datf1[20]));
			$crit_3_6 = $crit_3_6 + strval(trim($datf1[21]));
			//
			//
			$cn += 1;
		}
		//
		if ( $cn > 0  ) {
			if ( $crit_1_1 > 0 ) {
				$crit_1_1 = $crit_1_1 / $cn;
			}
			if ( $crit_1_2 > 0 ) {
				$crit_1_2 = $crit_1_2 / $cn;
			}
			if ( $crit_1_3 > 0 ) {
				$crit_1_3 = $crit_1_3 / $cn;
			}
			if ( $crit_1_4 > 0 ) {
				$crit_1_4 = $crit_1_4 / $cn;
			}
			if ( $crit_1_5 > 0 ) {
				$crit_1_5 = $crit_1_5 / $cn;
			}
			if ( $crit_1_6 > 0 ) {
				$crit_1_6 = $crit_1_6 / $cn;
			}
			if ( $crit_1_7 > 0 ) {
				$crit_1_7 = $crit_1_7 / $cn;
			}
			if ( $crit_1_8 > 0 ) {
				$crit_1_8 = $crit_1_8 / $cn;
			}
			//
			if ( $crit_2_1 > 0 ) {
				$crit_2_1 = $crit_2_1 / $cn;
			}
			if ( $crit_2_2 > 0 ) {
				$crit_2_2 = $crit_2_2 / $cn;
			}
			if ( $crit_2_3 > 0 ) {
				$crit_2_3 = $crit_2_3 / $cn;
			}
			if ( $crit_2_4 > 0 ) {
				$crit_2_4 = $crit_2_4 / $cn;
			}
			if ( $crit_2_5 > 0 ) {
				$crit_2_5 = $crit_2_5 / $cn;
			}
			if ( $crit_2_6 > 0 ) {
				$crit_2_6 = $crit_2_6 / $cn;
			}
			if ( $crit_2_7 > 0 ) {
				$crit_2_7 = $crit_2_7 / $cn;
			}
			if ( $crit_2_8 > 0 ) {
				$crit_2_8 = $crit_2_8 / $cn;
			}
			//
			if ( $crit_3_1 > 0 ) {
				$crit_3_1 = $crit_3_1 / $cn;
			}
			if ( $crit_3_2 > 0 ) {
				$crit_3_2 = $crit_3_2 / $cn;
			}
			if ( $crit_3_3 > 0 ) {
				$crit_3_3 = $crit_3_3 / $cn;
			}
			if ( $crit_3_4 > 0 ) {
				$crit_3_4 = $crit_3_4 / $cn;
			}
			if ( $crit_3_5 > 0 ) {
				$crit_3_5 = $crit_3_5 / $cn;
			}
			if ( $crit_3_6 > 0 ) {
				$crit_3_6 = $crit_3_6 / $cn;
			}
		}
		//
		$rate1 = $crit_1_1 + $crit_1_2 + $crit_1_3 + $crit_1_4 + $crit_1_5 + $crit_1_6 + $crit_1_7 + $crit_1_8;
		if ( $rate1 > 0 ) {
			$rate1 = $rate1 / 8;
		}
		//
		$rate2 = $crit_2_1 + $crit_2_2 + $crit_2_3 + $crit_2_4 + $crit_2_5 + $crit_2_6 + $crit_2_7 + $crit_2_8;
		if ( $rate2 > 0 ) {
			$rate2 = $rate2 / 8;
		}
		//
		$rate3 = $crit_3_1 + $crit_3_2 + $crit_3_3 + $crit_3_4 + $crit_3_5 + $crit_3_6;
		if ( $rate3 > 0 ) {
			$rate3 = $rate3 / 6;
		}
		//
		//
		$rate = $rate1 + $rate2 + $rate3;
		//
		if ( $rate > 0 ) {
			$rate = $rate / 3;
		}
		//
		return $rate;
	}

	function getHTEisRated3($hteid,$csy) {
		include "./data/connect.php";
		//
		$uid = $hteid;
		$sy = $csy;
		//
		$nn = 0;
		$stat = false;
		//GET ADDED
		$sqlf1 = " select hte_id,total_rate from tbl_hte_raterank where sy='$sy' and hte_id='$uid' group by hte_id ";
		$qryf1 = mysqli_query($conn,$sqlf1);
		while($datf1=mysqli_fetch_array($qryf1)) {
			if ( trim($datf1[0]) != "" && trim($datf1[1]) != "" ) {
				$nn = $nn + 1;
			}
		}
		if ( $nn <= 0 ) {
			$stat = false;
		}else{
			$stat = true;
		}
		return $stat;
	}

//========================================================================
//========================================================================

	function getCountHTEInterns2($hteid) {
		include "./data/connect.php";
		$uid = $hteid;
		$tmpn = 0;
		//GET ADDED
		$sqlf1 = " select * from tbl_hte_members where hte_id='$uid' ";
		$qryf1 = mysqli_query($conn,$sqlf1);
		while($datf1=mysqli_fetch_array($qryf1)) {
			if ( trim($datf1[0]) != "" ) {
				$tmpn = $tmpn + 1;
			}
		}
		return $tmpn;
	}

	function getInternRate2($studid) {
		include "./data/connect.php";
		$uid = $studid;
		$rate = 0;
		$tmpr = 0;
		$tmpn = 0;
		//GET ADDED
		$sqlf1 = " select rate from tbl_interns_evaluation where studentid='$uid' ";
		$qryf1 = mysqli_query($conn,$sqlf1);
		while($datf1=mysqli_fetch_array($qryf1)) {
			if ( trim($datf1[0]) != "" ) {
				$tmpn = $tmpn + 1;
				$tmpr = $tmpr + (trim($datf1[0]));
			}
		}
		if ( $tmpr > 0 && $tmpn > 0 ) {
			$rate = $tmpr/$tmpn;
		}
		return $rate;
	}

	function getInternisRated2($hteid) {
		include "./data/connect.php";
		$uid = $hteid;
		$nn = 0;
		$stat = false;
		//GET ADDED
		$sqlf1 = " select studentid,total_rate from tbl_interns_raterank where studentid='$uid' group by studentid ";
		$qryf1 = mysqli_query($conn,$sqlf1);
		while($datf1=mysqli_fetch_array($qryf1)) {
			if ( trim($datf1[0]) != "" && trim($datf1[1]) != "" ) {
				$nn = $nn + 1;
			}
		}
		if ( $nn <= 0 ) {
			$stat = false;
		}else{
			$stat = true;
		}
		return $stat;
	}

//========================================================================

	function getCountHTEStaffs2($hteid) {
		include "./data/connect.php";
		$uid = $hteid;
		$tmpn = 0;
		//GET ADDED
		$sqlf1 = " select * from tbl_hte_staff where hte_id='$uid' ";
		$qryf1 = mysqli_query($conn,$sqlf1);
		while($datf1=mysqli_fetch_array($qryf1)) {
			if ( trim($datf1[0]) != "" ) {
				$tmpn = $tmpn + 1;
			}
		}
		return $tmpn;
	}

	function getCountCOURSEStaffs2($id) {
		include "./data/connect.php";
		$uid = $id;
		$tmpn = 0;
		//GET ADDED
		$sqlf1 = " select * from tbl_crs_staff where crs_id='$uid' ";
		$qryf1 = mysqli_query($conn,$sqlf1);
		while($datf1=mysqli_fetch_array($qryf1)) {
			$tmpn = $tmpn + 1;
		}
		return $tmpn;
	}

	function getCountClassStaffs2($id) {
		include "./data/connect.php";
		$uid = $id;
		$tmpn = 0;
		//GET ADDED
		$sqlf1 = " select * from tbl_class_staff where class_id='$uid' ";
		$qryf1 = mysqli_query($conn,$sqlf1);
		while($datf1=mysqli_fetch_array($qryf1)) {
			$tmpn = $tmpn + 1;
		}
		return $tmpn;
	}

//========================================================================

	function getInternRate3($studid,$csy) {
		include "./data/connect.php";
		$uid = $studid;
		$sy = $csy;
		//
		$rate = 0;
		$tmpr = 0;
		$tmpn = 0;
		//
		$crit1 = 0;
		$crit2 = 0;
		$crit3 = 0;
		$crit4 = 0;
		$crit5 = 0;
		$crit6 = 0;
		$crit7 = 0;
		$crit8 = 0;
		$crit9 = 0;
		//
		$cn = 0;
		//GET ADDED
		//                     0               1           2            3           4         5              6               7         8                       
		$sqlf1 = " select professionalism,job_maturity,comm_skills,productivity,leadership,excellence,honesty_integrity,innovation,teamwork from tbl_interns_eval2 where studentid='$uid' and sy='$sy' ";
		$qryf1 = mysqli_query($conn,$sqlf1);
		while($datf1=mysqli_fetch_array($qryf1)) {
			$crit1 = $crit1 + strval(trim($datf1[0]));
			$crit2 = $crit2 + strval(trim($datf1[1]));
			$crit3 = $crit3 + strval(trim($datf1[2]));
			$crit4 = $crit4 + strval(trim($datf1[3]));
			$crit5 = $crit5 + strval(trim($datf1[4]));
			$crit6 = $crit6 + strval(trim($datf1[5]));
			$crit7 = $crit7 + strval(trim($datf1[6]));
			$crit8 = $crit8 + strval(trim($datf1[7]));
			$crit9 = $crit9 + strval(trim($datf1[8]));
			$cn += 1;
		}
		//
		if ( $cn > 0  ) {
			if ( $crit1 > 0 ) {
				$crit1 = $crit1 / $cn;
			}
			if ( $crit2 > 0 ) {
				$crit2 = $crit2 / $cn;
			}
			if ( $crit3 > 0 ) {
				$crit3 = $crit3 / $cn;
			}
			if ( $crit4 > 0 ) {
				$crit4 = $crit4 / $cn;
			}
			if ( $crit5 > 0 ) {
				$crit5 = $crit5 / $cn;
			}
			if ( $crit6 > 0 ) {
				$crit6 = $crit6 / $cn;
			}
			if ( $crit7 > 0 ) {
				$crit7 = $crit7 / $cn;
			}
			if ( $crit8 > 0 ) {
				$crit8 = $crit8 / $cn;
			}
			if ( $crit9 > 0 ) {
				$crit9 = $crit9 / $cn;
			}
		}
		//
		$rate = $crit1 + $crit2 + $crit3 + $crit4 + $crit5 + $crit6 + $crit7 + $crit8 + $crit9;
		//
		if ( $rate > 0 ) {
			$rate = $rate / 9;
		}
		//
		return $rate;
	}

	function getInternisRated3($hteid,$csy) {
		include "./data/connect.php";
		$uid = $hteid;
		$sy = $csy;
		//
		$nn = 0;
		$stat = false;
		//GET ADDED
		$sqlf1 = " select studentid,total_rate from tbl_interns_raterank where studentid='$uid' and sy='$sy' group by studentid ";
		$qryf1 = mysqli_query($conn,$sqlf1);
		while($datf1=mysqli_fetch_array($qryf1)) {
			if ( trim($datf1[0]) != "" && trim($datf1[1]) != "" ) {
				$nn = $nn + 1;
			}
		}
		if ( $nn <= 0 ) {
			$stat = false;
		}else{
			$stat = true;
		}
		return $stat;
	}

//========================================================================
//========================================================================

//========= PAGE CLASS ===================================================
	function getUserName($id,$typ) {
		include "./data/connect.php";
		$uid = $id;
		$tmpn = 0;
		$tsn = "student";
		if ( strtolower(trim($typ))==strtolower(trim($tsn)) ) {
			$sql16 = " select studentid,firstname,middlename,lastname from tbl_interns  where studentid='$uid'  order by lastname asc ";
			$qry16 = mysqli_query($conn,$sql16);
			while($dat16=mysqli_fetch_array($qry16)) {
				if ( trim($dat16[0]) != "" ) {
					$memname = "";
					$mname = "";
					if ( trim($dat16[2])!="" ) {
						$mname = "" . trim($dat16[2]) . " ";
					}
					$memname = trim($dat16[1]) . " " . $mname . trim($dat16[3]);
				}
			}
			$tmpn = $memname;
		}
		$tsn = "employee";
		if ( strtolower(trim($typ))==strtolower(trim($tsn)) ) {
			$sql16 = " select employee_id,firstname,middlename,lastname from tbl_employee  where employee_id='$uid'  order by lastname asc ";
			$qry16 = mysqli_query($conn,$sql16);
			while($dat16=mysqli_fetch_array($qry16)) {
				if ( trim($dat16[0]) != "" ) {
					$memname = "";
					$mname = "";
					if ( trim($dat16[2])!="" ) {
						$mname = "" . trim($dat16[2]) . " ";
					}
					$memname = trim($dat16[1]) . " " . $mname . trim($dat16[3]);
				}
			}
			$tmpn = $memname;
		}
		return $tmpn;
	}

	function getUserImage($id,$typ) {
		include "./data/connect.php";
		$uid = $id;
		$tmpn = "";
		$tsn = "student";
		if ( strtolower(trim($typ))==strtolower(trim($tsn)) ) {
			$sql15 = " select prof_img from tbl_interns  where studentid='$uid'  order by lastname asc ";
			$qry15 = mysqli_query($conn,$sql15);
			while($dat15=mysqli_fetch_array($qry15)) {
				if ( trim($dat15[0]) != "" ) {
					$tmpn = trim($dat15[0]);
				}
			}
		}
		$tsn = "employee";
		if ( strtolower(trim($typ))==strtolower(trim($tsn)) ) {
			$sql15 = " select prof_img from tbl_employee  where employee_id='$uid'  order by lastname asc ";
			$qry15 = mysqli_query($conn,$sql15);
			while($dat15=mysqli_fetch_array($qry15)) {
				if ( trim($dat15[0]) != "" ) {
					$tmpn = trim($dat15[0]);
				}
			}
		}
		if ( trim($tmpn)=="" ) {
			$tmpn = "./assets/img/empty_user.png";
		}
		return $tmpn;
	}

	function getClassSubPosts($id,$ppid) {
		include "./data/connect.php";
		//
		$logun =  $_SESSION['intern_data_cun'];
		$loguntype = $_SESSION['intern_data_utype'];
		//
		//
		$uid = $id;
		$tmpv = "";
		$nn = 0;
		$spnid = "";
		//                          0       1          2           3             4    5         6          7        8            9
		$sql11 = $sql = " select class_id,member_id,member_type,parent_post_id,type,content,date_posted,file_att,file_att_name,class_post_id from tbl_class_posts where class_id='$uid' and parent_post_id='$ppid'  order by date_posted desc ";
			$qry11 = mysqli_query($conn,$sql11);
			while($dat11=mysqli_fetch_array($qry11)) {
				if ( trim($dat11[0]) != "" && trim($dat11[3]) != "" ) {
					//echo "XX";
					//
					$spnid = trim($dat11[9]);
					//
					$nn = $nn + 1;
					$tdatep = trim($dat11[6]);
					$tpt = trim($dat11[4]);
					$tcid = trim($dat11[0]);
					$tpid = trim($dat11[3]);
					$tmid = trim($dat11[1]);
					$tmtyp = trim($dat11[2]);
					$tmsg = trim($dat11[5]);
					$fatt = trim($dat11[7]);
					$fattn = trim($dat11[8]);
					$tname = "";
					$tafl = "";
					$tsn = "reflection";
						if ( trim($fatt)!="" ) {
							if ( strtolower(trim($tsn))==strtolower(trim($tpt)) ) {
								if ( trim($fattn)=="" ) {
									$fattn = "LINK";
								}
								$tafl = "
									<a target='_blank' href='".trim($fatt)."'>$fattn</a>
								";
							}
						}
					$tlnk = "";
						$tsn = "student";
						if ( strtolower(trim($tsn))==strtolower(trim($tmtyp)) ) {
							$tlnk = "./page_profile.php";
						}
						$tsn = "employee";
						if ( strtolower(trim($tsn))==strtolower(trim($tmtyp)) ) {
							$tlnk = "./page_profile_employee.php";
						}
						$tname = "<a class='ann_link02' href='".trim($tlnk)."?id=$tmid'>" . getUserName($tmid,$tmtyp) . "</a>";
					if ( $nn > 1 ) {
						//$tmpv = $tmpv . "<br/>";
					}
					//
					//
					$frmedit = "";
					$frmedit2 = "";
					$ern = 0;
					//
					if ( trim($logun)=="" ) {
						$ern += 1;
					}
					if ( strtolower(trim($loguntype))==strtolower(trim("student")) ) {
						$ern += 1;
					}
					if ( strtolower(trim($loguntype))==strtolower(trim("coordinator")) ||
						 strtolower(trim($loguntype))==strtolower(trim("employee")) ) {
						if ( strtolower(trim($loguntype))!=strtolower(trim($dat[3])) && strtolower(trim($logun))!=strtolower(trim($dat[4])) ) {
							$ern += 1;
						}
					}
					//
					if ( $ern <= 0 ) {
						$frmedit = "

													<div class='dropdown'>
													  <a class='btn_action_01' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
													  <ul class='dropdown-menu'>
													    <li><a href='#' data-toggle='modal' data-target='#modalSubPEdit_$spnid'>Edit</a></li>
													    <li><a href='#' data-toggle='modal' data-target='#modalSubPDelete_$spnid'>Delete</a></li>
													  </ul>
													</div> ";
						//
							$frmedit2 = "
														    <div id='modalSubPEdit_$spnid' class='modal fade' role='dialog'>
														      <div class='modal-dialog'>
														      <!-- Modal content-->
														      <div class='modal-content'>
														      <div class='modal-header' align='left'>
														        <button type='button' class='close' data-dismiss='modal'>&times;</button>
														        <h4 class='modal-title'>Update</h4>
														      </div>
														          <form method='post' action='' enctype='multipart/form-data'>
														      <div class='modal-body' align='left'>
														        <p align='left'>
																			<input type='hidden' name='txtid' value='$spnid'/>

																		<input type='hidden' name='cpt' value='$tpt' />

																		<input type='hidden' name='type' value='$tpt' />

																		<div class='form-group div01'>
																			<label for='stud-add-msg' class='control-label sr-only'>Message...</label>
																			<textarea name='msg' class='form-control texta01' id='stud-add-msg' placeholder='Message...'>$tmsg</textarea>
																		</div>

														        </p>
														      </div>
														      <div class='modal-footer'>
														        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
														        <input type='submit' name='btnsavepostEdit' class='btn btn-primary btn-md btn01' value='SAVE'>
														      </div>
														          </form>
														      </div>

														      </div>
														    </div>

																<div id='modalSubPDelete_$spnid' class='modal fade' role='dialog'>
																	<div class='modal-dialog'>
																	<!-- Modal content-->
																	<div class='modal-content'>
																	<div class='modal-header' align='left'>
																		<button type='button' class='close' data-dismiss='modal'>&times;</button>
																		<h4 class='modal-title'>Delete</h4>
																	</div>
																			<form method='post' action='' enctype='multipart/form-data'>
																	<div class='modal-body' align='left'>
																		<p align='left'>
																		
																		<input type='hidden' name='cpt' value='$dat[4]' />

																			<input type='hidden' name='txtid' value='$spnid'/>
																			Delete post?
																		</p>
																	</div>
																	<div class='modal-footer'>
																		<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																		<input type='submit' name='btnsavepostDelete' class='btn btn-primary btn-md btn01' value='DELETE'>
																	</div>
																			</form>
																	</div>

																	</div>
																</div>

							";
					}
					//
					$tmpv = $tmpv . "
						<div class='panel class_post_sub1_msg01'>
						<div class='class_post_div_msg01'>
							<table class='' width='100%'>
								<tr>
									<td class='ann_td01_2'>
										<span class='span02 class_post_sub1_pname01'>$tname</span>
											<br/>
											<span class='pst_date_01'>$tdatep</span>
									</td>
									<td class='ann_td01_3'>
										
									$frmedit
									$frmedit2

									</td>
								</tr>
							</table>
							<hr class='hr01'/>
							<span class='class_post_sub1_pname01'>$tmsg</span>
							$tafl
						</div>
						<div>
						</div>
						</div>
					";
				}
			}
		return $tmpv;
	}

	function getClassActSubmissionStat($id,$postid,$memid) {
		include "./data/connect.php";
		$uid = $id;
		$pid = $postid;
		$mid = $memid;
		$tmpv = false;
		$nn = 0;
		$sql11 = $sql = " select class_id,member_id,member_type,parent_post_id,type,content,date_posted,file_att from tbl_class_posts where class_id='$uid' and parent_post_id='$pid' and member_id='$mid'  order by date_posted asc ";
		$qry11 = mysqli_query($conn,$sql11);
		while($dat11=mysqli_fetch_array($qry11)) {
			if ( trim($dat11[0]) != "" && trim($dat11[7]) != "" ) {
				$nn = $nn + 1;
			}
		}
		if ( $nn > 0 ) {
			$tmpv = true;
		}else{
			$tmpv = false;
		}
		return $tmpv;
	}

	function getClassActSubmissionStatCount($id,$postid,$memid) {
		include "./data/connect.php";
		$uid = $id;
		$pid = $postid;
		$mid = $memid;
		$tmpv = false;
		$nn = 0;
		$sql11 = $sql = " select class_id,member_id,member_type,parent_post_id,type,content,date_posted,file_att from tbl_class_posts where class_id='$uid' and parent_post_id='$pid'  order by date_posted asc ";
		$qry11 = mysqli_query($conn,$sql11);
		while($dat11=mysqli_fetch_array($qry11)) {
			if ( trim($dat11[0]) != "" && trim($dat11[1]) != "" && trim($dat11[7]) != "" ) {
				$nn = $nn + 1;
			}
		}
		return $nn;
	}

	function getClassActSubmissionPostID($id,$postid,$memid) {
		include "./data/connect.php";
		$uid = $id;
		$pid = $postid;
		$mid = $memid;
		$tmpv = "";
		$nn = 0;
		$sql11 = $sql = " select class_id,member_id,member_type,parent_post_id,type,content,date_posted,class_post_id from tbl_class_posts where class_id='$uid' and parent_post_id<>'' and member_id='$mid' and activity_sub='true'  order by date_posted asc ";
		$qry11 = mysqli_query($conn,$sql11);
		while($dat11=mysqli_fetch_array($qry11)) {
			if ( trim($dat11[0]) != "" && trim($dat11[7]) != "" ) {
				$tmpv = "" . trim($dat11[7]);
			}
		}
		return $tmpv;
	}

	function getClassActCount($id) {
		include "./data/connect.php";
		$uid = $id;
		$tmpv = 0;
		$nn = 0;
		$sql11 = $sql = " select class_id,member_id,member_type,parent_post_id,type,content,date_posted,class_post_id from tbl_class_posts where (class_id='$uid' and parent_post_id='' and type='reflection') and (activity_sub<>'true')  order by date_posted asc ";
		$qry11 = mysqli_query($conn,$sql11);
		while($dat11=mysqli_fetch_array($qry11)) {
			if ( trim($dat11[0]) != "" ) {
				$tmpv = $tmpv + 1;
			}
		}
		return $tmpv;
	}
//========= PAGE CLASS ===================================================


?>