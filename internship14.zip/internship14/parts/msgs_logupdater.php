<?php include "./data/connect.php";
					$curlog = $_SESSION['intern_data_cun'];
					$curlogtype = $_SESSION['intern_data_utype'];
					//
					$curid = trim($_GET['id']);
					//
					//
					$sidd = array();
					$sidd2 = array();
					//
					$sids = "";
					$sids2 = "";
					//                   0     1       2       3       4        5        6       7         8
					$sql2 = " select rcv_id,rcv_type,snd_id,snd_type,message,date_sent,own_id,own_type,msgs_group_id,msg_id from tbl_messages  where own_id='$curlog' and own_type='$curlogtype' group by msgs_group_id order by msg_id desc  ";
					$qry2 = mysqli_query($conn,$sql2);
					while($dat2=mysqli_fetch_array($qry2)) {
						if ( trim($dat2[8])!="" ) {
							if ( trim($sids)=="" ) {
								$sids = trim($dat2[8]);
							}else{
								$sids = $sids . ";" . trim($dat2[8]);
							}
						}
					}
					if ( trim($sids)!="" ) {
						$sidd = explode( ";" , trim($sids) );
						//
						$tmgid = "";
						//
						$name = "";
						$img = "";
						$msg = "";
						$msgby = "";
						$msgn = 0;
						//
						//GET LAST MESSAGE
						$msg = "";
						$msgby = "";
						$msgn = 0;
						$trcvid = "";
						$trcvidt = "";
						$tsndid = "";
						$tsndidt = "";
						$tmsg = "";
						$tdate = "";
						//
						for ( $i=0 ; $i<count($sidd) ; $i++ ) {
							$tcd = trim($sidd[$i]);
							if ( trim($tcd)!="" ) {
								//
								$tmgid = "";
								//GET LAST mESSAGE
								//                   0     1       2       3       4        5        6       7       8
								$sql2 = " select rcv_id,rcv_type,snd_id,snd_type,message,date_sent,own_id,own_type,msgs_group_id from tbl_messages  where  msgs_group_id='$tcd' order by msg_id desc limit 1 ";
								$qry2 = mysqli_query($conn,$sql2);
								while($dat2=mysqli_fetch_array($qry2)) {
									//
									$tmgid = trim($dat2[8]);
									//
									$name = "";
									$img = "";
									$msg = "";
									$msgby = "";
									$msgn = 0;
									//
									//GET LAST MESSAGE
									$msg = "";
									$msgby = "";
									$msgn = 0;
									$trcvid = "";
									$trcvidt = "";
									$tsndid = "";
									$tsndidt = "";
									$tmsg = "";
									$tdate = "";
									//
									if ( trim($dat2[0])!="" && trim($dat2[2])!="" ) {
										$msgn = 0;
										if ( $msgn <= 0 ) {
											$msg = $dat2[4];
											if ( strtolower(trim($curlog)) == strtolower(trim($dat2[2])) ) {
												$msgby = "You:";
											}else{
												$msgby = "";
											}
											$msgn = $msgn + 1;
											//FOR LOGS
											$trcvid = $dat2[0];
											$trcvidt = $dat2[1];
											$tsndid = $dat2[2];
											$tsndidt = $dat2[3];
											$tmsg = $dat2[4];
											$tdate = $dat2[5];
											//
										}
										//
										$tfid = "";
										$tfidt = "";
										//
										$tfid = $trcvid;
										$tfidt = $trcvidt;
										//
										if ( strtolower(trim($trcvidt)) == strtolower(trim($tsndidt)) ) {
											if ( strtolower(trim($trcvid)) != strtolower(trim($tsndid)) ) {
												if ( strtolower(trim($curlog))!=strtolower(trim($trcvid)) ) {
													$tfid = $trcvid;
													$tfidt = $trcvidt;
												}else{
													$tfid = $tsndid;
													$tfidt = $tsndidt;
												}
											}else{
												$tfid = $trcvid;
												$tfidt = $trcvidt;
											}
										}
										//
										if ( strtolower(trim($tfidt))==strtolower(trim("student")) ) {
											$sql = " select studentid,lastname,firstname,middlename,prof_img from tbl_interns where studentid='$tfid' order by lastname asc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[0])!="" && trim($dat[1])!="" && trim($dat[2])!="" ) {
													$dcid = trim($dat[0]);
													$name = "";
													$mname = "";
													$img = "";
													$css = "";
													if ( trim($dat[3])!="" ) {
														$mname = " " . trim($dat[3]);
													}
													$name = trim($dat[2]) . $mname . " " . trim($dat[1]);
													$img = trim($dat[4]);
													if ( trim($img)=="" ) {
														$img = "./assets/img/empty_user.png";
													}
													if ( strtolower(trim($dat[0]))==strtolower(trim($curid)) ) {
														$css = "active";
													}
												}
											}
										}
										if ( strtolower(trim($tfidt))==strtolower(trim("employee")) ) {
											$sql = " select employee_id,lastname,firstname,middlename,prof_img from tbl_employee where employee_id='$tfid' order by lastname asc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[0])!="" && trim($dat[1])!="" && trim($dat[2])!="" ) {
													$dcid = trim($dat[0]);
													$name = "";
													$mname = "";
													$img = "";
													$css = "";
													if ( trim($dat[3])!="" ) {
														$mname = " " . trim($dat[3]);
													}
													$name = trim($dat[2]) . $mname . " " . trim($dat[1]);
													$img = trim($dat[4]);
													if ( trim($img)=="" ) {
														$img = "./assets/img/empty_user.png";
													}
													if ( strtolower(trim($dat[0]))==strtolower(trim($curid)) ) {
														$css = "active";
													}
												}
											}
										}
										//
										//UPDATE MESSAGE LOGS
										//CHECK IF INSERTED
										//
										$ise = 0;
										//CHECK IF EXISTS
										$sql3 = " select * from tbl_messages_log  where msgs_group_id='$dat2[8]'  ";
										$qry3 = mysqli_query($conn,$sql3);
										while($dat3=mysqli_fetch_array($qry3)) {
											$ise += 1;
										}
										//
										if ( $ise > 0 ) {
											//EXIST, UPPDATE
											$sql4 = " 
														update tbl_messages_log set 
																date_sent='$dat2[5]',message='$dat2[4]' 
															where msgs_group_id='$dat2[8]'  ";
											$qry4 = mysqli_query($conn,$sql4);
										}else{
											//ADD
											$sql4 = " 
														insert into tbl_messages_log  
																(rcv_id,rcv_type,snd_id,snd_type,message,date_sent,own_id,own_type,msgs_group_id) 
															values 
																('$dat2[0]','$dat2[1]','$dat2[2]','$dat2[3]','$dat2[4]','$dat2[5]','$dat2[6]','$dat2[7]','$dat2[8]') 
													";
											$qry4 = mysqli_query($conn,$sql4);
										}
										//
									}
								}
								//
								//
								//
							}
							//
							//
							//
						}
					}
						
				?>