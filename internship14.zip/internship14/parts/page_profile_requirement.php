					<div class="row">
						<div class="col-md-12">

							<!-- PANEL DEFAULT -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="page_prof_reqtitle01">Resume</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body">
									<p align="left">
										<?php include "./data/connect.php";
												$sid = $_GET['id'];
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
											//
											$tsn = "";
											//
											$nn = "";
											//
											$tsn = "requirement:resume";
											$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' order by date_added desc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[4]) != "" ){
													$file = trim($dat[4]);
													$nn = trim($dat[0]);
													//
													$filef = "";
													//
													if ( trim($file)!="" ) {
														//
														$fln = trim($file);
														//
														$dn = 0;
														//
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
															) {
															$filef = "
																		<a class='' href='#' data-toggle='modal' data-target='#modalRPrevImage_$nn'>
																		<img class='page_prof_reqimg01' src='".trim($fln)."' />
																		</a>
																		<div id='modalRPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																			<img class='ann_img02' src='".trim($fln)."'/>
																			<p class='page_prof_btndiv01' align='center'>
																				<button type='button' class='btn btn-primary btn-sm' data-dismiss='modal'>Close</button>
																			</p>
																		</div>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="doc" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="docx"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_doc.png' />
																		</a>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="pdf"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_pdf.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														if ( $dn <= 0 ) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_empty.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														echo "<div class='page_prof_divlist01' align='left'>$filef</div>";
													}
												}
											}
										?>
									</p>
								</div>
							</div>
							<!-- END PANEL DEFAULT -->

							<!-- PANEL DEFAULT -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="page_prof_reqtitle01">Application Letter</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body">
									<p align="left">
										<?php include "./data/connect.php";
												$sid = $_GET['id'];
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
											//
											$tsn = "";
											//
											$nn = "";
											//
											$tsn = "requirement:application_letter";
											$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' order by date_added desc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[4]) != "" ){
													$file = trim($dat[4]);
													$nn = trim($dat[0]);
													//
													$filef = "";
													//
													if ( trim($file)!="" ) {
														//
														$fln = trim($file);
														//
														$dn = 0;
														//
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
															) {
															$filef = "
																		<a class='' href='#' data-toggle='modal' data-target='#modalRPrevImage_$nn'>
																		<img class='page_prof_reqimg01' src='".trim($fln)."' />
																		</a>
																		<div id='modalRPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																			<img class='ann_img02' src='".trim($fln)."'/>
																			<p class='page_prof_btndiv01' align='center'>
																				<button type='button' class='btn btn-primary btn-sm' data-dismiss='modal'>Close</button>
																			</p>
																		</div>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="doc" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="docx"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_doc.png' />
																		</a>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="pdf"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_pdf.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														if ( $dn <= 0 ) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_empty.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														echo "<div class='page_prof_divlist01' align='left'>$filef</div>";
													}
												}
											}
										?>
									</p>
								</div>
							</div>
							<!-- END PANEL DEFAULT -->
							
							<!-- PANEL DEFAULT -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="page_prof_reqtitle01">MOA</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body">
									<p align="left">
										<?php include "./data/connect.php";
												$sid = $_GET['id'];
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
											//
											$tsn = "";
											//
											$nn = "";
											//
											$tsn = "requirement:moa";
											$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' order by date_added desc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[4]) != "" ){
													$file = trim($dat[4]);
													$nn = trim($dat[0]);
													//
													$filef = "";
													//
													if ( trim($file)!="" ) {
														//
														$fln = trim($file);
														//
														$dn = 0;
														//
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
															) {
															$filef = "
																		<a class='' href='#' data-toggle='modal' data-target='#modalRPrevImage_$nn'>
																		<img class='page_prof_reqimg01' src='".trim($fln)."' />
																		</a>
																		<div id='modalRPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																			<img class='ann_img02' src='".trim($fln)."'/>
																			<p class='page_prof_btndiv01' align='center'>
																				<button type='button' class='btn btn-primary btn-sm' data-dismiss='modal'>Close</button>
																			</p>
																		</div>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="doc" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="docx"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_doc.png' />
																		</a>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="pdf"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_pdf.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														if ( $dn <= 0 ) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_empty.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														echo "<div class='page_prof_divlist01' align='left'>$filef</div>";
													}
												}
											}
										?>
									</p>
								</div>
							</div>
							<!-- END PANEL DEFAULT -->
							
							<!-- PANEL DEFAULT -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="page_prof_reqtitle01">MOU</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body">
									<p align="left">
										<?php include "./data/connect.php";
												$sid = $_GET['id'];
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
											//
											$tsn = "";
											//
											$nn = "";
											//
											$tsn = "requirement:mou";
											$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' order by date_added desc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[4]) != "" ){
													$file = trim($dat[4]);
													$nn = trim($dat[0]);
													//
													$filef = "";
													//
													if ( trim($file)!="" ) {
														//
														$fln = trim($file);
														//
														$dn = 0;
														//
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
															) {
															$filef = "
																		<a class='' href='#' data-toggle='modal' data-target='#modalRPrevImage_$nn'>
																		<img class='page_prof_reqimg01' src='".trim($fln)."' />
																		</a>
																		<div id='modalRPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																			<img class='ann_img02' src='".trim($fln)."'/>
																			<p class='page_prof_btndiv01' align='center'>
																				<button type='button' class='btn btn-primary btn-sm' data-dismiss='modal'>Close</button>
																			</p>
																		</div>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="doc" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="docx"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_doc.png' />
																		</a>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="pdf"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_pdf.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														if ( $dn <= 0 ) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_empty.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														echo "<div class='page_prof_divlist01' align='left'>$filef</div>";
													}
												}
											}
										?>
									</p>
								</div>
							</div>
							<!-- END PANEL DEFAULT -->
							
							<!-- PANEL DEFAULT -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="page_prof_reqtitle01">Certification of Acceptance</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body">
									<p align="left">
										<?php include "./data/connect.php";
												$sid = $_GET['id'];
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
											//
											$tsn = "";
											//
											$nn = "";
											//
											$tsn = "requirement:certification_of_acceptance";
											$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' order by date_added desc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[4]) != "" ){
													$file = trim($dat[4]);
													$nn = trim($dat[0]);
													//
													$filef = "";
													//
													if ( trim($file)!="" ) {
														//
														$fln = trim($file);
														//
														$dn = 0;
														//
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
															) {
															$filef = "
																		<a class='' href='#' data-toggle='modal' data-target='#modalRPrevImage_$nn'>
																		<img class='page_prof_reqimg01' src='".trim($fln)."' />
																		</a>
																		<div id='modalRPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																			<img class='ann_img02' src='".trim($fln)."'/>
																			<p class='page_prof_btndiv01' align='center'>
																				<button type='button' class='btn btn-primary btn-sm' data-dismiss='modal'>Close</button>
																			</p>
																		</div>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="doc" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="docx"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_doc.png' />
																		</a>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="pdf"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_pdf.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														if ( $dn <= 0 ) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_empty.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														echo "<div class='page_prof_divlist01' align='left'>$filef</div>";
													}
												}
											}
										?>
									</p>
								</div>
							</div>
							<!-- END PANEL DEFAULT -->
							
							<!-- PANEL DEFAULT -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="page_prof_reqtitle01">White Form</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body">
									<p align="left">
										<?php include "./data/connect.php";
												$sid = $_GET['id'];
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
											//
											$tsn = "";
											//
											$nn = "";
											//
											$tsn = "requirement:white_form";
											$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' order by date_added desc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[4]) != "" ){
													$file = trim($dat[4]);
													$nn = trim($dat[0]);
													//
													$filef = "";
													//
													if ( trim($file)!="" ) {
														//
														$fln = trim($file);
														//
														$dn = 0;
														//
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
															) {
															$filef = "
																		<a class='' href='#' data-toggle='modal' data-target='#modalRPrevImage_$nn'>
																		<img class='page_prof_reqimg01' src='".trim($fln)."' />
																		</a>
																		<div id='modalRPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																			<img class='ann_img02' src='".trim($fln)."'/>
																			<p class='page_prof_btndiv01' align='center'>
																				<button type='button' class='btn btn-primary btn-sm' data-dismiss='modal'>Close</button>
																			</p>
																		</div>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="doc" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="docx"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_doc.png' />
																		</a>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="pdf"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_pdf.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														if ( $dn <= 0 ) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_empty.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														echo "<div class='page_prof_divlist01' align='left'>$filef</div>";
													}
												}
											}
										?>
									</p>
								</div>
							</div>
							<!-- END PANEL DEFAULT -->
							
							<!-- PANEL DEFAULT -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="page_prof_reqtitle01">Recommendation Letter</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body">
									<p align="left">
										<?php include "./data/connect.php";
												$sid = $_GET['id'];
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
											//
											$tsn = "";
											//
											$nn = "";
											//
											$tsn = "requirement:recommendation_letter";
											$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' order by date_added desc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[4]) != "" ){
													$file = trim($dat[4]);
													$nn = trim($dat[0]);
													//
													$filef = "";
													//
													if ( trim($file)!="" ) {
														//
														$fln = trim($file);
														//
														$dn = 0;
														//
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
															) {
															$filef = "
																		<a class='' href='#' data-toggle='modal' data-target='#modalRPrevImage_$nn'>
																		<img class='page_prof_reqimg01' src='".trim($fln)."' />
																		</a>
																		<div id='modalRPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																			<img class='ann_img02' src='".trim($fln)."'/>
																			<p class='page_prof_btndiv01' align='center'>
																				<button type='button' class='btn btn-primary btn-sm' data-dismiss='modal'>Close</button>
																			</p>
																		</div>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="doc" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="docx"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_doc.png' />
																		</a>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="pdf"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_pdf.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														if ( $dn <= 0 ) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_empty.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														echo "<div class='page_prof_divlist01' align='left'>$filef</div>";
													}
												}
											}
										?>
									</p>
								</div>
							</div>
							<!-- END PANEL DEFAULT -->
							
							<!-- PANEL DEFAULT -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="page_prof_reqtitle01">Waiver</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body">
									<p align="left">
										<?php include "./data/connect.php";
												$sid = $_GET['id'];
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
											//
											$tsn = "";
											//
											$nn = "";
											//
											$tsn = "requirement:waiver";
											$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' order by date_added desc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[4]) != "" ){
													$file = trim($dat[4]);
													$nn = trim($dat[0]);
													//
													$filef = "";
													//
													if ( trim($file)!="" ) {
														//
														$fln = trim($file);
														//
														$dn = 0;
														//
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
															) {
															$filef = "
																		<a class='' href='#' data-toggle='modal' data-target='#modalRPrevImage_$nn'>
																		<img class='page_prof_reqimg01' src='".trim($fln)."' />
																		</a>
																		<div id='modalRPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																			<img class='ann_img02' src='".trim($fln)."'/>
																			<p class='page_prof_btndiv01' align='center'>
																				<button type='button' class='btn btn-primary btn-sm' data-dismiss='modal'>Close</button>
																			</p>
																		</div>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="doc" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="docx"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_doc.png' />
																		</a>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="pdf"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_pdf.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														if ( $dn <= 0 ) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_empty.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														echo "<div class='page_prof_divlist01' align='left'>$filef</div>";
													}
												}
											}
										?>
									</p>
								</div>
							</div>
							<!-- END PANEL DEFAULT -->
							
							<!-- PANEL DEFAULT -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="page_prof_reqtitle01">Parent's Consent</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body">
									<p align="left">
										<?php include "./data/connect.php";
												$sid = $_GET['id'];
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
											//
											$tsn = "";
											//
											$nn = "";
											//
											$tsn = "requirement:parent_consent";
											$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' order by date_added desc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[4]) != "" ){
													$file = trim($dat[4]);
													$nn = trim($dat[0]);
													//
													$filef = "";
													//
													if ( trim($file)!="" ) {
														//
														$fln = trim($file);
														//
														$dn = 0;
														//
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
															) {
															$filef = "
																		<a class='' href='#' data-toggle='modal' data-target='#modalRPrevImage_$nn'>
																		<img class='page_prof_reqimg01' src='".trim($fln)."' />
																		</a>
																		<div id='modalRPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																			<img class='ann_img02' src='".trim($fln)."'/>
																			<p class='page_prof_btndiv01' align='center'>
																				<button type='button' class='btn btn-primary btn-sm' data-dismiss='modal'>Close</button>
																			</p>
																		</div>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="doc" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="docx"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_doc.png' />
																		</a>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="pdf"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_pdf.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														if ( $dn <= 0 ) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_empty.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														echo "<div class='page_prof_divlist01' align='left'>$filef</div>";
													}
												}
											}
										?>
									</p>
								</div>
							</div>
							<!-- END PANEL DEFAULT -->
							
							<!-- PANEL DEFAULT -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="page_prof_reqtitle01">Medical Certificate</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body">
									<p align="left">
										<?php include "./data/connect.php";
												$sid = $_GET['id'];
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
											//
											$tsn = "";
											//
											$nn = "";
											//
											$tsn = "requirement:medical_certificate";
											$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' order by date_added desc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[4]) != "" ){
													$file = trim($dat[4]);
													$nn = trim($dat[0]);
													//
													$filef = "";
													//
													if ( trim($file)!="" ) {
														//
														$fln = trim($file);
														//
														$dn = 0;
														//
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
															) {
															$filef = "
																		<a class='' href='#' data-toggle='modal' data-target='#modalRPrevImage_$nn'>
																		<img class='page_prof_reqimg01' src='".trim($fln)."' />
																		</a>
																		<div id='modalRPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																			<img class='ann_img02' src='".trim($fln)."'/>
																			<p class='page_prof_btndiv01' align='center'>
																				<button type='button' class='btn btn-primary btn-sm' data-dismiss='modal'>Close</button>
																			</p>
																		</div>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="doc" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="docx"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_doc.png' />
																		</a>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="pdf"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_pdf.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														if ( $dn <= 0 ) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_empty.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														echo "<div class='page_prof_divlist01' align='left'>$filef</div>";
													}
												}
											}
										?>
									</p>
								</div>
							</div>
							<!-- END PANEL DEFAULT -->
							
							<!-- PANEL DEFAULT -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="page_prof_reqtitle01">Certificate of Appreciation</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body">
									<p align="left">
										<?php include "./data/connect.php";
												$sid = $_GET['id'];
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
											//
											$tsn = "";
											//
											$nn = "";
											//
											$tsn = "requirement:certificate_of_appreciation";
											$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' order by date_added desc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[4]) != "" ){
													$file = trim($dat[4]);
													$nn = trim($dat[0]);
													//
													$filef = "";
													//
													if ( trim($file)!="" ) {
														//
														$fln = trim($file);
														//
														$dn = 0;
														//
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
															) {
															$filef = "
																		<a class='' href='#' data-toggle='modal' data-target='#modalRPrevImage_$nn'>
																		<img class='page_prof_reqimg01' src='".trim($fln)."' />
																		</a>
																		<div id='modalRPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																			<img class='ann_img02' src='".trim($fln)."'/>
																			<p class='page_prof_btndiv01' align='center'>
																				<button type='button' class='btn btn-primary btn-sm' data-dismiss='modal'>Close</button>
																			</p>
																		</div>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="doc" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="docx"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_doc.png' />
																		</a>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="pdf"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_pdf.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														if ( $dn <= 0 ) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_empty.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														echo "<div class='page_prof_divlist01' align='left'>$filef</div>";
													}
												}
											}
										?>
									</p>
								</div>
							</div>
							<!-- END PANEL DEFAULT -->
							
							<!-- PANEL DEFAULT -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="page_prof_reqtitle01">Certificate of Completion</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body">
									<p align="left">
										<?php include "./data/connect.php";
												$sid = $_GET['id'];
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
											//
											$tsn = "";
											//
											$nn = "";
											//
											$tsn = "requirement:certificate_of_completion";
											$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' order by date_added desc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[4]) != "" ){
													$file = trim($dat[4]);
													$nn = trim($dat[0]);
													//
													$filef = "";
													//
													if ( trim($file)!="" ) {
														//
														$fln = trim($file);
														//
														$dn = 0;
														//
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
															) {
															$filef = "
																		<a class='' href='#' data-toggle='modal' data-target='#modalRPrevImage_$nn'>
																		<img class='page_prof_reqimg01' src='".trim($fln)."' />
																		</a>
																		<div id='modalRPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																			<img class='ann_img02' src='".trim($fln)."'/>
																			<p class='page_prof_btndiv01' align='center'>
																				<button type='button' class='btn btn-primary btn-sm' data-dismiss='modal'>Close</button>
																			</p>
																		</div>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="doc" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="docx"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_doc.png' />
																		</a>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="pdf"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_pdf.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														if ( $dn <= 0 ) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_empty.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														echo "<div class='page_prof_divlist01' align='left'>$filef</div>";
													}
												}
											}
										?>
									</p>
								</div>
							</div>
							<!-- END PANEL DEFAULT -->
							
							<!-- PANEL DEFAULT -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="page_prof_reqtitle01">OJT Photos</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body">
									<p align="left">
										<?php include "./data/connect.php";
												$sid = $_GET['id'];
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
											//
											$tsn = "";
											//
											$nn = "";
											//
											$tsn = "requirement:ojt_photo";
											$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' order by date_added desc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[4]) != "" ){
													$file = trim($dat[4]);
													$nn = trim($dat[0]);
													//
													$filef = "";
													//
													if ( trim($file)!="" ) {
														//
														$fln = trim($file);
														//
														$dn = 0;
														//
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
															) {
															$filef = "
																		<a class='' href='#' data-toggle='modal' data-target='#modalRPrevImage_$nn'>
																		<img class='page_prof_reqimg01' src='".trim($fln)."' />
																		</a>
																		<div id='modalRPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																			<img class='ann_img02' src='".trim($fln)."'/>
																			<p class='page_prof_btndiv01' align='center'>
																				<button type='button' class='btn btn-primary btn-sm' data-dismiss='modal'>Close</button>
																			</p>
																		</div>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="doc" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="docx"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_doc.png' />
																		</a>
																		";
															$dn += 1;
														}
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="pdf"
															) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_pdf.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														if ( $dn <= 0 ) {
															$filef = "
																		<a class='' target='_blank' href='".trim($fln)."'>
																		<img class='page_prof_reqimg01' src='./assets/img/dt_empty.png' />
																		</a>
																		";
															$dn += 1;
														}
														//
														echo "<div class='page_prof_divlist01' align='left'>$filef</div>";
													}
												}
											}
										?>
									</p>
								</div>
							</div>
							<!-- END PANEL DEFAULT -->
							
						</div>
					</div>