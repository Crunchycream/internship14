		<div id="modalAddInterns" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Add New Interns</h4>
			</div>
					<form method="post" action="">
			<div class="modal-body">
				<p>
					<div class="form-group">
									<?php echo $_SESSION['intern_disp_err']; $_SESSION['intern_disp_err'] = ""; ?>
								</div>
								<div class="form-group div01">
									<label for="stud-add-id" class="control-label sr-only">Student ID</label>
									<input type="text" name="studid" class="form-control txt01" id="stud-add-id" placeholder="Student ID"
										<?php
											$value = $_POST['studid'];
											echo " value='$value' ";
										?>
									>
								</div>
								<div class="form-group div01">
									<table>
										<tr>
											<td class="td01">
												<label for="stud-add-fn" class="control-label sr-only">Firstname</label>
												<input type="text" name="fname" class="form-control txt01" id="stud-add-fn" placeholder="Firstname"
													<?php
														$value = $_POST['fname'];
														echo " value='$value' ";
													?>
												>
											</td>
											<td class="td01">
												<label for="stud-add-mn" class="control-label sr-only">Middlename</label>
												<input type="text" name="mname" class="form-control txt01" id="stud-add-mn" placeholder="Middlename"
													<?php
														$value = $_POST['mname'];
														echo " value='$value' ";
													?>
												>
											</td>
											<td class="td01">
												<label for="stud-add-ln" class="control-label sr-only">Lastname</label>
												<input type="text" name="lname" class="form-control txt01" id="stud-add-ln" placeholder="Lastname"
													<?php
														$value = $_POST['lname'];
														echo " value='$value' ";
													?>
												>
											</td>
										</tr>
									</table>
									
								</div>
								<div class="div01">
									<table>
										<tr>
											<td class="td01">
												<select class="form-control txt01" name="gender">
													<?php include "./data/connect.php";
														$sql = " select no,gender from tbl_gender ";
														$qry = mysqli_query($conn,$sql);
														while($dat=mysqli_fetch_array($qry)) {
															if ( trim($dat[1]) != "" ) {
																echo "<option value='".trim($dat[1])."'>".trim($dat[1])."</option>";
															}
														}
													?>
												</select>
											</td>
										</tr>
									</table>
								</div>
								<div class="div01">
									<table>
										<tr>
											<td class="td01">
												<select class="form-control txt01" name="course">
													<?php include "./data/connect.php";
														$sql = " select course_id,course from tbl_course ";
														$qry = mysqli_query($conn,$sql);
														while($dat=mysqli_fetch_array($qry)) {
															if ( trim($dat[1]) != "" ) {
																echo "<option value='".trim($dat[0])."'>".trim($dat[1])."</option>";
															}
														}
													?>
												</select>
											</td>
											<td class="td01">
												<select class="form-control txt01" name="year">
													<?php include "./data/connect.php";
														$sql = " select year_id,year from tbl_year ";
														$qry = mysqli_query($conn,$sql);
														while($dat=mysqli_fetch_array($qry)) {
															if ( trim($dat[1]) != "" ) {
																echo "<option value='".trim($dat[1])."'>".trim($dat[1])."</option>";
															}
														}
													?>
												</select>
											</td>
										</tr>
									</table>
								</div>
								<table>
									<tr>
										<td class="td01">
											<div class="form-group">
												<label for="stud-add-contactno" class="control-label sr-only">Contact #</label>
												<input type="text" name="contactno" class="form-control txt01" id="stud-add-contactno" placeholder="Contact #"
													<?php
														$value = $_POST['contactno'];
														echo " value='$value' ";
													?>
												>
											</div>
										</td>
										<td class="td01">
											<div class="form-group">
												<label for="stud-add-email" class="control-label sr-only">E-mail</label>
												<input type="text" name="email" class="form-control txt01" id="stud-add-email" placeholder="E-mail"
													<?php
														$value = $_POST['email'];
														echo " value='$value' ";
													?>
												>
											</div>
										</td>
									</tr>
								</table>
								
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" name="btnsave" class="btn btn-primary btn-lg btn01" value="SAVE">
			</div>
					</form>
			</div>

			</div>
		</div>