
							<div class="header">
								<div class="logo text-center"></div>
								<p class="lead">Lost password recovery</p>
							</div>
							<form class="form-auth-small" action="index.php" method="post">
								<div class="form-group">
									<?php echo $_SESSION['intern_disp_err']; $_SESSION['intern_disp_err'] = ""; ?>
								</div>
								<div class="form-group">
									<label for="signin-email" class="control-label sr-only">Username</label>
									<input type="username" name="username" class="form-control" id="signin-email" placeholder="Username"
										<?php
											$value = $_POST['username'];
											echo " value='$value' ";
										?>
									>
								</div>
								<div class="form-group">
									<label for="signin-rmail" class="control-label sr-only">E-mail</label>
									<input type="text" name="rmail" class="form-control" id="signin-rmail" placeholder="E-mail"
										<?php
											$value = $_POST['rmail'];
											echo " value='$value' ";
										?>
									>
								</div>
								<input type="submit" name="btnloginlostpass" class="btn btn-primary btn-lg btn-block" value="Send Recovery E-mail">
								<div class="form-group clearfix">
								</div>
								
							</form>

								<br/>
								<div class="form-group clearfix" align="center">
									<b>[ <a href="./index.php"><span>Login</span></a> ]</b>
								</div>