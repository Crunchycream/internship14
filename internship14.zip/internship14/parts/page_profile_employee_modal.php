		<div id="modalChangePhoto" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Change Profile Photo</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-default" value="Save" name="btnProfilePhotoChange">
			</div>
					</form>
			</div>

			</div>
		</div>
		<div id="modalChangeCoverPhoto" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Change Cover Photo</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-default" value="Save" name="btnProfileCoverPhotoChange">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqResume" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update Resume</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF files only.<br/>
					<input type="hidden" name="action" value="resume">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-default" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqAppLet" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update Application Letter</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF files only.<br/>
					<input type="hidden" name="action" value="appletter">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-default" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqMOA" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update MOA</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF files only.<br/>
					<input type="hidden" name="action" value="moa">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-default" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqMOU" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update MOU</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF files only.<br/>
					<input type="hidden" name="action" value="mou">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-default" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<div id="modalReqCertAcc" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update Certificatin of Acceptance</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					DOC / DOCX / PDF files only.<br/>
					<input type="hidden" name="action" value="certacc">
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-default" value="Save" name="btnReqSave">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ================================================================================================= -->
		<!-- ================================================================================================= -->