
	<script type="text/javascript">
		//
		var lcount = 0;
		var count = 0;
		//
		setInterval('my_function();',1000);
		//
	    function my_function(){
	      $('#msgcountc').load(location.href + ' #msgcountcs');
	      //
	      count = parseInt( document.getElementById('d_msgcount').value );
	      if ( lcount != count ) {
	      	lcount = count;
	      	//
	      	$('#topmsgl').load(location.href + ' #topmsgls');
	      	//
	      	$('#msglogsup').load(location.href + ' #msglogsups');
	      	$('#conlist').load(location.href + ' #conlists');
	      	$('#msglist').load(location.href + ' #msglists');
	      	//
	      }
	    }

	</script>
