<?php include "./data/connect.php"; include "./parts/sys_functions.php"; include "./parts/sys_functions_02.php";
	$uid = $_GET['id'];
	$idname = "";
	//
$memid =  $_SESSION['intern_data_cun'];
$memtype = $_SESSION['intern_data_utype'];
	if ( trim($uid)!="" ) {
		$sql = " select class_id,name from tbl_class  where class_id='$uid' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			$idname = trim($dat[1]);
		}
	}
	if ( trim($uid)!="" ) {
		$target_dir = "uploads/";
		$foname = basename($_FILES["fileUP"]["name"]);
		$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
		$target_file = $target_dir . $foname;
		$target_file2 = "";
		$uploadOk = 1;
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		// Check if image file is a actual image or fake image
		if(isset($_POST["btnProfileCoverPhotoChange"])) {
		    // Check file size
			if ($_FILES["fileUP"]["size"] > 500000) {
			    //echo "Sorry, your file is too large.";
			    //$uploadOk = 0;
			}
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" && $imageFileType != "bmp" && $imageFileType != "ico" ) {
			    $uploadOk = 0;
			}
			if ($uploadOk == 0) {
			    //echo "Sorry, your file was not uploaded.";
			} else {
				//GET NEW NAME
				$fln = "file_".$date_month."_".$date_day."_".$date_year."__".$date_hour."_".$date_minute."_".$date_second.".".$imageFileType;
			    $target_file2 = $target_dir . "$fln";
			    if (move_uploaded_file($_FILES["fileUP"]["tmp_name"], $target_file2)) {
			        //echo "The file ". basename( $_FILES["fileUP"]["name"]). " has been uploaded.";
			        //UPDATE TO USER
			        $sql = " update tbl_class set prof_backimg='$target_file2'  where class_id='$uid' ";
					$qry = mysqli_query($conn,$sql);
					//SAVE TO UPLOADED FILES
			        $sql = " insert into tbl_upfiles
			        			 (name,location,date_uploaded)
			        		 values
			        		 	 ('$foname','$target_file2','$cdate') ";
					$qry = mysqli_query($conn,$sql);
					//NOTIFICATION
					$notif_ttl = "Cover photo changed.";
					$notif_lnk = "";
					$notif_cont = "$idname: Cover photo changed.";
					$notif_locid = "$uid";
					$notif_loctype = "class";
					$notif_tarsn = "page_class";
					$notif_status = "unseen";
					addNotification($memid,$memtype,$notif_ttl,$notif_lnk,$notif_cont,$notif_locid,$notif_loctype,$notif_tarsn,$notif_status);
			    } else {
			        //echo "Sorry, there was an error uploading your file.";
			    }
			}
		}
		if(isset($_POST["btnAddActPostComment"])) {
		    // Check file size
			if ($_FILES["fileUP"]["size"] > 500000) {
			    //echo "Sorry, your file is too large.";
			    //$uploadOk = 0;
			}
			if($imageFileType != "doc" && $imageFileType != "docx" && $imageFileType != "pdf" ) {
			    $uploadOk = 0;
			}
			if ($uploadOk == 0) {
			    //echo "Sorry, your file was not uploaded.";
			} else {
				//GET NEW NAME
				$fln = "file_".$date_month."_".$date_day."_".$date_year."__".$date_hour."_".$date_minute."_".$date_second.".".$imageFileType;
			    $target_file2 = $target_dir . "$fln";
			    if (move_uploaded_file($_FILES["fileUP"]["tmp_name"], $target_file2)) {
			        //echo "The file ". basename( $_FILES["fileUP"]["name"]). " has been uploaded.";
			        //UPDATE TO USER
					$pstid = $_POST['postid'];
					$type = $_POST['type'];
					$msg = htmlspecialchars( $_POST['msg'] , ENT_QUOTES );
					$weekname = $_POST['weekname'];
					//
					$memid =  $_SESSION['intern_data_cun'];
					$memtype = $_SESSION['intern_data_utype'];
					//
					$date = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
					$tsubstat = getClassActSubmissionStat($uid,$pstid,$memid);
					$tcupid = getClassActSubmissionPostID($uid,$pstid,$memid);
					$sql = "";
						if ( $tsubstat==true ) {
							$sql = " 
									update tbl_class_posts set 
										file_att='$target_file2',file_att_name='$foname' 
									  where class_post_id='$tcupid'
								 ";
						}else{
							$sql = " insert into tbl_class_posts 
									(class_id,member_id,member_type,type,content,date_posted,parent_post_id,file_att,file_att_name,activity_sub)
								values
									('$uid','$memid','$memtype','$type','$msg','$date','$pstid','$target_file2','$foname','true')
							";
						}
			        
					$qry = mysqli_query($conn,$sql);
					//SAVE TO UPLOADED FILES
			        $sql = " insert into tbl_upfiles
			        			 (name,location,date_uploaded,upby_id,upby_type,utype,uloc_id,uloc_type,uloc2_id,weekname)
			        		 values
			        		 	 ('$foname','$target_file2','$cdate','$memid','$memtype','$type','$uid','class','$pstid','$weekname') ";
					$qry = mysqli_query($conn,$sql);
					//
					//
					if ( strtolower(trim($memtype))==strtolower(trim("student")) ) {
						$msg = " submitted a reflection in ".trim($idname)." class.";
						$msgt = "1";
						addUserActivityLog($memid,$memtype,$msg,$msgt);
					}
			    } else {
			        //echo "Sorry, there was an error uploading your file.";
			    }
			}
		}
	}
	if ( trim($uid)!="" ) {
		//ADD HTE
		if ($_POST["btnAddHTE"]) {
			$value = $_POST['hte'];
			$errn = 0;
			$errmsg = "";
			if ( trim($value) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "HTE required. ";
			}
			$ec = 0;
			$sql = " select * from tbl_class_member_hte  where hte_id='$value' ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				$ec = $ec + 1;
			}
			if ( trim($ec) > 0 ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "HTE already added. ";
			}
			if ( $errn <= 0 ) {
				//SAVE DATA
				$sql = " insert into tbl_class_member_hte 
							(class_id,hte_id)
							values
							('$uid','$value')
						";
				$qry = mysqli_query($conn,$sql);
					//NOTIFICATION
					$notif_ttl = "New HTE added.";
					$notif_lnk = "";
					$notif_cont = "$idname: New HTE added.";
					$notif_locid = "$uid";
					$notif_loctype = "class";
					$notif_tarsn = "page_class";
					$notif_status = "unseen";
					addNotification($memid,$memtype,$notif_ttl,$notif_lnk,$notif_cont,$notif_locid,$notif_loctype,$notif_tarsn,$notif_status);
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
			}
		}
		//ADD POST
		if ($_POST["btnAddPost"]) {
			$type = $_POST['type'];
			$msg = htmlspecialchars( $_POST['msg'] , ENT_QUOTES );
			$memid =  $_SESSION['intern_data_cun'];
			$memtype = $_SESSION['intern_data_utype'];
			$date = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
			$ppid = trim($_POST['postid']);
			$weekname = trim($_POST['weekname']);
			//
			$tsn = "post";
			if ( strtolower(trim($tsn))==strtolower(trim($type)) ) {
				$errn = 0;
				$errmsg = "";
				if ( trim($memid) == "" ) {
					$errn = $errn + 1;
				}
				if ( trim($msg) == "" ) {
					$errn = $errn + 1;
					$errmsg = $errmsg . "Message required. ";
				}
				if ( $errn <= 0 ) {
					//SAVE DATA
					$sql = " insert into tbl_class_posts 
								(class_id,member_id,member_type,type,content,date_posted,parent_post_id,activity_sub)
								values
								('$uid','$memid','$memtype','$type','$msg','$date','$ppid','false')
							";
					$qry = mysqli_query($conn,$sql);
					//NOTIFICATION
					$notif_ttl = "New post added.";
					$notif_lnk = "";
					$notif_cont = "$idname: New post added.";
					$notif_locid = "$uid";
					$notif_loctype = "class";
					$notif_tarsn = "page_class";
					$notif_status = "unseen";
					addNotification($memid,$memtype,$notif_ttl,$notif_lnk,$notif_cont,$notif_locid,$notif_loctype,$notif_tarsn,$notif_status);
					//
					if ( strtolower(trim($memtype))==strtolower(trim("student")) ) {
						$msg = " posted in ".trim($idname)." class.";
						$msgt = "1";
						//addUserActivityLog($memid,$memtype,$msg,$msgt);
					}
					//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
				}else{
					//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
					echo "
						<script>
							alert('$errmsg');
						</script>
					";
				}
			}
			$tsn = "reflection";
			if ( strtolower(trim($tsn))==strtolower(trim($type)) ) {
				//
				$errn = 0;
				$errmsg = "";
				//
				$ec = 0;
				$sql = " select * from tbl_class_posts  where class_id='$uid' and type='$type' and parent_post_id='' and activity_sub='false' and weekname='$weekname' ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					$ec = $ec + 1;
				}
				if ( trim($ec) > 0 ) {
					$errn = $errn + 1;
					$errmsg = $errmsg . "Submission area for that Week already created. ";
				}
				//
				if ( $errn <= 0 ) {
					//SAVE DATA
					$sql = " insert into tbl_class_posts 
								(class_id,member_id,member_type,type,content,date_posted,parent_post_id,activity_sub,weekname)
								values
								('$uid','$memid','$memtype','$type','$msg','$date','$ppid','false','$weekname')
							";
					$qry = mysqli_query($conn,$sql);
					//NOTIFICATION
					$notif_ttl = "New reflection requirement added.";
					$notif_lnk = "";
					$notif_cont = "$idname: New activity added.";
					$notif_locid = "$uid";
					$notif_loctype = "class";
					$notif_tarsn = "page_class";
					$notif_status = "unseen";
					addNotification($memid,$memtype,$notif_ttl,$notif_lnk,$notif_cont,$notif_locid,$notif_loctype,$notif_tarsn,$notif_status);
					//
					if ( strtolower(trim($memtype))==strtolower(trim("student")) ) {
						$msg = " submitted a reflection in ".trim($idname)." class.";
						$msgt = "1";
						//addUserActivityLog($memid,$memtype,$msg,$msgt);
					}
					//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
				}else{
					//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
					echo "
						<script>
							alert('$errmsg');
						</script>
					";
				}
			}
		}
		//
		//EDIT POST
		if ($_POST["btnsavepostEdit"]) {
			//
			$pid = $_POST['txtid'];
			//
			$type = $_POST['type'];
			$msg = htmlspecialchars( $_POST['msg'] , ENT_QUOTES );
			//
			$memid =  $_SESSION['intern_data_cun'];
			$memtype = $_SESSION['intern_data_utype'];
			//
			$tsn = "post";
			if ( strtolower(trim($tsn))==strtolower(trim($type)) ) {
				$errn = 0;
				$errmsg = "";
				if ( trim($memid) == "" ) {
					$errn = $errn + 1;
				}
				if ( trim($msg) == "" ) {
					$errn = $errn + 1;
					$errmsg = $errmsg . "Message required. ";
				}
				if ( $errn <= 0 ) {
					//SAVE DATA
					$sql = " update tbl_class_posts set  
								content='$msg' 
									where class_post_id='$pid' 
							";
					$qry = mysqli_query($conn,$sql);
					//
					//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
				}else{
					//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
					echo "
						<script>
							alert('$errmsg');
						</script>
					";
				}
			}
			$tsn = "reflection";
			if ( strtolower(trim($tsn))==strtolower(trim($type)) ) {
				//
				$errn = 0;
				$errmsg = "";
				//
				//
				if ( $errn <= 0 ) {
					//SAVE DATA
					$sql = " update tbl_class_posts set  
								content='$msg' 
									where class_post_id='$pid' 
							";
					$qry = mysqli_query($conn,$sql);
					//
					//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
				}else{
					//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
					echo "
						<script>
							alert('$errmsg');
						</script>
					";
				}
			}
		}
		//
		if ($_POST["btnsavepostDelete"]) {
			//
			$pid = $_POST['txtid'];
			//
			//
			$memid =  $_SESSION['intern_data_cun'];
			$memtype = $_SESSION['intern_data_utype'];
			//
			if ( trim($pid)!="" ) {

					$sql = " delete from tbl_class_posts 
								where class_post_id='$pid' 
							";
					$qry = mysqli_query($conn,$sql);

			}
		}
//===============================================================================

		if ( $_POST['btnsaveAddCOORD'] ) {
			$employee_id = (trim($_POST['empid']));
			$department_id = (trim($_POST['deptid']));
			$course_id = (trim($_POST['crsid']));
			$hte_id = (trim($_POST['hteid']));
			$errn = 0;
			$errmsg = "";
			if ( trim($employee_id) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Employee required. ";
			}
			if ( trim($department_id) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Department required. ";
			}
			if ( trim($course_id) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Course required. ";
			}
			if ( trim($hte_id) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "HTE required. ";
			}
			$ec = 0;
			$sql = " select * from tbl_coordinator  where employee_id='$employee_id' and department_id='$department_id' and course_id='$course_id' and hte_id='$hte_id' ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				$ec = $ec + 1;
			}
			if ( trim($ec) > 0 ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Coordinator already exist. ";
			}
			if ( $errn <= 0 ) {
				//SAVE DATA
				$sql = " insert into tbl_coordinator  
							(employee_id,department_id,course_id,hte_id)
							values
							('$employee_id','$department_id','$course_id','$hte_id')
						";
				$qry = mysqli_query($conn,$sql);
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
			}
		}
		//
		//
		if ( $_POST['btnsaveSendMessage'] ) {
			$rcv_id = $_POST['txtstudid'];
			$rcv_type = $_POST['txtstudtype'];
			//
			$snd_id = $_SESSION['intern_data_cun'];
			$snd_type = $_SESSION['intern_data_utype'];
			//
			$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
			//
			$msg = htmlspecialchars( $_POST['msg'] , ENT_QUOTES );
			//
			$errmsg = "";
			$errn = 0;
			if ( trim($msg) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Enter a message. ";
			}
			if ( $errn <= 0 ) {
				//SAVE DATA
				if ( trim($rcv_id)!="" && trim($snd_id)!="" && ($msg)!="" ) {
					//
					//GET GRROUP ID, IF NONE CREATE AND GET
					$tgid = "";
					//
					//                    0       1     2    3    4     5     6      7
					$sql = " select msgs_group_id,mem1_id,mem1_type,mem2_id,mem2_type from tbl_messages_group where ( mem1_id='$rcv_id' and mem1_type='$rcv_type' and mem2_id='$snd_id' and mem2_type='$snd_type' ) or ( mem1_id='$snd_id' and mem1_type='$snd_type' and mem2_id='$rcv_id' and mem2_type='$rcv_type' ) ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						$tgid = trim($dat[0]);
					}
					//
					if ( trim($tgid)=="" ) {
						//CREATE
						$sql = " insert into tbl_messages_group
									( mem1_id,mem1_type,mem2_id,mem2_type )
								values
									( '$rcv_id','$rcv_type','$snd_id','$snd_type' )
						 ";
							$qry = mysqli_query($conn,$sql);
					}
					//GET
					//                    0       1     2    3    4     5     6      7
					$sql = " select msgs_group_id,mem1_id,mem1_type,mem2_id,mem2_type from tbl_messages_group where ( mem1_id='$rcv_id' and mem1_type='$rcv_type' and mem2_id='$snd_id' and mem2_type='$snd_type' ) or ( mem1_id='$snd_id' and mem1_type='$snd_type' and mem2_id='$rcv_id' and mem2_type='$rcv_type' ) ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						$tgid = trim($dat[0]);
					}
					//
					//
					//FOR SENDER
					$sql = "
							insert into tbl_messages
								(rcv_id,rcv_type,snd_id,snd_type,message,date_sent,own_id,own_type,msgs_group_id) 
							values 
								('$rcv_id','$rcv_type','$snd_id','$snd_type','$msg','$cdate','$snd_id','$snd_type','$tgid') 
							";
					$qry = mysqli_query($conn,$sql);
					//FOR RECEIVER
					$sql = "
							insert into tbl_messages
								(rcv_id,rcv_type,snd_id,snd_type,message,date_sent,own_id,own_type,msgs_group_id) 
							values 
								('$rcv_id','$rcv_type','$snd_id','$snd_type','$msg','$cdate','$rcv_id','$rcv_type','$tgid') 
							";
					$qry = mysqli_query($conn,$sql);
				}
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
			}
		}
//===============================================================================

		if ( $_POST['btnsaveStaff'] ) {
			$staff = trim($_POST['txtemployee']);
			$position = trim($_POST['txtposition']);
			//$memid = "1234";
			$errmsg = "";
			$errn = 0;
			//
			if ( trim($memid) == "" || strtolower(trim($memtype))==strtolower(trim("student")) ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "";
			}
			//
			if ( trim($staff) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Staff required. ";
			}
			if ( trim($position) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Position required. ";
			}
			//
			$ec = 0;
			$sql = " select * from tbl_class_staff  where class_id='$uid' and staff_id='$staff' and staff_type='employee' ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				$ec = $ec + 1;
			}
			if ( trim($ec) > 0 ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Staff already added. ";
			}
			//
			//
			if ( $errn <= 0 ) {
				//SAVE DATA
				$sql = " insert into tbl_class_staff 
							(class_id,staff_id,staff_type,position)
							values
							('$uid','$staff','employee','$position')
						";
				$qry = mysqli_query($conn,$sql);
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
			}
		}

		if ( $_POST['btnsaveStaffRemove'] ) {
			$id = trim($_POST['txtid']);
			//
			$errmsg = "";
			$errn = 0;
			//
			if ( trim($memid) == "" || strtolower(trim($memtype))==strtolower(trim("student")) ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "";
			}
			//
			if ( trim($id) == "" ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "";
			}
			//
			//
			if ( $errn <= 0 ) {
				//SAVE DATA
				$sql = " delete from tbl_class_staff  
							where class_staff_id='$id' 
						";
				$qry = mysqli_query($conn,$sql);
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
			}else{
				//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				//echo "
				//	<script>
				//		alert('$errmsg');
				//	</script>
				//";
			}
		}
		


	}
	//MSGS LOG UPDATER
	include "./parts/msgs_logupdater.php";
?>