		<div id="modalChangeCoverPhoto" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Change Cover Photo</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary" value="Save" name="btnProfileCoverPhotoChange">
			</div>
					</form>
			</div>

			</div>
		</div>
    <!--==============ADD HTE==========================-->
		<div id="modalAddHTE" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Add HTE</h4>
			</div>
					<form action="" method="post">
			<div class="modal-body">
				<p>
					<select class="form-control txt01" name="hte">
						<?php include "./data/connect.php";
							$exc = "";
							//GET ALREADY ADDED
							$sql = " select hte_id from tbl_class_member_hte ";
							$qry = mysqli_query($conn,$sql);
							while($dat=mysqli_fetch_array($qry)) {
								if ( trim($dat[0]) != "" ) {
									if ( trim($exc)=="" ) {
										$exc = " where hte_id<>'$dat[0]' ";
									}else{
										$exc = $exc . " and hte_id<>'$dat[0]' ";
									}
								}
							}
							//LOAD AVAILABLE
							$sql = " select hte_id,name from tbl_hte  $exc  order by name asc ";
							$qry = mysqli_query($conn,$sql);
							while($dat=mysqli_fetch_array($qry)) {
								if ( trim($dat[1]) != "" ) {
									echo "<option value='".trim($dat[0])."'>".trim($dat[1])."</option>";
								}
							}
						?>
					</select>
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary" value="Save" name="btnAddHTE">
			</div>
					</form>
			</div>

			</div>
		</div>
    <!--==============ADD HTE==========================-->
    <!--==============ADD POST==========================-->
		<div id="modalAddPost" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Add Post</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					<div class="form-group">
						<?php echo $_SESSION['intern_disp_err']; $_SESSION['intern_disp_err'] = ""; ?>
					</div>

					<input type="hidden" name="cpt" value="post" />

					<div class="form-group div01">
						<input type="hidden" name="type" value="Post" />
					</div>
					<div class="form-group div01">
						<label for="stud-add-msg" class="control-label sr-only">Message...</label>
						<textarea name="msg" class="form-control texta01" id="stud-add-msg" placeholder="Message..."><?php $value = $_POST['msg']; echo "$value";?></textarea>
					</div>
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary" value="Save" name="btnAddPost">
			</div>
					</form>
			</div>

			</div>
		</div>
    <!--==============ADD POST==========================-->
    <!--==============ADD POST==========================-->
		<div id="modalAddPostReflection" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Add Post</h4>
			</div>
					<form action="" method="post">
			<div class="modal-body">
				<p>
					<div class="form-group">
						<?php echo $_SESSION['intern_disp_err']; $_SESSION['intern_disp_err'] = ""; ?>
					</div>

					<input type="hidden" name="cpt" value="reflection" />

					<div class="form-group div01">
						<b>Week:</b>
						<select class="form-control txt01" name="weekname">
							<?php
								for ( $i=1 ; $i<=48 ; $i++ ) {
									echo "<option value='week_$i'>Week $i</option>";
								}
							?>
						</select>
					</div>
					<div class="form-group div01">
						<input type="hidden" name="type" value="Reflection" />
					</div>
					<div class="form-group div01">
						<label for="stud-add-msg" class="control-label sr-only">Message...</label>
						<textarea name="msg" class="form-control texta01" id="stud-add-msg" placeholder="Message..."><?php $value = $_POST['msg']; echo "$value";?></textarea>
					</div>
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary" value="Save" name="btnAddPost">
			</div>
					</form>
			</div>

			</div>
		</div>
    <!--==============ADD POST==========================-->