    <div id="modalAddEvalInfo" class="modal fade" role="dialog">
      <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add Eval Info</h4>
      </div>
          <form method="post" action="">
      <div class="modal-body">
        <p>
          <div class="form-group">
              <?php echo $_SESSION['intern_disp_err']; $_SESSION['intern_disp_err'] = ""; ?>
            </div>
            <?php
                $ctype = trim($_GET['type']);
                $ftype = $ctype;
                if ( strtolower(trim($ctype))==strtolower(trim("intern")) ) {
                  $ftype = "student";
                }
                //echo "<input type='hidden' name='txtitype' value='$ftype' />";
            ?>
            
            <div class="form-group div01">
              <label for="txt-name" class="control-label sr-only">Name</label>
              <input type="text" name="txtname" class="form-control txt01" id="txt-name" placeholder="Name"
                <?php
                  $value = $_POST['txtname'];
                  echo " value='$value' ";
                ?>
              >
            </div>
            <div class="form-group div01">
              <label for="txt-tagtype" class="control-label sr-only">Type</label>
              <select name="txtitype" class="form-control txt01" id="txt-tagtype" placeholder="Type">
                <option value="hte">HTE</option>
                <option value="intern">INTERN</option>
              </select>
            </div>
            <div class="form-group div01">
              <label for="txt-tdate" class="control-label sr-only">Target Date</label>
              <input type="date" name="txttdate" class="form-control txt01" id="txt-tdate" placeholder="Target Date"
                <?php
                  $value = $_POST['txttdate'];
                  echo " value='$value' ";
                ?>
              >
            </div>
        </p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <input type="submit" name="btnsave" class="btn btn-primary btn-lg btn01" value="SAVE">
      </div>
          </form>
      </div>

      </div>
    </div>