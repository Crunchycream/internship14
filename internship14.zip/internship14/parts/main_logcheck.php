<?php 
		$logun = $_SESSION['intern_data_cun'];
		$logutype = $_SESSION['intern_data_utype'];
			$tcpage = $_SESSION['intern_page_current'];
		if ( trim($logun)=="" ) {
			if ( strtolower(trim($tcpage))!=strtolower(trim("index")) ) {
				echo "<META HTTP-EQUIV='Refresh' Content='0; URL=index.php'>";
			}
		}
	if ( trim($logun)!="" && strtolower(trim($tcpage))==strtolower(trim("index")) ) {
		$tsn = "admin";
		if ( strtolower(trim($logutype)) == strtolower(trim($tsn)) ) {
			echo "<META HTTP-EQUIV='Refresh' Content='0; URL=cpanel.php'>";
		}
		$tsn = "employee";
		if ( strtolower(trim($logutype)) == strtolower(trim($tsn)) ) {
			echo "<META HTTP-EQUIV='Refresh' Content='0; URL=cpanel.php'>";
		}
		$tsn = "student";
		if ( strtolower(trim($logutype)) == strtolower(trim($tsn)) ) {
			echo "<META HTTP-EQUIV='Refresh' Content='0; URL=cpanel.php'>";
		}
	}
		$tsn = "student";
		if ( strtolower(trim($tsn))==strtolower(trim($logutype)) ) {
			$nn = 0;
			$tsn2 = "manage_class";
			if ( strtolower(trim($tsn2))==strtolower(trim($tcpage)) ) {
				$nn = $nn + 1;
			}
			$tsn2 = "manage_coordinator";
			if ( strtolower(trim($tsn2))==strtolower(trim($tcpage)) ) {
				$nn = $nn + 1;
			}
			$tsn2 = "manage_course";
			if ( strtolower(trim($tsn2))==strtolower(trim($tcpage)) ) {
				$nn = $nn + 1;
			}
			$tsn2 = "manage_department";
			if ( strtolower(trim($tsn2))==strtolower(trim($tcpage)) ) {
				$nn = $nn + 1;
			}
			$tsn2 = "manage_employee";
			if ( strtolower(trim($tsn2))==strtolower(trim($tcpage)) ) {
				$nn = $nn + 1;
			}
			$tsn2 = "manage_hte";
			if ( strtolower(trim($tsn2))==strtolower(trim($tcpage)) ) {
				$nn = $nn + 1;
			}
			$tsn2 = "manage_interns";
			if ( strtolower(trim($tsn2))==strtolower(trim($tcpage)) ) {
				$nn = $nn + 1;
			}
			$tsn2 = "manage_rate_scores";
			if ( strtolower(trim($tsn2))==strtolower(trim($tcpage)) ) {
				$nn = $nn + 1;
			}
			$tsn2 = "manage_staff_position";
			if ( strtolower(trim($tsn2))==strtolower(trim($tcpage)) ) {
				$nn = $nn + 1;
			}
			$tsn2 = "manage_year";
			if ( strtolower(trim($tsn2))==strtolower(trim($tcpage)) ) {
				$nn = $nn + 1;
			}
				if ( $nn > 0 ) {
					echo "<META HTTP-EQUIV='Refresh' Content='0; URL=./cpanel.php'>";
				}
		}
	//
	//MSGS LOG UPDATER
	//include "./parts/msgs_logupdater.php";
?>