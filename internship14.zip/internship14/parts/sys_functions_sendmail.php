<?php include "./data/connect.php";
	function sendMail($to,$subject,$msg,$header) {
		//
		$resmsg = "";
		//
		if ( trim($header)=="" ) {
			$header = "From: UMDC Internship Management System";
		}
		if ( trim($to)!="" ) {
			if(mail($to, $subject, $message, $headers)){
				//echo "Your Password has been sent to your email id";
				$resmsg = "Your Password has been sent to your email.";
			}else{
				//echo "Failed to Recover your password, try again";
				$resmsg = "Failed to Recover your password, try again.";
			}
				echo "
					<script>
						alert('$resmsg');
					</script>
				";
		}
	}
?>
