		<div id="modalAddCoordinator" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Add New Coordinator</h4>
			</div>
					<form method="post" action="">
			<div class="modal-body">
				<p>
					<div class="form-group">
									<?php echo $_SESSION['intern_disp_err']; $_SESSION['intern_disp_err'] = ""; ?>
								</div>
								<div class="form-group div01">
									Employee<br/>
										<select class="form-control txt01" name="empid">
											<?php include "./data/connect.php";
												$sql = " select employee_id,lastname,firstname,middlename from tbl_employee  order by lastname asc ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[0]) != "" && trim($dat[1]) != "" && trim($dat[2]) != "" ) {
														$val = trim($dat[0]);
														$nam = trim($dat[1]) . ", " . trim($dat[2]) . " " . trim($dat[3]);
														echo "<option value='".$val."'>".$nam."</option>";
													}
												}
											?>
										</select>
								</div>
								<div class="form-group div01">
									Department<br/>
										<select class="form-control txt01" name="deptid">
											<?php include "./data/connect.php";
												$sql = " select department_id,department from tbl_department  order by department asc  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[0]) != "" && trim($dat[1]) != "" ) {
														$val = trim($dat[0]);
														$nam = trim($dat[1]);
														echo "<option value='".$val."'>".$nam."</option>";
													}
												}
											?>
										</select>
								</div>
								<div class="form-group div01">
									Course<br/>
										<select class="form-control txt01" name="crsid">
											<?php include "./data/connect.php";
												$sql = " select course_id,course from tbl_course  order by course asc ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[0]) != "" && trim($dat[1]) != "" ) {
														$val = trim($dat[0]);
														$nam = trim($dat[1]);
														echo "<option value='".$val."'>".$nam."</option>";
													}
												}
											?>
										</select>
								</div>
								<div class="form-group div01">
									HTE<br/>
										<select class="form-control txt01" name="hteid">
											<?php include "./data/connect.php";
												$sql = " select hte_id,name from tbl_hte  order by name asc ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[0]) != "" && trim($dat[1]) != "" ) {
														$val = trim($dat[0]);
														$nam = trim($dat[1]);
														echo "<option value='".$val."'>".$nam."</option>";
													}
												}
											?>
										</select>
								</div>
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" name="btnsave" class="btn btn-primary btn-lg btn01" value="SAVE">
			</div>
					</form>
			</div>

			</div>
		</div>