<?php include "./data/connect.php";
	function getUserHTE($userid) {
		include "./data/connect.php";
		//
		$hte = "";
		//
		$hteid = "";
		$sql = " select hte_id from tbl_hte_members  where member_id='$userid' order by hte_mem_id desc limit 1 ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			$hteid = trim($dat[0]);
		}
		//GET HTE NAME
		$sql = " select name from tbl_hte  where hte_id='$hteid' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			$hte = trim($dat[0]);
		}
		return $hte;
	}
?>
