		<div id="modalChangeCoverPhoto" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Change Cover Photo</h4>
			</div>
					<form action="" method="post" enctype="multipart/form-data">
			<div class="modal-body">
				<p>
					<input type="file" name="fileUP" id="fileUP">
						
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-success" value="Save" name="btnProfileCoverPhotoChange">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ====================== ADD JOBS ============================== -->
		<div id="modalAddJobs" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Add Jobs</h4>
			</div>
					<form action="" method="post">
			<div class="modal-body">
				<p>
					<div class="form-group">
						<?php echo $_SESSION['intern_disp_err']; $_SESSION['intern_disp_err'] = ""; ?>
					</div>
					<div class="form-group div01">
						<label for="stud-add-name" class="control-label sr-only">Job Name</label>
						<input type="text" name="jobname" class="form-control" id="stud-add-name" placeholder="Job Name"
							<?php
								$value = $_POST['jobname'];
								echo " value='$value' ";
							?>
						>
					</div>
					<div class="form-group div01">
						<label for="stud-add-desc" class="control-label sr-only">Job Description</label>
						<textarea name="jobdesc" class="form-control" id="stud-add-desc" placeholder="Job Description"><?php $value = $_POST['studid']; echo "$value";?></textarea>
					</div>
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-success" value="Save" name="btnAddJob">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ====================== ADD JOBS ============================== -->
		<!-- ====================== ADD INTERNS ============================== -->
		<div id="modalAddInterns" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Add Interns</h4>
			</div>
					<form action="" method="post">
			<div class="modal-body">
				<p>
					<select class="form-control span02" name="studid">
						<?php include "./data/connect.php";
							$uid = $_GET['id'];
							$exc = "";
							//GET ALREADY ADDED
							$sql = " select member_id from tbl_hte_members  where hte_id='$uid' ";
							$qry = mysqli_query($conn,$sql);
							while($dat=mysqli_fetch_array($qry)) {
								if ( trim($dat[0]) != "" ) {
									if ( trim($exc)=="" ) {
										$exc = " where studentid<>'$dat[0]' ";
									}else{
										$exc = $exc . " and studentid<>'$dat[0]' ";
									}
								}
							}
							//LOAD AVAILABLE
							$sql = " select studentid,firstname,middlename,lastname from tbl_interns  $exc  order by lastname asc ";
							$qry = mysqli_query($conn,$sql);
							while($dat=mysqli_fetch_array($qry)) {
								if ( trim($dat[0]) != "" && trim($dat[1]) != "" && trim($dat[3]) != "" ) {
									$memname = "";
									$mname = "";
									if ( trim($dat[2])!="" ) {
										$mname = "" . trim($dat[2]);
									}
									$memname = trim($dat[3]) . ", " . trim($dat[1]) . " " . $mname . " ";
									echo "<option value='".trim($dat[0])."'>".trim($memname)."</option>";
								}
							}
						?>
					</select>
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-success" value="Save" name="btnAddIntern">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ====================== ADD INTERNS ============================== -->
		<!-- ====================== ADD RATE ============================== -->
		<div id="modalAddRating" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Add Rating</h4>
			</div>
					<form action="" method="post">
			<div class="modal-body">
				<p>
					<select class="form-control txt01 span02" name="value">
						<?php include "./data/connect.php";
							$uid = $_GET['id'];
							//LOAD RATINGS
							$sql = " select rate from tbl_rate_score order by rate asc ";
							$qry = mysqli_query($conn,$sql);
							while($dat=mysqli_fetch_array($qry)) {
								if ( trim($dat[0]) ) {
									echo "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
								}
							}
						?>
					</select>
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-success" value="Save" name="btnAddRate">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ====================== ADD RATE ============================== -->
		<!-- ====================== ADD RATE 2 ============================== -->
		<div id="modalHTEEval" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content eval_modal01">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">HTE Evaluation</h4>
			</div>
					<form action="" method="post">
			<div class="modal-body">
				<p>
					<?php include "./data/connect.php";
						//
							$uid = $_GET['id'];
						//
						$cursy = trim($_SESSION['intern_data_active_sy']);
						//
						//
						$rateopt = "";
						$rateopt = "
									<option value='1'>1</option>
									<option value='2'>2</option>
									<option value='3'>3</option>
									<option value='4'>4</option>
									<option value='5'>5</option>
						";
						//
						$majoropt = "";
						$semopt = "";
						$syopt = "";
						$deptopt = "";
						//
						$majoropt = $majoropt . "<option value='none'>None</option>";
						//
						$sql = " select major from tbl_major order by major asc  ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" ) {
								$majoropt = $majoropt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
							}
						}
						//
						$sql = " select semester from tbl_semester order by semester asc  ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" ) {
								$semopt = $semopt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
							}
						}
						//
						$sql = " select sy from tbl_sy order by sy asc  ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" ) {
								$syopt = $syopt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
							}
						}
						//
						$sql = " select department from tbl_department order by department asc  ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" ) {
								$deptopt = $deptopt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
							}
						}
						//
						$tcrit = array();
						$n = 0;
						//GET CRITERIA
						$sql = " select name,sy,adate from tbl_hte_eval_criteria where hte_id='$uid' and sy='$cursy' ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" ) {
								$tcrit[$n] = trim($dat[0]);
								$n += 1;
							}
						}
						//
						echo "
							<div class='table-responsive'>
								<table width='100%;'>
									<tr>
										<td class='eval_td01'>
											<b>Major:</b>
											<span>
												<select class='form-control txt01 span02' name='major'>
													$majoropt
												</select>
											</span>
										</td>
										<td class='eval_td01'>
											<span>
												<b>Semester:</b>
												<select class='form-control txt01 span02' name='semester'>
													$semopt
												</select>
											</span>
										</td>
									</tr>
									<tr>
										<td class='eval_td01'>
											<span>
												<b>S.Y.:</b>
												<select class='form-control txt01 span02' name='sy'>
													$syopt
												</select>
											</span>
										</td>
										<td class='eval_td01'>
											<span>
												<b>Department:</b>
												<select class='form-control txt01 span02' name='dept'>
													$deptopt
												</select>
											</span>
										</td>
									</tr>
								</table>
								<br/>
								<table>
									<thead>
										<tr>
											<td class='eval_td01'>

											</td>
											<td class='eval_td01'>
												<b>Program Competences</b>
											</td>
											<td class='eval_td01'>
												<b>Number of Hours</b>
											</td>
											<td class='eval_td01'>
												<b>Evaluation Rating</b>
											</td>
										</tr>
									</thead>
									<tbody>";
							if ( count($tcrit)>0 && count($tcrit)>=1 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>1.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp1' readonly='true'>$tcrit[0]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp1hrs' value='0' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp1rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=2 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>2.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp2' readonly='true'>$tcrit[1]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp2hrs' value='0' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp2rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=3 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>3.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp3' readonly='true'>$tcrit[2]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp3hrs' value='0' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp3rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=4 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>4.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp4' readonly='true'>$tcrit[3]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp4hrs' value='0' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp4rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=5 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>5.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp5' readonly='true'>$tcrit[4]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp5hrs' value='0' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp5rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=6 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>6.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp6' readonly='true'>$tcrit[5]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp6hrs' value='0' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp6rate' value='3' />
											</td>
										</tr>";
							}
									
							if ( count($tcrit)>0 && count($tcrit)>=7 ) {
								echo "
										<tr>
											<td class='eval_td01'>
												<b>7.</b>
											</td>
											<td class='eval_td01'>
												<textarea class='form-control span02 txt_disp01' name='comp7' readonly='true'>$tcrit[6]</textarea>
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp7hrs' value='0' />
											</td>
											<td class='eval_td01 eval_td01_1'>
												<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp7rate' value='3' />
											</td>
										</tr>";
							}
									
								echo "
									</tbody>
								</table>
							</div>
						";
					?>
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-sm" value="Save" name="btnAddHTEEval">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ====================== ADD RATE 2 ============================== -->
		<!-- ====================== ADD RATE 3 ============================== -->
		<div id="modalHTEEval3" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content eval_modal01">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">HTE Evaluation</h4>
			</div>
					<form action="" method="post">
			<div class="modal-body">
				<p>
					<?php include "./data/connect.php";
						//
							$uid = $_GET['id'];
						//
						$cursy = trim($_SESSION['intern_data_active_sy']);
						//
						//
						$rateopt = "";
						$rateopt = "
									<option value='1'>1</option>
									<option value='2'>2</option>
									<option value='3' selected='true'>3</option>
									<option value='4'>4</option>
									<option value='5'>5</option>
						";
						//
						//
						echo "
							<div class='table-responsive'>
								
								<div>
									<b>The Supervisor</b>
								</div>
								<hr class='hr01'/>

								<table width='100%'>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>1. conducts orientation with the student trainees</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit1_1'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>2. is approachable</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit1_2'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>3. is skillful in all areas in the department</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit1_3'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>4. answers questions/clarifications clearly and direct to the point</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit1_4'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>5. is fair in dealing student-trainees</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit1_5'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>6. shows willingness and interest in teaching student-trainees</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit1_6'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>7. schedules meetings with student trainees regularly</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit1_7'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>8. gives clear instructions</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit1_8'>
													$rateopt
												</select>
											</td>
										</tr>

								</table>

								<br/>
								<hr class='hr01'/>
								<div>
									<b>The company OJT Designated Facilities/Laboratories/Offices/work stations</b>
								</div>
								<hr class='hr01'/>

								<table width='100%'>

										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>1. have the complete equipment/facilities needed for acquisition of specific skills</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit2_1'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>2. are open for student trainees to use</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit2_2'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>3. are all operational/functional</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit2_3'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>4. are free from pollution</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit2_4'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>5. have good ventilation</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit2_5'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>6. have good lighting</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit2_6'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>7. have updated work manuals accesible to student-trainees</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit2_7'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>8. instructions are posted in conspicuous places in the halls/rooms</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit2_8'>
													$rateopt
												</select>
											</td>
										</tr>
								</table>


								<br/>
								<hr class='hr01'/>
								<div>
									<b>The company</b>
								</div>
								<hr class='hr01'/>

								<table width='100%'>

										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>1. has satisfactorily transferred the skills to the student trainees</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit3_1'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>2. takes care of the welfare of the student trainees</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit3_2'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>3. assigns specific supervisor for the student trainees</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit3_3'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>4. in general, has satisfactorily improved the competencies/skills the student trainees need</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit3_4'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>5. staff are friendly and appropriate</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit3_5'>
													$rateopt
												</select>
											</td>
										</tr>
										<tr>
											<td class='eval_td03'>
												<span class='eval_span03'>6. the company promotes and demonstrates the same university core values<br/>
												- Excellence; Honesty and Integrity; Innovation; Teamwork</span><br/>
												<span class='eval_span01'>
													
												</span>
											</td>
											<td class='eval_td01_2'>
												<select class='form-control span02 txt_disp01 eval_txt01' name='crit3_6'>
													$rateopt
												</select>
											</td>
										</tr>
								</table>

								<br/>
								<b>Comments/Suggestions/Recommendations:</b><br/>
								<textarea class='form-control span02' name='comments'></textarea>
							</div>
						";
					?>
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-sm" value="Save" name="btnAddHTEEval3">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ====================== ADD RATE 3 ============================== -->
		<!-- ====================== MANAGE RATE CRITERIA ============================== -->
		<div id="modalHTEEvalCriteria" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content eval_modal01">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Manage HTE Evaluation Criteria</h4>
			</div>
					<form action="" method="post">
			<div class="modal-body">
				<p>
					<?php include "./data/connect.php";
						//
						//
						echo "
							<b>1.</b> <textarea class='form-control span02 txt_disp01' name='comp1'></textarea><br/>
							<b>2.</b> <textarea class='form-control span02 txt_disp01' name='comp2'></textarea><br/>
							<b>3.</b> <textarea class='form-control span02 txt_disp01' name='comp3'></textarea><br/>
							<b>4.</b> <textarea class='form-control span02 txt_disp01' name='comp4'></textarea><br/>
							<b>5.</b> <textarea class='form-control span02 txt_disp01' name='comp5'></textarea><br/>
							<b>6.</b> <textarea class='form-control span02 txt_disp01' name='comp6'></textarea><br/>
							<b>7.</b> <textarea class='form-control span02 txt_disp01' name='comp7'></textarea><br/>
						";
					?>
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary btn-sm" value="Save" name="btnAddHTEEvalCriteria">
			</div>
					</form>
			</div>

			</div>
		</div>
		<!-- ====================== MANAGE RATE CRITERIA ============================== -->
		<!-- ====================== UPDATTE MAP ============================== -->
		<div id="modalUpdateMapInfo" class="modal fade" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Update Map Info</h4>
			</div>
					
			<div class="modal-body">
				<p>
					<?php
						$cid = trim($_GET['id']);
						echo "<iframe class='map_up_iframe01' src='./tmap.php?id=$cid' frameborder='0'></iframe>";
					?>
				</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-primary btnn-md" data-dismiss="modal">Close</button>
			</div>
					
			</div>

			</div>
		</div>
		<!-- ====================== UPDATTE MAP ============================== -->