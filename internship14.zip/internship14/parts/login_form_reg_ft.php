
							<div class="header">
								<div class="logo text-center"></div>
								<p class="lead">First time account setup</p>
							</div>
							<form class="form-auth-small" action="index.php" method="post">
								<div class="form-group">
									<?php echo $_SESSION['intern_disp_err']; $_SESSION['intern_disp_err'] = ""; ?>
								</div>
								<div class="form-group">
									<label for="signin-email" class="control-label sr-only">Username</label>
									<input type="username" name="username" class="form-control" id="signin-email" placeholder="Username"
										<?php
											$value = $_POST['username'];
											echo " value='$value' ";
										?>
									>
								</div>
								<div class="form-group">
									<label for="signin-password" class="control-label sr-only">Password</label>
									<input type="password" name="password" class="form-control" id="signin-password" value="" placeholder="Password">
								</div>
								<div class="form-group">
									<label for="signin-password2" class="control-label sr-only">Confirm Password</label>
									<input type="password" name="password2" class="form-control" id="signin-password2" value="" placeholder="Confirm Password">
								</div>
								<input type="submit" name="btnloginftas" class="btn btn-primary btn-lg btn-block" value="Continue">
								<div class="form-group clearfix">
								</div>
								
							</form>