<?php  error_reporting( E_ALL ^ E_NOTICE );
	function addUserActivityLog($memid,$memtype,$msg,$mtype) {
		include "./data/connect.php";
		$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
		//
		$errn = 0;
		if ( trim($memid)=="" ) {
			$errn = $errn + 1;
		}
		if ( $errn <= 0 ) {
			$sql101 = "
					insert into tbl_uact 
						(member_id,member_type,adate,msg,atype) 
					values 
						('$memid','$memtype','$cdate','$msg','$mtype') 
			";
			$qry101 = mysqli_query($conn,$sql101);
			echo "
				<script>

				</script>
			";
		}
	}
	function addNotification($user_id,$user_type,$title,$link,$content,$locid,$loctype,$tarsn,$status) {
		include "./data/connect.php";
		$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
		//$uid = $_GET['id'];
		if ( trim($user_id)!="" && (trim($title)!="" || trim($content)!="") ) {
			//SAVE

			$tsn = "page_class";
			if ( strtolower(trim($tsn)) == strtolower(trim($tarsn)) ) {
			// === COORDINATORS ===============================================================================
				$exc = "";
				$exc2 = "";
				//GET ADDED HTE
				$sql = " select hte_id from tbl_class_member_hte where class_id='$locid' ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					if ( trim($dat[0]) != "" ) {
						if ( trim($exc)=="" ) {
							$exc = " where hte_id='$dat[0]' ";
						}else{
							$exc = $exc . " or hte_id='$dat[0]' ";
						}
					}
				}
				//GET GET HTE COORDINATOR ID
				/*
				$sql = " select employee_id from tbl_coordinator  $exc  group by employee_id ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					if ( trim($dat[0]) != "" ) {
						//SAVE
						$tmpid = trim($dat[0]);
						$tmptype = "employee";
						$tmperr = 0;
						if ( strtolower(trim($tmptype)) == strtolower(trim($user_type)) && strtolower(trim($tmpid)) == strtolower(trim($user_id)) ) {
							$tmperr = $tmperr + 100;
						}
						/*
						if ( $tmperr <= 0 ) {
							$sql101 = "
									insert into tbl_notifications 
										(user_id,user_type,title,content,date_added,location_id,location_type,by_id,by_type) 
									values 
										('$tmpid','$tmptype','$title','$content','$cdate','$locid','$loctype','$user_id','$user_type') 
							";
							$qry101 = mysqli_query($conn,$sql101);
						}
					}
				}
						*/
			// === ------ ===============================================================================
				//
				//GET GET HTE STAFFS
				$sql = " select staff_id from tbl_hte_staff  $exc  group by employee_id ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					if ( trim($dat[0]) != "" ) {
						//SAVE
						$tmpid = trim($dat[0]);
						$tmptype = "employee";
						$tmperr = 0;
						if ( strtolower(trim($tmptype)) == strtolower(trim($user_type)) && strtolower(trim($tmpid)) == strtolower(trim($user_id)) ) {
							$tmperr = $tmperr + 100;
						}
						if ( $tmperr <= 0 ) {
							$sql101 = "
									insert into tbl_notifications 
										(user_id,user_type,title,content,date_added,location_id,location_type,by_id,by_type) 
									values 
										('$tmpid','$tmptype','$title','$content','$cdate','$locid','$loctype','$user_id','$user_type') 
							";
							$qry101 = mysqli_query($conn,$sql101);
						}
					}
				}
			// === COORDINATORS ===============================================================================
			// === INTERNS ===============================================================================
				$exc = "";
				$exc2 = "";
				//GET ADDED HTE
				$sql = " select hte_id from tbl_class_member_hte where class_id='$locid' ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					if ( trim($dat[0]) != "" ) {
						if ( trim($exc)=="" ) {
							$exc = " where hte_id='$dat[0]' ";
						}else{
							$exc = $exc . " or hte_id='$dat[0]' ";
						}
					}
				}
				//GET GET HTE INTERN ID
				$res = "";
				$sql = " select studentid from tbl_interns $exc  group by studentid ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					if ( trim($dat[0]) != "" ) {
						//SAVE
						$tmpid = trim($dat[0]);
						$tmptype = "student";
						$tmperr = 0;
						if ( strtolower(trim($tmptype)) == strtolower(trim($user_type)) && strtolower(trim($tmpid)) == strtolower(trim($user_id)) ) {
							$tmperr = $tmperr + 100;
						}
						if ( $tmperr <= 0 ) {
							$sql101 = "
									insert into tbl_notifications 
										(user_id,user_type,title,content,date_added,location_id,location_type,by_id,by_type) 
									values 
										('$tmpid','$tmptype','$title','$content','$cdate','$locid','$loctype','$user_id','$user_type') 
							";
							$qry101 = mysqli_query($conn,$sql101);
						}
					}
				}
			// === INTERNS ===============================================================================

				//echo "<script>alert('$res');</script>";
			}

			$tsn = "page_hte";
			if ( strtolower(trim($tsn)) == strtolower(trim($tarsn)) ) {
			
			// === INTERNS ===============================================================================
				$exc = "";
				$exc2 = "";
				//GET ADDED INTERNS
				$sql = " select member_id from tbl_hte_members where hte_id='$locid' ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					if ( trim($dat[0]) != "" ) {
						if ( trim($exc)=="" ) {
							$exc = " where studentid='$dat[0]' ";
						}else{
							$exc = $exc . " or studentid='$dat[0]' ";
						}
					}
				}
				//GET GET HTE INTERN ID
				$res = "";
				$sql = " select studentid from tbl_interns $exc  group by studentid ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					if ( trim($dat[0]) != "" ) {
						//SAVE
						$tmpid = trim($dat[0]);
						$tmptype = "student";
						$tmperr = 0;
						if ( strtolower(trim($tmptype)) == strtolower(trim($user_type)) && strtolower(trim($tmpid)) == strtolower(trim($user_id)) ) {
							$tmperr = $tmperr + 100;
						}
						if ( $tmperr <= 0 ) {
							$sql101 = "
									insert into tbl_notifications 
										(user_id,user_type,title,content,date_added,location_id,location_type,by_id,by_type) 
									values 
										('$tmpid','$tmptype','$title','$content','$cdate','$locid','$loctype','$user_id','$user_type') 
							";
							$qry101 = mysqli_query($conn,$sql101);
						}
					}
				}
			// === INTERNS ===============================================================================

				//echo "<script>alert('$res');</script>";
			}
			
		}
	}

?>