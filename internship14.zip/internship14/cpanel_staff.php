 <?php include "./data/connect.php";
	//
	$logun =  $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	//
	$supn = 0;
	$admn = 0;
	//
	if ( strtoupper(trim($logutype))==strtoupper(trim("employee")) ) {
	//echo "$logun $logutype";
		$sql = " select crs_staff_id,crs_id,staff_id,staff_type,position from tbl_crs_staff where staff_id='$logun' and staff_type='$logutype' and position='admin' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			$admn += 1;
		}
	}
	if ( strtoupper(trim($logutype))==strtoupper(trim("employee")) ) {
	//echo "$logun $logutype";
		$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff where staff_id='$logun' and staff_type='$logutype' and position='supervisor' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			$supn += 1;
		}
	}
	//
	if ( strtoupper(trim($logun))==strtoupper(trim("admin")) || strtoupper(trim($logutype))==strtoupper(trim("admin")) ) {
		$admn += 1;
	}
	//
	//
	if ( $admn > 0 ) {
		include "./cpanel_staff_admin.php";
	}
	//
	if ( $supn > 0 ) {
		include "./cpanel_staff_sup.php";
	}
	//
 ?>