<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./parts/sys_functions.php";
	include "./data/connect.php";
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$csy = trim($_SESSION['intern_data_active_sy']);
	//
	//
	$paid = trim($_GET['aid']);
	$patype = trim($_GET['atype']);
	//
	$_SESSION['intern_page_current'] = "page_subacts";
		include "./parts/main_logcheck.php";
		
	//
	//
	if ( trim($logun)!="" ) {
		if ( strtolower(trim($logutype))==strtolower(trim("student")) ) {
			if ( $_POST['btnsaveApplication'] ) {
				$jpid = trim($_POST['txtjpid']);
				$act = trim($_POST['txtact']);
				//
				$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
				//
				if ( trim($jpid)!="" ) {
					if ( strtolower(trim($act))==strtolower(trim("APPLY")) ) {
						//REMOVE RECENT ADDED DATA IF EXISTS
						$sql = " delete from tbl_jobpost_applicant  
									where jobpost_id='$jpid' and app_id='$logun' and app_type='$logutype' 
						 ";
						$qry = mysqli_query($conn,$sql);
						//SAVE
						$sql = " insert into tbl_jobpost_applicant  
									(jobpost_id,pdate,sy,app_id,app_type)
								values
									('$jpid','$cdate','$csy','$logun','$logutype')
						 ";
						$qry = mysqli_query($conn,$sql);
						//echo "
						//	<script>
								//alert('SS');
						//	</script>
						//";
					}
					if ( strtolower(trim($act))==strtolower(trim("UNAPPLY")) ) {
						//REMOVE RECENT ADDED DATA IF EXISTS
						$sql = " delete from tbl_jobpost_applicant  
									where jobpost_id='$jpid' and app_id='$logun' and app_type='$logutype' 
						 ";
						$qry = mysqli_query($conn,$sql);
						//echo "
						//	<script>
						//		//alert('XX');
						//	</script>
						//";
					}
				}
			}
		}
	}
	//
	//
	if ( trim($logun)=="" || strtolower(trim($logutype))==strtolower(trim("student")) ) {
		echo "<META HTTP-EQUIV='Refresh' Content='0; URL=./cpanel.php'>";
		exit;
	}
?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>

	<script type="text/javascript">
		setInterval('my_function();',5000);
	    function my_function(){
	      $('#up_new_jobpost').load(location.href + ' #up_new_jobpost_s');
	    }

	    function detectScrollbar()
		{
			if (navigator.appName == "Microsoft Internet Explorer")
			{
				window.name=document.body.scrollTop;
			}
			else
			{
				window.name=window.pageYOffset;
			}
		}

		function doScroll()
		{
			if (window.name) window.scrollTo(0, window.name);
		}
	</script>

</head>

<body onload="doScroll()" onunload="window.name=document.body.scrollTop" >
	<div id="up_new_jobpost">
		<div id="up_new_jobpost_s">
			<?php
				//
				$cpage = trim($_SESSION['intern_page_current']);
				//
				$doref = trim($_SESSION['intern_sys_page_doref']);
				//
				if ( strtolower(trim($cpage))==strtolower(trim("page_jobposts")) ) {
					if ( strtolower(trim($doref))==strtolower(trim("true")) ) {
						$_SESSION['intern_sys_page_doref'] = "";
						echo "<META HTTP-EQUIV='Refresh' Content='0; URL=./page_jobposts.php'>";
					}
				}
			?>
		</div>
	</div>
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
	<?php //include "./parts/page_announcement_modal.php"; ?>
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-8">
							<!-- LEFT COLUMN -->
							<div class="profleft01" align="center">
								
								
											<?php
												include "./data/connect.php";
												//
												//
												$classid = trim($_GET['class_id']);
												$classname = "";
												$type = trim($_GET['status']);
												$weekname = trim($_GET['weekname']);
												//
												$ctype = "reflection";
												if ( trim($ctype)=="" ) {
													$ctype = "reflection";
												}
												//
												//GET CLASS NAME
												$sql2 = " select class_id,name from tbl_class where class_id='$classid'  ";
													$qry2 = mysqli_query($conn,$sql2);
													while($dat2=mysqli_fetch_array($qry2)) {
														$classname = trim($dat2[1]);
													}
												//
											
												//
												if ( strtolower(trim($type))==strtolower(trim("submitted")) ) {
													//
													$disp = "";
													$dispcount = 0;
													//
													$cn = 0;
													$nn = "";
													//               0  1     2        3             4        5       6      7        8        9        10        11
													$sql = " select no,name,location,date_uploaded,upby_id,upby_type,utype,uloc_id,uloc_type,uloc2_id,ap_status,weekname from tbl_upfiles where upby_type='student' and utype='$ctype' and uloc_type='class' and uloc_id='$classid' and weekname='$weekname'  order by date_uploaded desc  ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {

														$cn += 1;

														$dispcount += 1;
														
														$lnk = "";
														//
														$nn = trim($dat[0]);
														//
														$name = "";
														$file = "";
														$fln = trim($dat[2]);
														if ( trim($fln)!="" ) {
															if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
															) {
																//IMAGE
																$file = "
																			<a class='' target='_blank' href='#' data-toggle='modal' data-target='#modalPrevImage_$nn'>$fln</a>
																			<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																				<img class='ann_img02' src='".trim($fln)."'/>
																			</div>
																		";
															}else{
																//NOT IMAGE
																$file = "<a target='_blank' href='".trim($fln)."'>".trim($fln)."</a>";
															}
														}
														//
														$locname = "";
														$loclink = "";
														//
														//
														$sql2 = "";
														//
														if ( trim($dat[5])!="" ) {
															if ( strtolower(trim($dat[5]))==strtolower(trim("coordinator")) ) {
																$lnk = "page_profile_employee.php";
																//
																$sql2 = " select firstname,middlename,lastname from tbl_employee where employee_id='$dat[4]'  ";
																	$qry2 = mysqli_query($conn,$sql2);
																	while($dat2=mysqli_fetch_array($qry2)) {
																		$name = trim($dat2[2]).", ".trim($dat2[0])." ".trim($dat2[1]);
																	}
															}
															if ( strtolower(trim($dat[5]))==strtolower(trim("student")) ) {
																$lnk = "page_profile.php";
																//
																$sql2 = " select firstname,middlename,lastname from tbl_interns where studentid='$dat[4]'  ";
																	$qry2 = mysqli_query($conn,$sql2);
																	while($dat2=mysqli_fetch_array($qry2)) {
																		$name = trim($dat2[2]).", ".trim($dat2[0])." ".trim($dat2[1]);
																	}														
															}
															if ( trim($dat[4])!="" ) {
																//GET NAME
															}
														}
														//
														if ( trim($dat[7])!="" ) {
															if ( strtolower(trim($dat[8]))==strtolower(trim("class")) ) {
																$loclink = "page_class.php";
																//
																$sql2 = " select class_id,name from tbl_class where class_id='$dat[7]'  ";
																	$qry2 = mysqli_query($conn,$sql2);
																	while($dat2=mysqli_fetch_array($qry2)) {
																		$locname = trim($dat2[1]);
																	}
															}
														}
														//
														//
														$memid = "";
														$memname = "";
														$img = "";
														$link = "";
														//GET MEMBER NAME
														if ( strtolower(trim($dat[5]))==strtolower(trim("student")) ) {
															$sql1 = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns  where studentid='$dat[4]'  ";
															$qry1 = mysqli_query($conn,$sql1);
															while($dat1=mysqli_fetch_array($qry1)) {
																if ( trim($dat1[0]) != "" ) {
																	$mname = "";
																	if ( trim($dat1[2])!="" ) {
																		$mname = " " . trim($dat1[2]);
																	}
																	$memid = trim($dat1[0]);
																	$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
																	//
																	$img = trim($dat1[4]);
																	if ( trim($img)=="" ) {
																		$img = "./assets/img/empty_user.png";
																	}
																	//
																	$link = "./page_profile.php?id=".trim($dat1[0]);
																}
															}
														}
														if ( strtolower(trim($dat[5]))==strtolower(trim("employee")) ) {
															$sql1 = " select employee_id,firstname,middlename,lastname,prof_img from tbl_employee  where employee_id='$dat[4]'  ";
															$qry1 = mysqli_query($conn,$sql1);
															while($dat1=mysqli_fetch_array($qry1)) {
																if ( trim($dat1[0]) != "" ) {
																	$mname = "";
																	if ( trim($dat1[2])!="" ) {
																		$mname = " " . trim($dat1[2]);
																	}
																	$memid = trim($dat1[0]);
																	$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
																	//
																	$img = trim($dat1[4]);
																	if ( trim($img)=="" ) {
																		$img = "./assets/img/empty_user.png";
																	}
																	//
																	$link = "./page_profile_employee.php?id=".trim($dat1[0]);
																}
															}
														}
														//
														//
														//FILE
														$pfile = "";
														$fln = trim($dat[2]);
														//
														$dfn = "File";
														$dfnx = "";
														//
														//
														if ( trim($fln)!="" ) {
															$dfnx = "." . trim(pathinfo($fln,PATHINFO_EXTENSION));
															if ( trim($dat[1])=="" ) {
																$dfn = "File";
															}else{
																$dfn = trim($dat[1]);
															}
															//
															if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
																  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
																  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
																  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
																  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
																) {
																$pfile = "<p align='center'>
																				<a href='#' class='ann_lnkprev01' data-toggle='modal' data-target='#modalPrevImage_$nn'>
																			<img class='ann_img01' src='".trim($fln)."'/>
																				</a>
																			<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																				<img class='ann_img02' src='".trim($fln)."'/>
																			</div>
																		  </p>";
															}else{
																$dfnx = "";
																$pfile = "<p align='left'><a href='".trim($fln)."' target='_blank'>".trim($dfn).trim($dfnx)."</a></p>";
															}
														}
														//
														if ( $cn > 1 ) {
															$disp = $disp . "<hr class='class_pst_hr01' />";
														}
														//
														$disp = $disp . "

															<li>
																<div class='uldiv01' align='left'>
																	<div class='uldiv01'>
																		<table class=''>
																			<tr>
																				<td>
																					<img src='$img' class='ann_img03' />
																				</td>
																				<td>
																					<div class='div_ann_name01'>
																						<a href='$link' class='ann_link01'>$memname</a>
																						<br/>
																						<span class='pst_date_01'>$dat[3]</span>
																					</div>
																				</td>
																			</tr>
																		</table>
																		<hr class='hr02'/>
																		<div class='div_ann_msg02'>
																			Submitted: $pfile.
																			<b><span class='span02'>@$classname: $weekname </span>reflection.</b>
																		</div>
																	</div>
																</div>
															</li>

														";
													}
															echo "
																<div class='panel ann_divr02'>
																	<h3 class='subact_h01'>Submitted ($dispcount)</h3>
																</div>";
														if ( $dispcount > 0 ) {
															echo "
																<div class='panel ann_divr02'>
																	<ul class='ul01'>
																		$disp
																	</ul>
																</div>";
														}
												}

										/////// XXXXXXXX ///////////////////////////////////////////////

												//
												if ( strtolower(trim($type))==strtolower(trim("notsubmitted")) ) {
													//
												 	$exq = "";
												 	$exq2 = "";
												 	//GET ID OF SUBMITTED
													$sql2 = " select no,upby_id,upby_type from tbl_upfiles where upby_type='student'  and utype='$ctype' and uloc_type='class' and uloc_id='$classid' and weekname='$weekname'  ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															if ( trim( $exq )=="" ) {
																$exq = " member_id<>'$dat2[1]' ";
															}else{
																$exq = $exq . " and member_id<>'$dat2[1]' ";
															}
														}
													if ( trim($exq)!="" ) {
														$exq = "and (" . $exq . ")";
													}
													//
													$hteid = "";
													//GET HTE ID
													$sql2 = " select class_mem_id,class_id,hte_id from tbl_class_member_hte where class_id='$classid'  ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															if ( trim( $hteid )=="" ) {
																$hteid = " hte_id='$dat2[2]' ";
															}else{
																$hteid = $hteid . " or hte_id='$dat2[2]' ";
															}
														}
													if ( trim($hteid)!="" ) {
														$hteid = "where (" . $hteid . ")";
													}
													//	echo "  $hteid $exq ";
													//
													//GET EXCLUDED ID
													if ( trim($hteid)!="" ) {
														$sql2 = " select hte_mem_id,hte_id,member_id from tbl_hte_members $hteid $exq  ";
															$qry2 = mysqli_query($conn,$sql2);
															while($dat2=mysqli_fetch_array($qry2)) {
																if ( trim( $exq2 )=="" ) {
																	$exq2 = " upby_id<>'$dat2[2]' ";
																}else{
																	$exq2 = $exq2 . " and upby_id<>'$dat2[2]' ";
																}
															}
													}
													if ( trim($hteid)!="" ) {
														$exq2 = " and (" . $exq2 . ")";
													}
													//echo "$exq2";
													//
													$cn = 0;
													$nn = "";
													//
													if ( $exq2 != "" ) {
														//
														$disp = "";
														$dispcount = 0;
														////////
														////////
														//               0  1     2        3             4        5       6      7        8        9        10        11
														//$sql = " select no,name,location,date_uploaded,upby_id,upby_type,utype,uloc_id,uloc_type,uloc2_id,ap_status,weekname from tbl_upfiles where ( upby_type='student' and utype='$ctype' and uloc_type='class' and uloc_id='$classid' and weekname='$weekname' )   $exq2   order by date_uploaded desc  ";
														 	//                0       1       2      
														$sql = " select hte_mem_id,hte_id,member_id from tbl_hte_members $hteid $exq  group by member_id ";
														$qry = mysqli_query($conn,$sql);
														while($dat=mysqli_fetch_array($qry)) {

															$cn += 1;
															$dispcount += 1;
															
															$lnk = "";
															//
															$nn = trim($dat[0]);
															//
															$name = "";
															//
															$locname = "";
															$loclink = "";
															//
															//
															$sql2 = "";
															//
															$utyp = "student";
															//
															if ( trim($utyp)!="" ) {
																if ( strtolower(trim($utyp))==strtolower(trim("coordinator")) ) {
																	$lnk = "page_profile_employee.php";
																	//
																	$sql2 = " select firstname,middlename,lastname from tbl_employee where employee_id='$dat[2]'  ";
																		$qry2 = mysqli_query($conn,$sql2);
																		while($dat2=mysqli_fetch_array($qry2)) {
																			$name = trim($dat2[2]).", ".trim($dat2[0])." ".trim($dat2[1]);
																		}
																}
																if ( strtolower(trim($utyp))==strtolower(trim("student")) ) {
																	$lnk = "page_profile.php";
																	//
																	$sql2 = " select firstname,middlename,lastname from tbl_interns where studentid='$dat[2]'  ";
																		$qry2 = mysqli_query($conn,$sql2);
																		while($dat2=mysqli_fetch_array($qry2)) {
																			$name = trim($dat2[2]).", ".trim($dat2[0])." ".trim($dat2[1]);
																		}														
																}
																if ( trim($dat[2])!="" ) {
																	//GET NAME
																}
															}
															//
															//
															//
															$memid = "";
															$memname = "";
															$img = "";
															$link = "";
															//GET MEMBER NAME
															if ( strtolower(trim($utyp))==strtolower(trim("student")) ) {
																$sql1 = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns  where studentid='$dat[2]'  ";
																$qry1 = mysqli_query($conn,$sql1);
																while($dat1=mysqli_fetch_array($qry1)) {
																	if ( trim($dat1[0]) != "" ) {
																		$mname = "";
																		if ( trim($dat1[2])!="" ) {
																			$mname = " " . trim($dat1[2]);
																		}
																		$memid = trim($dat1[0]);
																		$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
																		//
																		$img = trim($dat1[4]);
																		if ( trim($img)=="" ) {
																			$img = "./assets/img/empty_user.png";
																		}
																		//
																		$link = "./page_profile.php?id=".trim($dat1[0]);
																	}
																}
															}
															if ( strtolower(trim($utyp))==strtolower(trim("employee")) ) {
																$sql1 = " select employee_id,firstname,middlename,lastname,prof_img from tbl_employee  where employee_id='$dat[2]'  ";
																$qry1 = mysqli_query($conn,$sql1);
																while($dat1=mysqli_fetch_array($qry1)) {
																	if ( trim($dat1[0]) != "" ) {
																		$mname = "";
																		if ( trim($dat1[2])!="" ) {
																			$mname = " " . trim($dat1[2]);
																		}
																		$memid = trim($dat1[0]);
																		$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
																		//
																		$img = trim($dat1[4]);
																		if ( trim($img)=="" ) {
																			$img = "./assets/img/empty_user.png";
																		}
																		//
																		$link = "./page_profile_employee.php?id=".trim($dat1[0]);
																	}
																}
															}
															//
															//
															//FILE
															$pfile = "";
															$fln = "";
															//
															$dfn = "File";
															$dfnx = "";
															//
															//
															if ( $cn > 1 ) {
																$disp = $disp . "<hr class='class_pst_hr01' />";
															}
															//
															$disp = $disp . "

																<li>
																	<div class='uldiv01' align='left'>
																		<div class='uldiv01'>
																			<table class=''>
																				<tr>
																					<td>
																						<img src='$img' class='ann_img03' />
																					</td>
																					<td>
																						<div class='div_ann_name01'>
																							<a href='$link' class='ann_link01'>$memname</a>
																						</div>
																					</td>
																				</tr>
																			</table>
																			<hr class='hr02'/>
																			<div class='div_ann_msg02'>
																				Not yet submitted.
																				<br/>
																				<b><span class='span02'>@$classname: $weekname </span>reflection.</b>
																			</div>
																		</div>
																	</div>
																</li>

															";
															
														}
															echo "
																<div class='panel ann_divr02'>
																	<h3 class='subact_h01'>Not Submitted ($dispcount)</h3>
																</div>";
														if ( $dispcount > 0 ) {
															echo "
																<div class='panel ann_divr02'>
																	<ul class='ul01'>
															 			$disp
																	</ul>
																</div>";
														}
														////////
														////////
													}
												}
												
												
											?>
											
								
							</div>
							<!-- END LEFT COLUMN -->
						</div>
						<div class="col-md-4">
							<!-- RIGHT COLUMN -->
							<div class="panel ann_divr02">
								<div class="tab-content divclass03" align="left">
									<?php
										$curid = $_SESSION['intern_data_cun'];
										$curidtype = $_SESSION['intern_data_utype'];
										if ( strtolower(trim($curid))!=strtolower(trim("")) ) {
											
										}
										//
										$curclassid = trim($_GET['class_id']);
										$curweekn = trim($_GET['weekname']);
										$curtype = trim($_GET['status']);
										//
										//
										//
										$classopt = "";
										$weekopt = "";
										$statopt = "";
										//
										//
										//                 0   1
										$sql = " select class_id,name from tbl_class  ";
										$qry = mysqli_query($conn,$sql);
										while($dat=mysqli_fetch_array($qry)) {
											$isel = "";
											if ( strtolower(trim($curclassid))==strtolower(trim($dat[0])) ) {
												$isel = " selected='true' ";
											}
											$classopt = $classopt . "<option value='$dat[0]' $isel>$dat[1]</option>";
										}
										//                 0   1
										for ( $i=1 ; $i<=48 ; $i++ ) {
											//
											$cval = "week_$i";
											//
											$isel = "";
											if ( strtolower(trim($curweekn))==strtolower(trim($cval)) ) {
												$isel = " selected='true' ";
											}
											$weekopt = $weekopt . "<option value='$cval' $isel>WEEK $i</option>";
										}
										//
											$tmpd = "Submitted";
											$isel = "";
											if ( strtolower(trim($curtype))==strtolower(trim($tmpd)) ) {
												$isel = " selected='true' ";
											}
											$statopt = $statopt . "<option value='$tmpd' $isel>Submitted</option>";
											//
											$tmpd = "NotSubmitted";
											$isel = "";
											if ( strtolower(trim($curtype))==strtolower(trim($tmpd)) ) {
												$isel = " selected='true' ";
											}
											$statopt = $statopt . "<option value='$tmpd' $isel>Not Submitted</option>";
										//

											echo "

												<form action='' method='get'>
													<b>HTE:</b><br/>
													<select class='form-control' name='class_id'>
														$classopt
													</select>
													<br/>
													<b>Week:</b><br/>
													<select class='form-control' name='weekname'>
														$weekopt
													</select>
													<br/>
													<b>Type:</b><br/>
													<select class='form-control' name='status'>
														$statopt
													</select>
													<br/>
													<input class='btn btn-success btn-md btn-block' type='submit' value='SHOW'/>
												</form>

											";
									?>
									<br/>
								</div>
								
							</div>
							<!-- END RIGHT COLUMN -->
						</div>
					</div>

				</div>

			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>

	<script >
	$(document).ready(function(){
  $("#myInput1").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable1 tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

	</script>

	
<?php
	include "./parts/btm_script.php";
?>

</body>

</html>
