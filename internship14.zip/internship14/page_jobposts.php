<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./parts/sys_functions.php";
	include "./data/connect.php";
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$csy = trim($_SESSION['intern_data_active_sy']);
	//
	//
	$paid = trim($_GET['aid']);
	$patype = trim($_GET['atype']);
	//
	$_SESSION['intern_page_current'] = "page_jobposts";
	$_SESSION['intern_page_current2'] = "page_jobposts_".$patype."_".$paid;
		include "./parts/main_logcheck.php";
		
	//
	//
	if ( trim($logun)!="" ) {
		if ( strtolower(trim($logutype))==strtolower(trim("student")) ) {
			if ( $_POST['btnsaveApplication'] ) {
				$jpid = trim($_POST['txtjpid']);
				$act = trim($_POST['txtact']);
				//
				$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
				//
				if ( trim($jpid)!="" ) {
					if ( strtolower(trim($act))==strtolower(trim("APPLY")) ) {
						//REMOVE RECENT ADDED DATA IF EXISTS
						$sql = " delete from tbl_jobpost_applicant  
									where jobpost_id='$jpid' and app_id='$logun' and app_type='$logutype' 
						 ";
						$qry = mysqli_query($conn,$sql);
						//SAVE
						$sql = " insert into tbl_jobpost_applicant  
									(jobpost_id,pdate,sy,app_id,app_type)
								values
									('$jpid','$cdate','$csy','$logun','$logutype')
						 ";
						$qry = mysqli_query($conn,$sql);
						//echo "
						//	<script>
								//alert('SS');
						//	</script>
						//";
					}
					if ( strtolower(trim($act))==strtolower(trim("UNAPPLY")) ) {
						//REMOVE RECENT ADDED DATA IF EXISTS
						$sql = " delete from tbl_jobpost_applicant  
									where jobpost_id='$jpid' and app_id='$logun' and app_type='$logutype' 
						 ";
						$qry = mysqli_query($conn,$sql);
						//echo "
						//	<script>
						//		//alert('XX');
						//	</script>
						//";
					}
				}
			}
		}
		//
		if ( strtolower(trim($logutype))!=strtolower(trim("student")) ) {
			if ( $_POST['btnsaveAppStatus'] ) {
				$jpid = trim($_POST['txtjpid']);
				$appid = trim($_POST['txtappid']);
				$act = trim($_POST['txtact']);
				$hte_id = trim($_POST['txthteid']);
				$jobs = trim($_POST['txtjobs']);
				//
				$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
				//
				if ( trim($jpid)!="" ) {
					if ( strtolower(trim($act))!=strtolower(trim("")) ) {
						//UPDATE
						$sql = " update tbl_jobpost_applicant set  
									status='$act' 
								where jobpost_id='$jpid' and app_type='student' and app_id='$appid'
						 ";
						$qry = mysqli_query($conn,$sql);
						//echo "
						//	<script>
								//alert('SS');
						//	</script>
						//";
						if ( strtolower(trim($act))==strtolower(trim("accepted")) ) {
							if ( trim($appid)!="" ) {
								//
								$nn = 0;
								//
								$sql = " select hte_mem_id,hte_id,member_id from tbl_hte_members  where member_id='$appid' ";
								$qry = mysqli_query($conn,$sql);
								while($dat=mysqli_fetch_array($qry)) {
									$nn += 1;
								}
								//
								//
								if ( $nn <= 0 ) {
									//
									//ADD TO  HTE
									$sql = " insert into tbl_hte_members  
												(hte_id,member_id,jobs) 
											values 
												('$hte_id','$appid','$jobs')

									 ";
									$qry = mysqli_query($conn,$sql);
									//
								}
								//
							}
						}
						//
						if ( strtolower(trim($act))==strtolower(trim("rejected")) ) {
							if ( trim($appid)!="" ) {
								//
									//REMOVE TO  HTE
									$sql = " delete from tbl_hte_members  
												where hte_id='$hte_id' and member_id='$appid'

									 ";
									$qry = mysqli_query($conn,$sql);
								//
							}
						}
					}
				}
			}
		}
	}
	//
	//
	if ( trim($logun)=="" ) {
		exit;
	}
?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>

	<script type="text/javascript">
		setInterval('my_function();',5000);
	    function my_function(){
	      $('#up_new_jobpost').load(location.href + ' #up_new_jobpost_s');
	    }

	    function detectScrollbar()
		{
			if (navigator.appName == "Microsoft Internet Explorer")
			{
				window.name=document.body.scrollTop;
			}
			else
			{
				window.name=window.pageYOffset;
			}
		}

		function doScroll()
		{
			if (window.name) window.scrollTo(0, window.name);
		}


	</script>

</head>

<body onload="doScroll()" onunload="window.name=document.body.scrollTop" >
	<div id="up_new_jobpost">
		<div id="up_new_jobpost_s">
			<?php
				//
				$cpage = trim($_SESSION['intern_page_current']);
				//
				$doref = trim($_SESSION['intern_sys_page_doref']);
				//
				if ( strtolower(trim($cpage))==strtolower(trim("page_jobposts")) ) {
					if ( strtolower(trim($doref))==strtolower(trim("true")) ) {
						$_SESSION['intern_sys_page_doref'] = "";
						echo "<META HTTP-EQUIV='Refresh' Content='0; URL=./page_jobposts.php'>";
					}
				}
			?>
		</div>
	</div>
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
	<?php //include "./parts/page_announcement_modal.php"; ?>
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-8">
							<!-- LEFT COLUMN -->
							<div class="profleft01" align="center">
								
								<?php include "./data/connect.php";
									//
									$logun = $_SESSION['intern_data_cun'];
									$logutype = $_SESSION['intern_data_utype'];
									//
									$csy = trim($_SESSION['intern_data_active_sy']);
									//
									$id = $_GET['aid'];
									$idtype = $_GET['atype'];
									//
									$page = trim($_GET['page']);
									//
									//
									$disp = "";
									//
									//
									if ( strtolower(trim($page))==strtolower(trim("jobs")) ||
										 trim($page)==""
									 ) {
										//LOAD AVAILABLE
										$nn = 0;
										//                    0       1     2    3    4     5     6      7
										$sql = " select jobpost_id,subject,msg,pdate,jobs,by_id,by_type,cfile from tbl_jobpost   order by jobpost_id desc ";
										$qry = mysqli_query($conn,$sql);
										while($dat=mysqli_fetch_array($qry)) {
											if ( trim($dat[1])!=="" || trim($dat[2])!="" || trim($dat[7])!="" ) {
												$nn = $nn + 1;
												//
												//FILE
												$pfile = "";
												$fln = trim($dat[7]);
												//
												$dfn = "File";
												$dfnx = "";
												//
												//
												if ( trim($fln)!="" ) {
													$dfnx = "." . trim(pathinfo($fln,PATHINFO_EXTENSION));
													if ( trim($dat[1])=="" ) {
														$dfn = "File";
													}else{
														$dfn = trim($dat[1]);
													}
													//
													if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
														$pfile = "<p align='center'>
																		<a href='#' class='ann_lnkprev01' data-toggle='modal' data-target='#modalPrevImage_$nn'>
																	<img class='ann_img01' src='".trim($fln)."'/>
																		</a>
																	<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																		<img class='ann_img02' src='".trim($fln)."'/>
																	</div>
																  </p>";
													}else{
														$pfile = "<p align='left'><a href='".trim($fln)."' target='_blank'>".trim($dfn).trim($dfnx)."</a></p>";
													}
												}
												//
												$memid = "";
												$memname = "";
												$img = "";
												$link = "";
												//GET MEMBER NAME
												if ( strtolower(trim($dat[6]))==strtolower(trim("student")) ) {
													$sql1 = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns  where studentid='$dat[5]'  ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														if ( trim($dat1[0]) != "" ) {
															$mname = "";
															if ( trim($dat1[2])!="" ) {
																$mname = " " . trim($dat1[2]);
															}
															$memid = trim($dat1[0]);
															$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
															//
															$img = trim($dat1[4]);
															//
															$link = "./page_profile.php?id=".trim($dat1[0]);
														}
													}
												}
												if ( strtolower(trim($dat[6]))==strtolower(trim("employee")) ) {
													$sql1 = " select employee_id,firstname,middlename,lastname,prof_img from tbl_employee  where employee_id='$dat[5]'  ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														if ( trim($dat1[0]) != "" ) {
															$mname = "";
															if ( trim($dat1[2])!="" ) {
																$mname = " " . trim($dat1[2]);
															}
															$memid = trim($dat1[0]);
															$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
															//
															$img = trim($dat1[4]);
															//
															$link = "./page_profile_employee.php?id=".trim($dat1[0]);
														}
													}
												}
												if ( strtolower(trim($dat[6]))==strtolower(trim("")) || strtolower(trim($dat[6]))==strtolower(trim("admin")) ) {
													$memid = "Admin";
													$memname = "Admin";
													$img = "";
													//
													$link = "#";
												}
												//
												if ( trim($img)=="" ) {
													$img = "./assets/img/empty_user.png";
												}
												//
												//
												//GET JOB LIST
												$finjl = "";
												//
												$sjl = trim($dat[4]);
												$sjla = explode(";", $sjl);
												//
												for ( $i=0 ; $i < count($sjla) ; $i++ ) {
													if ( trim($sjla[$i])!="" ) {
														$tmpn = "";
														//
														//FIND JOB NAME
														$sql1 = " select hte_job_id,name from tbl_hte_jobs  where hte_job_id='$sjla[$i]'  ";
														$qry1 = mysqli_query($conn,$sql1);
														while($dat1=mysqli_fetch_array($qry1)) {
															if ( trim($dat1[1]) != "" ) {
																$tmpn = trim($dat1[1]);
															}
														}
														//
														$finjl = $finjl . "&bullet; <span class='span02'>" . trim($tmpn) . "</span><br/>";
													}
												}
												//
												if ( trim($finjl)!="" ) {
													$finjl = "
																<br/>
																<b>Jobs Needed:</b><br/>
																<div class='div_jp01'>
																	<b>$finjl</b>
																</div>
																<br/>
													";
												}
												//
												//
												//APPLY
												$frmapply = "";
												if ( trim($logun)!="" ) {
													if ( strtolower(trim($logutype))==strtolower(trim("student")) ) {
														//CHECK
														$cn = 0;
														$sql1 = " select jobpost_app_id,jobpost_id,pdate,app_id,app_type from tbl_jobpost_applicant  where jobpost_id='$dat[0]' and app_id='$logun'  ";
														$qry1 = mysqli_query($conn,$sql1);
														while($dat1=mysqli_fetch_array($qry1)) {
															$cn += 1;
														}
														//
														if ( $cn > 0 ) {
															//APPLIED
															$frmapply = "
																	<div align='center'>
																		<form action='' method='post'>
																			<input type='hidden' name='txtjpid' value='$dat[0]' />
																			<input type='hidden' name='txtact' value='UNAPPLY' />
																			<input type='submit' class='btn btn-danger btn-md' name='btnsaveApplication' value='UNAPPLY' />
																		</form>
																	</div>
																	<br/>
															";
														}else{
															//NOT YET APPLIED
															$frmapply = "
																	<div align='center'>
																		<form action='' method='post'>
																			<input type='hidden' name='txtjpid' value='$dat[0]' />
																			<input type='hidden' name='txtact' value='APPLY' />
																			<input type='submit' class='btn btn-success btn-md' name='btnsaveApplication' value='APPLY' />
																		</form>
																	</div>
																	<br/>
															";
														}
													}
												}
												//
												//
												$disp = $disp . "
														<li>
															<div class='panel panel-default uldiv01' align='left'>
																<div class='uldiv01'>
																	<table class=''>
																		<tr>
																			<td>
																				<img src='$img' class='ann_img03' />
																			</td>
																			<td>
																				<div class='div_ann_name01'>
																					<a href='$link' class='ann_link01'>$memname</a>
																					<br/>
																					<span class='pst_date_01'>$dat[3]</span>
																				</div>
																			</td>
																		</tr>
																	</table>
																	<hr class='hr02'/>
																	$frmapply
																	<div class='div_ann_msg01'>
																		$dat[2]
																	</div>
																	<div class='div_ann_msg03'>
																		$finjl
																	</div>
																	<div class='div_ann_msg02'>
																		$pfile
																	</div>
																</div>
															</div>
														</li>
												";
											}
										}
										//
										echo "<ul class='ul01'>";
										echo "$disp";
										echo "</ul>";
										//
									}
									//
				//==============================================
									//
									if ( strtolower(trim($page))==strtolower(trim("application")) &&
										 strtolower(trim($logun))!=strtolower(trim(""))  &&
										 strtolower(trim($logutype))==strtolower(trim("student")) 
										) {
										//LOAD AVAILABLE
										$nn = 0;
										//
										//
										$appstat = trim($_GET['appstat']);
										//
										if ( trim($appstat)=="" ) {
											$appstat = "pending";
										}
										//
										$asq = "";
										if ( trim($appstat)!="" ) {
											if ( strtolower(trim($appstat))==strtolower(trim("pending")) ) {
												$asq = " and ( status='$appstat' or status='' ) ";
											}else{
												$asq = " and status='$appstat' ";
											}
										}
										//
										$ids = "";
										//
										$sql = " select jobpost_app_id,jobpost_id,sy,app_id,app_type,status from tbl_jobpost_applicant  where ( app_type='student' and app_id='$logun' ) $asq   order by jobpost_app_id desc ";
										$qry = mysqli_query($conn,$sql);
										while($dat=mysqli_fetch_array($qry)) {
											if ( trim($ids)=="" ) {
												$ids = " jobpost_id='$dat[1]' ";
											}else{
												$ids = $ids . " and jobpost_id='$dat[1]' ";
											}
										}
										if ( trim($ids)!="" ) {
											$ids = " where ( " . $ids . " ) ";
										}
										//
										if ( strtolower(trim($logutype))!=strtolower(trim("student")) ) {
											$ids = "";
										}
										//
										if ( trim($ids)!="" ) {
											//
											//                    0       1     2    3    4     5     6      7
											$sql = " select jobpost_id,subject,msg,pdate,jobs,by_id,by_type,cfile from tbl_jobpost $ids   order by jobpost_id desc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[1])!=="" || trim($dat[2])!="" || trim($dat[7])!="" ) {
													$nn = $nn + 1;
													//
													//FILE
													$pfile = "";
													$fln = trim($dat[7]);
													//
													$dfn = "File";
													$dfnx = "";
													//
													//
													if ( trim($fln)!="" ) {
														$dfnx = "." . trim(pathinfo($fln,PATHINFO_EXTENSION));
														if ( trim($dat[1])=="" ) {
															$dfn = "File";
														}else{
															$dfn = trim($dat[1]);
														}
														//
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
															  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
															) {
															$pfile = "<p align='center'>
																			<a href='#' class='ann_lnkprev01' data-toggle='modal' data-target='#modalPrevImage_$nn'>
																		<img class='ann_img01' src='".trim($fln)."'/>
																			</a>
																		<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																			<img class='ann_img02' src='".trim($fln)."'/>
																		</div>
																	  </p>";
														}else{
															$pfile = "<p align='left'><a href='".trim($fln)."' target='_blank'>".trim($dfn).trim($dfnx)."</a></p>";
														}
													}
													//
													$memid = "";
													$memname = "";
													$img = "";
													$link = "";
													//GET MEMBER NAME
													if ( strtolower(trim($dat[6]))==strtolower(trim("student")) ) {
														$sql1 = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns  where studentid='$dat[5]'  ";
														$qry1 = mysqli_query($conn,$sql1);
														while($dat1=mysqli_fetch_array($qry1)) {
															if ( trim($dat1[0]) != "" ) {
																$mname = "";
																if ( trim($dat1[2])!="" ) {
																	$mname = " " . trim($dat1[2]);
																}
																$memid = trim($dat1[0]);
																$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
																//
																$img = trim($dat1[4]);
																//
																$link = "./page_profile.php?id=".trim($dat1[0]);
															}
														}
													}
													if ( strtolower(trim($dat[6]))==strtolower(trim("employee")) ) {
														$sql1 = " select employee_id,firstname,middlename,lastname,prof_img from tbl_employee  where employee_id='$dat[5]'  ";
														$qry1 = mysqli_query($conn,$sql1);
														while($dat1=mysqli_fetch_array($qry1)) {
															if ( trim($dat1[0]) != "" ) {
																$mname = "";
																if ( trim($dat1[2])!="" ) {
																	$mname = " " . trim($dat1[2]);
																}
																$memid = trim($dat1[0]);
																$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
																//
																$img = trim($dat1[4]);
																//
																$link = "./page_profile_employee.php?id=".trim($dat1[0]);
															}
														}
													}
													if ( strtolower(trim($dat[6]))==strtolower(trim("")) || strtolower(trim($dat[6]))==strtolower(trim("admin")) ) {
														$memid = "Admin";
														$memname = "Admin";
														$img = "";
														//
														$link = "#";
													}
													//
													if ( trim($img)=="" ) {
														$img = "./assets/img/empty_user.png";
													}
													//
													//
													//GET JOB LIST
													$finjl = "";
													//
													$sjl = trim($dat[4]);
													$sjla = explode(";", $sjl);
													//
													for ( $i=0 ; $i < count($sjla) ; $i++ ) {
														if ( trim($sjla[$i])!="" ) {
															$tmpn = "";
															//
															//FIND JOB NAME
															$sql1 = " select hte_job_id,name from tbl_hte_jobs  where hte_job_id='$sjla[$i]'  ";
															$qry1 = mysqli_query($conn,$sql1);
															while($dat1=mysqli_fetch_array($qry1)) {
																if ( trim($dat1[1]) != "" ) {
																	$tmpn = trim($dat1[1]);
																}
															}
															//
															$finjl = $finjl . "&bullet; <span class='span02'>" . trim($tmpn) . "</span><br/>";
														}
													}
													//
													if ( trim($finjl)!="" ) {
														$finjl = "
																	<br/>
																	<b>Jobs Needed:</b><br/>
																	<div class='div_jp01'>
																		<b>$finjl</b>
																	</div>
																	<br/>
														";
													}
													//
													//
													//APPLY
													$frmapply = "";
													$fstat = "";
													if ( trim($logun)!="" ) {
														if ( strtolower(trim($logutype))==strtolower(trim("student")) ) {
															//CHECK
															//
															$stat = "";
															$cn = 0;
															//                      0           1        2      3      4       5
															$sql1 = " select jobpost_app_id,jobpost_id,pdate,app_id,app_type,status from tbl_jobpost_applicant  where jobpost_id='$dat[0]' and app_id='$logun'  ";
															$qry1 = mysqli_query($conn,$sql1);
															while($dat1=mysqli_fetch_array($qry1)) {
																$stat = $dat1[5];
															}
															//
															if ( strtolower(trim($stat))==strtolower(trim("accepted")) ) {
																//APPLIED
																$fstat = "
																		<div align='center'>
																			<span class='btn btn-success btn-md'>STATUS: ACCEPTED</span>
																		</div>
																		<br/>
																";
															}
															if ( strtolower(trim($stat))==strtolower(trim("rejected")) ) {
																//APPLIED
																$fstat = "
																		<div align='center'>
																			<span class='btn btn-danger btn-md'>STATUS: REJECTED</span>
																		</div>
																		<br/>
																";
															}
															if ( strtolower(trim($stat))==strtolower(trim("pending")) || trim($stat)=="" ) {
																//APPLIED
																$fstat = "
																		<div align='center'>
																			<span class='btn btn-warning btn-md'>STATUS: PENDING</span>
																		</div>
																		<br/>
																";
															}
															//
															$cn = 0;
															$sql1 = " select jobpost_app_id,jobpost_id,pdate,app_id,app_type from tbl_jobpost_applicant  where jobpost_id='$dat[0]' and app_id='$logun'  ";
															$qry1 = mysqli_query($conn,$sql1);
															while($dat1=mysqli_fetch_array($qry1)) {
																$cn += 1;
															}
															//
															if ( $cn > 0 ) {
																//APPLIED
																$frmapply = "
																		<div align='center'>
																			<form action='' method='post'>
																				<input type='hidden' name='txtjpid' value='$dat[0]' />
																				<input type='hidden' name='txtact' value='UNAPPLY' />
																				<input type='submit' class='btn btn-danger btn-md' name='btnsaveApplication' value='CANCEL APPLICATION' />
																			</form>
																		</div>
																		<br/>
																";
															}else{
																//NOT YET APPLIED
																$frmapply = "
																		<div align='center'>
																			<form action='' method='post'>
																				<input type='hidden' name='txtjpid' value='$dat[0]' />
																				<input type='hidden' name='txtact' value='APPLY' />
																				<input type='submit' class='btn btn-success btn-md' name='btnsaveApplication' value='APPLY' />
																			</form>
																		</div>
																		<br/>
																";
															}
														}
														//
													}
													//
													//
													$disp = $disp . "
															<li>
																<div class='panel panel-default uldiv01' align='left'>
																	<div class='uldiv01'>
																		<table class=''>
																			<tr>
																				<td>
																					<img src='$img' class='ann_img03' />
																				</td>
																				<td>
																					<div class='div_ann_name01'>
																						<a href='$link' class='ann_link01'>$memname</a>
																						<br/>
																						<span class='pst_date_01'>$dat[3]</span>
																					</div>
																				</td>
																			</tr>
																		</table>
																		<hr class='hr02'/>
																		$fstat
																		$frmapply
																		<div class='div_ann_msg01'>
																			$dat[2]
																		</div>
																		<div class='div_ann_msg03'>
																			$finjl
																		</div>
																		<div class='div_ann_msg02'>
																			$pfile
																		</div>
																	</div>
																</div>
															</li>
													";
												}
											}
											//
											echo "<ul class='ul01'>";
											echo "$disp";
											echo "</ul>";
										}
										//
									}
									//
			//=======================================================================
									//
									if ( strtolower(trim($page))==strtolower(trim("application")) &&
										 strtolower(trim($logun))!=strtolower(trim("")) &&
										 strtolower(trim($logutype))!=strtolower(trim("student"))  
										) {
										//LOAD AVAILABLE
										$nn = 0;
										$dn = 0;
										//
										//
							// =====================================================================================
										//
										if ( strtoupper(trim($logutype))==strtoupper(trim("employee")) ) {
										//echo "$logun $logutype";
											$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff where staff_id='$logun' and staff_type='$logutype' ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												$dn += 1;
											}
										}
										//
										//
										if ( $dn > 0 ) {
											//
											/// ================================================
											//
											$htecq = "";
											//
											//                  0          1      2       3          4
											$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff where staff_id='$logun' and staff_type='$logutype' ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($htecq) == "" ) {
													$htecq = " hte_id='$dat[1]' ";
												}else{
													$htecq = $htecq . " or hte_id='$dat[1]' ";
												}
											}
											//
											if ( trim($htecq)!="" ) {
												$htecq = " where " . $htecq;
											}
											//
											//GET JOB POST ID
											$cjpi = "";
											//                  0      1
											$sql = " select jobpost_id,hte_id from tbl_jobpost $htecq  ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($cjpi) == "" ) {
													$cjpi = " jobpost_id='$dat[0]' ";
												}else{
													$cjpi = $cjpi . " or jobpost_id='$dat[0]' ";
												}
											}
											//
											if ( trim($cjpi)!="" ) {
												$cjpi = " and ( " . $cjpi . " ) ";
											}
											//
											//
										// ====================
									if ( trim($cjpi)!="" ){
											//
											$ids = "";
											//
											$appstat = trim($_GET['appstat']);
											//
											if ( trim($appstat)=="" ) {
												$appstat = "pending";
											}
											//
											$asq = "";
											if ( trim($appstat)!="" ) {
												if ( strtolower(trim($appstat))==strtolower(trim("pending")) ) {
													$asq = " where status='$appstat' or status='' ";
												}else{
													$asq = " where status='$appstat' ";
												}
											}
											//
											//                      0            1     2    3      4       5
											$sql3 = " select jobpost_app_id,jobpost_id,sy,app_id,app_type,pdate from tbl_jobpost_applicant $asq $cjpi  order by jobpost_app_id desc ";
											$qry3 = mysqli_query($conn,$sql3);
											while($dat3=mysqli_fetch_array($qry3)) {
												//
												$appid = trim($dat3[3]);
												$appname = "";
												$appimg = "";
												$appdate = trim($dat3[5]);
												$applink = "";
												//
												$hte_id = "";
												$jobs = "";
												//
												//GET APPLICANT INFO
													if ( strtolower(trim($dat3[4]))==strtolower(trim("student")) ) {
														$sql1 = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns  where studentid='$dat3[3]'  ";
														$qry1 = mysqli_query($conn,$sql1);
														while($dat1=mysqli_fetch_array($qry1)) {
															if ( trim($dat1[0]) != "" ) {
																$mname = "";
																if ( trim($dat1[2])!="" ) {
																	$mname = " " . trim($dat1[2]);
																}
																$appname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
																//
																$appimg = trim($dat1[4]);
																//
																$applink = "./page_profile.php?id=".trim($dat1[0]);
															}
														}
													}
												//
												//                    0       1     2    3    4     5     6      7     8
												$sql = " select jobpost_id,subject,msg,pdate,jobs,by_id,by_type,cfile,hte_id from tbl_jobpost  where jobpost_id='$dat3[1]'   order by jobpost_id desc ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[1])!=="" || trim($dat[2])!="" || trim($dat[7])!="" ) {
														$nn = $nn + 1;
														//
														//FILE
														$pfile = "";
														$fln = trim($dat[7]);
														//
														$dfn = "File";
														$dfnx = "";
														//
														$jobs = trim($dat[4]);
														$hte_id = trim($dat[8]);
														//
														//
														if ( trim($fln)!="" ) {
															$dfnx = "." . trim(pathinfo($fln,PATHINFO_EXTENSION));
															if ( trim($dat[1])=="" ) {
																$dfn = "File";
															}else{
																$dfn = trim($dat[1]);
															}
															//
															if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
																  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
																  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
																  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
																  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
																) {
																$pfile = "<p align='center'>
																				<a href='#' class='ann_lnkprev01' data-toggle='modal' data-target='#modalPrevImage_$nn'>
																			<img class='ann_img01' src='".trim($fln)."'/>
																				</a>
																			<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																				<img class='ann_img02' src='".trim($fln)."'/>
																			</div>
																		  </p>";
															}else{
																$pfile = "<p align='left'><a href='".trim($fln)."' target='_blank'>".trim($dfn).trim($dfnx)."</a></p>";
															}
														}
														//
														$memid = "";
														$memname = "";
														$img = "";
														$link = "";
														//GET MEMBER NAME
														if ( strtolower(trim($dat[6]))==strtolower(trim("student")) ) {
															$sql1 = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns  where studentid='$dat[5]'  ";
															$qry1 = mysqli_query($conn,$sql1);
															while($dat1=mysqli_fetch_array($qry1)) {
																if ( trim($dat1[0]) != "" ) {
																	$mname = "";
																	if ( trim($dat1[2])!="" ) {
																		$mname = " " . trim($dat1[2]);
																	}
																	$memid = trim($dat1[0]);
																	$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
																	//
																	$img = trim($dat1[4]);
																	//
																	$link = "./page_profile.php?id=".trim($dat1[0]);
																}
															}
														}
														if ( strtolower(trim($dat[6]))==strtolower(trim("employee")) ) {
															$sql1 = " select employee_id,firstname,middlename,lastname,prof_img from tbl_employee  where employee_id='$dat[5]'  ";
															$qry1 = mysqli_query($conn,$sql1);
															while($dat1=mysqli_fetch_array($qry1)) {
																if ( trim($dat1[0]) != "" ) {
																	$mname = "";
																	if ( trim($dat1[2])!="" ) {
																		$mname = " " . trim($dat1[2]);
																	}
																	$memid = trim($dat1[0]);
																	$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
																	//
																	$img = trim($dat1[4]);
																	//
																	$link = "./page_profile_employee.php?id=".trim($dat1[0]);
																}
															}
														}
														if ( strtolower(trim($dat[6]))==strtolower(trim("")) || strtolower(trim($dat[6]))==strtolower(trim("admin")) ) {
															$memid = "Admin";
															$memname = "Admin";
															$img = "";
															//
															$link = "#";
														}
														//
														if ( trim($img)=="" ) {
															$img = "./assets/img/empty_user.png";
														}
														//
														//
														//GET JOB LIST
														$finjl = "";
														//
														$sjl = trim($dat[4]);
														$sjla = explode(";", $sjl);
														//
														for ( $i=0 ; $i < count($sjla) ; $i++ ) {
															if ( trim($sjla[$i])!="" ) {
																$tmpn = "";
																//
																//FIND JOB NAME
																$sql1 = " select hte_job_id,name from tbl_hte_jobs  where hte_job_id='$sjla[$i]'  ";
																$qry1 = mysqli_query($conn,$sql1);
																while($dat1=mysqli_fetch_array($qry1)) {
																	if ( trim($dat1[1]) != "" ) {
																		$tmpn = trim($dat1[1]);
																	}
																}
																//
																$finjl = $finjl . "&bullet; <span class='span02'>" . trim($tmpn) . "</span><br/>";
															}
														}
														//
														if ( trim($finjl)!="" ) {
															$finjl = "
																		<br/>
																		<b>Jobs Needed:</b><br/>
																		<div class='div_jp01'>
																			<b>$finjl</b>
																		</div>
																		<br/>
															";
														}
														//
														//
														//APPLY
														$fstat = "";
														$frmapply = "";
														if ( trim($logun)!="" ) {
															//
															if ( strtolower(trim($logutype))!=strtolower(trim("student")) ) {
																//CHECK
																$stat = "";
																$cn = 0;
																//                      0           1        2      3      4       5
																$sql1 = " select jobpost_app_id,jobpost_id,pdate,app_id,app_type,status from tbl_jobpost_applicant  where jobpost_id='$dat3[1]' and app_type='student' and app_id='$appid'  ";
																$qry1 = mysqli_query($conn,$sql1);
																while($dat1=mysqli_fetch_array($qry1)) {
																	$stat = $dat1[5];
																}
																//
																$fstat = "";
																//
																if ( strtolower(trim($stat))==strtolower(trim("accepted")) ) {
																	//APPLIED
																	$fstat = "
																			<div align='center'>
																				<span class='btn btn-success btn-md'>STATUS: ACCEPTED</span>
																			</div>
																			<br/>
																	";
																}
																if ( strtolower(trim($stat))==strtolower(trim("rejected")) ) {
																	//APPLIED
																	$fstat = "
																			<div align='center'>
																				<span class='btn btn-danger btn-md'>STATUS: REJECTED</span>
																			</div>
																			<br/>
																	";
																}
																if ( strtolower(trim($stat))==strtolower(trim("pending")) || trim($stat)=="" ) {
																	//APPLIED
																	$fstat = "
																			<div align='center'>
																				<span class='btn btn-warning btn-md'>STATUS: PENDING</span>
																			</div>
																			<br/>
																	";
																}
																//
																	$frmapply = "
																			<div align='center'>
																				<table>
																					<tr>
																						<td>
																							<form action='' method='post'>
																								<input type='hidden' name='txtjpid' value='$dat[0]' />
																								<input type='hidden' name='txtappid' value='$appid' />
																								<input type='hidden' name='txthteid' value='$hte_id' />
																								<input type='hidden' name='txtjobs' value='$jobs' />
																								<input type='hidden' name='txtact' value='ACCEPTED' />
																								<input type='submit' class='btn btn-success btn-md' name='btnsaveAppStatus' value='ACCEPT' />
																							</form>
																						</td>
																						<td>
																							<form action='' method='post'>
																								<input type='hidden' name='txtjpid' value='$dat[0]' />
																								<input type='hidden' name='txtappid' value='$appid' />
																								<input type='hidden' name='txtact' value='PENDING' />
																								<input type='submit' class='btn btn-warning btn-md' name='btnsaveAppStatus' value='PENDING' />
																							</form>
																						</td>
																						<td>
																							<form action='' method='post'>
																								<input type='hidden' name='txtjpid' value='$dat[0]' />
																								<input type='hidden' name='txtappid' value='$appid' />
																								<input type='hidden' name='txthteid' value='$hte_id' />
																								<input type='hidden' name='txtjobs' value='$jobs' />
																								<input type='hidden' name='txtact' value='REJECTED' />
																								<input type='submit' class='btn btn-danger btn-md' name='btnsaveAppStatus' value='REJECT' />
																							</form>
																						</td>
																					</tr>
																				</table>
																			</div>
																			<br/>
																	";
															}
														}
														//
														//
														$disp = $disp . "
																<li>
																	<div class='panel panel-default uldiv01' align='left'>
																		<div class='uldiv01'>
																			<table class=''>
																				<tr>
																					<td>
																						<img src='$img' class='ann_img03' />
																					</td>
																					<td>
																						<div class='div_ann_name01'>
																							<a href='$link' class='ann_link01'>$memname</a>
																							<br/>
																							<span class='pst_date_01'>$dat[3]</span>
																						</div>
																					</td>
																				</tr>
																			</table>
																			<hr class='hr02'/>
																			<p align='left'>
																				<b>APPLICANT:</b>
																			</p>
																			<table class=''>
																				<tr>
																					<td>
																						<img src='$appimg' class='ann_img03' />
																					</td>
																					<td>
																						<div class='div_ann_name01'>
																							<a href='$applink' class='ann_link01'>$appname</a>
																							<br/>
																							<span class='pst_date_01'>$appdate</span>
																						</div>
																					</td>
																				</tr>
																			</table>
																			<hr class='hr02'/>
																			$fstat
																			$frmapply
																			<div class='div_ann_msg01'>
																				$dat[2]
																			</div>
																			<div class='div_ann_msg03'>
																				$finjl
																			</div>
																			<div class='div_ann_msg02'>
																				$pfile
																			</div>
																		</div>
																	</div>
																</li>
														";
													}
												}
												
											}

											//
											echo "<ul class='ul01'>";
											echo "$disp";
											echo "</ul>";
											//
											//
									}
											/// ================================================
											//
										}
										//
							// =====================================================================================
									}
									//
								?>
							</div>
							<!-- END LEFT COLUMN -->
						</div>
						<div class="col-md-4">
							<!-- RIGHT COLUMN -->
									<?php
										$curid = $_SESSION['intern_data_cun'];
										$curidtype = $_SESSION['intern_data_utype'];
										//
										$logun = $curid;
										$logutype = $curidtype;
										//
										//
										$page = trim($_GET['page']);
										//
										$nn = 0;
										//
										//
										if ( strtolower(trim($curidtype))==strtolower(trim("employee")) ) {
											$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff where staff_id='$logun' and staff_type='$logutype' and position='supervisor' ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												$nn += 1;
											}
										}
										//
										if ( $nn > 0) {
											//
											//
											echo "
												<div class='panel ann_divr02'>
													<div class='tab-content divclass03' align='center'>
											";
											//
											//
											echo "<a href='' data-target='#modalAddJobPost' class='btn btn-success btn-sm btn-block' data-toggle='modal'><b>+ CREATE JOB POST</b></a> ";
											//echo "<br/>";
											//echo "<br/>";
											include "./parts/page_jobposts_modal.php";
											//
											//
											echo "
												</div>
											</div>	
											";
										}
										//
										if ( strtolower(trim($curidtype))==strtolower(trim("student")) ) {
											//
											//
											echo "
												<div class='panel ann_divr02'>
													<div class='tab-content divclass03' align='center'>
											";
											//
											//
											if ( strtolower(trim($page))==strtolower(trim("jobs")) ||
												 strtolower(trim($page))==strtolower(trim(""))
												) {
												echo "<a href='./page_jobposts.php?page=application' class='btn btn-primary btn-sm btn-block'><b>VIEW APPLICATIONS</b></a> ";
											}
											if ( strtolower(trim($page))==strtolower(trim("application")) ) {
												echo "<a href='./page_jobposts.php?page=jobs' class='btn btn-primary btn-sm btn-block'><b>VIEW JOB POSTS</b></a> ";
												//
												echo "<br/> ";
												echo "<b>[ FILTER BY ]</b><br/> ";
												echo "<a href='./page_jobposts.php?page=application&appstat=accepted' class='btn btn-success btn-sm '><b>ACCEPTED</b></a> ";
												echo "<a href='./page_jobposts.php?page=application&appstat=pending' class='btn btn-warning btn-sm '><b>PENDING</b></a> ";
												echo "<a href='./page_jobposts.php?page=application&appstat=rejected' class='btn btn-danger btn-sm '><b>REJECTED</b></a> ";
											}
											//
											//
											echo "
												</div>
											</div>	
											";
										}
										//
										if ( strtolower(trim($curidtype))!=strtolower(trim("student")) ) {
											//
											$appvok = 0;
											if ( strtoupper(trim($logutype))==strtoupper(trim("employee")) ) {
											//echo "$logun $logutype";
												$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff where staff_id='$logun' and staff_type='$logutype' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$appvok += 1;
												}
											}
											//
											echo "
												<div class='panel ann_divr02'>
													<div class='tab-content divclass03' align='center'>
											";
											//
											//
											if ( strtolower(trim($page))==strtolower(trim("jobs")) ||
												 strtolower(trim($page))==strtolower(trim(""))
												) {
												if ( $appvok > 0 ) {
													echo "<a href='./page_jobposts.php?page=application' class='btn btn-primary btn-sm btn-block'><b>VIEW APPLICATIONS</b></a> ";
												}
											}
											if ( strtolower(trim($page))==strtolower(trim("application")) ) {
												echo "<a href='./page_jobposts.php?page=jobs' class='btn btn-primary btn-sm btn-block'><b>VIEW JOB POSTS</b></a> ";
												//
												echo "<br/> ";
												echo "<b>[ FILTER BY ]</b><br/> ";
												echo "<a href='./page_jobposts.php?page=application&appstat=accepted' class='btn btn-success btn-sm '><b>ACCEPTED</b></a> ";
												echo "<a href='./page_jobposts.php?page=application&appstat=pending' class='btn btn-warning btn-sm '><b>PENDING</b></a> ";
												echo "<a href='./page_jobposts.php?page=application&appstat=rejected' class='btn btn-danger btn-sm '><b>REJECTED</b></a> ";
											}
											//
											//
											echo "
												</div>
											</div>	
											";
										}
										//
									?>
							<!-- END RIGHT COLUMN -->
						</div>
					</div>

				</div>

			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>

	<script >
	$(document).ready(function(){
  $("#myInput1").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable1 tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

	</script>

	
<?php
	include "./parts/btm_script.php";
?>

</body>

</html>
