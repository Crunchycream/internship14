<?php  session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$_SESSION['intern_page_current'] = "page_profile_employee";
		include "./parts/main_logcheck.php";
	//
	if ( trim($logun)=="" ) {
		exit;
	}
?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>

</head>

<body>
		<!---MODAL -->
	<?php include "./parts/page_profile_employee_modal.php"; ?>
	<?php include "./parts/page_profile_employee_upload.php"; ?>
		<!---END MODAL -->
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-7">
							<!-- LEFT COLUMN -->
							<div class="panel">
								<?php
									$id = $_GET['id'];
									$cuid =  $_SESSION['intern_data_cun'];
									$cutype = $_SESSION['intern_data_utype'];
									//
									$accn = 0;
									//
									if ( strtolower(trim($cutype))==strtolower(trim("employee")) && strtolower(trim($cuid))==strtolower(trim($id)) ) {
										$accn += 1;
									}
									if ( strtolower(trim($cutype))==strtolower(trim("admin")) ) {
										$accn += 1;
									}
									//
									if ( $accn > 0 ) {
										echo "
											<div class='dropdown divprof_menu01'>
											  <button class='btn btn-primary dropdown-toggle btnprof_menu01' type='button' data-toggle='dropdown'>&equiv;</button>
											  <ul class='dropdown-menu'>
											    <li><a  data-toggle='modal' data-target='#modalChangePhoto' href='' class=''>Update Photo</a></li>
											    <li><a  data-toggle='modal' data-target='#modalChangeCoverPhoto' href='' class=''>Update Background Photo</a></li>
											    <li class='divider'></li>
											    <li><a  data-toggle='modal' data-target='#modalUpdateInfo' href='' class=''>Update Info</a></li>
											    <li><a  data-toggle='modal' data-target='#modalUpdateInfoPassword' href='' class=''>Update Password</a></li>
											  </ul>
											</div>
										";
									}
								?>
<!-- ========================================================================================== -->


											<?php
												//
												$nn = 0;
												//
												include "./data/connect.php";
												//
												//
												$cpid = $_GET['id'];
												$cuid =  $_SESSION['intern_data_cun'];
												$cutype = $_SESSION['intern_data_utype'];
												//
												//                   0         1       2         3          4       5      6        7        8       
												$sql = " select employee_id,lastname,firstname,middlename,gender,position,email,contact_no,address from tbl_employee where employee_id='$cpid'  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$nn = $nn + 1;
													//
													$genderopt = "";
													$posopt = "";
							                            $sql2 = " select no,gender from tbl_gender ";
							                            $qry2 = mysqli_query($conn,$sql2);
							                            while($dat2=mysqli_fetch_array($qry2)) {
							                              if ( trim($dat2[1]) != "" ) {
							                              	$isel = "";
							                              	if (  strtolower(trim($dat2[1]))==strtolower(trim($dat[4])) ) {
							                              		$isel = " selected='true' ";
							                              	}
							                                $genderopt = $genderopt . "<option value='".trim($dat2[1])."' $isel>".trim($dat2[1])."</option>";
							                              }
							                            }
							                            //
							                            $sql2 = " select staff_position_id,position from tbl_staff_position ";
							                            $qry2 = mysqli_query($conn,$sql2);
							                            while($dat2=mysqli_fetch_array($qry2)) {
							                              if ( trim($dat2[1]) != "" ) {
							                              	$isel = "";
							                              	if (  strtolower(trim($dat2[1]))==strtolower(trim($dat[5])) ) {
							                              		$isel = " selected='true' ";
							                              	}
							                                $posopt = $posopt . "<option value='".trim($dat2[1])."' $isel>".trim($dat2[1])."</option>";
							                              }
							                            }
													//
													$frm_updateinfo = "

																    <div id='modalUpdateInfo' class='modal fade' role='dialog'>
																      <div class='modal-dialog'>
																      <!-- Modal content-->
																      <div class='modal-content'>
																      <div class='modal-header'>
																        <button type='button' class='close' data-dismiss='modal'>&times;</button>
																        <h4 class='modal-title'>Update Employee</h4>
																      </div>
																          <form method='post' action=''>
																      <div class='modal-body'>
																        <p>
																					<input type='hidden' name='txtid' value='$dat[0]'/>
																          <div class='form-group'>
																                  
																                </div>
																                <div class='form-group div01'>
																                  <label for='stud-add-id' class='control-label sr-only'>Employee ID</label>
																                  <input type='text' name='employee_id' class='form-control txt01' id='stud-add-id' placeholder='Employee ID'
																                     value='$dat[0]' 
																                  >
																                </div>
																                <div class='form-group div01'>
																                  <table>
																                    <tr>
																                      <td class='td01'>
																                        <label for='stud-add-fn' class='control-label sr-only'>Firstname</label>
																                        <input type='text' name='fname' class='form-control txt01' id='stud-add-fn' placeholder='Firstname'
																                           value='$dat[2]' 
																                        >
																                      </td>
																                      <td class='td01'>
																                        <label for='stud-add-mn' class='control-label sr-only'>Middlename</label>
																                        <input type='text' name='mname' class='form-control txt01' id='stud-add-mn' placeholder='Middlename'
																                           value='$dat[3]' 
																                        >
																                      </td>
																                      <td class='td01'>
																                        <label for='stud-add-ln' class='control-label sr-only'>Lastname</label>
																                        <input type='text' name='lname' class='form-control txt01' id='stud-add-ln' placeholder='Lastname'
																                           value='$dat[1]' 
																                        >
																                      </td>
																                    </tr>
																                  </table>
																                  
																                </div>
																                <div class='div01'>
																                  <table>
																                    <tr>
																                      <td class='td01'>
																                        <select class='form-control txt01' name='gender'>
																                          $genderopt
																                        </select>
																                      </td>
																                    </tr>
																                  </table>
																                </div>
																                <div class='form-group div01'>
																                  <label for='stud-add-address' class='control-label sr-only'>Address</label>
																                  <input type='text' name='address' class='form-control txt01' id='stud-add-address' placeholder='Address'
																                     value='$dat[8]' 
																                  >
																                </div>
																                <div class='div01'>
																                  <table>
																                    <tr>
																                      <td class='td01'>
																                        <select class='form-control txt01' name='position'>
																                          $posopt
																                        </select>
																                      </td>
																                    </tr>
																                  </table>
																                </div>
																                <table>
																                  <tr>
																                    <td class='td01'>
																                      <div class='form-group'>
																                        <label for='stud-add-contactno' class='control-label sr-only'>Contact #</label>
																                        <input type='text' name='contactno' class='form-control txt01' id='stud-add-contactno' placeholder='Contact #'
																                           value='$dat[7]' 
																                        >
																                      </div>
																                    </td>
																                    <td class='td01'>
																                      <div class='form-group'>
																                        <label for='stud-add-email' class='control-label sr-only'>E-mail</label>
																                        <input type='text' name='email' class='form-control txt01' id='stud-add-email' placeholder='E-mail'
																                           value='$dat[6]' 
																                        >
																                      </div>
																                    </td>
																                  </tr>
																                </table>
																            
																        </p>
																      </div>
																      <div class='modal-footer'>
																        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																        <input type='submit' name='btnsaveUpdateInfo' class='btn btn-primary btn-lg btn01' value='SAVE'>
																      </div>
																          </form>
																      </div>

																      </div>
																    </div>


																<div id='modalUpdateInfoPassword' class='modal fade' role='dialog'>
																	<div class='modal-dialog'>
																	<!-- Modal content-->
																	<div class='modal-content'>
																	<div class='modal-header'>
																		<button type='button' class='close' data-dismiss='modal'>&times;</button>
																		<h4 class='modal-title'>Update Password</h4>
																	</div>
																			<form method='post' action=''>
																				<input type='hidden' name='acttab1' value='reg' />
																	<div class='modal-body'>
																		<p>
																			<input type='hidden' name='txtid' value='".trim($cpid)."' />
																			
																			<div class='form-group div01'>
																				<label for='opass' class='control-label sr-only'>Current Password</label>
																				<input type='Password' name='opass' class='form-control txt01' id='opass' placeholder='Current Password' 
																				>
																			</div>

																			<div class='form-group div01'>
																				<label for='npass1' class='control-label sr-only'>New Password</label>
																				<input type='Password' name='npass1' class='form-control txt01' id='npass1' placeholder='New Password' 
																				>
																			</div>

																			<div class='form-group div01'>
																				<label for='npass2' class='control-label sr-only'>Repeat New Password</label>
																				<input type='Password' name='npass2' class='form-control txt01' id='npass2' placeholder='Repeat New Password' 
																				>
																			</div>

																		</p>
																	</div>
																	<div class='modal-footer'>
																		<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																		<input type='submit' name='btnsaveUpdateInfoPassword' class='btn btn-primary btn-lg btn01' value='SAVE'>
																	</div>
																			</form>
																	</div>

																	</div>
																</div>


													";
													if ( (strtolower(trim($cutype))==strtolower(trim("employee")) && strtolower(trim($cuid))==strtolower(trim($cpid))) || (strtolower(trim($cutype))==strtolower(trim("admin"))) ) {
														echo "$frm_updateinfo";
													}
												}
											?>
											

<!-- ========================================================================================== -->

								<!-- PROFILE HEADER -->
								<div class="profile-header">
									<div class="overlay"></div>
									
										<?php include "./data/connect.php";
											$id = $_GET['id'];
											$sql = " select no,employee_id,firstname,middlename,lastname,prof_img,prof_backimg from tbl_employee where employee_id='$id' ";
											$qry = mysqli_query($conn,$sql);
											$ttl = "";
											$ttlid = "";
											$img = "";
											$backimg = "";
											while($dat=mysqli_fetch_array($qry)) {
												$ttl = trim($dat[2])." ".trim($dat[3])." ".trim($dat[4]);
												$ttlid = trim($dat[1]);
												$img = trim($dat[5]);
												$backimg = trim($dat[6]);
											}
											if ( trim($img) == "" ) {
												$img = "assets/img/empty_user.png";
											}
											if ( trim($backimg) == "" ) {
												$backimg = "assets/img/profile-bg.png";
											}
											echo "
													<div class='profile-main' style='background:url($backimg) no-repeat; background-size: 100%;'>
													<br/>
													<img src='$img' class='img-circle img_prof_02' alt='Photo'>
													<h3 class='name'>
														<span class='span02'><a class='prof_name_link01' href='./page_profile_employee.php?id=".trim($ttlid)."'>$ttl</a></span>
													</h3>
													<span class='online-status status-available'>Available</span>

													</div>
												";
										?>
									
								</div>
									<?php
										//
										$logun = $_SESSION['intern_data_cun'];
										$logutype = $_SESSION['intern_data_utype'];
										//
										$cid = trim($_GET['id']);
										$cidt = "employee";
										//
										if ( strtolower(trim($logun))==strtolower(trim($cid)) && strtolower(trim($logutype))==strtolower(trim($cidt)) ) {

										}else{
											echo "

												<div align='right'>
													<a class='btn btn-success btn-sm' href='#' data-toggle='modal' data-target='#modalSendMessage'>Send Message</a>
												</div>

												<div id='modalSendMessage' class='modal fade' role='dialog'>
													<div class='modal-dialog'>
													<!-- Modal content-->
													<div class='modal-content'>
													<div class='modal-header'>
														<button type='button' class='close' data-dismiss='modal'>&times;</button>
														<h4 class='modal-title'>Send Message</h4>
													</div>
															<form action='' method='post'>
													<div class='modal-body'>
														<p>
															<input type='hidden' name='txtid' value='$cid'/>
															<input type='hidden' name='txttype' value='$cidt'/>
															<div class='form-group'>
																
															</div>
															<div class='form-group div01'>
																<label for='send-msg-msg' class='control-label sr-only'>Message</label>
																<textarea name='msg' class='form-control txta01' id='send-msg-msg' placeholder='Message'></textarea>
															</div>
														</p>
													</div>
													<div class='modal-footer'>
														<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
														<input type='submit' class='btn btn-primary' value='Send' name='btnsaveSendMessage'>
													</div>
															</form>
													</div>

													</div>
												</div>

											";
										}
									?>
								<!-- END PROFILE HEADER -->
								<!-- PROFILE DETAIL -->

					<!-- TABBED CONTENT -->
					
					<!-- END TABBED CONTENT -->

								
								<!-- END PROFILE DETAIL -->

							</div>
				<!-- END LEFT COLUMN -->
			</div>

						<div class="col-md-5">
				<!-- RIGHT COLUMN -->
							<div class="panel ann_divr02">
								<h4 class="heading">Info</h4>
								<!-- AWARDS -->
								<div class="">
									<div class="">

										<div class="">
											
										<?php
											include "./data/connect.php";
											//
											$cpid = $_GET['id'];
											$cuid =  $_SESSION['intern_data_cun'];
											$cutype = $_SESSION['intern_data_utype'];
											//
											$info = "";
											//                     0     1          2          3      4      5        6      7        8     9 
											$sql = " select employee_id,firstname,middlename,lastname,email,address,gender,contact_no,no,position from tbl_employee  where employee_id='$cpid'  ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												$info = "
														<div class='table-responsive'>
															<table class='table'>
																<tr>
																	<td>
																		Contact #:
																	</td>
																	<td>
																		$dat[7]
																	</td>
																</tr>
																<tr>
																	<td>
																		Email:
																	</td>
																	<td>
																		$dat[4]
																	</td>
																</tr>
																<tr>
																	<td>
																		Address:
																	</td>
																	<td>
																		$dat[5]
																	</td>
																</tr>
																<tr>
																	<td>
																		Gender:
																	</td>
																	<td>
																		$dat[6]
																	</td>
																</tr>
																<tr>
																	<td>
																		Position:
																	</td>
																	<td>
																		$dat[9]
																	</td>
																</tr>
															</table>
														</div>
												";
											}
											echo "$info";
										?>

										</div>
										
									</div>
									
								</div>
								<!-- END AWARDS -->
								<!-- TABBED CONTENT -->
								<!-- END TABBED CONTENT -->
							</div>
							<!-- END RIGHT COLUMN -->
						</div>
						
					</div>
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>

	
<?php
	include "./parts/btm_script.php";
?>

</body>

</html>
