<?php session_start(); error_reporting( E_ALL ^ E_NOTICE );
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	//
	$ptype = trim($_GET['type']);
	//
	$_SESSION['intern_page_current'] = "ranking";
	$_SESSION['intern_page_current2'] = "ranking_".trim($ptype);
		include "./parts/main_logcheck.php";
	include "./parts/sys_hte_raterank_updater.php";
	//
	if ( trim($logun)=="" || strtolower(trim($logutype))==strtolower(trim("student")) ) {
		echo "<META HTTP-EQUIV='Refresh' Content='0; URL=./cpanel.php'>";
		exit;
	}
 ?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>

</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">
						<?php
							$cpage=$_SESSION['intern_page_current'];
							$cpage2=$_SESSION['intern_page_current2'];
							if ( strtolower(trim($cpage))==strtolower(trim("ranking")) ) {
								if ( strtolower(trim($cpage2))==strtolower(trim("ranking_intern")) ) {
									echo "Intern Ranking";
								}
								if ( strtolower(trim($cpage2))==strtolower(trim("ranking_hte")) ) {
									echo "HTE Ranking";
								}
							}
						?>
					</h3>
					<div class="row">
						
						<div class="col-md-12">
							<!-- BASIC TABLE -->
							<div class="row">
							<div class="col-md-9">
							<h5 class="ss">Search:</h5>
							</div>
						
							
							<div class="col-md-3">
							<div class="form-group pull-right">
								<form action="" method="get">
							<input type="text" id="myInput1" name="search" class="search form-control" placeholder="What you looking for" 
								<?php
									$val = $_GET['search'];
									echo " value='$val' ";
								?>
									>
							<!-- 
								<span class="counter pull-right"><input type="submit" class="btn btn-primary" value="Search"/></span>
							-->
							
								</form>
								</div>
									<span class="counter pull-right"></span>
									</div>
						</div>
						<hr>

						<div class="">

							<div class="panel divrank01">
					
								<div class="table-responsive">
									<?php include "./data/connect.php";
										$ptype = trim($_GET['type']);
										//
										$sy = trim($_SESSION['intern_data_active_sy']);
										//
										if ( trim($ptype)=="" ) {
											$ptype = "hte";
										}
										//
										$nn = 0;
										$dhval = "";
										$dval = "";
										//
										if ( strtolower(trim($ptype))==strtolower(trim("hte")) ) {
											$sql = " select hte_id,total_rate from tbl_hte_raterank  where sy='$sy'  order by total_rate desc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												$nn = $nn + 1;
												//$rate = getHTERate2($dat[0]);
												$rate = $dat[1];
												$nos = getCountHTEInterns2($dat[0]);
												$id = trim($dat[0]);
												$hte = "";
												$addr = "";
												//$nos = "";
													//                  0    1   2    3        4           5
													$sql1 = " select hte_id,dsn,name,address,no_students,prof_backimg from tbl_hte  where hte_id='$id'  ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														//
														$img = "";
														$img = trim($dat1[5]);
														if ( trim($img)=="" ) {
															$img = "./assets/img/empty_user.png";
														}
														//
														$hte = "<b><a class='' href='page_hte.php?id=$dat1[0]'><img class='ranking_img01' src='$img' />  ".trim($dat1[2])."</a></b>";
														$addr = trim($dat1[3]);
														//$nos = trim($dat1[4]);
													}
													//
													$cd = explode(".", trim($rate));
													$c1 = $cd[0];
													$c2 = "0";
													if ( strval($cd[1])>0 ) {
														$c2 = substr(trim($cd[1]), 0,2);
													}
													//
													$fc = $c1 . "." . $c2;
													//
													//
												$dval = $dval . "
													<tr>
														<td>
															$nn
														</td>
														<td>
															$hte
														</td>
														<td>
															$addr
														</td>
														<td>
															$nos
														</td>
														<td>
															$fc
														</td>
													</tr>
												";
											}
											$dhval = "
														<tr>
															<th>Rank #</th>
															<th>HTE</th>
															<th>Address</th>
															<th># of Students</th>
															<th>Evalutaion Result</th>
														</tr>
											";
										}
										//
										if ( strtolower(trim($ptype))==strtolower(trim("intern")) ) {
											//
											$sql = " select studentid,total_rate from tbl_interns_raterank  where sy='$sy' group by studentid order by total_rate desc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												$nn = $nn + 1;
												//$rate = getInternRate2($dat[0]);
												$rate = ($dat[1]);
												//$nos = getCountHTEInterns2($dat[0]);
												$id = trim($dat[0]);
												$lnk = "";
												$crsid = "";
												$crsn = "";
												//
												$lname = "";
												$fname = "";
														$img = "";
												//$nos = "";
													//                  0        1        2         3          4      5
													$sql1 = " select studentid,lastname,firstname,middlename,course,prof_img from tbl_interns  where studentid='$id'  ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														$lnk = "page_profile.php?id=$dat1[0]";
														$crsid = trim($dat1[4]);
														//
														$fname = trim($dat1[2]);
														$lname = trim($dat1[1]);
														//
														$img = trim($dat1[5]);
													}
													$sql1 = " select course_id,course from tbl_course  where course_id='$crsid'  ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														$crsn = trim($dat1[1]);
													}
													//
													$cd = explode(".", trim($rate));
													$c1 = $cd[0];
													$c2 = "0";
													if ( strval($cd[1])>0 ) {
														$c2 = substr(trim($cd[1]), 0,2);
													}
													//
													$fc = $c1 . "." . $c2;
													//
														//
														if ( trim($img)=="" ) {
															$img = "./assets/img/empty_user.png";
														}
														//
														//
												$dval = $dval . "
													<tr>
														<td>
															$nn
														</td>
														<td>
															<b><a class='' href='".trim($lnk)."'><img class='ranking_img01' src='$img' />  ".trim($lname)."</a></b>
														</td>
														<td>
															<b><a class='' href='".trim($lnk)."'>".trim($fname)."</a></b>
														</td>
														<td>
															$crsn
														</td>
														<td>
															$fc
														</td>
													</tr>
												";
											}
											$dhval = "
														<tr>
															<th>Rank #</th>
															<th>Lastname</th>
															<th>Firstname</th>
															<th>Course</th>
															<th>Evalutaion Result</th>
														</tr>
											";
										}
										//
										//
										if ( strtolower(trim($ptype))!=strtolower(trim("")) ) {
											echo "
												<table class='table'>
													<thead>
														$dhval
													</thead>
													<tbody id='myTable1'>
														$dval
													</tbody>
												</table>
											";
										}
										//
									?>
									
								</div>
							</div>
					

						</div>
					</div>

				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/vendor/chartist/js/chartist.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>
	<script>
	$(function() {
		var options;

		var data = {
			labels: ['5', '4', '3', '2', '1'],
			series: [{
				name: 'series-Eva1',
				data:[20, 40, 20, 15, 5], 
			
		},{
				name: 'series-Eva2',
				data:[25, 35, 25, 12, 3],
			}]
		};

		// bar chart
		options = {
			height: "300px",
			axisX: {
				showGrid: false
			},
		};

		new Chartist.Bar('#demo-bar-chart', data, options);


		var data2 = {
			labels: ['2015', '2016', '2017', '2018'],
			series: [{
				data:[4.0, 3.5, 4.2, 4.7],
			}
			
		]
		};

		// line chart
		options = {
			height: "300px",
			showPoint: true,
			axisX: {
				showGrid: false
			},
			lineSmooth: false,
		};

		new Chartist.Line('#demo-line-chart', data2, options);
		
		
		

		// area chart
		options = {
			height: "270px",
			showArea: true,
			showLine: false,
			showPoint: false,
			axisX: {
				showGrid: false
			},
			lineSmooth: false,
		};

		new Chartist.Line('#demo-area-chart', data, options);


		// multiple chart
		var data = {
			labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
			series: [{
				name: 'series-real',
				data: [200, 380, 350, 320, 410, 450, 570, 400, 555, 620, 750, 900],
			}, {
				name: 'series-projection',
				data: [240, 350, 360, 380, 400, 450, 480, 523, 555, 600, 700, 800],
			}]
		};

		var options = {
			fullWidth: true,
			lineSmooth: false,
			height: "270px",
			low: 0,
			high: 'auto',
			series: {
				'series-projection': {
					showArea: true,
					showPoint: false,
					showLine: false
				},
			},
			axisX: {
				showGrid: false,

			},
			axisY: {
				showGrid: false,
				onlyInteger: true,
				offset: 0,
			},
			chartPadding: {
				left: 20,
				right: 20
			}
		};

		new Chartist.Line('#multiple-chart', data, options);

	});
	</script>
	<script >
	$(document).ready(function(){
	  $("#myInput1").on("keyup", function() {
	    var value = $(this).val().toLowerCase();
	    $("#myTable1 tr").filter(function() {
	      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
	    });
	  });
	});
	</script>

	
<?php
	include "./parts/btm_script.php";
?>

</body>

</html>
