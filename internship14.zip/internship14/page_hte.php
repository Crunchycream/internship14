<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); //include "./parts/sys_functions.php";
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$_SESSION['intern_page_current'] = "page_hte";
		include "./parts/main_logcheck.php";
		include "./parts/page_profile_hte_upload.php";
	//
	include "./parts/sys_hte_raterank_updater.php";
		//
	if ( trim($logun)=="" ) {
		exit;
	}
?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>

    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
    </style>

	<script type="text/javascript">
		setInterval('my_function();',5000);
	    function my_function(){
	      $('#up_new_jobpost').load(location.href + ' #up_new_jobpost_s');
	    }

	    function detectScrollbar()
		{
			if (navigator.appName == "Microsoft Internet Explorer")
			{
				window.name=document.body.scrollTop;
			}
			else
			{
				window.name=window.pageYOffset;
			}
		}

		function doScroll()
		{
			if (window.name) window.scrollTo(0, window.name);
		}


	</script>

</head>

<body onload="doScroll()" onunload="window.name=document.body.scrollTop" >
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
	<?php include "./parts/page_profile_hte_modal.php"; ?>
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-8">
							<!-- LEFT COLUMN -->
						<div class="panel">
						<?php include "./data/connect.php";
							//
							$logun = $_SESSION['intern_data_cun'];
							$logutype = $_SESSION['intern_data_utype'];
							//
							$cc = 0;
							if ( strtolower(trim($logutype))==strtolower(trim("employee")) ) {
								//GET MEMBER HTE
								$sql1 = " select hte_staff_id,hte_id,staff_id,staff_type from tbl_hte_staff  where staff_id='$logun' and staff_type='$logutype' ";
								$qry1 = mysqli_query($conn,$sql1);
								while($dat1=mysqli_fetch_array($qry1)) {
									$cc += 1;
								}
							}
							if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
								//$cc = 1;
							}
							if ( $cc > 0 ) {
								echo "
											<div class='dropdown'>
											  <button class='btn btn-primary dropdown-toggle btnprof_menu01' type='button' data-toggle='dropdown'>&equiv;</button>
											  <ul class='dropdown-menu'>
											    <li><a  data-toggle='modal' data-target='#modalChangeCoverPhoto' href='' class=''>Update Cover Photo</a></li>
											    <li><a  data-toggle='modal' data-target='#modalUpdateMapInfo' href='' class=''>Update Map Location</a></li>
											  </ul>
											</div>
								";
							}
						?>
							<div class="">
								<!-- PROFILE HEADER -->
								<div class="profile-header">
									<div class="overlay"></div>
									
											<?php include "./data/connect.php";
												$id = $_GET['id'];
												$sql = " select hte_id,dsn,name,address,prof_backimg from tbl_hte where hte_id='$id' ";
												$qry = mysqli_query($conn,$sql);
												$ttl = "";
												$backimg = "";
												while($dat=mysqli_fetch_array($qry)) {
													$ttl = trim($dat[2]);
													$backimg = trim($dat[4]);
												}
												if ( trim($backimg) == "" ) {
													$backimg = "assets/img/profile-bg.png";
												}
												echo "
													<div class='profile-main' style='background:url($backimg) no-repeat; background-size: 100%;'>
													<br/>
													<br/>
													<br/>
													<br/>
													<h3 class='name'>
													<span class='span02'>$ttl</span>
													</h3>
													</div>
												";
											?>
										
									<div class="profile-stat2">
										<div class="row">
											<?php include "./data/connect.php";
												//
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
												//
												//
												$id = $_GET['id'];
												//
												$sy = trim($_SESSION['intern_data_active_sy']);
												//
												$cid = $_GET['id'];
												//
												//
												$value1 = getCountHTEInterns2($id);
												$count = "0";
												//
												$nn = 0;
												$nn = getHTEJobCount($id);
												//
												//
												$sql = " select hte_id,total_rate from tbl_hte_raterank  where sy='$sy' and hte_id='$cid'  order by total_rate desc ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$count = $dat[1];
												}
												//
												$cd = explode(".", trim($count));
												$c1 = $cd[0];
												$c2 = "0";
												if ( strval($cd[1])>0 ) {
													$c2 = substr(trim($cd[1]), 0,1);
												}
												//
												$fc = $c1 . "." . $c2;
												//
												//
												$derr = 0;
												//
												if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
													$derr += 1;
												}
												//
												if ( $derr <= 0 ) {
													echo "
															<div class='col-md-4 stat-item'>
																$value1 <span>Interns</span>
															</div>

															<div class='col-md-4 stat-item'>
																<a class='prof_name_link01' href='#tab-bottom-stats' role='tab' data-toggle='tab'>$fc <span>Rating</span></a>
															</div>

															<div class='col-md-4 stat-item'>
																$nn <span>Jobs</span>
															</div>
														";
												}
												//
											?>

										</div>
									</div>
								</div>

					<!-- === EVALUATE ======================= -->
							<?php include "./data/connect.php";
								$memid =  $_SESSION['intern_data_cun'];
								$memtype = $_SESSION['intern_data_utype'];
								//
								$hteid = $_GET['id'];
								//
								$cn = 0;
								//
									$sql = " select * from tbl_hte_rating where member_id='$memid' and hte_id='$hteid' ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										$cn = $cn + 1;
									}
								//
								if ( 
									strtolower(trim($memtype))==strtolower(trim("student")) && 
									$cn <= 0 &&
									strtolower(trim($memtype))==strtolower(trim("admin"))
									) {
									/*
									echo "

										<div class='panel' align='center'>
											<br/>
											<span class='font01'>You haven't evaluated yet. </span>
											<a href='' data-toggle='modal' data-target='#modalAddRating' class='btn btn-success btn-lg'>Evaluate Now!</a> 
											<span class='font01'></span>
											<br/>
											<br/>
										</div>

									";
									*/
									//
									//
									//
								}
							?>
					<!-- === EVALUATE ======================= -->

							</div>
						</div>
		<!-- ===== LEFT LOWER ==================================================== -->
				<?php include "./data/connect.php";
					//
					$logun = $_SESSION['intern_data_cun'];
					$logutype = $_SESSION['intern_data_utype'];
					//
					//
					$derr = 0;
					//
					if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
						$derr += 1;
					}
					//
					if ( $derr <= 0 ) {
						//
						echo "
							<div class='custom-tabs-line tabs-line-bottom left-aligned'>
								<ul class='nav' role='tablist'>
									<li class=''><a href='#tab-bottom-announcement' role='tab' data-toggle='tab'>Announcement</a></li>
									<li class='active'><a href='#tab-bottom-stats' role='tab' data-toggle='tab'>Statistics</a></li>
									<li class=''><a href='#tab-bottom-map' role='tab' data-toggle='tab'>Map</a></li>
								</ul>
							</div>
						";
						//
						echo "
							<div class='tab-content'>
						";
						echo "
								<div class='tab-pane fade in' id='tab-bottom-announcement'>
						";
						//
						//
									//
									//
									$id = $_GET['id'];
									$idtype = "hte";
									//
									echo "<ul class='ul01'>";
									//
									//LOAD AVAILABLE
									$nn = 0;
									$nid = "";
									//                      0         1      2       3      4      5      6      7    8
									$sql = " select announcement_id,ann_id,ann_type,by_id,by_type,pdate,subject,msg,cfile from tbl_announcement  where ann_id='$id' and ann_type='$idtype'  order by pdate desc ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										if ( trim($dat[7])!=="" || trim($dat[8])!="" ) {
											$nn = $nn + 1;
											//
											$nid = trim($dat[0]);
											//
											//FILE
											$pfile = "";
											$fln = trim($dat[8]);
											//
											$dfn = "File";
											$dfnx = "";
											//
											//
											if ( trim($fln)!="" ) {
												$dfnx = "." . trim(pathinfo($fln,PATHINFO_EXTENSION));
												if ( trim($dat[6])=="" ) {
													$dfn = "File";
												}else{
													$dfn = trim($dat[6]);
												}
												//
												if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
													  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
													  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
													  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
													  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
													) {
													$pfile = "<p align='center'>
																	<a href='#' class='ann_lnkprev01' data-toggle='modal' data-target='#modalPrevImage_$nn'>
																<img class='ann_img01' src='".trim($dat[8])."'/>
																	</a>
																<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																	<img class='ann_img02' src='".trim($dat[8])."'/>
																</div>
															  </p>";
												}else{
													$pfile = "<p align='left'><a href='".trim($dat[8])."' target='_blank'>".trim($dfn).trim($dfnx)."</a></p>";
												}
											}
											//
											$memid = "";
											$memname = "";
											$img = "";
											$link = "";
											//GET MEMBER NAME
											if ( strtolower(trim($dat[4]))==strtolower(trim("student")) ) {
												$sql1 = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns  where studentid='$dat[3]'  ";
												$qry1 = mysqli_query($conn,$sql1);
												while($dat1=mysqli_fetch_array($qry1)) {
													if ( trim($dat1[0]) != "" ) {
														$mname = "";
														if ( trim($dat1[2])!="" ) {
															$mname = " " . trim($dat1[2]);
														}
														$memid = trim($dat1[0]);
														$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
														//
														$img = trim($dat1[4]);
														//
														$link = "./page_profile.php?id=".trim($dat1[0]);
													}
												}
											}
											if ( strtolower(trim($dat[4]))==strtolower(trim("employee")) ) {
												$sql1 = " select employee_id,firstname,middlename,lastname,prof_img from tbl_employee  where employee_id='$dat[3]'  ";
												$qry1 = mysqli_query($conn,$sql1);
												while($dat1=mysqli_fetch_array($qry1)) {
													if ( trim($dat1[0]) != "" ) {
														$mname = "";
														if ( trim($dat1[2])!="" ) {
															$mname = " " . trim($dat1[2]);
														}
														$memid = trim($dat1[0]);
														$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
														//
														$img = trim($dat1[4]);
														//
														$link = "./page_profile_employee.php?id=".trim($dat1[0]);
													}
												}
											}
											if ( strtolower(trim($dat[4]))==strtolower(trim("admin")) ) {
												$memid = "Admin";
												$memname = "Admin";
												$img = "";
												//
												$link = "#";
											}
											//
											if ( trim($img)=="" ) {
												$img = "./assets/img/empty_user.png";
											}
											//
											//
											$frmedit = "";
											$ern = 0;
											//
											if ( trim($logun)=="" ) {
												$ern += 1;
											}
											if ( strtolower(trim($loguntype))==strtolower(trim("student")) ) {
												$ern += 1;
											}
											if ( strtolower(trim($loguntype))==strtolower(trim("coordinator")) ||
												 strtolower(trim($loguntype))==strtolower(trim("employee")) ) {
												if ( strtolower(trim($loguntype))!=strtolower(trim($dat[3])) && strtolower(trim($logun))!=strtolower(trim($dat[4])) ) {
													$ern += 1;
												}
											}
											//
											if ( $ern <= 0 ) {
												$frmedit = "

																			<div class='dropdown'>
																			  <a class='btn_action_01' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																			  <ul class='dropdown-menu'>
																			    <li><a href='#' data-toggle='modal' data-target='#modalEdit_$nid'>Edit</a></li>
																			    <li><a href='#' data-toggle='modal' data-target='#modalDelete_$nid'>Delete</a></li>
																			  </ul>
																			</div>

																			    <div id='modalEdit_$nid' class='modal fade' role='dialog'>
																			      <div class='modal-dialog'>
																			      <!-- Modal content-->
																			      <div class='modal-content'>
																			      <div class='modal-header' align='left'>
																			        <button type='button' class='close' data-dismiss='modal'>&times;</button>
																			        <h4 class='modal-title'>Update</h4>
																			      </div>
																			          <form method='post' action='' enctype='multipart/form-data'>
																			      <div class='modal-body' align='left'>
																			        <p align='left'>
																								<input type='hidden' name='txtid' value='$dat[0]'/>

																						<div class='form-group div01'>
																							<label for='subject' class='control-label sr-only'>Subject</label>
																							<input type='text' name='txtsubject' class='form-control txt01' id='subject' placeholder='Subject'
																								 value='$dat[6]' 
																							>
																						</div>
																						<div class='form-group div01'>
																							<label for='msg' class='control-label sr-only'>Message</label>
																							<textarea name='txtmsg' class='form-control txta01' id='msg' placeholder='Message'>$dat[7]</textarea>
																						</div>
																						<div class='form-group div01'>
																							Attach file:
																							<label for='fileUP' class='control-label sr-only'>Attach File</label>
																							<input type='file' name='fileUP' id='fileUP' placeholder='Attach File'>
																						</div>

																			        </p>
																			      </div>
																			      <div class='modal-footer'>
																			        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																			        <input type='submit' name='btnsaveEdit' class='btn btn-primary btn-md btn01' value='SAVE'>
																			      </div>
																			          </form>
																			      </div>

																			      </div>
																			    </div>

																					<div id='modalDelete_$nid' class='modal fade' role='dialog'>
																						<div class='modal-dialog'>
																						<!-- Modal content-->
																						<div class='modal-content'>
																						<div class='modal-header' align='left'>
																							<button type='button' class='close' data-dismiss='modal'>&times;</button>
																							<h4 class='modal-title'>Delete</h4>
																						</div>
																								<form method='post' action='' enctype='multipart/form-data'>
																						<div class='modal-body' align='left'>
																							<p align='left'>
																								<input type='hidden' name='txtid' value='$dat[0]'/>
																								Delete announcement?
																							</p>
																						</div>
																						<div class='modal-footer'>
																							<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																							<input type='submit' name='btnsaveDelete' class='btn btn-primary btn-md btn01' value='DELETE'>
																						</div>
																								</form>
																						</div>

																						</div>
																					</div>

												";
											}
											//
											//
											echo "
													<li>
														<div class='panel panel-default uldiv01' align='left'>
															<div class='uldiv01'>
																<table class='' width='100%'>
																	<tr>
																		<td class='ann_td01_1'>
																			<img src='$img' class='ann_img03' />
																		</td>
																		<td class='ann_td01_2'>
																			<div class='div_ann_name01'>
																				<a href='$link' class='ann_link01'>$memname</a>
																				<br/>
																				<span class='pst_date_01'>$dat[5]</span>
																			</div>
																		</td>
																		<td class='ann_td01_3'>
																			
																			$frmedit

																		</td>
																	</tr>
																</table>
																<hr class='hr02'/>
																<div class='div_ann_msg01'>
																	$dat[7]
																</div>
																<div class='div_ann_msg02'>
																	$pfile
																</div>
															</div>
														</div>
													</li>
											";
										}
									}
									//
									echo "</ul>";
									//
							echo "
								</div>
							";
							//
							//
							echo "
								<div class='tab-pane fade in active' id='tab-bottom-stats'>
									<div class='panel panel-default uldiv01' align='center'>
										<div class='table-responsive'>
											<div align='left'>
												<h4>The Supervisor:</h4>
											</div>
											<div id='stat-bar-chart1' class='ct-chart chart_03'></div>
											<br/>
											<div align='left'>
												<h4>The company OJT Designated Facilities/Laboratories/Offices/Work Stations:</h4>
											</div>
											<div id='stat-bar-chart2' class='ct-chart chart_03'></div>
											<br/>
											<div align='left'>
												<h4>The Company:</h4>
											</div>
											<div id='stat-bar-chart3' class='ct-chart chart_03'></div>
										</div>
							";
							//
								//
								//COMMENTS
								//
								$comm = "";
								//
								$nn = 0;
								//                 0         1           2
								$sql = " select comments,evaluator_id,evaluator_type from tbl_hte_eval2 where hte_id='$cid'  order by hte_eval_id desc  ";
								$qry = mysqli_query($conn,$sql);
								while($dat=mysqli_fetch_array($qry)) {
									if ( trim($dat[0])!="" ) {
										$nn += 1;
										//
										//
											//
											$memid = "";
											$memname = "";
											$img = "";
											$link = "";
											//GET MEMBER NAME
											if ( strtolower(trim($dat[2]))==strtolower(trim("student")) ) {
												$sql1 = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns  where studentid='$dat[1]'  ";
												$qry1 = mysqli_query($conn,$sql1);
												while($dat1=mysqli_fetch_array($qry1)) {
													if ( trim($dat1[0]) != "" ) {
														$mname = "";
														if ( trim($dat1[2])!="" ) {
															$mname = " " . trim($dat1[2]);
														}
														$memid = trim($dat1[0]);
														$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
														//
														$img = trim($dat1[4]);
														//
														$link = "./page_profile.php?id=".trim($dat1[0]);
													}
												}
											}
											if ( strtolower(trim($dat[2]))==strtolower(trim("employee")) ) {
												$sql1 = " select employee_id,firstname,middlename,lastname,prof_img from tbl_employee  where employee_id='$dat[1]'  ";
												$qry1 = mysqli_query($conn,$sql1);
												while($dat1=mysqli_fetch_array($qry1)) {
													if ( trim($dat1[0]) != "" ) {
														$mname = "";
														if ( trim($dat1[2])!="" ) {
															$mname = " " . trim($dat1[2]);
														}
														$memid = trim($dat1[0]);
														$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
														//
														$img = trim($dat1[4]);
														//
														$link = "./page_profile_employee.php?id=".trim($dat1[0]);
													}
												}
											}
											if ( strtolower(trim($dat[2]))==strtolower(trim("admin")) ) {
												$memid = "Admin";
												$memname = "Admin";
												$img = "";
												//
												$link = "#";
											}
											//
											if ( trim($img)=="" ) {
												$img = "./assets/img/empty_user.png";
											}
										//
										//
										if ( $nn > 1 ) {
											$comm = $comm . "
												<hr class='hr01' />
											";
										}
										//
										$comm = $comm . "
											<div class='evaldiv01'>
												<img class='evalimg01' src='$img' /> <a class='evalname01' href='$link'>$memname</a>: 
												<br/>
												<span class='evalcomm01'>
													$dat[0]
												</span>
											</div>
										";
									}
								}
								if ( trim($comm)!="" ) {
									echo "
										<br/>
										<br/>
										<div align='left'>
											<h4>Comments:</h4>
										</div>
										<hr/>
										<br/>
										<div align='left'>
											$comm
										</div>
									";
								}
							//
							echo "
									<br/>
									</div>
							";
							echo "
								</div>
							";
							//
							$cuid = trim($_GET['id']);
							//
							echo "
								<div class='tab-pane fade in' id='tab-bottom-map'>
									<div class='panel panel-default uldiv01' align='center'>
										<div id='map'></div>

										<iframe class='map_s01' src='./smap.php?id=$cuid' frameborder='0'></iframe>

									</div>
								</div>
							";
						//
						//
						echo "
							</div>
						";
						//
					}

				?>

					</div>
		<!-- ===== LEFT LOWER ==================================================== -->
							<!-- END LEFT COLUMN -->
						


					<div class="row">
						<div class="col-md-4">
							<!-- RIGHT COLUMN -->
							<div class="panel ann_divr02">
								<div class="tab-content divclass03">
									<?php include "./data/connect.php";
										$curid = $_SESSION['intern_data_cun'];
										$curidtype = $_SESSION['intern_data_utype'];
										//
										//
											$cc = 0;
											$cc2 = 0;
										//
											//echo "<a href='' data-target='#modalHTEEval' class='btn btn-danger btn-lg' data-toggle='modal'>Evaluate</a> ";
										if ( 
											strtolower(trim($curidtype))==strtolower(trim("student"))||
											strtolower(trim($curidtype))==strtolower(trim("admin")) ||
											strtolower(trim($curidtype))==strtolower(trim("employee")) 
											) {
											//echo "<a href='' data-target='#modalHTEEval3' class='btn btn-danger btn-lg btn-block' data-toggle='modal'>Evaluate</a> ";
										}
										//
										//
										if ( strtolower(trim($curidtype))==strtolower(trim("student")) ) {
											//
											//GET MEMBER HTE
											$sql1 = " select member_id from tbl_hte_members  where member_id='$curid' ";
											$qry1 = mysqli_query($conn,$sql1);
											while($dat1=mysqli_fetch_array($qry1)) {
												$cc2 += 1;
											}
										}
										//
										if ( strtolower(trim($curidtype))==strtolower(trim("employee")) ) {
											//
											//GET MEMBER HTE
											$sql1 = " select hte_staff_id,hte_id,staff_id,staff_type from tbl_hte_staff  where staff_id='$curid' and staff_type='$curidtype' ";
											$qry1 = mysqli_query($conn,$sql1);
											while($dat1=mysqli_fetch_array($qry1)) {
												$cc += 1;
											}
										}
										//
										//
										if ( $cc2 > 0 ) {
											echo "<a href='' data-target='#modalHTEEval3' class='btn btn-danger btn-lg btn-block' data-toggle='modal'>Evaluate</a> ";
										}
										//
										if ( $cc > 0 ) {
											echo "<br/><br/><a href='' data-target='#modalHTEEvalCriteria' class='btn btn-link btn-sm' data-toggle='modal'>Manage Evaluation Criteria</a> ";
											echo "<br/>";
											echo "<br/>";
											echo "<a href='' data-target='#modalAddJobs' class='btn btn-success btn-sm' data-toggle='modal'>+ Add Jobs</a> ";
											echo "<a href='' data-target='#modalAddInterns' class='btn btn-success btn-sm' data-toggle='modal'>+ Add Interns</a> ";
											echo "<br/>";
										}
										//
									?>
								</div>
								<div class="custom-tabs-line tabs-line-bottom left-aligned divclass03">
									 <a href="#divJobs" class="linkclass01" data-toggle="collapse">JOBS 
									<span class="badge">
										<?php include "./data/connect.php";
											$id = $_GET['id'];
											$nn = 0;
											$nn = getHTEJobCount($id);
											echo "$nn";
										?>
									</span>
									</a>
								</div>
								<div class="tab-content divclass01">
									<div class="collapse divclass02 fade in active" id="divJobs">
										<?php include "./data/connect.php";
											$id = $_GET['id'];
											//
												$curid = $_SESSION['intern_data_cun'];
												$curidtype = $_SESSION['intern_data_utype'];
											//LOAD AVAILABLE
											$nn = 0;
											//                  0        1      2       3          
											$sql = " select hte_job_id,hte_id,name,description from tbl_hte_jobs  where hte_id='$id' order by name asc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[1]) != "" ) {
													$nn = $nn + 1;
													if ( $nn > 1 ) {
														//echo "<br/>";
													}
													//
													$nid = trim($dat[0]);
													//
													$topt = "";
													if ( strtolower(trim($curidtype))!=strtolower(trim("student")) ) {
														$topt = "
															  <ul class='dropdown-menu'>
															    <li><a href='#' data-toggle='modal' data-target='#modalJobEdit_$nid'>Edit</a></li>
															    <li><a href='#' data-toggle='modal' data-target='#modalJobDelete_$nid'>Delete</a></li>
															  </ul>
														";
													}
													//
													echo "

													<div class='dropdown divclasscont01'>
														<a href='#' data-toggle='dropdown'>
														<span class='fontclasscont01 span02'>".trim($dat[2])."</span>
														</a>
														$topt
													</div>

														<div id='modalJobEdit_$nid' class='modal fade' role='dialog'>
															<div class='modal-dialog'>
															<!-- Modal content-->
															<div class='modal-content'>
															<div class='modal-header'>
																<button type='button' class='close' data-dismiss='modal'>&times;</button>
																<h4 class='modal-title'>Add Jobs</h4>
															</div>
																	<form action='' method='post'>
															<div class='modal-body'>
																<p>
																	<input type='hidden' name='txtid' value='$dat[0]'/>
																	<div class='form-group'>
																		
																	</div>
																	<div class='form-group div01'>
																		<label for='stud-add-name' class='control-label sr-only'>Job Name</label>
																		<input type='text' name='jobname' class='form-control txt01' id='stud-add-name' placeholder='Job Name'
																			 value='$dat[2]' 
																		>
																	</div>
																	<div class='form-group div01'>
																		<label for='stud-add-desc' class='control-label sr-only'>Job Description</label>
																		<textarea name='jobdesc' class='form-control txt01' id='stud-add-desc' placeholder='Job Description'>$dat[3]</textarea>
																	</div>
																</p>
															</div>
															<div class='modal-footer'>
																<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																<input type='submit' class='btn btn-primary' value='Save' name='btnsaveJobEdit'>
															</div>
																	</form>
															</div>

															</div>
														</div>

														<div id='modalJobDelete_$nid' class='modal fade' role='dialog'>
															<div class='modal-dialog'>
															<!-- Modal content-->
															<div class='modal-content'>
															<div class='modal-header'>
																<button type='button' class='close' data-dismiss='modal'>&times;</button>
																<h4 class='modal-title'>Delete Job</h4>
															</div>
																	<form method='post' action=''>
															<div class='modal-body'>
																<p>
																	<input type='hidden' name='txtid' value='$dat[0]'/>
																	Delete job?
																</p>
															</div>
															<div class='modal-footer'>
																<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																<input type='submit' name='btnsaveJobDelete' class='btn btn-primary btn-lg btn01' value='DELETE'>
															</div>
																	</form>
															</div>

															</div>
														</div>

													";
												}
											}
										?>
									</div>
								</div>

								<div class="custom-tabs-line tabs-line-bottom left-aligned divclass03">
									 <a href="#divInterns" class="linkclass01" data-toggle="collapse">INTERNS 
									<span class="badge"><?php $id = $_GET['id']; echo getCountHTEInterns2($id); ?></span>
									</a>
								</div>
								<div class="tab-content divclass01">
									<div class="collapse divclass02 fade in active" id="divInterns">
										<?php include "./data/connect.php";
											$id = $_GET['id'];
											//LOAD AVAILABLE
											$nn = 0;
											//                   0       1       2        3
											$sql = " select hte_mem_id,hte_id,member_id,jobs from tbl_hte_members  where hte_id='$id' ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[1]) != "" ) {
													$nn = $nn + 1;
													if ( $nn > 1 ) {
														//echo "<br/>";
													}
													$memid = "";
													$memname = "";
													$img = "";
													//
													$jobids = trim($dat[3]);
													$joblist = "";
													//
													if ( trim($jobids)!="" ) {
														//GET JOB NAME
														$cd = explode(";", trim($jobids));
														//
														for ( $i=0 ; $i < count($cd) ; $i++ ) {
															//
															//                   0        1     2     3
															$sql1 = " select hte_job_id,hte_id,name,description from tbl_hte_jobs  where hte_job_id='$cd[$i]'  ";
															$qry1 = mysqli_query($conn,$sql1);
															while($dat1=mysqli_fetch_array($qry1)) {
																if ( trim($dat1[2]) != "" ) {
																	if ( trim($joblist)=="" ) {
																		$joblist = "" . trim($dat1[2]);
																	}else{
																		$joblist = $joblist . ", " . trim($dat1[2]);
																	}
																}
															}
															//
														}
														//
														if ( trim($joblist)!="" ) {
															$joblist = "<span class='jobsapp01'>(Job: <span class='span02'>" . trim($joblist) . "</span>)</span>";
														}
														//
													}
													//
													//GET MEMBER NAME
													$sql1 = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns  where studentid='$dat[2]' ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														if ( trim($dat1[0]) != "" ) {
															$mname = "";
															if ( trim($dat1[2])!="" ) {
																$mname = " " . trim($dat1[2]);
															}
															$memid = trim($dat1[0]);
															$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
															//
															$img = trim($dat1[4]);
														}
													}
													//
													if ( trim($img)=="" ) {
														$img = "./assets/img/empty_user.png";
													}
													//
													$nid = trim($dat[0]);
													//
													echo "

													<div class='dropdown divclasscont01'>
														<a href='#' data-toggle='dropdown'>
														<img src='$img' class='msgnotif_img03' />
														<span class='fontclasscont01 span02'>".trim($memname)."</span>
														</a>
														  $joblist
														  <ul class='dropdown-menu'>
														    
														    <li><a href='#' data-toggle='modal' data-target='#modalInternSendMessage_$nid'>Send Message</a></li>
														  </ul>
													</div>

														<div id='modalInternSendMessage_$nid' class='modal fade' role='dialog'>
															<div class='modal-dialog'>
															<!-- Modal content-->
															<div class='modal-content'>
															<div class='modal-header'>
																<button type='button' class='close' data-dismiss='modal'>&times;</button>
																<h4 class='modal-title'>Send Message to '<span class='span02'>".trim($memname)."</span>'</h4>
															</div>
																	<form action='' method='post'>
															<div class='modal-body'>
																<p>
																	<input type='hidden' name='txtstudid' value='$memid'/>
																	<input type='hidden' name='txtstudtype' value='student'/>
																	<div class='form-group'>
																		
																	</div>
																	<div class='form-group div01'>
																		<label for='send-msg-msg' class='control-label sr-only'>Message</label>
																		<textarea name='msg' class='form-control txt01' id='send-msg-msg' placeholder='Message'></textarea>
																	</div>
																</p>
															</div>
															<div class='modal-footer'>
																<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																<input type='submit' class='btn btn-primary' value='Send' name='btnsaveInternSendMessage'>
															</div>
																	</form>
															</div>

															</div>
														</div>

													";
												}
											}
										?>
									</div>
								</div>

								<div class="custom-tabs-line tabs-line-bottom left-aligned divclass03">
									 <a href="#divStaffs" class="linkclass01" data-toggle="collapse">STAFFS 
									<span class="badge"><?php $id = $_GET['id']; echo getCountHTEStaffs2($id); ?></span>
									</a>
								</div>
								<div class="tab-content divclass01">
									<div class="collapse divclass02 fade in active" id="divStaffs">
										<?php include "./data/connect.php";
											$id = $_GET['id'];
											//LOAD AVAILABLE
											//
											//
											$logun =  $_SESSION['intern_data_cun'];
											$logutype = $_SESSION['intern_data_utype'];
											//
											//
											$xqry = "";
											//
											//                  0           1         2         3     4
											$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff where hte_id<>'' and hte_id='$id' and staff_id<>'' and staff_type='employee'  ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($xqry)=="" ) {
													$xqry = " where employee_id<>'$dat[2]' ";
												}else{
													$xqry = $xqry . " and employee_id<>'$dat[2]' ";
												}
											}
											//
											//LOAD AVAIL. EMPLOYEE
											$staffs = "";
											//                  0     1         2         3    
											$sql = " select employee_id,lastname,firstname,middlename from tbl_employee $xqry  order by lastname asc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												$name = "";
												//
												$name = trim($dat[1]) . ", " . trim($dat[2]) . " " . trim($dat[3]);
												//
												$staffs = $staffs . "<option value='$dat[0]'>$name</option>";
											}
											//
											//
											if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
												echo "
													<a href='#' class='btn btn-success btn-sm btn-block' data-toggle='modal' data-target='#modalAddStaff'>ADD STAFFS</a>

														<div id='modalAddStaff' class='modal fade' role='dialog'>
															<div class='modal-dialog'>
															<!-- Modal content-->
															<div class='modal-content'>
															<div class='modal-header'>
																<button type='button' class='close' data-dismiss='modal'>&times;</button>
																<h4 class='modal-title'>Add Staff</h4>
															</div>
																	<form action='' method='post'>
															<div class='modal-body'>
																<p>
																	
																	<div class='form-group div01'>
																		<b>Name:</b>
																		<select class='form-control' name='txtemployee'>
																			$staffs
																		</select>
																	</div>
																	<div class='form-group div01'>
																		<b>Position:</b>
																		<select class='form-control' name='txtposition'>
																			<option value='Supervisor'>Supervisor</option>
																		</select>
																	</div>
																</p>
															</div>
															<div class='modal-footer'>
																<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																<input type='submit' class='btn btn-primary' value='Save' name='btnsaveStaff'>
															</div>
																	</form>
															</div>

															</div>
														</div>

													";
											}
											//
											//
											$nn = 0;
											///\                  0         1     2        3          4
											$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff  where hte_id='$id' ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[1]) != "" ) {
													$nn = $nn + 1;
													if ( $nn > 1 ) {
														//echo "<br/>";
													}
													$memid = "";
													$memname = "";
													$img = "";
													//GET MEMBER NAME
													$sql1 = " select employee_id,firstname,middlename,lastname,prof_img from tbl_employee  where employee_id='$dat[2]' ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														if ( trim($dat1[0]) != "" ) {
															$mname = "";
															if ( trim($dat1[2])!="" ) {
																$mname = " " . trim($dat1[2]);
															}
															$memid = trim($dat1[0]);
															$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
															//
															$img = trim($dat1[4]);
														}
													}
													//
													if ( trim($img)=="" ) {
														$img = "./assets/img/empty_user.png";
													}
													//
													$nid = trim($dat[0]);
													//
													//
													$aopt = "";
													$aoptv = "";
													if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
														$aopt = "
															<li class='divider'></li>
															<li><a href='#' data-toggle='modal' data-target='#modalStaffRemove_$nid'>Remove Staff</a></li>

															";
														$aoptv = "

																<div id='modalStaffRemove_$nid' class='modal fade' role='dialog'>
																	<div class='modal-dialog'>
																	<!-- Modal content-->
																	<div class='modal-content'>
																	<div class='modal-header'>
																		<button type='button' class='close' data-dismiss='modal'>&times;</button>
																		<h4 class='modal-title'>Remove Staff</h4>
																	</div>
																			<form action='' method='post'>
																	<div class='modal-body'>
																		<p>
																		<input type='hidden' name='txtid' value='$nid' />

																			Remove Staff?

																		</p>
																	</div>
																	<div class='modal-footer'>
																		<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																		<input type='submit' class='btn btn-primary' value='Save' name='btnsaveStaffRemove'>
																	</div>
																			</form>
																	</div>

																	</div>
																</div>

															";
													}
													//
													//
													echo "

													<div class='dropdown divclasscont01'>
														<a href='#' data-toggle='dropdown'>
														<img src='$img' class='msgnotif_img03' />
														<span class='fontclasscont01 span02'>".trim($memname)." <br/>(" . trim($dat[4]) . ")"."</span>
														</a>
														  <ul class='dropdown-menu'>
														    <li><a href='./page_profile_employee.php?id=".trim($dat[2])."'>Profile</a></li>
														    <li><a href='#' data-toggle='modal' data-target='#modalInternSendMessage_$nid'>Send Message</a></li>
														    $aopt
														  </ul>
													</div>
														$aoptv
														<div id='modalInternSendMessage_$nid' class='modal fade' role='dialog'>
															<div class='modal-dialog'>
															<!-- Modal content-->
															<div class='modal-content'>
															<div class='modal-header'>
																<button type='button' class='close' data-dismiss='modal'>&times;</button>
																<h4 class='modal-title'>Send Message to '<span class='span02'>".trim($memname)."</span>'</h4>
															</div>
																	<form action='' method='post'>
															<div class='modal-body'>
																<p>
																	<input type='hidden' name='txtstudid' value='$memid'/>
																	<input type='hidden' name='txtstudtype' value='employee'/>
																	<div class='form-group'>
																		
																	</div>
																	<div class='form-group div01'>
																		<label for='send-msg-msg' class='control-label sr-only'>Message</label>
																		<textarea name='msg' class='form-control txt01' id='send-msg-msg' placeholder='Message'></textarea>
																	</div>
																</p>
															</div>
															<div class='modal-footer'>
																<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																<input type='submit' class='btn btn-primary' value='Send' name='btnsaveInternSendMessage'>
															</div>
																	</form>
															</div>

															</div>
														</div>

													";
												}
											}
										?>
									</div>
								</div>
								
							</div>
							<!-- END RIGHT COLUMN -->

							<div class="panel ann_divr02">
								<h4 class="heading">Info</h4>
								<!-- AWARDS -->
								<div class="">
									<div class="">

										<div class="">
											
										<?php
											include "./data/connect.php";
											//
											$cpid = $_GET['id'];
											$cuid =  $_SESSION['intern_data_cun'];
											$cutype = $_SESSION['intern_data_utype'];
											//
											$info = "";
											//                 0     1   2       3
											$sql = " select hte_id,name,address,info from tbl_hte  where hte_id='$cpid'  ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												$info = "
														<div class='table-responsive'>
															<table class='tbl_info01'>
																<tr>
																	<td>
																		Address:
																	</td>
																	<td>
																		$dat[2]
																	</td>
																</tr>
																<tr>
																	<td>
																		
																	</td>
																	<td>
																		$dat[3]
																	</td>
																</tr>
															</table>
														</div>
												";
											}
											echo "$info";
										?>

										</div>
										
									</div>
									
								</div>

								<br/>
								<br/>
								<!-- END AWARDS -->
								<!-- TABBED CONTENT -->
								<!-- END TABBED CONTENT -->
							</div>


						</div>

					</div>

					</div>

				</div>

			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<?php include "./parts/footer.php"; ?>
		<footer>
			<?php //include "./parts/footer.php"; ?>
		</footer>

		<?php
			//
			$id = $_GET['id'];
			$sy = trim($_SESSION['intern_data_active_sy']);
			//
			include "./data_eval_hte_frm2.php";
			//
		?>

	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>
	<script src="assets/vendor/chartist/js/chartist.min.js"></script>

	<script >
	$(document).ready(function(){
  $("#myInput1").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable1 tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

	</script>

	<script>

		 var count = 0;
		 var names = [];
		 var values = [];
		 //
		 var names1 = [];
		 var values1 = [];
		 //
		 var names2 = [];
		 var values2 = [];
		 //
		 var names3 = [];
		 var values3 = [];


		$(function() {

			//count = parseInt( document.getElementById('hte_eval_data_count').value );
			count = 22;

			var c1 = 0;
			var c2 = 0;
			var c3 = 0;


		 for ( var i = 0 ; i < count ; i++ ) {
		 	//
		 	names[i] = document.getElementById('eval_data_name_' + (i) ).value;
		 	values[i] = document.getElementById('eval_data_value_' + (i) ).value;
		 //alert(names[i] + " " + values[i]);
		 	//
		 	if ( i >= 0 && i < 8 ) {
		 		names1[c1] = names[i];
		 		values1[c1] = values[i];
		 		c1 += 1;
		 	}
		 	//
		 	if ( i >= 8 && i < 16 ) {
		 		names2[c2] = names[i];
		 		values2[c2] = values[i];
		 		c2 += 1;
		 	}
		 	//
		 	if ( i >= 16 && i < 22 ) {
		 		names3[c3] = names[i];
		 		values3[c3] = values[i];
		 		c3 += 1;
		 	}
		 	//
		 }
		 //alert(names[2]);

	    	var options;

			//
			//

			// bar chart
			options = {
				height: "240px",
				axisX: {
					showGrid: false
				},
			};

			//
			var data1 = {
				labels: names1,
				series: [
					{
						name: 'series-Eva1',
						data: values1,
					
					}
				]
			};
			new Chartist.Bar('#stat-bar-chart1', data1, options);
			//
			//
			var data2 = {
				labels: names2,
				series: [
					{
						name: 'series-Eva1',
						data: values2,
					
					}
				]
			};
			new Chartist.Bar('#stat-bar-chart2', data2, options);
			//
			//
			var data3 = {
				labels: names3,
				series: [
					{
						name: 'series-Eva1',
						data: values3,
					
					}
				]
			};
			new Chartist.Bar('#stat-bar-chart3', data3, options);
			//
			

		});

	</script>


<?php
	include "./parts/btm_script.php";
?>

</body>

</html>
