<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
	include "./sys_load_active_sy.php";
	//
	$_SESSION['intern_page_current'] = "index";
		include "./parts/main_logcheck.php";
	//
		include "./parts/sys_functions_sendmail.php";
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	//
	if ( $_POST['btnloginlostpass'] ) {
		//
		$_SESSION['intern_lpage_dtype'] = $utype;
		//
		echo "<META HTTP-EQUIV='Refresh' Content='0; URL=./index.php?page=lostpass'>";
		//
		exit;
	}
	//
	if ( $_POST['btnloginftas'] ) {
		$un = $_POST['username'];
		$up = $_POST['password'];
		$up2 = $_POST['password2'];
		//
		$ftadt = trim($_SESSION['intern_lpage_dtype']);
		//
		$utype = "";
		$cun = "";
		$dpn = "";
		$cdbpass = "";
		//
			$mc = 0;
		///
		$tsn = "";
		//
		$tsn = "student";
		if ( strtolower(trim($tsn))==strtolower(trim($ftadt)) ) {
			//CHECK IF ID REGISTERED
			$sql = " select studentid,username,password from tbl_interns  where studentid='$un' and reg_status='registered' ";
			$qry = mysqli_query($conn,$sql);
			$mc = 0;
			while($dat=mysqli_fetch_array($qry)) {
				$mc = $mc + 1;
				if ( trim($dat[2])!="" ) {

				}
			}
		}
		//
		$tsn = "employee";
		if ( strtolower(trim($tsn))==strtolower(trim($ftadt)) ) {
			//CHECK IF ID REGISTERED
			$sql = " select employee_id,username,password from tbl_employee  where employee_id='$un' ";
			$qry = mysqli_query($conn,$sql);
			$mc = 0;
			while($dat=mysqli_fetch_array($qry)) {
				$mc = $mc + 1;
				if ( trim($dat[2])!="" ) {

				}
			}
		}
		//
		//
		if ( $mc > 0 ) {
			//IS REG
			//CHECK IF PASS WORD MATCH
			if ( $up != "" ) {
				if ( $up == $up2 ) {
					//OK
					//
					$tsn = "student";
					if ( strtolower(trim($tsn))==strtolower(trim($ftadt)) ) {
						//SAVE
						$sql = " update tbl_interns  set  username='$un',password='$up'  where studentid='$un' ";
						$qry = mysqli_query($conn,$sql);
					}
					//
					$tsn = "employee";
					if ( strtolower(trim($tsn))==strtolower(trim($ftadt)) ) {
						//SAVE
						$sql = " update tbl_employee  set  username='$un',password='$up'  where employee_id='$un' ";
						$qry = mysqli_query($conn,$sql);
					}
					//
					$_SESSION['intern_lpage_page'] = "";
					$_SESSION['intern_lpage_dtype'] = "";
				}else{
					//NOT MATCHED
					$_SESSION['intern_lpage_page'] = "ftasetup";
					$_SESSION['intern_disp_err'] = "<span class='span01_error'>Passwords don't match.</span>";
				}
			}else{
					$_SESSION['intern_lpage_page'] = "ftasetup";
					$_SESSION['intern_disp_err'] = "<span class='span01_error'>Enter a password.</span>";
			}
		}else{
			//NO SUCH ID REG
			$_SESSION['intern_lpage_page'] = "ftasetup";
			$_SESSION['intern_disp_err'] = "<span class='span01_error'>ID is not registered.</span>";
		}
	}
	//
	if ( $_POST['btnloginlostpass'] ) {
		$un = $_POST['username'];
		$rmail = $_POST['rmail'];
		//
		//
		$ftadt = trim($_SESSION['intern_lpage_dtype']);
		if ( strtolower(trim($ftadt))==strtolower(trim("staff")) ) {
			$ftadt = "employee";
		}
		//
		$rpass = "";
		//
		$tsn = "";
		//
		$tsn = "student";
		if ( strtolower(trim($tsn))==strtolower(trim($ftadt)) ) {
			//CHECK IF ID REGISTERED
			$sql = " select password from tbl_interns  where studentid='$un' and email='$rmail' ";
			$qry = mysqli_query($conn,$sql);
			$mc = 0;
			while($dat=mysqli_fetch_array($qry)) {
				$mc = $mc + 1;
				//
				$rpass = $dat[0];
			}
		}
		//
		$tsn = "employee";
		if ( strtolower(trim($tsn))==strtolower(trim($ftadt)) ) {
			//CHECK IF ID REGISTERED
			$sql = " select password from tbl_employee  where employee_id='$un' and email='$rmail' ";
			$qry = mysqli_query($conn,$sql);
			$mc = 0;
			while($dat=mysqli_fetch_array($qry)) {
				$mc = $mc + 1;
				//
				$rpass = $dat[0];
			}
		}
		//
		//
		if ( $mc > 0 ) {
			//IS OK
			$to = trim($rmail);
			$subject = "Password Recovery";
			$msg = "Please use this password to login: " . $rpass;
			$header = "";
			sendMail($to,$subject,$msg,$header);
			//
			$_SESSION['intern_lpage_page'] = "";
			$_SESSION['intern_lpage_dtype'] = "";
			//
			echo "<META HTTP-EQUIV='Refresh' Content='0; URL=./index.php'>";
		}else{
			//NO SUCH ID REG
			$_SESSION['intern_lpage_page'] = "lostpass";
			$_SESSION['intern_disp_err'] = "<span class='span01_error'>Invalid ID or Email.</span>";
		}
	}
	//
	//
	if ( trim($logun)!="" ) {
		exit;
	}
?>
<!doctype html>
<html lang="en" class="fullscreen-bg">

<head>
	<title>Login | UMDC Internship Management</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>

</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<div class="vertical-align-wrap">
			<div class="vertical-align-middle">
				<div class="auth-box ">
					<div class="left">
						<div class="content">
							<?php
								$lpage = $_SESSION['intern_lpage_page'];
								//
								$lpage2 = trim($_GET['page']);
								//
								if ( strtolower(trim($lpage2))==strtolower(trim("")) && strtolower(trim($lpage2))==strtolower(trim("")) ) {
									if ( strtolower(trim($lpage))==strtolower(trim("")) || strtolower(trim($lpage))==strtolower(trim("login")) ) {
										include "./parts/login_form_main.php";
									}
									if ( strtolower(trim($lpage))==strtolower(trim("ftasetup")) ) {
										include "./parts/login_form_reg_ft.php";
									}
								}
								if ( strtolower(trim($lpage))==strtolower(trim("lostpass")) || strtolower(trim($lpage2))==strtolower(trim("lostpass")) ) {
									include "./parts/login_form_lostpass.php";
								}
								$_SESSION['intern_lpage_page'] = "";
							?>
						</div>
					</div>
					<div class="right">
						<div class="overlay"></div>
						<div class="content text">
							<h1 class="heading">University of Mindanao Internship Management</h1>
							<p></p>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>
	<!-- END WRAPPER -->
</body>

</html>
