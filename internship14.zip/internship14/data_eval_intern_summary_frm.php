<?php include "./data/connect.php";
	//
	$cid = trim($_GET['id']);
	$sy = trim($_SESSION['intern_data_active_sy']);
	//echo "$cid $sy";
	//
	$cname = array();
	$cval = array();
	$cvalcount = array();
	//
	$cn = 0;
	//
//=============================================================================
			$crit1_1 = 0;
			$crit1_2 = 0;
			$crit1_3 = 0;
			$crit1_4 = 0;
			$crit1_5 = 0;
			$crit1_6 = 0;
			$crit1_7 = 0;
			$crit1_8 = 0;
			$crit1_9 = 0;
			$crit1n = 0; // PILA KA STUDENT in 1 course
	//LOAD ALL COURSE
	$sql = " select course_id,course from tbl_course order by course asc ";
	$qry = mysqli_query($conn,$sql);
	while($dat=mysqli_fetch_array($qry)) {
		if ( trim($dat[0])!="" && trim($dat[1])!="" ) {
			$crsid = trim($dat[0]);
			//========================================================
			$crit1_1 = 0;
			$crit1_2 = 0;
			$crit1_3 = 0;
			$crit1_4 = 0;
			$crit1_5 = 0;
			$crit1_6 = 0;
			$crit1_7 = 0;
			$crit1_8 = 0;
			$crit1_9 = 0;
			$crit1n = 0; // PILA KA STUDENT in 1 course
			//GET STUDENT BY COURSE
			//                     0              1    2   3
			$sql1 = " select studentid,course from tbl_interns where course='$crsid'  order by lastname asc ";
			$qry1 = mysqli_query($conn,$sql1);
			while($dat1=mysqli_fetch_array($qry1)) {
				$studid = trim($dat1[0]);
				//========================================================
				$crit2_1 = 0;
				$crit2_2 = 0;
				$crit2_3 = 0;
				$crit2_4 = 0;
				$crit2_5 = 0;
				$crit2_6 = 0;
				$crit2_7 = 0;
				$crit2_8 = 0;
				$crit2_9 = 0;
				$crit2n = 0; //PILA KA DATA SA 1 STUDENT
				//GET INDIVIDUAL RATE
				//                     0             1          2           3            4          5            6               7         8        9
				$sql2 = " select studentid,professionalism,job_maturity,comm_skills,productivity,leadership,excellence,honesty_integrity,innovation,teamwork from tbl_interns_eval2  where studentid='$studid' and sy='$sy' ";
				$qry2 = mysqli_query($conn,$sql2);
				while($dat2=mysqli_fetch_array($qry2)) {
					//
					$crit2_1 = strval(trim($dat2[1]));
					$crit2_2 = strval(trim($dat2[2]));
					$crit2_3 = strval(trim($dat2[3]));
					$crit2_4 = strval(trim($dat2[4]));
					$crit2_5 = strval(trim($dat2[5]));
					$crit2_6 = strval(trim($dat2[6]));
					$crit2_7 = strval(trim($dat2[7]));
					$crit2_8 = strval(trim($dat2[8]));
					$crit2_9 = strval(trim($dat2[9]));
					//
					$crit2n += 1;
					//
				}
				//
				$upn = 0;
				//
				if ( $crit2_1>0 ){
					$crit2_1 = $crit2_1 / $crit2n;
					$upn += 1;
				}
				if ( $crit2_2>0 ){
					$crit2_2 = $crit2_2 / $crit2n;
					$upn += 1;
				}
				if ( $crit2_3>0 ){
					$crit2_3 = $crit2_3 / $crit2n;
					$upn += 1;
				}
				if ( $crit2_4>0 ){
					$crit2_4 = $crit2_4 / $crit2n;
					$upn += 1;
				}
				if ( $crit2_5>0 ){
					$crit2_5 = $crit2_5 / $crit2n;
					$upn += 1;
				}
				if ( $crit2_6>0 ){
					$crit2_6 = $crit2_6 / $crit2n;
					$upn += 1;
				}
				if ( $crit2_7>0 ){
					$crit2_7 = $crit2_7 / $crit2n;
					$upn += 1;
				}
				if ( $crit2_8>0 ){
					$crit2_8 = $crit2_8 / $crit2n;
					$upn += 1;
				}
				if ( $crit2_9>0 ){
					$crit2_9 = $crit2_9 / $crit2n;
					$upn += 1;
				}
				//
				$upn += 1;
				//
				if ( $upn > 0 ) {
					$crit1_1 += $crit2_1;
					$crit1_2 += $crit2_2;
					$crit1_3 += $crit2_3;
					$crit1_4 += $crit2_4;
					$crit1_5 += $crit2_5;
					$crit1_6 += $crit2_6;
					$crit1_7 += $crit2_7;
					$crit1_8 += $crit2_8;
					$crit1_9 += $crit2_9;
					$crit1n += 1;
				}
				//========================================================
			}
			//
			//
			if ( $crit1_1>0 ) {
				$crit1_1 = $crit1_1 / $crit1n;
			}
			if ( $crit1_2>0 ) {
				$crit1_2 = $crit1_2 / $crit1n;
			}
			if ( $crit1_3>0 ) {
				$crit1_3 = $crit1_3 / $crit1n;
			}
			if ( $crit1_4>0 ) {
				$crit1_4 = $crit1_4 / $crit1n;
			}
			if ( $crit1_5>0 ) {
				$crit1_5 = $crit1_5 / $crit1n;
			}
			if ( $crit1_6>0 ) {
				$crit1_6 = $crit1_6 / $crit1n;
			}
			if ( $crit1_7>0 ) {
				$crit1_7 = $crit1_7 / $crit1n;
			}
			if ( $crit1_8>0 ) {
				$crit1_8 = $crit1_8 / $crit1n;
			}
			if ( $crit1_9>0 ) {
				$crit1_9 = $crit1_9 / $crit1n;
			}
			//========================================================
			//
			$cval[0] = $crit1_1;
			$cval[1] = $crit1_2;
			$cval[2] = $crit1_3;
			$cval[3] = $crit1_4;
			$cval[4] = $crit1_5;
			$cval[5] = $crit1_6;
			$cval[6] = $crit1_7;
			$cval[7] = $crit1_8;
			$cval[8] = $crit1_9;
			//
			for ( $i=0 ; $i < 9 ; $i++ ) {
				echo "<input type='hidden' id='eval_sum_crs_data_value_".$cn."_".$i."' value='$cval[$i]' readonly='true' />";
			}
			//
			$cn += 1;
		}
	}
	//
	$cname[0] = "<b>Professionalism</b>";
	$cname[1] = "<b>Job maturity</b>";
	$cname[2] = "<b>Communication skills</b>";
	$cname[3] = "<b>Productivity</b>";
	$cname[4] = "<b>Leadership</b>";
	$cname[5] = "<b>Excellence</b>";
	$cname[6] = "<b>Honesty and integrity</b>";
	$cname[7] = "<b>Innovation</b>";
	$cname[8] = "<b>Teamwork</b>";
	//
	$cval[0] = $crit1_1;
	$cval[1] = $crit1_2;
	$cval[2] = $crit1_3;
	$cval[3] = $crit1_4;
	$cval[4] = $crit1_5;
	$cval[5] = $crit1_6;
	$cval[6] = $crit1_7;
	$cval[7] = $crit1_8;
	$cval[8] = $crit1_9;
	//
	for ( $i=0 ; $i < 9 ; $i++ ) {
		echo "<input type='hidden' id='eval_sum_crs_data_name_$i' value='$cname[$i]' readonly='true' />";
		echo "<input type='hidden' id='eval_sum_crs_data_count' value='$cn' readonly='true' />";
		//echo "<input type='' id='eval_sum_crs_data_value_$i' value='$cval[$i]' readonly='true' />";
	}
	//
	//
//=============================================================================
//
?>