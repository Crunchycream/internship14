<?php  session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$_SESSION['intern_page_current'] = "page_profile_employee";
		include "./parts/main_logcheck.php";
	//
	if ( trim($logun)=="" ) {
		exit;
	}
?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>

</head>

<body>
		<!---MODAL -->
	<?php include "./parts/page_profile_employee_modal.php"; ?>
	<?php include "./parts/page_profile_employee_upload.php"; ?>
		<!---END MODAL -->
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-7">
							<!-- LEFT COLUMN -->
							<div class="panel">
											<div class="dropdown divprof_menu01">
											  <button class="btn btn-primary dropdown-toggle btnprof_menu01" type="button" data-toggle="dropdown">&equiv;</button>
											  <ul class="dropdown-menu">
											    <li><a  data-toggle='modal' data-target='#modalChangePhoto' href='' class=''>Update Photo</a></li>
											    <li><a  data-toggle='modal' data-target='#modalChangeCoverPhoto' href='' class=''>Update Background Photo</a></li>
											  </ul>
											</div>
								<!-- PROFILE HEADER -->
								<div class="profile-header">
									<div class="overlay"></div>
									
										<?php include "./data/connect.php";
											$id = $_GET['id'];
											$sql = " select no,employee_id,firstname,middlename,lastname,prof_img,prof_backimg from tbl_employee where employee_id='$id' ";
											$qry = mysqli_query($conn,$sql);
											$ttl = "";
											$img = "";
											$backimg = "";
											while($dat=mysqli_fetch_array($qry)) {
												$ttl = trim($dat[2])." ".trim($dat[3])." ".trim($dat[4]);
												$img = trim($dat[5]);
												$backimg = trim($dat[6]);
											}
											if ( trim($img) == "" ) {
												$img = "assets/img/empty_user.png";
											}
											if ( trim($backimg) == "" ) {
												$backimg = "assets/img/profile-bg.png";
											}
											echo "
													<div class='profile-main' style='background:url($backimg) no-repeat; background-size: 100%;'>
													<br/>
													<img src='$img' class='img-circle img_prof_02' alt='Photo'>
													<h3 class='name'>
														<span class='span02'>$ttl</span>
													</h3>
													<span class='online-status status-available'>Available</span>

													</div>
												";
										?>
									
									<div class="profile-stat">
										<div class="row">
											<div class="col-md-4 stat-item">
												45 <span>Projects</span>
											</div>
											<div class="col-md-4 stat-item">
												15 <span>Awards</span>
											</div>
											<div class="col-md-4 stat-item">
												2174 <span>Points</span>
											</div>
										</div>
									</div>
								</div>
									<?php
										$cid = trim($_GET['id']);
										echo "

											<div align='right'>
												<a class='btn btn-success btn-sm' href='#' data-toggle='modal' data-target='#modalSendMessage'>Send Message</a>
											</div>

											<div id='modalSendMessage' class='modal fade' role='dialog'>
												<div class='modal-dialog'>
												<!-- Modal content-->
												<div class='modal-content'>
												<div class='modal-header'>
													<button type='button' class='close' data-dismiss='modal'>&times;</button>
													<h4 class='modal-title'>Send Message</h4>
												</div>
														<form action='' method='post'>
												<div class='modal-body'>
													<p>
														<input type='hidden' name='txtid' value='$cid'/>
														<input type='hidden' name='txttype' value='student'/>
														<div class='form-group'>
															
														</div>
														<div class='form-group div01'>
															<label for='send-msg-msg' class='control-label sr-only'>Message</label>
															<textarea name='msg' class='form-control txta01' id='send-msg-msg' placeholder='Message'></textarea>
														</div>
													</p>
												</div>
												<div class='modal-footer'>
													<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
													<input type='submit' class='btn btn-primary' value='Send' name='btnsaveSendMessage'>
												</div>
														</form>
												</div>

												</div>
											</div>

										";
									?>
								<!-- END PROFILE HEADER -->
								<!-- PROFILE DETAIL -->

					<!-- TABBED CONTENT -->
					<div class="custom-tabs-line tabs-line-bottom left-aligned">
						<ul class="nav" role="tablist">
							<li class="active"><a href="#tab-bottom-left1" role="tab" data-toggle="tab">Info</a></li>
							<li><a href="#tab-bottom-left2" role="tab" data-toggle="tab">Others</a></li>
						</ul>
					</div>
					<div class="tab-content">
						<div class="tab-pane fade in active" id="tab-bottom-left1">
							<div class="profile-pdf">

								<?php include "./data/connect.php";
									$sid = $_GET['id'];
									$req_resume = "";
									$fd = "";
									$tsn = "requirement:resume";
									$sql = " select no,employee_id,name,req_type,req_file,date_added from tbl_employee_requirements where employee_id='$sid' and req_type='$tsn' ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										if ( trim($dat[4]) != "" ){
											$req_resume = trim($dat[4]);
										}
									}
									if ( trim($req_resume)!="" && pathinfo($req_resume,PATHINFO_EXTENSION)=="pdf" ) {
										$fd = "
											<iframe src='$req_resume' width='100%' height='90%'>
											This browser does not support PDFs. Please download the PDF to view it: <a href='assets/pdf/resume.pdf'>Download PDF</a>
											</iframe>
										";
									}
									echo "$fd";
								?>

								
							</div>
						</div>
						<div class="tab-pane fade" id="tab-bottom-left2">
							
						</div>
					</div>
					<!-- END TABBED CONTENT -->

								
								<!-- END PROFILE DETAIL -->

							</div>
				<!-- END LEFT COLUMN -->
			</div>
			<div class="col-md-5">
				<!-- RIGHT COLUMN -->
							<div class="panel ann_divr02">
								<h4 class="heading">Requirements</h4>
								<!-- AWARDS -->
								<div class="awards">
									<div class="">
										<div class="">
											<?php include "./data/connect.php";
												$sid = $_GET['id'];
												$req_resume = "";
												$req_appletter = "";
												$req_moa = "";
												$req_mou = "";
												$req_certacc = "";
												$req_resume_stat = "<span class='span01_error'>&cross;</span>";
												$req_appletter_stat = "<span class='span01_error'>&cross;</span>";
												$req_moa_stat = "<span class='span01_error'>&cross;</span>";
												$req_mou_stat = "<span class='span01_error'>&cross;</span>";
												$req_certacc_stat = "<span class='span01_error'>&cross;</span>";
												$req_resume_name = "Resume";
												$req_appletter_name = "Application Letter";
												$req_moa_name = "MOA";
												$req_mou_name = "MOU";
												$req_certacc_name = "Certification of Acceptance";
												$tsn = "";

												$tsn = "requirement:resume";
												$sql = " select no,employee_id,name,req_type,req_file,date_added from tbl_employee_requirements where employee_id='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_resume = trim($dat[4]);
													}
												}
												if ( trim($req_resume)!="" ) {
													$req_resume_stat = "<span class='span01_success'>&check;</span>";
													$req_resume_name = "<a class='link01' target='_blank' href='$req_resume'>Resume</a>";
												}

												$tsn = "requirement:application_letter";
												$sql = " select no,employee_id,name,req_type,req_file,date_added from tbl_employee_requirements where employee_id='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_appletter = trim($dat[4]);
													}
												}
												if ( trim($req_appletter)!="" ) {
													$req_appletter_stat = "<span class='span01_success'>&check;</span>";
													$req_appletter_name = "<a class='link01' target='_blank' href='$req_appletter'>Application Letter</a>";
												}

												$tsn = "requirement:moa";
												$sql = " select no,employee_id,name,req_type,req_file,date_added from tbl_employee_requirements where employee_id='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_moa = trim($dat[4]);
													}
												}
												if ( trim($req_moa)!="" ) {
													$req_moa_stat = "<span class='span01_success'>&check;</span>";
													$req_moa_name = "<a class='link01' target='_blank' href='$req_moa'>MOA</a>";
												}

												$tsn = "requirement:mou";
												$sql = " select no,employee_id,name,req_type,req_file,date_added from tbl_employee_requirements where employee_id='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_mou = trim($dat[4]);
													}
												}
												if ( trim($req_mou)!="" ) {
													$req_mou_stat = "<span class='span01_success'>&check;</span>";
													$req_mou_name = "<a class='link01' target='_blank' href='$req_mou'>MOU</a>";
												}

												$tsn = "requirement:certification_of_acceptance";
												$sql = " select no,employee_id,name,req_type,req_file,date_added from tbl_employee_requirements where employee_id='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_certacc = trim($dat[4]);
													}
												}
												if ( trim($req_certacc)!="" ) {
													$req_certacc_stat = "<span class='span01_success'>&check;</span>";
													$req_certacc_name = "<a class='link01' target='_blank' href='$req_certacc'>Certification of Acceptance</a>";
												}

												echo "
													<div class='table-responsive'>
														<table class='table project-table'>
															<tbody>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_resume_stat  $req_resume_name</span>
																	</td>
																	<td>
																		<a data-toggle='modal' data-target='#modalReqResume' class='label-success btnact01' href=''>E</a>
																	</td>
																</tr>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_appletter_stat  $req_appletter_name</span>
																	</td>
																	<td>
																		<a data-toggle='modal' data-target='#modalReqAppLet' class='label-success btnact01' href=''>E</a>
																	</td>
																</tr>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_moa_stat  $req_moa_name</span>
																	</td>
																	<td>
																		<a data-toggle='modal' data-target='#modalReqMOA' class='label-success btnact01' href=''>E</a>
																	</td>
																</tr>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_mou_stat  $req_mou_name</span>
																	</td>
																	<td>
																		<a data-toggle='modal' data-target='#modalReqMOU' class='label-success btnact01' href=''>E</a>
																	</td>
																</tr>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_certacc_stat  $req_certacc_name</span>
																	</td>
																	<td>
																		<a data-toggle='modal' data-target='#modalReqCertAcc' class='label-success btnact01' href=''>E</a>
																	</td>
																</tr>
															</tbody>
														</table>
		    											
													</div>
												";
											?>
											
										</div>
										
									</div>
									
								</div>
								<!-- END AWARDS -->
								<!-- TABBED CONTENT -->
								<!-- END TABBED CONTENT -->
							</div>
							<!-- END RIGHT COLUMN -->
						</div>
					</div>
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>
</body>

</html>
