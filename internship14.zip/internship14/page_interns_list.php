<?php session_start(); error_reporting( E_ALL ^ E_NOTICE );
	//
	include "./sys_load_active_sy.php";
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$_SESSION['intern_page_current'] = "page_interns_list";
		include "./parts/main_logcheck.php";
	//
	if ( trim($logun)=="" || strtolower(trim($logutype))==strtolower(trim("student")) ) {
		echo "<META HTTP-EQUIV='Refresh' Content='0; URL=./cpanel.php'>";
		exit;
	}
?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	
	<?php include "./parts/head_content.php"; ?>

</head>

<body> 
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">Interns/Students</h3>
					<div class="row">
						
							<!-- BASIC TABLE -->
				
							<!-- RECENT PURCHASES -->
						<div class="row">
							<div class="col-md-9">
							<h5 class="ss">Search:</h5>
							</div>
						
							
							<div class="col-md-3">
							<div class="form-group pull-right">
							<input type="text" id="myInput" value="" class="search form-control" placeholder="What you looking for">
							<!--	<span class="counter pull-right"><button type="button" class="btn btn-primary">Search</button></span>-->
								</div>
									<span class="counter pull-right"></span>
									</div>
						</div>
						<hr><br/>
							<div class="panel">
						
								<div class="table-responsive">
								
									<table class="table table-hover results">
										<thead>
											<tr>
												<th>Student ID</th>
												<th>Student's Name</th>
												<th>Course</th>
												<th>Year</th>
												<th># of Hours</th>
												<th>Duty Time Status</th>
												<th>Evalutaion Result</th>
												<th>Requirements Status</th>
											</tr>
											<tr class="warning no-result">
      											<td><i class="fa fa-warning"></i> No result</td>
   											</tr>
										</thead>
										<tbody id="myTable">
											<?php
												include "./data/connect.php";
												//
												$csy = trim($_SESSION['intern_data_active_sy']);
												//
											//
											$logun =  $_SESSION['intern_data_cun'];
											$logutype = $_SESSION['intern_data_utype'];
											//
											//
											$xq = "";
											$hteidq = "";
											$studidq1 = "";
											if ( strtolower(trim($logutype))==strtolower(trim("employee")) ) {
												//GET USER HTE
												//                 0           1      2        3         4
												$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff where staff_id='$logun' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($hteidq)=="" ) {
														$hteidq = " hte_id='$dat[1]' ";
													}else{
														$hteidq = $hteidq . " || hte_id='$dat[1]' ";
													}
												}
												//
												if ( trim($hteidq)!="" ) {
													//
													$hteidq = " where " . $hteidq;
													//GET USERS IN HTE
													//                 0         1      2
													$sql = " select hte_mem_id,hte_id,member_id from tbl_hte_members $hteidq ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($studidq1)=="" ) {
															$studidq1 = " studentid='$dat[2]' ";
														}else{
															$studidq1 = $studidq1 . " || studentid='$dat[2]' ";
														}
													}
												}
												//
												//
											}
											if ( trim($studidq1)!="" ) {
												//
												$studidq1 = " and ( " . $studidq1 . " ) ";
											}
											//
											//
												//
												//
												//                  0       1         2          3       4      5      6      7      8    9        10          11        12       13      14    15         16
												$sql = " select studentid,firstname,middlename,lastname,email,address,gender,course,year,no_hours,date_start,date_end,contact_no,eval_1,eval_2,req_status,no from tbl_interns  where reg_status='registered' $studidq1  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
														//REQUIREMENT STATUS
													//
													$studid = trim($dat[0]);
													//
													$crsid = trim($dat[7]);
													$crsname = "";
													//
														$reqstats = "";
														$reqstatsx = 13;
														$reqstatsn = 0;
														//
														//$sql2 = " select * from tbl_user_requirements where studentid='$dat[0]' and (req_type<>'') group by req_type ";
														//$qry2 = mysqli_query($conn,$sql2);
														//while($dat2=mysqli_fetch_array($qry2)) {
														//	$reqstatsn = $reqstatsn + 1;
														//}
														//
														$req1 = array();
														//                   0      1             2      3
														$sql2 = " select req_file,date_added,studentid,req_type from tbl_user_requirements where studentid='$dat[0]' and 
																		( req_type='requirement:resume' or req_type='requirement:application_letter' or req_type='requirement:moa' or req_type='requirement:mou' or req_type='requirement:certification_of_acceptance'
																		  or req_type='requirement:white_form' or req_type='requirement:recommendation_letter' or req_type='requirement:waiver' or req_type='requirement:parent_consent'
																		   or req_type='requirement:medical_certificate' or req_type='requirement:certificate_of_appreciation' or req_type='requirement:certificate_of_completion' or req_type='requirement:ojt_photo'
																		) ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:resume")) ) {
																$req1[0][0] = $dat2[0];
																$req1[0][1] = $dat2[1];
																$req1[0][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:application_letter")) ) {
																$req1[1][0] = $dat2[0];
																$req1[1][1] = $dat2[1];
																$req1[1][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:moa")) ) {
																$req1[2][0] = $dat2[0];
																$req1[2][1] = $dat2[1];
																$req1[2][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:mou")) ) {
																$req1[3][0] = $dat2[0];
																$req1[3][1] = $dat2[1];
																$req1[3][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:certification_of_acceptance")) ) {
																$req1[4][0] = $dat2[0];
																$req1[4][1] = $dat2[1];
																$req1[4][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:white_form")) ) {
																$req1[5][0] = $dat2[0];
																$req1[5][1] = $dat2[1];
																$req1[5][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:recommendation_letter")) ) {
																$req1[6][0] = $dat2[0];
																$req1[6][1] = $dat2[1];
																$req1[6][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:waiver")) ) {
																$req1[7][0] = $dat2[0];
																$req1[7][1] = $dat2[1];
																$req1[7][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:parent_consent")) ) {
																$req1[8][0] = $dat2[0];
																$req1[8][1] = $dat2[1];
																$req1[8][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:medical_certificate")) ) {
																$req1[9][0] = $dat2[0];
																$req1[9][1] = $dat2[1];
																$req1[9][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:certificate_of_appreciation")) ) {
																$req1[10][0] = $dat2[0];
																$req1[10][1] = $dat2[1];
																$req1[10][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:certificate_of_completion")) ) {
																$req1[11][0] = $dat2[0];
																$req1[11][1] = $dat2[1];
																$req1[11][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:ojt_photo")) ) {
																$req1[12][0] = $dat2[0];
																$req1[12][1] = $dat2[1];
																$req1[12][2] = $dat2[2];
															}
														}
														for ( $i=0 ; $i<13 ; $i++ ) {
															//
															$xn = 0;
															//
															$sql3 = " select * from tbl_upfiles where location='".$req1[$i][0]."' and date_uploaded='".$req1[$i][1]."' and upby_type='student' and upby_id='".$req1[$i][2]."' and utype='requirement' and ap_status<>'dis-approved' order by no desc limit 2 ";
															$qry3 = mysqli_query($conn,$sql3);
															while($dat3=mysqli_fetch_array($qry3)) {
																$xn += 1;
															}
															//
															if ( $xn > 0 ) {
																$reqstatsn = $reqstatsn + 1;
															}
														}
														//
														//echo "$reqstatsn";
													$urs = trim($dat[15]);
													$fstat = "";
													$tsn = "";
													$tsn = "completed";
													//if ( strtolower(trim($urs)) == strtolower(trim($tsn)) ) {
													if ( $reqstatsn >= $reqstatsx ) {
														$fstat = "<span class='label label-success'>COMPLETED</span>";
													}
													$tsn = "pending";
													//if ( strtolower(trim($urs)) == strtolower(trim($tsn)) ) {
													if ( $reqstatsn < $reqstatsx  ) {
														$reqstats = $reqstatsn . "/" . $reqstatsx;
														//$fstat = "<span class='label label-warning'>PENDING</span>";
														$fstat = "<span class='label label-warning'>PENDING ($reqstats)</span>";
													}
													$tsn = "dropped";
													if ( strtolower(trim($urs)) == strtolower(trim($tsn)) ) {
														//$fstat = "<span class='label label-danger'>DROPPED</span>";
													}
														//GET EVAL. RATE
														$evalrate = "-";
														//$sql2 = " select rate from tbl_interns_evaluation where studentid='$dat[0]' order by no desc limit 1 ";
														//$qry2 = mysqli_query($conn,$sql2);
														//while($dat2=mysqli_fetch_array($qry2)) {
														//	if ( trim($dat2[0])!="" ) {
																//$evalrate = trim($dat2[0]);
														//	}
														//}
														//GET OVER ALL RATING
														$crit1 = 0;
														$crit2 = 0;
														$crit3 = 0;
														$crit4 = 0;
														$crit5 = 0;
														$crit6 = 0;
														$crit7 = 0;
														$crit8 = 0;
														$crit9 = 0;
														//                  0             1              2           3          4            5           6           7               8           9          
														$sql3 = " select stud_eval_id,professionalism,job_maturity,comm_skills,productivity,leadership,excellence,honesty_integrity,innovation,teamwork from tbl_interns_eval2 where studentid='$studid' and sy='$csy' ";
														$qry3 = mysqli_query($conn,$sql3);
														while($dat3=mysqli_fetch_array($qry3)) {
															$crit1 += strval(trim($dat3[1]));
															$crit2 += strval(trim($dat3[2]));
															$crit3 += strval(trim($dat3[3]));
															$crit4 += strval(trim($dat3[4]));
															$crit5 += strval(trim($dat3[5]));
															$crit6 += strval(trim($dat3[6]));
															$crit7 += strval(trim($dat3[7]));
															$crit8 += strval(trim($dat3[8]));
															$crit9 += strval(trim($dat3[9]));
														}
														$evalrate = ($crit1 + $crit2 + $crit3 + $crit4 + $crit5 + $crit6 + $crit7 + $crit8 + $crit9) / 9;
														$td = explode(".", $evalrate);
														$evalrate = strval($td[0]);
														//
														//GET CRS NAME
														$sql2 = " select course_id,course from tbl_course where course_id='$crsid' ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															$crsname = trim($dat2[1]);
														}
													//
													//
													$remhrs = "0";
													//GET REMAINING TIME
														//               0     1      2   3          4       5
														$sql2 = " select no,studentid,sy,total_hrs,used_hrs,rem_hrs from tbl_interns_totalhrs where studentid='$studid' and sy='$csy' ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															$remhrs = trim($dat2[5]);
														}
													//
													$tothrs = strval(trim($dat[9]));
													//
													if ( $remhrs <= 0 && $tothrs > 0 ) {
														$remhrs = $tothrs;
													}
													//
													$hrsstat = "";
													//
													if ( $remhrs > 0 ) {
														$hrsstat = "<span class='label label-warning'>ONGOING</span>";
													}
													if ( $remhrs <= 0 ) {
														$hrsstat = "<span class='label label-success'>DONE</span>";
													}
													//

													echo "
														<tr>
															<td>
																".trim($dat[0])."
															</td>
															<td>
																<a href='page_profile.php?id=".trim($dat[0])."'>
																<span class='span02'>".trim($dat[1])." ".trim($dat[2])." ".trim($dat[3])."</span>
																</a>
															</td>
															<td>
																".trim($crsname)."
															</td>
															<td>
																".trim($dat[8])."
															</td>
															<td>
																".trim($remhrs)."/".trim($dat[9])."
															</td>
															<td>
																".trim($hrsstat)."
															</td>
															<td>
																".trim($evalrate)."
															</td>
															<td>
																".$fstat."
															</td>
														</tr>
													";
												}
											?>
											
											
										</tbody>
									</table>
								</div>
							
							</div>
					
							<!-- END TABLE NO PADDING -->
						
					</div>
					
					
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>

<script>
/*	
	$(document).ready(function() {
  $(".search").keyup(function () {
    var searchTerm = $(".search").val();
    var listItem = $('.results tbody').children('tr');
    var searchSplit = searchTerm.replace(/ /g, "'):containsi('")
    
  $.extend($.expr[':'], {'containsi': function(elem, i, match, array){
        return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
    }
  });
    
  $(".results tbody tr").not(":containsi('" + searchSplit + "')").each(function(e){
    $(this).attr('visible','false');
  });

  $(".results tbody tr:containsi('" + searchSplit + "')").each(function(e){
    $(this).attr('visible','true');
  });

  var jobCount = $('.results tbody tr[visible="true"]').length;
    $('.counter').text(jobCount + ' item');

  if(jobCount == '0') {$('.no-result').show();}
    else {$('.no-result').hide();}
		  });
});*/

$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

</script>


<?php
	include "./parts/btm_script.php";
?>

</body>

</html>
