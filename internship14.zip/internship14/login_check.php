<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
	include "./sys_load_active_sy.php";
	//
	$_SESSION['intern_page_current'] = "login_check";
	$_SESSION['intern_page_lastpage'] = "login_check";
	//
		include "./parts/main_logcheck.php";
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	//
	if ( $_POST['btnloginlostpass'] ) {
		//
		$utype = $_POST['logtype'];
		//
		$_SESSION['intern_lpage_dtype'] = $utype;
		//
		echo "<META HTTP-EQUIV='Refresh' Content='0; URL=./index.php?page=lostpass'>";
		//
		exit;
	}
	//
	//
	if ( $_POST['btnlogin'] ) {
		$un = $_POST['username'];
		$up = $_POST['password'];
		//
		$logt = $_POST['logtype'];
		if ( strtolower(trim($logt))==strtolower(trim("staff")) ) {
			$logt = "employee";
		}
		$logt = "";
		//echo "$logt";
		//
		$utype = "";
		$cun = "";
		$dpn = "";
		$staffpos = "";
		//
		$dbpass = "";
		$dbregstats = "";
		//
		if ( trim($un)!="" && trim($up)!="" ){

			$mc = 0;

			if ( strtolower(trim($logt))==strtolower(trim("student")) || trim($logt)=="" ) {

				//STUDENT
				if ( $mc <= 0 ) {
					$sql = " select studentid,username,password,firstname,middlename,lastname,reg_status from tbl_interns  where studentid='$un' ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						if ( $mc <= 0 ){
							$dbpass = $dat[2];
							$dbregstats = $dat[6];
							if ( trim($dbpass) == "" ) {
								$utype = "student";
								$mc = $mc + 1;
							}else{
								if ( ( strtolower(trim($un))==strtolower(trim($dat[0])) || strtolower(trim($un))==strtolower(trim($dat[1])) ) && $up == $dat[2] ) {
									$cun = trim($dat[0]);
									$dpn = trim($dat[3]);
									$utype = "student";
									$mc = $mc + 1;
								}
							}
						}
					}
				}

			}

			if ( strtolower(trim($logt))==strtolower(trim("employee")) || trim($logt)=="" ) {

				$sql = " select un,email,up,dname from tbl_admin  where un='$un' ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					if ( $mc <= 0 ){
						if ( ( strtolower(trim($un))==strtolower(trim($dat[0])) || strtolower(trim($un))==strtolower(trim($dat[1])) ) && $up == $dat[2] ) {
							$cun = trim($dat[0]);
							$dpn = trim($dat[3]);
							$utype = "admin";
							$mc = $mc + 1;
						}
					}
				}

				//EMPLOYEE
				if ( $mc <= 0 ) {
					//                   0          1       2        3         4         5        6
					$sql = " select employee_id,username,password,firstname,middlename,lastname,position from tbl_employee  where employee_id='$un' ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						if ( $mc <= 0 ){
							//
							$dbpass = $dat[2];
							if ( trim($dbpass) == "" ) {
								$utype = "employee";
								$mc = $mc + 1;
							}else{
								if ( ( strtolower(trim($un))==strtolower(trim($dat[0])) || strtolower(trim($un))==strtolower(trim($dat[1])) ) && $up == $dat[2] ) {
									$cun = trim($dat[0]);
									$dpn = trim($dat[3]);
									$utype = "employee";
									$mc = $mc + 1;
								}
							}
						}
					}
					echo "
						<script>
							//alert('XX');
						</script>
					";
				}

			}

	////////////////////////

			if ( $mc > 0 ){
				$tsn = "student";
				if ( strtolower(trim($tsn))==strtolower(trim($utype)) ) {
					if ( trim($dbpass)=="" ) {
						if ( strtolower(trim($dbregstats))==strtolower(trim("registered")) ) {
							$_SESSION['intern_lpage_page'] = "ftasetup";
							$_SESSION['intern_lpage_dtype'] = $utype;
						}else{
							$_SESSION['intern_lpage_page'] = "";
							$_SESSION['intern_disp_err'] = "<span class='span01_error'>ID is not registered.</span>";
						}
						
					}else{
						$_SESSION['intern_data_cun'] = $cun;
						$_SESSION['intern_data_dpn'] = $dpn;
						$_SESSION['intern_data_utype'] = $utype;
						$_SESSION['intern_data_staffposs'] = "";
						//echo "<script>alert('$cun');</script>";
						echo "<META HTTP-EQUIV='Refresh' Content='0; URL=cpanel.php'>";
					}
				}
				$tsn = "admin";
				if ( strtolower(trim($tsn))==strtolower(trim($utype)) ) {
						$_SESSION['intern_data_cun'] = $cun;
						$_SESSION['intern_data_dpn'] = $dpn;
						$_SESSION['intern_data_utype'] = $utype;
						$_SESSION['intern_data_staffposs'] = "admin";
						//echo "<script>alert('$cun');</script>";
						echo "<META HTTP-EQUIV='Refresh' Content='0; URL=cpanel.php'>";
				}
				$tsn = "employeexxx";
				if ( strtolower(trim($tsn))==strtolower(trim($utype)) ) {
						$_SESSION['intern_data_cun'] = $cun;
						$_SESSION['intern_data_dpn'] = $dpn;
						$_SESSION['intern_data_utype'] = $utype;
						$_SESSION['intern_data_staffposs'] = $staffpos;
						//echo "<script>alert('$cun');</script>";
						echo "<META HTTP-EQUIV='Refresh' Content='0; URL=cpanel.php'>";
				}
				$tsn = "employee";
				if ( strtolower(trim($tsn))==strtolower(trim($utype)) ) {
					if ( trim($dbpass)=="" ) {
						$_SESSION['intern_lpage_page'] = "ftasetup";
						$_SESSION['intern_lpage_dtype'] = $utype;
						
					}else{
						$_SESSION['intern_data_cun'] = $cun;
						$_SESSION['intern_data_dpn'] = $dpn;
						$_SESSION['intern_data_utype'] = $utype;
						$_SESSION['intern_data_staffposs'] = $staffpos;
						//echo "<script>alert('$cun');</script>";
						echo "<META HTTP-EQUIV='Refresh' Content='0; URL=cpanel.php'>";
					}
				}
				//$_SESSION['intern_disp_err'] = "<span class='span01_success'>OK.</span>";
			}else{
				$_SESSION['intern_disp_err'] = "<span class='span01_error'>Incorrect Username or Password.</span>";
				//
				$_SESSION['intern_login_tempn'] = $un;
				$_SESSION['intern_login_templt'] = $logt;
				//
				echo "<META HTTP-EQUIV='Refresh' Content='0; URL=./index.php'>";
			}
		}else{
				$_SESSION['intern_login_tempn'] = $un;
				$_SESSION['intern_login_templt'] = $logt;
				//
				echo "<META HTTP-EQUIV='Refresh' Content='0; URL=./index.php'>";
		}
	}else{
		echo "<META HTTP-EQUIV='Refresh' Content='0; URL=./index.php'>";
	}
?>
<!DOCTYPE html>
<html>
<head>
<title>UMDC Internship Management System</title>
</head>
<body>

</body>
</html>