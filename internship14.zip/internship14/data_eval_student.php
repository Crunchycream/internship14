<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
	//
	$logun =  $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$curid = trim($_GET['cid']);
	//$curid = "90789";
	//
	if ( trim($logun)!="" ) {
		$fdata;
		$n = 0;
		//
		$sql = " select professionalism,job_maturity,comm_skills,productivity,leadership,excellence,honesty_integrity,innovation,teamwork from tbl_interns_eval2  where studentid='$curid' limit 1 ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_row($qry)) {
			$fdata[$n] = $dat;
			$n += 1;
		}
		echo json_encode($fdata);
	}
?>