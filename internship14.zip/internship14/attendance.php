<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
	include "./sys_load_active_sy.php";
	//
	$_SESSION['intern_page_current'] = "attendance";
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	//$csy = "2016-2017";
	$csy = trim($_SESSION['intern_data_active_sy']);
	//
	if ( $_POST['btnlogin'] ) {
		$un = $_POST['user'];
		$up = $_POST['pass'];
		$ltype = $_POST['atype'];
		$lcode = $_POST['lcode'];
		$mae = $_POST['mae'];
		//
		$tdate = trim($date_year)."-".trim($date_month)."-".trim($date_day);
		//
		$utype = "";
		$cun = "";
		$dpn = "";
		//
		$errmsg = "";
		$errn = 0;
		//
		if ( trim($un) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Enter a username. ";
		}
		if ( ($up) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Enter a password. ";
		}
		if ( trim($ltype) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Choose a attendance type. ";
		}
		if ( trim($mae) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Choose either MORNING/AFTERNOON/EVENING. ";
		}
		if ( trim($lcode) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Permission code required. ";
		}
		//
			$ec = 0;
			$sql = " select studentid,password from tbl_interns  where studentid='$un' ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				if ( $up == $dat[1] ) {
					$ec = $ec + 1;
				}
			}
			if ( $ec <= 0 ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Incorrect ID or Password. ";
			}
		//
		//
			$ec = 0;
			$sql = " select * from tbl_interns_dtr  where studentid='$un' and sy='$csy' and att_type='$ltype' and att_mae='$mae' and dt_year='$date_year' and dt_month='$date_month' and dt_day='$date_day' ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				$ec = $ec + 1;
			}
			//
			$mt1 = strtoupper(trim($mae));
			$mt2 = strtoupper(trim($ltype));
			//
			//
			if ( $ec > 0 ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "You're not allowed to have attendence for ". trim($mt1) . " " . trim($mt2) . ".";
			}
		//
			//CHECK CODE
			$qac = "";
			//$xx = "";
			///
			$ec = 0;
			$sql = " select attcode_id,attcode,mae,ltype,adate,tdate from tbl_attcode  where mae='$mae' and ltype='$ltype' ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				//
				$dcdate = explode("-", trim($dat[5]));
				//$xx = $xx . " $dat[1]-$dat[5]==$lcode-$dcdate[0]-$dcdate[1]-$dcdate[2] ";
				//
				if ( $lcode == $dat[1] && strval(trim($dcdate[0]))==strval(trim($date_year)) && strval(trim($dcdate[1]))==strval(trim($date_month)) && strval(trim($dcdate[2]))==strval(trim($date_day)) ) {
					$ec = $ec + 1;
					$qac = $dat[1];
					//
				}
			}
			if ( $ec <= 0 ) {
				$errn = $errn + 1;
				$errmsg = $errmsg . "Incorrect Permission Code. ";
			}
			//echo "
			//	<script>
					//alert('$ec $tdate $tmpdate $xx');
			//	</script>
			//";
		//
		//
		if ( $errn <= 0 ) {
			//SAVE DATA
				$sql = "
						insert into tbl_interns_dtr 
							(studentid,sy,att_mae,att_type,pcode,dt_year,dt_month,dt_day,dt_hour,dt_min,dt_sec) 
						values 
							('$un','$csy','$mae','$ltype','$qac','$date_year','$date_month','$date_day','$date_hour','$date_minute','$date_second') 
						";
				$qry = mysqli_query($conn,$sql);
			//
			//
			//UPDATE USER TOTAL HRS
			//CHECK IF ALREADY HAS RECORDS
			$rn = 0;
			$sql = " select * from tbl_interns_totalhrs  where studentid='$un' and sy='$csy' ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				$rn = $rn + 1;
			}
			if ( $rn <= 0 ) {
				//GET STUDENT TOTAL HRS
				//ADD NEW RECORD
				$sql = "
						insert into tbl_interns_totalhrs 
							(studentid,sy,total_hrs,used_hrs,rem_hrs) 
						values 
							('$un','$csy','0','0','0') 
						";
				$qry = mysqli_query($conn,$sql);
			}
			//GET CALC TIME
			//
			include "./parts/sys_functions_calchrs.php";
			calcDTime($un,$csy);
			//
			//CLEAR
			$_POST['user'] = "";
			$_POST['pass'] = "";
			$_POST['lcode'] = "";
			$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully attended.</span>";
		}else{
			$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
			//echo "
			//	<script>
			//		alert('$errmsg');
			//	</script>
			//";
		}
	}
	//
?>
<!doctype html>
<html lang="en" class="fullscreen-bg">

<head>
	<title>Login | UMDC Internship Management</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>

</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<div class="vertical-align-wrap">
			<div class="vertical-align-middle">
				<div class="auth-box ">
					<div class="left">
						<div class="content">
							
							<div class="header">
								<div class="logo text-center"></div>
								<p class="lead">Attendance</p>
							</div>

								<div class="form-group">
									<?php echo $_SESSION['intern_disp_err']; $_SESSION['intern_disp_err'] = ""; ?>
								</div>

							<form class="form-auth-small" action="" method="post">

								<div class="form-group">
									<label for="user" class="control-label sr-only">Username</label>
									<input type="username" name="user" class="form-control" id="user" placeholder="Username"
										<?php
											$value = $_POST['user'];
											//
											echo " value='$value' ";
										?>
									>
								</div>
								<div class="form-group">
									<label for="pass" class="control-label sr-only">Password</label>
									<input type="password" name="pass" class="form-control" id="pass" value="" placeholder="Password">
								</div>

								<table width="100%">
									<tr>
										<td>
											<select name="mae" class="form-control" >
												<option value="MORNING">MORNING</option>
												<option value="AFTERNOON">AFTERNOON</option>
												<option value="EVENING">EVENING</option>
											</select>
										</td>
										<td>
											<select name="atype" class="form-control" >
												<option value="IN">IN</option>
												<option value="OUT">OUT</option>
											</select>
										</td>
									</tr>
								</table>


								<br/>

								<div class="form-group">
									<label for="lcode" class="control-label sr-only">Permission Code</label>
									<input type="username" name="lcode" class="form-control" id="lcode" placeholder="Permission Code"
										<?php
											$value = $_POST['lcode'];
											//
											echo " value='$value' ";
										?>
									>
								</div>
								
								<input type="submit" name="btnlogin" class="btn btn-primary btn-lg btn-block" value="ATTENDANCE">

							</form>

								<br/>
								<div class="form-group clearfix" align="center">
									<b>[ <a href="./index.php"><span>LOGIN</span></a> ]</b>
								</div>
								

						</div>
					</div>
					<div class="right">
						<div class="overlay"></div>
						<div class="content text">
							<h1 class="heading">University of Mindanao Internship Management</h1>
							<p></p>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>
	<!-- END WRAPPER -->
</body>

</html>
