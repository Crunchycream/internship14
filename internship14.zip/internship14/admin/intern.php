<?php
	include('dbcon.php');
	include('session.php');
  ?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	<link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="../assets/vendor/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="../assets/vendor/linearicons/style.css">
	<!-- MAIN CSS -->
	<link rel="stylesheet" href="../assets/css/main.css">
	<!-- FOR DEMO PURPOSES ONLY. You should remove this in your project -->
	<link rel="stylesheet" href="../assets/css/demo.css">
	<!-- GOOGLE FONTS -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
	<!-- ICONS -->
	<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="../assets/img/favicon.png">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<style >
	

	</style>


</head>

<body> 
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
			<?php include('navheader.php');  ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include('sidebar_intern.php'); ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">Interns/Students</h3>
					<div class="row">
						<div class="col-md-12">
							<!-- BASIC TABLE -->
				
							<!-- RECENT PURCHASES -->
						<div class="row">
							<div class="col-md-9">
							</div>
						
							
							<div class="col-md-3">
								<div class="form-group pull-right">
									<input type="text" id="myInput" value="" class="search form-control" placeholder="Search...">
							<!--	<span class="counter pull-right"><button type="button" class="btn btn-primary">Search</button></span>-->
								</div>
									<span class="counter pull-right"></span>
							</div>
						</div>
							<div class="row">
								<div class="panel">
									<div class="table-responsive">	
										<table class="table">
											<thead>
												<tr>
													<th>Student's Name</th>
													<th>Course</th>
													<th>Year</th>
													<th># of Hours</th>
													<th>Date Started</th>
													<th>Date Ended</th>
													<th>Mobile #</th>
													<th>Email Add</th>
													<th>1st Evalutaion Result</th>
													<th>2nd Evalutaion Result</th>
													<th>Requirements Status</th>
												</tr>
												<tr class="warning no-result">
	      											<td><i class="fa fa-warning"></i> No result</td>
	   											</tr>
											</thead>
											<tbody id="myTable">
												<tr>
													<td><a href="#">Cadis Raizel</a></td>
													<td>BSIT</td>
													<td>4th</td>
													<td>486</td>
													<td>01/13/18</td>
													<td>02/27/18</td>
													<td>09879654678</td>
													<td>kiat@gmail.com</td>
													<td>3.7</td>
													<td>N/A</td>
													<td><span class="label label-success">COMPLETED</span></td>

												</tr>
												<tr>
													<td><a href="#">Gon Frecks</a></td>
													<td>BSIT</td>
													<td>4th</td>
													<td>486</td>
													<td>01/13/18</td>
													<td>02/27/18</td>
													<td>0976543268</td>
													<td>amaw@gmail.com</td>
													<td>3.7</td>
													<td>N/A</td>
													<td><span class="label label-success">COMPLETED</span></td>
												</tr>
												<tr>
													<td><a href="#">Frankenstein</a></td>
													<td>BSIT</td>
													<td>4th</td>
													<td>486</td>
													<td>01/13/18</td>
													<td>02/27/18</td>
													<td>09345678976</td>
													<td>lodi@gmail.com</td>
													<td>3.7</td>
													<td>N/A</td>
													<td><span class="label label-warning">PENDING</span></td>
												</tr>
												<tr>
													<td><a href="#">Bob Marley</a></td>
													<td>BSIT</td>
													<td>4th</td>
													<td>486</td>
													<td>01/13/18</td>
													<td>02/27/18</td>
													<td>09342543165</td>
													<td>waddup@gmail.com</td>
													<td>3.7</td>
													<td>N/A</td>
													<td><span class="label label-warning">PENDING</span></td>
												</tr>
												<tr>
													<td><a href="#">Hisoka Gwapo</a></td>
													<td>BSIT</td>
													<td>4th</td>
													<td>486</td>
													<td>01/13/18</td>
													<td>02/27/18</td>
													<td>09567043245</td>
													<td>petmalu@gmail.com</td>
													<td>3.7</td>
													<td>N/A</td>
													<td><span class="label label-warning">PENDING</span></td>
												</tr>
												<tr>
													<td><a href="#">Tibugok Balot</a></td>
													<td>BSIT</td>
													<td>4th</td>
													<td>486</td>
													<td>01/13/18</td>
													<td>02/27/18</td>
													<td>0923854135</td>
													<td>werpa@gmail.com</td>
													<td>N/A</td>
													<td>N/A</td>
													<td><span class="label label-danger">DROPPED</span></td>
												</tr>
												<tr>
													<td><a href="#">Pocahontas 1</a></td>
													<td>BSIT</td>
													<td>4th</td>
													<td>486</td>
													<td>01/13/18</td>
													<td>02/27/18</td>
													<td>09397654763</td>
													<td>hawhow@gmail.com</td>
													<td>N/A</td>
													<td>N/A</td>
													<td><span class="label label-danger">DROPPED</span></td>

												</tr>
												
											</tbody>
										</table>
									</div>
								</div>
							
							</div>
					
							<!-- END TABLE NO PADDING -->
						</div>
					</div>
					
					
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<div class="container-fluid">
				<p class="copyright">&copy; 2017 <a href="#" target="_blank">Lazy</a>. All Rights Reserved.</p>
			</div>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="../assets/vendor/jquery/jquery.min.js"></script>
	<script src="../assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="../assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="../assets/scripts/klorofil-common.js"></script>

<script>
/*	
	$(document).ready(function() {
  $(".search").keyup(function () {
    var searchTerm = $(".search").val();
    var listItem = $('.results tbody').children('tr');
    var searchSplit = searchTerm.replace(/ /g, "'):containsi('")
    
  $.extend($.expr[':'], {'containsi': function(elem, i, match, array){
        return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
    }
  });
    
  $(".results tbody tr").not(":containsi('" + searchSplit + "')").each(function(e){
    $(this).attr('visible','false');
  });

  $(".results tbody tr:containsi('" + searchSplit + "')").each(function(e){
    $(this).attr('visible','true');
  });

  var jobCount = $('.results tbody tr[visible="true"]').length;
    $('.counter').text(jobCount + ' item');

  if(jobCount == '0') {$('.no-result').show();}
    else {$('.no-result').hide();}
		  });
});*/

$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

</script>


</body>

</html>
