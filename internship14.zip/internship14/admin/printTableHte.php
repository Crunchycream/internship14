<?php  
	function printTable($dbName){
		$admin = $_SESSION['user_id'];
		$getDbName = $dbName;
		$sqlText = "SELECT * FROM hte";
		$query = mysql_query($sqlText);
		$numOfCols = mysql_num_fields($query);
		while($getResult = mysql_fetch_array($query)){
			for($i = 1; $i <= 4; $i++){
				echo "<td>" . $getResult[$i] . "</td>";
			}
			echo "</tr>";
		}
	}
					
?>