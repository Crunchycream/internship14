<?php
	// connect make log
	$host = "localhost";
	$username = "root";
	$password = "";
	$db = "capshit";

	function connect($host, $username, $password){
		$connect = mysql_connect($host,$username,$password);
		if(!$connect){
			echo "could not connect to sql";
		}
	}

	function selectDb($db){
		mysql_select_db($db);
	}

	connect($host,$username,$password);
	selectDb($db);
?>