<nav>
					<ul class="nav">
						<li><a href="dashboard.php" class="active"><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>
						<li>
							<a href="#subPages" data-toggle="collapse" class="collapsed"><i class="lnr lnr-file-empty"></i> <span>Pages</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="subPages" class="collapse ">
								<ul class="nav">
									<li><a href="intern.php" class=""><i class="lnr lnr-users"></i><span>Interns</span></a></li>
									<li><a href="hte.php" class=""><i class="lnr lnr-apartment"></i><span>HTE</span> </a></li>
								</ul>
							</div>
						</li>
						<li>
							<a href="#subPages1" data-toggle="collapse" class="collapsed"><i class="lnr lnr-chart-bars"></i> <span>Evaluation</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="subPages1" class="collapse ">
								<ul class="nav">
									<li><a href="ChartStudents.html" class=""><i class="lnr lnr-users"></i><span>Interns</span></a></li>
									<li><a href="ChartHTE.html" class=""><i class="lnr lnr-apartment"></i><span>HTE</span> </a></li>
								</ul>
							</div>
						</li>
						
						<li><a href="page-profile.html" class=""><i class="lnr lnr-user"></i> <span>Profile</span></a></li>



						<li><a href="notifications.html" class=""><i class="lnr lnr-select"></i> <span>Map</span></a></li>
					</ul>
				</nav>