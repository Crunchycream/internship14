<?php 
	session_start();
	include_once('dbcon.php'); 
?>
<!DOCTYPE html>
<html lang="en" class="fullscreen-bg">
<head>
	<title>Login | UMDC Internship Management</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="../assets/vendor/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="../assets/vendor/linearicons/style.css">
	<!-- MAIN CSS -->
	<link rel="stylesheet" href="../assets/css/main.css">
	<!-- FOR DEMO PURPOSES ONLY. You should remove this in your project -->
	<link rel="stylesheet" href="../assets/css/demo.css">
	<!-- GOOGLE FONTS -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
	<!-- ICONS -->
	<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="../assets/img/favicon.png">
</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<div class="vertical-align-wrap">
			<div class="vertical-align-middle">
				<div class="auth-box ">
					<div class="left">
						<div class="content">
							<div class="header">
								<div class="logo text-center"><img src="../assets/img/logo-dark.png" alt="Klorofil Logo"></div>
								<p class="lead">Login to your account</p>
							</div>
							<form class="form-auth-small" action="index.php" method="POST">
								<div class="form-group">
									<input type="username" name="username" class="form-control" id="signin-email" value="" placeholder="Username">
								</div>
								<div class="form-group">
									<input type="password" name="password" class="form-control" id="signin-password" value="password" placeholder="Password">
								</div>
								<div class="form-group clearfix">
									<label class="fancy-checkbox element-left">
										<input type="checkbox">
										<span>Remember me</span>
									</label>
								</div>
								<button type="submit" name="submit" class="btn btn-primary btn-lg btn-block">LOGIN</button>
								<div class="bottom">
									<span class="helper-text"><i class="fa fa-lock"></i> <a href="#">Forgot password?</a></span>
								</div>
							</form>
								 <?php  
							        if(isset($_POST['submit'])){
							            $username = $_POST['username'];
							            $password = $_POST['password'];
							            $sqlText = "SELECT * FROM admin WHERE username LIKE '$username' AND password LIKE '$password' ";
							            $result = mysql_num_rows(mysql_query($sqlText));
							            $getResult = mysql_fetch_row(mysql_query($sqlText));
							            if($result){
							              $_SESSION['user_id'] = $getResult[0];
							              $_SESSION['firsname'] = $getResult[3];
							              $_SESSION['lastname'] = $getResult[4];

							              header("location: dashboard.php");
							            }else{
							              echo "nope";
							            }
							        }
							     ?>				
						</div>
					</div>
					<div class="right">
						<div class="overlay"></div>
						<div class="content text">
							<h1 class="heading">University of Mindanao Internship Management</h1>
							<p>by Satan</p>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>
	<!-- END WRAPPER -->
</body>

</html>
