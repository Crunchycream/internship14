<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$_SESSION['intern_page_current'] = "class_files";
		include "./parts/main_logcheck.php"; 
	//
	if ( $_POST['btnupdateAStat'] ) {
		$cid = trim($_POST['txtid']);
		$cval = trim($_POST['txtval']);
		if ( trim($cid)!="" ) {
			$sql = " update tbl_upfiles set ap_status='$cval' where no='$cid'  ";
			$qry = mysqli_query($conn,$sql);
		}
	}
	if ( $_POST['btnsaveGrade'] ) {
		$cid = trim($_POST['txtid']);
		$cval = trim($_POST['txtgrade']);
		//
		if ( trim($cid)!="" && trim($cval)!="" ) {
			$sql = " update tbl_upfiles set grade='$cval' where no='$cid'  ";
			$qry = mysqli_query($conn,$sql);
		}
	}
	//
	//
	if ( trim($logun)=="" ) {
		exit;
	}
?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	
	<?php include "./parts/head_content.php"; ?>

</head>

<body> 
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">
						<?php
							$ctype = trim($_GET['type']);
							if ( trim($ctype)=="" ) {
								$ctype = "reflection";
							}
							//
							if ( strtolower(trim($ctype))==strtolower(trim("reflection")) ) {
								echo "Submitted Reflections";
							}
							if ( strtolower(trim($ctype))==strtolower(trim("post")) ) {
								echo "Posts";
							}
							if ( strtolower(trim($ctype))==strtolower(trim("student_docs")) ) {
								echo "Submitted Documents";
							}
						?>
					</h3>
					<div class="row">
						
							<!-- BASIC TABLE -->
				
							<!-- RECENT PURCHASES -->
						<div class="row">
							<div class="col-md-9">
							<h5 class="ss">Search:</h5>
							</div>
						
							
							<div class="col-md-3">
							<div class="form-group pull-right">
							<input type="text" id="myInput" value="" class="search form-control" placeholder="What you looking for">
							<!--	<span class="counter pull-right"><button type="button" class="btn btn-primary">Search</button></span>-->
								</div>
									<span class="counter pull-right"></span>
									</div>
						</div>
						<hr><br/>

							<div class="panel">
								<div class="panel-body">
									<?php include "./data/connect.php";
										$curid = $_SESSION['intern_data_cun'];
										$curidtype = $_SESSION['intern_data_utype'];
										if ( strtolower(trim($curid))!=strtolower(trim("")) ) {
											
										}
										$ctype = trim($_GET['type']);
										if ( trim($ctype)=="" ) {
											$ctype = "reflection";
										}
										//
										$curclassid = trim($_GET['class_id']);
										$curweekn = trim($_GET['weekname']);
										$curtype = trim($_GET['status']);
										//
										//
										//
										$classopt = "";
										$weekopt = "";
										$statopt = "";
										//
										//
											//
											$classopt = $classopt . "<option value='all'>All</option>";
											//
										$xq = "";
										//
										$sql = " select class_id from tbl_class_staff  where staff_type='$curidtype' and staff_id='$curid'  ";
										$qry = mysqli_query($conn,$sql);
										while($dat=mysqli_fetch_array($qry)) {
											if ( trim($xq)=="" ) {
												$xq = " class_id='$dat[0]' ";
											}else{
												$xq = $xq . " or class_id='$dat[0]' ";
											}
										}
										if ( trim($xq)!="" ) {
											$xq = " and ( " . $xq . " ) ";
											//                 0   1
											$sql = " select class_id,name from tbl_class  where class_id<>'' and name<>'' $xq ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												$isel = "";
												if ( strtolower(trim($curclassid))==strtolower(trim($dat[0])) ) {
													$isel = " selected='true' ";
												}
												$classopt = $classopt . "<option value='$dat[0]' $isel>$dat[1]</option>";
											}
										}
											//
											//
											//
											$weekopt = $weekopt . "<option value='all'>All</option>";
											//
										//                 0   1
										for ( $i=1 ; $i<=48 ; $i++ ) {
											//
											$cval = "week_$i";
											//
											$isel = "";
											if ( strtolower(trim($curweekn))==strtolower(trim($cval)) ) {
												$isel = " selected='true' ";
											}
											$weekopt = $weekopt . "<option value='$cval' $isel>WEEK $i</option>";
										}
										//
											//
											$statopt = $statopt . "<option value='all'>All</option>";
											//
											$tmpd = "Approved";
											$isel = "";
											if ( strtolower(trim($curtype))==strtolower(trim($tmpd)) ) {
												$isel = " selected='true' ";
											}
											$statopt = $statopt . "<option value='$tmpd' $isel>Approved</option>";
											//
											$tmpd = "Dis-Approved";
											$isel = "";
											if ( strtolower(trim($curtype))==strtolower(trim($tmpd)) ) {
												$isel = " selected='true' ";
											}
											$statopt = $statopt . "<option value='$tmpd' $isel>Dis-Approved</option>";
										//
										if ( strtolower(trim($ctype))==strtolower(trim("reflection")) ) {
											echo "

												<form action='' method='get'>
													<table >
														<tr>
															<td>
																<b>HTE:</b> 
																<select class='form-control txt01 txt_inline01' name='class_id'>
																	$classopt
																</select>
															</td>
															<td>
																<b>Week:</b> 
																<select class='form-control txt01 txt_inline01' name='weekname'>
																	$weekopt
																</select>
															</td>
															<td>
																<b>Status:</b>
																<select class='form-control txt01 txt_inline01' name='status'>
																	$statopt
																</select>
															</td>
														</tr>
													</table>
													<input class='btn btn-success btn-md' type='submit' value='Filter'/>
													
												</form>

											";
										}
									?>
								</div>
							</div>

							<div class="panel">
						
								<div class="table-responsive">
								
									<table class="table table-hover results">
										<thead>
											<?php
												$ctype = trim($_GET['type']);
												if ( trim($ctype)=="" ) {
													$ctype = "reflection";
												}
												//
												if ( strtolower(trim($ctype))==strtolower(trim("reflection")) ) {

													echo "

													<tr>
														<th></th>
														<th>Grade</th>
														<th>Submitted By</th>
														<th>Submitted In</th>
														<th>Week</th>
														<th>File Name</th>
														<th>Location</th>
														<th>Date Submitted</th>
														<th></th>
													</tr>

													";

												}else{

													echo "

													<tr>
														<th></th>
														<th>Submitted By</th>
														<th>Submitted As</th>
														<th>File Name</th>
														<th>Location</th>
														<th>Date Added</th>
														<th>Status</th>
													</tr>

													";
													
												}
												//
											?>
											<tr class="warning no-result">
      											<td><i class="fa fa-warning"></i> No result</td>
   											</tr>
										</thead>
										<tbody id="myTable">
											<?php
												include "./data/connect.php";
												//
												$logun =  $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
												//
												$ctype = trim($_GET['type']);
												if ( trim($ctype)=="" ) {
													$ctype = "reflection";
												}
												//
												$fil_classid = trim($_GET['class_id']);
												$fil_weekn = trim($_GET['weekname']);
												$fil_stats = trim($_GET['status']);
												//
												$aqry = "";
												//
												if ( trim($fil_classid)!="" && 
													strtolower(trim($fil_classid))!=strtolower(trim("")) && 
													strtolower(trim($fil_classid))!=strtolower(trim("all")) 
													) {
													if ( trim($aqry)=="" ) {
														$aqry = " and uloc_id='" . trim($fil_classid) . "' ";
													}else{
														$aqry = " and uloc_id='" . trim($fil_classid) . "' ";
													}
												}
												if ( trim($fil_weekn)!=""  && 
													strtolower(trim($fil_weekn))!=strtolower(trim("")) && 
													strtolower(trim($fil_weekn))!=strtolower(trim("all"))
													) {
													if ( trim($aqry)=="" ) {
														$aqry = " and weekname='" . trim($fil_weekn) . "' ";
													}else{
														$aqry = " and weekname='" . trim($fil_weekn) . "' ";
													}
												}
												if ( trim($fil_stats)!=""  && 
													strtolower(trim($fil_stats))!=strtolower(trim("")) && 
													strtolower(trim($fil_stats))!=strtolower(trim("all"))
												 ) {
													if ( trim($aqry)=="" ) {
														$aqry = " and ap_status='" . trim($fil_stats) . "' ";
													}else{
														$aqry = " and ap_status='" . trim($fil_stats) . "' ";
													}
												}
												//
												$rateopt = "";
												$sql = " select no,rate from tbl_rate_score  order by rate asc  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[1])!="" ) {
														$rateopt = $rateopt . "<option value='".trim($dat[1])."'>".trim($dat[1])."<option>";
													}
												}
												//
												$xq = "";
												//
												if ( strtolower(trim($ctype))==strtolower(trim("reflection")) && ( trim($fil_classid)=="" || strtolower(trim($fil_classid))==strtolower(trim("all")) ) ) {
													$xq = "";
													//
													$sql = " select class_id from tbl_class_staff  where staff_type='$curidtype' and staff_id='$curid'  ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($xq)=="" ) {
															$xq = " uloc_id='$dat[0]' ";
														}else{
															$xq = $xq . " or uloc_id='$dat[0]' ";
														}
													}
													if ( trim($xq)!="" ) {
														$xq = " and ( uloc_type='class' ) and ( " . $xq . " ) ";
													}
												}
												//echo "$xq";
												//
												$subas = "";
								//////////////////////////////////////////////////////////////////////////
											//
											//
											//
											$hteidq = "";
											$studidq1 = "";
											if ( strtolower(trim($logutype))==strtolower(trim("employee")) ) {
												//GET USER HTE
												//                 0           1      2        3         4
												$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff where staff_id='$logun' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($hteidq)=="" ) {
														$hteidq = " hte_id='$dat[1]' ";
													}else{
														$hteidq = $hteidq . " || hte_id='$dat[1]' ";
													}
												}
												//
												if ( trim($hteidq)!="" ) {
													//
													$hteidq = " where " . $hteidq;
													//GET USERS IN HTE
													//                 0         1      2
													$sql = " select hte_mem_id,hte_id,member_id from tbl_hte_members $hteidq ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($studidq1)=="" ) {
															$studidq1 = " upby_id='$dat[2]' ";
														}else{
															$studidq1 = $studidq1 . " || upby_id='$dat[2]' ";
														}
													}
												}
												//
												//
											}
											if ( trim($studidq1)!="" ) {
												//
												$studidq1 = " and ( " . $studidq1 . " ) ";
											}
											//
											//
												//
												$nn = "";
								//////////////////////////////////////////////////////////////////////////
												//               0  1     2        3             4        5       6      7        8        9        10        11      12
												$sql = " select no,name,location,date_uploaded,upby_id,upby_type,utype,uloc_id,uloc_type,uloc2_id,ap_status,weekname,grade from tbl_upfiles where utype='$ctype' $aqry $xq $studidq1  order by no desc  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													//
													$subas = "";
													//
														$sql2 = " select name from tbl_user_requirements where studentid='$dat[4]' and req_file='$dat[2]' and date_added='$dat[3]'  ";
															$qry2 = mysqli_query($conn,$sql2);
															while($dat2=mysqli_fetch_array($qry2)) {
																$subas = trim($dat2[0]);
															}
													//
													$lnk = "";
													//
													$nn = trim($dat[0]);
													//
													$weekname = "";
													$td = trim($dat[11]);
													if ( trim($td)!="" ) {
														$tdd = explode("_", trim($td));
														$weekname = trim($tdd[0]) . " " . trim($tdd[1]);
													}
													//
													$name = "";
													$file = "";
													$fln = trim($dat[2]);
													if ( trim($fln)!="" ) {
														if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
															//IMAGE
															$file = "
																		<a class='' target='_blank' href='#' data-toggle='modal' data-target='#modalPrevImage_$nn'>$fln</a>
																		<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																			<img class='ann_img02' src='".trim($fln)."'/>
																		</div>
																	";
														}else{
															//NOT IMAGE
															$file = "<a target='_blank' href='".trim($fln)."'>".trim($fln)."</a>";
														}
													}
													//
													$locname = "";
													$loclink = "";
													//
													$apstat = trim($dat[10]);
													$tfstat = "";
														if ( trim($apstat)=="" ) {
															$tfstat = "<span class='label label-warning label-md'>Pending</span>";
														}else{
															if ( strtolower(trim($apstat))==strtolower(trim("approved")) ) {
																$tfstat = "<span class='label label-success label-md'>Approved</span>";
															}else{
																$tfstat = "<span class='label label-danger label-md'>Dis-Approved</span>";
															}
														}
													//
													$sql2 = "";
													//
													if ( trim($dat[5])!="" ) {
														if ( strtolower(trim($dat[5]))==strtolower(trim("coordinator")) ) {
															$lnk = "page_profile_employee.php";
															//
															$sql2 = " select firstname,middlename,lastname from tbl_employee where employee_id='$dat[4]'  ";
																$qry2 = mysqli_query($conn,$sql2);
																while($dat2=mysqli_fetch_array($qry2)) {
																	$name = trim($dat2[2]).", ".trim($dat2[0])." ".trim($dat2[1]);
																}
														}
														if ( strtolower(trim($dat[5]))==strtolower(trim("student")) ) {
															$lnk = "page_profile.php";
															//
															$sql2 = " select firstname,middlename,lastname from tbl_interns where studentid='$dat[4]'  ";
																$qry2 = mysqli_query($conn,$sql2);
																while($dat2=mysqli_fetch_array($qry2)) {
																	$name = trim($dat2[2]).", ".trim($dat2[0])." ".trim($dat2[1]);
																}														}
														if ( trim($dat[4])!="" ) {
															//GET NAME
														}
													}
													//
													if ( trim($dat[7])!="" ) {
														if ( strtolower(trim($dat[8]))==strtolower(trim("class")) ) {
															$loclink = "page_class.php";
															//
															$sql2 = " select class_id,name from tbl_class where class_id='$dat[7]'  ";
																$qry2 = mysqli_query($conn,$sql2);
																while($dat2=mysqli_fetch_array($qry2)) {
																	$locname = trim($dat2[1]);
																}
														}
													}
													//
													//
													//
													$topt = "";
													$topts1 = "";
													//
													//
													if ( strtolower(trim($logutype))!=strtolower(trim("student")) ) {
														if ( strtolower(trim($ctype))==strtolower(trim("reflection")) ) {

															$topt = "

																	<div class='dropdown'>
																	  <a class='btn_action_01' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																	  <ul class='dropdown-menu'>
																	    <li>
																	  		<form method='post' action=''>
																	  			<input type='hidden' name='txtid' value='$dat[0]' />
																	  			<input type='hidden' name='txtval' value='Approved' />
																	    	<input type='submit' name='btnupdateAStat' class='btn_opt01' value='Approve' />
																	    	</form>
																	    </li>
																	    <li class='divider'></li>
																	    <li>
																	  		<form method='post' action=''>
																	  			<input type='hidden' name='txtid' value='$dat[0]' />
																	  			<input type='hidden' name='txtval' value='Dis-Approved' />
																	    	<input type='submit' name='btnupdateAStat' class='btn_opt01' value='Dis-Approve' />
																	    	</form>
																	    </li>
																	    <li class='divider'></li>
																	    <li><a href='#' data-toggle='modal' data-target='#modalrate_$nn'>Grade</a></li>
																	  </ul>
																	</div>

																	    <div id='modalrate_$nn' class='modal fade' role='dialog'>
																	      <div class='modal-dialog'>
																	      <!-- Modal content-->
																	      <div class='modal-content'>
																	      <div class='modal-header'>
																	        <button type='button' class='close' data-dismiss='modal'>&times;</button>
																	        <h4 class='modal-title'>Grade</h4>
																	      </div>
																	          <form method='post' action=''>
																	      <div class='modal-body'>
																	        <p>
																						<input type='hidden' name='txtid' value='$dat[0]'/>
																	          	<select name='txtgrade' class='form-control txt01'>
																	          		$rateopt
																	          	<select>
																	        </p>
																	      </div>
																	      <div class='modal-footer'>
																	        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																	        <input type='submit' name='btnsaveGrade' class='btn btn-primary btn-lg btn01' value='SAVE GRADE'>
																	      </div>
																	          </form>
																	      </div>

																	      </div>
																	    </div>

															";

														}else{

															$topt = "

																	<div class='dropdown'>
																	  <a class='btn_action_01' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																	  <ul class='dropdown-menu'>
																	    <li>
																	  		<form method='post' action=''>
																	  			<input type='hidden' name='txtid' value='$dat[0]' />
																	  			<input type='hidden' name='txtval' value='Approved' />
																	    	<input type='submit' name='btnupdateAStat' class='btn_opt01' value='Approve' />
																	    	</form>
																	    </li>
																	    <li class='divider'></li>
																	    <li>
																	  		<form method='post' action=''>
																	  			<input type='hidden' name='txtid' value='$dat[0]' />
																	  			<input type='hidden' name='txtval' value='Dis-Approved' />
																	    	<input type='submit' name='btnupdateAStat' class='btn_opt01' value='Dis-Approve' />
																	    	</form>
																	    </li>																	  </ul>
																	</div>


															";
															
														}
													}
													//
												if ( strtolower(trim($ctype))==strtolower(trim("reflection")) ) {
													echo "
														<tr>
															<td>
																$topt
															</td>
															<td>
																".trim($dat[12])."
															</td>
															<td>
																<a href='".$lnk."?id=".trim($dat[4])."'>
																<span class='span02'>".trim($name)."</span>
																</a>
															</td>
															<td>
																<a href='".$loclink."?id=".trim($dat[7])."'>
																<span class='span02'>".trim($locname)."</span>
																</a>
															</td>
															<td>
																<span class='span02'>".trim($weekname)."</span>
															</td>
															<td>
																".trim($dat[1])."
															</td>
															<td>
																$file
															</td>
															<td>
																".trim($dat[3])."
															</td>
															<td>
																".trim($dat[6])."
															</td>
															<td>
																$tfstat
															</td>
														</tr>
													";
												}
												if ( strtolower(trim($ctype))!=strtolower(trim("reflection")) ) {
													echo "
														<tr>
															<td>
																$topt
															</td>
															<td>
																<a href='".$lnk."?id=".trim($dat[4])."'>
																<span class='span02'>".trim($name)."</span>
																</a>
															</td>
															<td>
																".trim($subas)."
															</td>
															<td>
																".trim($dat[1])."
															</td>
															<td>
																$file
															</td>
															<td>
																".trim($dat[3])."
															</td>
															<td>
																$tfstat
															</td>
														</tr>
													";
												}
												//
												}
											?>
											
											
										</tbody>
									</table>
								</div>
							
							</div>
					
							<!-- END TABLE NO PADDING -->
						
					</div>
					
					
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>

<script>
/*	
	$(document).ready(function() {
  $(".search").keyup(function () {
    var searchTerm = $(".search").val();
    var listItem = $('.results tbody').children('tr');
    var searchSplit = searchTerm.replace(/ /g, "'):containsi('")
    
  $.extend($.expr[':'], {'containsi': function(elem, i, match, array){
        return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
    }
  });
    
  $(".results tbody tr").not(":containsi('" + searchSplit + "')").each(function(e){
    $(this).attr('visible','false');
  });

  $(".results tbody tr:containsi('" + searchSplit + "')").each(function(e){
    $(this).attr('visible','true');
  });

  var jobCount = $('.results tbody tr[visible="true"]').length;
    $('.counter').text(jobCount + ' item');

  if(jobCount == '0') {$('.no-result').show();}
    else {$('.no-result').hide();}
		  });
});*/

$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

</script>


<?php
	include "./parts/btm_script.php";
?>

</body>

</html>
