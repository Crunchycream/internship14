<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php"; include "./parts/sys_functions_generatecode.php"; 
	$_SESSION['intern_page_current'] = "manage_attcode";
		include "./parts/main_logcheck.php";
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	if ( $_POST['btnsave'] ) {
		$attcode = $_POST['attcode'];
		$mae = $_POST['mae'];
		$typ = $_POST['typ'];
		$tdate = $_POST['tdate'];
		//
		$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
		//
		$errn = 0;
		$errmsg = "";
		//
		if ( trim($attcode) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Code required. ";
		}
		if ( trim($tdate) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Target date required. ";
		}
		//
		$ec = 0;
		$sql = " select * from tbl_attcode  where attcode='$attcode' and mae='$mae' and ltype='$typ' and tdate='$tdate' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			$ec = $ec + 1;
		}
		if ( trim($ec) > 0 ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Code already exist. ";
		}
		if ( $errn <= 0 ) {
			//SAVE DATA
			$sql = " insert into tbl_attcode 
						(attcode,mae,ltype,adate,tdate)
						values
						('$attcode','$mae','$typ','$cdate','$tdate')
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
			echo "
				<script>
					alert('$errmsg');
				</script>
			";
		}
	}
	//
	if ( $_POST['btnsaveEdit'] ) {
		$cid = $_POST['txtid'];
		//
		$attcode = $_POST['attcode'];
		$mae = $_POST['mae'];
		$typ = $_POST['typ'];
		$tdate = $_POST['tdate'];
		//
		$errn = 0;
		$errmsg = "";
		if ( trim($attcode) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Code required. ";
		}
		if ( $errn <= 0 ) {
			//SAVE DATA
			$sql = " update tbl_attcode set 
						attcode='$attcode',mae='$mae',ltype='$typ',tdate='$tdate' 
							where attcode_id='$cid'
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
			echo "
				<script>
					alert('$errmsg');
				</script>
			";
		}
	}
	if ( $_POST['btnsaveDelete'] ) {
		$cid = $_POST['txtid'];
		//
		$errn = 0;
		if ( $errn <= 0 ) {
			//SAVE DATA
			$sql = " delete from tbl_attcode 
						where attcode_id='$cid'
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
			echo "
				<script>
					alert('$errmsg');
				</script>
			";
		}
	}
	//
	//
	if ( $_POST['btnsaveAttCode2'] ) {
		//
		$mae_1 = $_POST['mae_1'];
		$mae_2 = $_POST['mae_2'];
		$mae_3 = $_POST['mae_3'];
		//
		$io_1 = $_POST['io_1'];
		$io_2 = $_POST['io_2'];
		//
		$csameio = $_POST['csameio'];
		$csameall = $_POST['csameall'];
		//
		$tdate = $_POST['tdate'];
		//
		$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
		//
		$code_mi = generateCode(6);
		$code_mo = generateCode(6);
		//
		$code_ai = generateCode(6);
		$code_ao = generateCode(6);
		//
		$code_ei = generateCode(6);
		$code_eo = generateCode(6);
		//
		//
		$errn = 0;
		$errmsg = "";
		//
		//
		if ( trim($tdate) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Target date required. ";
		}
		//
		//
		if ( $errn <= 0 ) {
			//
			//SAVE DATA
			//
			if ( strtolower(trim($mae_1))==strtolower(trim("morning")) ) {
				if ( strtolower(trim($csameio))!=strtolower(trim("same")) && strtolower(trim($csameall))!=strtolower(trim("same")) ) {
					if ( strtolower(trim($io_1))==strtolower(trim("in")) ) {
						//IN
						$sql = " insert into tbl_attcode 
									(attcode,mae,ltype,adate,tdate)
									values
									('$code_mi','MORNING','IN','$cdate','$tdate')
								";
						$qry = mysqli_query($conn,$sql);
					}
					if ( strtolower(trim($io_2))==strtolower(trim("out")) ) {
						//OUT
						$sql = " insert into tbl_attcode 
									(attcode,mae,ltype,adate,tdate)
									values
									('$code_mo','MORNING','OUT','$cdate','$tdate')
								";
						$qry = mysqli_query($conn,$sql);
					}
				}else{
						//IN
						$sql = " insert into tbl_attcode 
									(attcode,mae,ltype,adate,tdate)
									values
									('$code_mi','MORNING','IN','$cdate','$tdate')
								";
						$qry = mysqli_query($conn,$sql);
						//OUT
						$sql = " insert into tbl_attcode 
									(attcode,mae,ltype,adate,tdate)
									values
									('$code_mi','MORNING','OUT','$cdate','$tdate')
								";
						$qry = mysqli_query($conn,$sql);
				}
			}
			//
			if ( strtolower(trim($mae_2))==strtolower(trim("afternoon")) ) {
				if ( strtolower(trim($csameio))!=strtolower(trim("same")) && strtolower(trim($csameall))!=strtolower(trim("same")) ) {
					if ( strtolower(trim($io_1))==strtolower(trim("in")) ) {
						//IN
						$sql = " insert into tbl_attcode 
									(attcode,mae,ltype,adate,tdate)
									values
									('$code_ai','AFTERNOON','IN','$cdate','$tdate')
								";
						$qry = mysqli_query($conn,$sql);
					}
					if ( strtolower(trim($io_2))==strtolower(trim("out")) ) {
						//OUT
						$sql = " insert into tbl_attcode 
									(attcode,mae,ltype,adate,tdate)
									values
									('$code_ao','AFTERNOON','OUT','$cdate','$tdate')
								";
						$qry = mysqli_query($conn,$sql);
					}
				}else{
						//IN
						$sql = " insert into tbl_attcode 
									(attcode,mae,ltype,adate,tdate)
									values
									('$code_ai','AFTERNOON','IN','$cdate','$tdate')
								";
						$qry = mysqli_query($conn,$sql);
						//OUT
						$sql = " insert into tbl_attcode 
									(attcode,mae,ltype,adate,tdate)
									values
									('$code_ai','AFTERNOON','OUT','$cdate','$tdate')
								";
						$qry = mysqli_query($conn,$sql);
				}
			}
			//
			if ( strtolower(trim($mae_3))==strtolower(trim("evening")) ) {
				if ( strtolower(trim($csameio))!=strtolower(trim("same")) && strtolower(trim($csameall))!=strtolower(trim("same")) ) {
					if ( strtolower(trim($io_1))==strtolower(trim("in")) ) {
						//IN
						$sql = " insert into tbl_attcode 
									(attcode,mae,ltype,adate,tdate)
									values
									('$code_ei','EVENING','IN','$cdate','$tdate')
								";
						$qry = mysqli_query($conn,$sql);
					}
					if ( strtolower(trim($io_2))==strtolower(trim("out")) ) {
						//OUT
						$sql = " insert into tbl_attcode 
									(attcode,mae,ltype,adate,tdate)
									values
									('$code_eo','EVENING','OUT','$cdate','$tdate')
								";
						$qry = mysqli_query($conn,$sql);
					}
				}else{
						//IN
						$sql = " insert into tbl_attcode 
									(attcode,mae,ltype,adate,tdate)
									values
									('$code_ei','EVENING','IN','$cdate','$tdate')
								";
						$qry = mysqli_query($conn,$sql);
						//OUT
						$sql = " insert into tbl_attcode 
									(attcode,mae,ltype,adate,tdate)
									values
									('$code_ei','EVENING','OUT','$cdate','$tdate')
								";
						$qry = mysqli_query($conn,$sql);
				}
			}
			//
			//
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
			echo "
				<script>
					alert('$errmsg');
				</script>
			";
		}
	}
	//
	//
	//
	include "./sys_load_active_sy.php";
	//
	//
	if ( trim($logun)=="" || strtolower(trim($logutype))==strtolower(trim("student")) ) {
		exit;
	}
?>

<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>


</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">Attendance Codes</h3>
					<div class="row">

<!-- ====================== MODAL ============================================== -->

    <div id="modalAddAttCode" class="modal fade" role="dialog">
      <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add Attendance Code</h4>
      </div>
          <form method="post" action="">
      <div class="modal-body">
        <p>
          <div class="form-group">
              <?php echo $_SESSION['intern_disp_err']; $_SESSION['intern_disp_err'] = ""; ?>
            </div>

            <div class="form-group div01">
              <label for="code" class="control-label sr-only">Code</label>
              <input type="text" name="attcode" class="form-control txt01" id="code" placeholder="Code"
                <?php
                  $value = $_POST['attcode'];
                  echo " value='$value' ";
                ?>
              >
            </div>

			<table width="100%">
				<tr>
					<td>
						<select name="mae" class="form-control" >
							<option value="MORNING">MORNING</option>
							<option value="AFTERNOON">AFTERNOON</option>
							<option value="EVENING">EVENING</option>
						</select>
					</td>
					<td>
						<select name="typ" class="form-control" >
							<option value="IN">IN</option>
							<option value="OUT">OUT</option>
						</select>
					</td>
				</tr>
			</table>

            <div class="form-group div01">
              <label for="tdate" class="control-label sr-only">Target Date</label>
              <input type="date" name="tdate" class="form-control txt01" id="tdate" placeholder="Target Date"
                <?php
                  $value = $_POST['tdate'];
                  echo " value='$value' ";
                ?>
              >
            </div>

        </p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <input type="submit" name="btnsave" class="btn btn-primary btn-lg btn01" value="SAVE">
      </div>
          </form>
      </div>

      </div>
    </div>

    <div id="modalAddAttCode2" class="modal fade" role="dialog">
      <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add Auto-Generated Attendance Code</h4>
      </div>
          <form method="post" action="">
      <div class="modal-body">
        <p>
          <div class="form-group">
              <?php echo $_SESSION['intern_disp_err']; $_SESSION['intern_disp_err'] = ""; ?>
            </div>


            <table>
            	<tr>
            		<td>
						<label class="fancy-checkbox">
							<input type="checkbox" name="mae_1" value="MORNING" checked="true">
							<span>Morning</span>
						</label>
            		</td>
            		<td class="tblspace01">
						<label class="fancy-checkbox">
							<input type="checkbox" name="mae_2" value="AFTERNOON" checked="true">
							<span>Afternoon</span>
						</label>
            		</td>
            		<td class="tblspace01">
						<label class="fancy-checkbox">
							<input type="checkbox" name="mae_3" value="EVENING" checked="true">
							<span>Evening</span>
						</label>
            		</td>
            	</tr>
            </table>

            <table>
            	<tr>
            		<td>
						<label class="fancy-checkbox">
							<input type="checkbox" name="io_1" value="IN" checked="true">
							<span>IN</span>
						</label>
            		</td>
            		<td class="tblspace01">
						<label class="fancy-checkbox">
							<input type="checkbox" name="io_2" value="OUT" checked="true">
							<span>OUT</span>
						</label>
            		</td>
            	</tr>
            </table>

            <div class="form-group div01">
              <label for="tdate" class="control-label sr-only">Target Date</label>
              <input type="date" name="tdate" class="form-control txt01" id="tdate" placeholder="Target Date"
                <?php
                  $value = $_POST['tdate'];
                  echo " value='$value' ";
                ?>
              >
            </div>

				<label class="fancy-checkbox">
					<input type="checkbox" name="csameio" value="same">
					<span>Same IN/OUT Code</span>
				</label>

				<label class="fancy-checkbox">
					<input type="checkbox" name="csameall" value="same">
					<span>Same All Code</span>
				</label>

        </p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <input type="submit" name="btnsaveAttCode2" class="btn btn-primary btn-md btn01" value="SAVE">
      </div>
          </form>
      </div>

      </div>
    </div>

<!-- ====================== MODAL ============================================== -->


						<div class="col-md-12">
							<!-- BASIC TABLE -->
							<div class="row">
							<div class="col-md-9">
							<h5 class="ss">Search:</h5>
							</div>
						
							
							<div class="col-md-3">
							<div class="form-group pull-right">
							<input type="text" id="myInput1" value="" class="search form-control" placeholder="What you looking for">
							<!--	<span class="counter pull-right"><button type="button" class="btn btn-primary">Search</button></span>-->
								</div>
									<span class="counter pull-right"></span>
									</div>
						</div>
						<hr>

					<a href="" data-toggle="modal" data-target="#modalAddAttCode" class="btn btn-success btn-md">+ ADD ATTENDANCE CODE</a>
					<a href="" data-toggle="modal" data-target="#modalAddAttCode2" class="btn btn-success btn-md">+ ADD AUTO-GENERATED CODE</a>
					
					<br/>
					<br/>
				
							<!-- RECENT PURCHASES -->
							<div class="panel">
					
								<div class="table-responsive">
									<table class="table">
										<thead>
											<tr>
												<th></th>
												<th>ID</th>
												<th>Attendance Code</th>
												<th>Morning/Afternoon/Evening</th>
												<th>In/Out</th>
												<th>Target Date</th>
											</tr>
										</thead>
										<tbody id="myTable1">
											<?php
												//
												$nn = 0;
												//
												include "./data/connect.php";
												//                 0         1      2   3      4    5
												$sql = " select attcode_id,attcode,mae,ltype,tdate,adate from tbl_attcode  order by attcode_id desc ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$nn = strval(trim($dat[0]));
													echo "
														<tr>
															<td>
															
																<div class='dropdown'>
																  <a class='btn_action_01' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu'>
																    <li><a href='#' data-toggle='modal' data-target='#modalEdit_$nn'>Edit</a></li>
																    <li><a href='#' data-toggle='modal' data-target='#modalDelete_$nn'>Delete</a></li>
																  </ul>
																</div>

																    <div id='modalEdit_$nn' class='modal fade' role='dialog'>
																      <div class='modal-dialog'>
																      <!-- Modal content-->
																      <div class='modal-content'>
																      <div class='modal-header'>
																        <button type='button' class='close' data-dismiss='modal'>&times;</button>
																        <h4 class='modal-title'>Update</h4>
																      </div>
																          <form method='post' action=''>
																      <div class='modal-body'>
																        <p>
																					<input type='hidden' name='txtid' value='$dat[0]'/>
																																             
																            <div class='form-group div01'>
																              <label for='code' class='control-label sr-only'>Code</label>
																              <input type='text' name='attcode' class='form-control txt01' id='code' placeholder='Code'
																                 value='$dat[1]' 
																              >
																            </div>

																			<table width='100%'>
																				<tr>
																					<td>
																						<select name='mae' class='form-control' >
																							<option value='MORNING'>MORNING</option>
																							<option value='AFTERNOON'>AFTERNOON</option>
																							<option value='EVENING'>EVENING</option>
																						</select>
																					</td>
																					<td>
																						<select name='typ' class='form-control' >
																							<option value='IN'>IN</option>
																							<option value='OUT'>OUT</option>
																						</select>
																					</td>
																				</tr>
																			</table>

																            <div class='form-group div01'>
																              <label for='tdate' class='control-label sr-only'>Target Date</label>
																              <input type='date' name='tdate' class='form-control txt01' id='tdate' placeholder='Target Date'
																                 value='$dat[4]' 
																              >
																            </div>

																        </p>
																      </div>
																      <div class='modal-footer'>
																        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																        <input type='submit' name='btnsaveEdit' class='btn btn-primary btn-lg btn01' value='SAVE'/>
																      </div>
																          </form>
																      </div>

																      </div>
																    </div>

																		<div id='modalDelete_$nn' class='modal fade' role='dialog'>
																			<div class='modal-dialog'>
																			<!-- Modal content-->
																				<div class='modal-content'>
																					<div class='modal-header'>
																						<button type='button' class='close' data-dismiss='modal'>&times;</button>
																						<h4 class='modal-title'>Delete</h4>
																					</div>
																						<form method='post' action=''>
																					<div class='modal-body'>
																						<p>
																							<input type='hidden' name='txtid' value='$dat[0]'/>
																							Delete code?
																						</p>
																					</div>
																					<div class='modal-footer'>
																						<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																						<input type='submit' name='btnsaveDelete' class='btn btn-primary btn-lg btn01' value='DELETE'>
																					</div>
																						</form>
																				</div>

																			</div>
																		</div>

															</td>
															<td>
																".trim($dat[0])."
															</td>
															<td>
																".trim($dat[1])."
															</td>
															<td>
																".trim($dat[2])."
															</td>
															<td>
																".trim($dat[3])."
															</td>
															<td>
																".trim($dat[4])."
															</td>
														</tr>
													";
												}
											?>
											
										</tbody>
									</table>
								</div>
							</div>
					
							<!-- END TABLE NO PADDING -->
						</div>
					</div>
								
					
				
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>

	<script >
	$(document).ready(function(){
  $("#myInput1").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable1 tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
	</script>

	
<?php
	include "./parts/btm_script.php";
?>


</body>

</html>
