<?php include "./data/connect.php";
	//
	$cid = trim($_GET['id']);
	$sy = trim($_SESSION['intern_data_active_sy']);
	//echo "$cid $sy";
	//
	$cname = array();
	$cval = array();
	$cvalcount = array();
	//
	$cn = 0;
	//
	if ( trim($cid)!="" ) {
		//GET CRITERIA BASED ON SY
		//                     0              1    2   3
		$sql = " select hte_eval_criteria_id,name,sy,adate from tbl_hte_eval_criteria  where hte_id='$cid' and sy='$sy' group by name order by hte_eval_criteria_id asc ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			if ( trim($dat[1])!="" ) {
				$cname[$cn] = trim($dat[1]);
				$cn += 1;
			}
		}
		//
		$cn = 0;
		$vc = 0;
		//
		//GET CRITERIA POINTS
		for ( $i=0 ; $i<count($cname) ; $i++ ) {
			//GET RATING
				$tv = 0;
				$vc = 0;
			//                     0              1             2       3            4      5
			$sql = " select hte_eval_progcomp_id,hte_eval_id,prog_comp,num_hours,eval_rate,sy from tbl_hte_eval_progcomp  where hte_id='$cid' and prog_comp='".$cname[$i]."' and sy='$sy' order by hte_eval_progcomp_id asc ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				$tv = $tv + strval(trim($dat[4]));
				$vc += 1;
				//
			}
			//
			$cval[$i] = $tv;
			$cvalcount[$i] = $vc;
		}
		//echo " $cval[0] - $cvalcount[0]";
		//
		$cn = 0;
		for ( $i=0 ; $i<count($cname) ; $i++ ) {
			if ( trim($cname[$i])!="" ) {
				//
				$cn += 1;
				//
				$tv = 0;
				//
				$tv = strval($cval[$i]);
				if ( strval($cvalcount[$i]) > 0 ) {
					$tv = strval($cval[$i]) / strval($cvalcount[$i]);
				}
				//
				echo "<input type='hidden' id='hte_eval_data_name_$cn' value='$cname[$i]' readonly='true' />";
				echo "<input type='hidden' id='hte_eval_data_value_$cn' value='$tv' readonly='true' />";
				//
			}
		}
				echo "<input type='hidden' id='hte_eval_data_count' value='$cn' readonly='true' />";
	}
	//
?>