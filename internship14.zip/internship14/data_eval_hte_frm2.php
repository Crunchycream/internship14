<?php include "./data/connect.php";
	//
	$cid = trim($_GET['id']);
	$sy = trim($_SESSION['intern_data_active_sy']);
	//echo "$cid $sy";
	//
	$cname = array();
	$cval = array();
	$comm = array();
	$cvalcount = array();
	//
	$cval[0] = 0;
	$cval[1] = 0;
	$cval[2] = 0;
	$cval[3] = 0;
	$cval[4] = 0;
	$cval[5] = 0;
	$cval[6] = 0;
	$cval[7] = 0;
	//
	$cval[8] = 0;
	$cval[9] = 0;
	$cval[10] = 0;
	$cval[11] = 0;
	$cval[12] = 0;
	$cval[13] = 0;
	$cval[14] = 0;
	$cval[15] = 0;
	//
	$cval[16] = 0;
	$cval[17] = 0;
	$cval[18] = 0;
	$cval[19] = 0;
	$cval[20] = 0;
	$cval[21] = 0;
	//
	$cn = 0;
	//
	if ( trim($cid)!="" ) {
		//GET CRITERIA BASED ON SY
		//                     0      1    2    3           4              5     6        7      
		$sql = " select hte_eval_id,hte_id,sy,evaluator_id,evaluator_type,adate,crit_1_1,crit_1_2,crit_1_3,crit_1_4,crit_1_5,crit_1_6,crit_1_7,crit_1_8,crit_2_1,crit_2_2,crit_2_3,crit_2_4,crit_2_5,crit_2_6,crit_2_7,crit_2_8,crit_3_1,crit_3_2,crit_3_3,crit_3_4,crit_3_5,crit_3_6,comments from tbl_hte_eval2  where hte_id='$cid' and sy='$sy' order by hte_eval_id asc ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			//
			$cval[0] = strval($cval[0]) + strval(trim($dat[6]));
			$cval[1] = strval($cval[1]) + strval(trim($dat[7]));
			$cval[2] = strval($cval[2]) + strval(trim($dat[8]));
			$cval[3] = strval($cval[3]) + strval(trim($dat[9]));
			$cval[4] = strval($cval[4]) + strval(trim($dat[10]));
			$cval[5] = strval($cval[5]) + strval(trim($dat[11]));
			$cval[6] = strval($cval[6]) + strval(trim($dat[12]));
			$cval[7] = strval($cval[7]) + strval(trim($dat[13]));
			//
			$cval[8] = strval($cval[8]) + strval(trim($dat[14]));
			$cval[9] = strval($cval[9]) + strval(trim($dat[15]));
			$cval[10] = strval($cval[10]) + strval(trim($dat[16]));
			$cval[11] = strval($cval[11]) + strval(trim($dat[17]));
			$cval[12] = strval($cval[12]) + strval(trim($dat[18]));
			$cval[13] = strval($cval[13]) + strval(trim($dat[19]));
			$cval[14] = strval($cval[14]) + strval(trim($dat[20]));
			$cval[15] = strval($cval[15]) + strval(trim($dat[21]));
			//
			$cval[16] = strval($cval[16]) + strval(trim($dat[22]));
			$cval[17] = strval($cval[17]) + strval(trim($dat[23]));
			$cval[18] = strval($cval[18]) + strval(trim($dat[24]));
			$cval[19] = strval($cval[19]) + strval(trim($dat[25]));
			$cval[20] = strval($cval[20]) + strval(trim($dat[26]));
			$cval[21] = strval($cval[21]) + strval(trim($dat[27]));
			//
			//
			$cn += 1;
			//
		}
		//
		//
		$cname[0] = "<b>conducts orientation with the student trainees</b>";
		$cname[1] = "<b>is approachable</b>";
		$cname[2] = "<b>is skillful in all areas in the department</b>";
		$cname[3] = "<b>answers questions/clarifications clearly and direct to the point</b>";
		$cname[4] = "<b>is fair in dealing student-trainees</b>";
		$cname[5] = "<b>shows willingness and interest in teaching student-trainees</b>";
		$cname[6] = "<b>schedules meetings with student trainees regularly</b>";
		$cname[7] = "<b>gives clear instructions</b>";
		//
		$cname[8] = "<b>have the complete equipment/facilities needed for the acquisition of specific skills</b>";
		$cname[9] = "<b>are open for student trainees to use</b>";
		$cname[10] = "<b>are all operational/functional</b>";
		$cname[11] = "<b>are free from pollution</b>";
		$cname[12] = "<b>have good ventilation</b>";
		$cname[13] = "<b>have good lighting</b>";
		$cname[14] = "<b>have updated work manuals accesible to student trainees</b>";
		$cname[15] = "<b>instructions are posted in conspicuous places in the halls/rooms</b>";
		//
		$cname[16] = "<b>has satisfactorily transferred the skills to the student trainees</b>";
		$cname[17] = "<b>takes care of the welfare of the student trainees</b>";
		$cname[18] = "<b>assigns specific supervisor for the student trainees</b>";
		$cname[19] = "<b>in general, has satisfactorily improved the competencies/skills the student trainees need</b>";
		$cname[20] = "<b>staff are friendly and appropriate</b>";
		$cname[21] = "<b>the company promotes and demonstrates the university core values - Excelence; Honesty and Integrity; Innovation; Teamwork</b>";
		//
		//
		for ( $i=0 ; $i<22 ; $i++ ) {
			if ( $cval[$i] > 0 ) {
				$cval[$i] = strval($cval[$i]) / $cn;
			}
			//
				echo "<input type='hidden' id='eval_data_name_$i' value='".$cname[$i]."' readonly='true' />";
				echo "<input type='hidden' id='eval_data_value_$i' value='".$cval[$i]."' readonly='true' />";
		}
		//
		//
	}
	//
?>