<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
      $cid = trim($_GET['id']);
      if ( trim($cid)!="" ) {
        //
        $name = "";
        $info = "";
        $lati = "";
        $longi = "";
        //
        //                 0    1    2       3       4                5        
        $sql = " select hte_id,name,address,info,map_loc_latitude,map_loc_longitude from tbl_hte where hte_id='$cid'  limit 1 ";
        //$sql = " select hte_id,name,address,info,map_loc_latitude,map_loc_longitude from tbl_hte  where hte_id='$curid' ";
        $qry = mysqli_query($conn,$sql);
        while($dat=mysqli_fetch_row($qry)) {
          $name = trim($dat[1]);
          $info = trim($dat[3]);
          $lati = trim($dat[4]);
          $longi = trim($dat[5]);
        }
        //
        //
        if ( trim($lati)=="" || trim($longi)=="" ) {
          exit;
        }
      }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <title>Map</title>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
    </style>
  </head>
  <body>

    <div id="map"></div>

    <?php include "./data/connect.php";
      $cid = trim($_GET['id']);
      if ( trim($cid)!="" ) {
        //
        $name = "";
        $info = "";
        $lati = "";
        $longi = "";
        //
        //                 0    1    2       3       4                5        
        $sql = " select hte_id,name,address,info,map_loc_latitude,map_loc_longitude from tbl_hte where hte_id='$cid'  limit 1 ";
        //$sql = " select hte_id,name,address,info,map_loc_latitude,map_loc_longitude from tbl_hte  where hte_id='$curid' ";
        $qry = mysqli_query($conn,$sql);
        while($dat=mysqli_fetch_row($qry)) {
          $name = trim($dat[1]);
          $info = trim($dat[3]);
          $lati = trim($dat[4]);
          $longi = trim($dat[5]);
        }
        //
        //
        echo "
              <input type='hidden' id='d_name' value='$name' >
              <input type='hidden' id='d_latitude' value='$lati' >
              <input type='hidden' id='d_longitude' value='$longi' >
              <textarea style='visibility:hidden;' id='d_info'>$info</textarea>
        ";
      }
    ?>

    <script>

      // This example displays a marker at the center of Australia.
      // When the user clicks the marker, an info window opens.
      var cid;
      var dname = document.getElementById('d_name').value;
      var dlati = parseFloat( document.getElementById('d_latitude').value );
      var dlongi = parseFloat( document.getElementById('d_longitude').value );
      var dinfo = document.getElementById('d_info').value;
      var dinfo2 = "";

      if ( dinfo.trim()!="" ) {
        dinfo2 = '<b>' + dname + '</b>' + dinfo;
      }

      //alert(dlati + " " + dlongi + " " + dinfo);

      //var smdata;
      //smdata = "<iframe src='data_map_info.php'></iframe>";
      //alert(smdata[0]);

      //function getdata() {
        //$.getJSON('./data_map_info.php?id=1', function (data) {
          // begin accessing JSON data here
            //alert("XXXXX");
            //alert(data[0]);
        //});
      //};

        //$.ajax({                                      
         // url: './data_map_info.php?id=1',
          //data1: "",
          
         // dataType: 'json',
          //success: function(data1)
          //{
              //dname = data1[1];
          //    alert("VVV");
         // }
        //}); 

      function initMap() {

        var $_GET = {};
        document.location.search.replace(/\??(?:([^=]+)=([^&]*)&?)/g, function () {
        function decode(s) {
        return decodeURIComponent(s.split("+").join(" "));
        }
        $_GET[decode(arguments[1])] = decode(arguments[2]);
        });
        //alert($_GET['id']);
        cid = $_GET['id'];
        
         //alert(cid);
         
        //$.ajax({                                      
         // url: './data_map_info.php?id=' + cid,
         // data1: "",
          
         // dataType: 'json',
         // success: function(data1)
         // {
         //     dname = data1[1];
         //     alert(data1);
         // } 
        //});
         //$.getJSON("data_map_info.php", function(json){
         //alert("dname");
               //do some thing with json  or assign global variable to incoming json. 
          //      dname=json[0];
          //      alert(dname);
          //});

        //
        var loca = {lat: dlati, lng: dlongi};
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 15,
          center: loca
        });

        var contentString = '<div id="content">'+
            '<div id="siteNotice">'+
            '</div>'+
            '<h1 id="firstHeading" class="firstHeading">' + dname +'</h1>'+
            '<div id="bodyContent">'+
            '<p>' + dinfo2 +
            '</p>'+
            '</div>'+
            '</div>';

        var infowindow = new google.maps.InfoWindow({
          content: contentString
        });

        var marker = new google.maps.Marker({
          position: loca,
          map: map,
          draggable:false,
          title: 'Uluru (Ayers Rock)'
        });
        marker.addListener('click', function() {
          infowindow.open(map, marker);
        });
      }
      //alert(cid);
            //alert("XXXXX");

    </script>
   <script async defer
src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAe0TDpjcFA9M6zRYBkEXj9UprpQDqiro8&callback=initMap&z=100">
</script>
  </body>
</html>