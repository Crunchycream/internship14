
					<!-- OVERVIEW -->
					<div class="panel panel-headline">
						<div class="panel-heading">
							<h3 class="panel-title">Online Internship Management System</h3>
						<p class="panel-subtitle"> </p>
						</div>
						<div class="panel-body">
							<div class="row">
								<div class="col-md-6">
									<div class="metric">
										<span class="icon"><i class="lnr lnr-users"></i></span>
										<p>
											<span class="number">
											<?php include "./data/connect.php";
												//GET INTERNS
												$count = 0;
												$sql = " select * from tbl_interns ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$count = $count + 1;
												}
												echo "$count";
											?>
											</span>
											<span class="title">Interns</span>
										</p>
									</div>
								</div>
								<div class="col-md-6" >
									<div class="metric" >
										<span class="icon"><i class="lnr lnr-apartment"></i></span>
										<p>
											<span class="number">
											<?php include "./data/connect.php";
												//GET HTE
												$count = 0;
												$sql = " select * from tbl_hte ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$count = $count + 1;
												}
												echo "$count";
											?>
											</span>
											<span class="title">Host Training Establishment</span>
										</p>
									</div>
								</div>
							</div>

							
						<div class="panel-body">
							
						</div>
					


							<div class="row">
								
							</div>
						</div>
					</div>
					<!-- END OVERVIEW -->

					<?php include "./data/connect.php";
						//
						$logun =  $_SESSION['intern_data_cun'];
						$logutype = $_SESSION['intern_data_utype'];
						//
						$cn = 0;
						//
						if ( strtoupper(trim($logutype))==strtoupper(trim("employee")) ) {
						//echo "$logun $logutype";
							$sql = " select crs_staff_id,crs_id,staff_id,staff_type,position from tbl_crs_staff where staff_id='$logun' and staff_type='$logutype' and position='admin' ";
							$qry = mysqli_query($conn,$sql);
							while($dat=mysqli_fetch_array($qry)) {
								$cn += 1;
							}
						}
						//
						if ( strtolower(trim($logun))==strtolower(trim("admin")) || strtolower(trim($logutype))==strtolower(trim("admin")) ) {
							$cn += 1;
						}
						//
						//
						if ( $cn > 0 ) {
							include "./cpanel_stats.php";
						}
						//
					?>


					<div class="row">
						<div class="col-md-7">
							<!-- RECENT PURCHASES -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Interns</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
										
									</div>
								</div>
								<div class="panel-body no-padding">
								<div class="table-responsive">
									<table class="table table-striped">
										<thead>
											<tr>
												<th>Last Name</th>
												<th>First Name</th>
												<th>Company</th>
												<th>Deficit</th>
												<th>Status</th>
											</tr>
										</thead>
										<tbody>
											<?php
												include "./data/connect.php";
														include "./parts/sys_functions_03.php";
												//
												//
											//
											//
											$logun =  $_SESSION['intern_data_cun'];
											$logutype = $_SESSION['intern_data_utype'];
											//
											//
											$xq = "";
											$hteidq = "";
											$studidq1 = "";
											if ( strtolower(trim($logutype))==strtolower(trim("employee")) ) {
												//GET USER HTE
												//                 0           1      2        3         4
												$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff where staff_id='$logun' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($hteidq)=="" ) {
														$hteidq = " hte_id='$dat[1]' ";
													}else{
														$hteidq = $hteidq . " || hte_id='$dat[1]' ";
													}
												}
												//
												if ( trim($hteidq)!="" ) {
													//
													$hteidq = " where " . $hteidq;
													//GET USERS IN HTE
													//                 0         1      2
													$sql = " select hte_mem_id,hte_id,member_id from tbl_hte_members $hteidq ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($studidq1)=="" ) {
															$studidq1 = " studentid='$dat[2]' ";
														}else{
															$studidq1 = $studidq1 . " || studentid='$dat[2]' ";
														}
													}
												}
												//
												//
											}
											if ( trim($studidq1)!="" ) {
												//
												$studidq1 = " and ( " . $studidq1 . " ) ";
											}
											//
												//
												//                  0       1         2          3       4      5      6      7      8    9        10          11        12       13      14    15         16
												$sql = " select studentid,firstname,middlename,lastname,email,address,gender,course,year,no_hours,date_start,date_end,contact_no,eval_1,eval_2,req_status,no from tbl_interns  where reg_status='registered' $studidq1  limit 5  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
														//REQUIREMENT STATUS
														$reqstats = "";
														$reqstatsx = 13;
														$reqstatsn = 0;
														//
														$req1 = array();
														//                   0      1             2      3
														$sql2 = " select req_file,date_added,studentid,req_type from tbl_user_requirements where studentid='$dat[0]' and 
																		( req_type='requirement:resume' or req_type='requirement:application_letter' or req_type='requirement:moa' or req_type='requirement:mou' or req_type='requirement:certification_of_acceptance'
																		  or req_type='requirement:white_form' or req_type='requirement:recommendation_letter' or req_type='requirement:waiver' or req_type='requirement:parent_consent'
																		   or req_type='requirement:medical_certificate' or req_type='requirement:certificate_of_appreciation' or req_type='requirement:certificate_of_completion' or req_type='requirement:ojt_photo'
																		) ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:resume")) ) {
																$req1[0][0] = $dat2[0];
																$req1[0][1] = $dat2[1];
																$req1[0][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:application_letter")) ) {
																$req1[1][0] = $dat2[0];
																$req1[1][1] = $dat2[1];
																$req1[1][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:moa")) ) {
																$req1[2][0] = $dat2[0];
																$req1[2][1] = $dat2[1];
																$req1[2][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:mou")) ) {
																$req1[3][0] = $dat2[0];
																$req1[3][1] = $dat2[1];
																$req1[3][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:certification_of_acceptance")) ) {
																$req1[4][0] = $dat2[0];
																$req1[4][1] = $dat2[1];
																$req1[4][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:white_form")) ) {
																$req1[5][0] = $dat2[0];
																$req1[5][1] = $dat2[1];
																$req1[5][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:recommendation_letter")) ) {
																$req1[6][0] = $dat2[0];
																$req1[6][1] = $dat2[1];
																$req1[6][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:waiver")) ) {
																$req1[7][0] = $dat2[0];
																$req1[7][1] = $dat2[1];
																$req1[7][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:parent_consent")) ) {
																$req1[8][0] = $dat2[0];
																$req1[8][1] = $dat2[1];
																$req1[8][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:medical_certificate")) ) {
																$req1[9][0] = $dat2[0];
																$req1[9][1] = $dat2[1];
																$req1[9][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:certificate_of_appreciation")) ) {
																$req1[10][0] = $dat2[0];
																$req1[10][1] = $dat2[1];
																$req1[10][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:certificate_of_completion")) ) {
																$req1[11][0] = $dat2[0];
																$req1[11][1] = $dat2[1];
																$req1[11][2] = $dat2[2];
															}
															if ( strtolower(trim($dat2[3]))==strtolower(trim("requirement:ojt_photo")) ) {
																$req1[12][0] = $dat2[0];
																$req1[12][1] = $dat2[1];
																$req1[12][2] = $dat2[2];
															}
														}
														for ( $i=0 ; $i<13 ; $i++ ) {
															//
															$xn = 0;
															//
															$sql3 = " select * from tbl_upfiles where location='".$req1[$i][0]."' and date_uploaded='".$req1[$i][1]."' and upby_type='student' and upby_id='".$req1[$i][2]."' and utype='requirement' and ap_status<>'dis-approved' order by no desc limit 2 ";
															$qry3 = mysqli_query($conn,$sql3);
															while($dat3=mysqli_fetch_array($qry3)) {
																$xn += 1;
															}
															//
															if ( $xn > 0 ) {
																$reqstatsn = $reqstatsn + 1;
															}
														}
													//
													//
													$urs = trim($dat[15]);
													$depi = "";
													$fstat = "";
													$tsn = "";
													$tsn = "completed";
													//if ( strtolower(trim($urs)) == strtolower(trim($tsn)) ) {
													if ( $reqstatsn >= $reqstatsx ) {
														$fstat = "<span class='label label-success'>COMPLETED</span>";
														$depi = "None";
													}
													$tsn = "pending";
													//if ( strtolower(trim($urs)) == strtolower(trim($tsn)) ) {
													if ( $reqstatsn < $reqstatsx  ) {
														$reqstats = $reqstatsn . "/" . $reqstatsx;
														//$fstat = "<span class='label label-warning'>PENDING</span>";
														$fstat = "<span class='label label-warning'>PENDING ($reqstats)</span>";
														$depi = "Requirements";
													}
													$tsn = "dropped";
													if ( strtolower(trim($urs)) == strtolower(trim($tsn)) ) {
														//$fstat = "<span class='label label-danger'>DROPPED</span>";
														$depi = "Requirements";
													}
														//GET EVAL. RATE
														$evalrate = "-";
														$sql2 = " select rate from tbl_interns_evaluation where studentid='$dat[0]' order by no desc limit 1 ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															if ( trim($dat2[0])!="" ) {
																$evalrate = trim($dat2[0]);
															}
														}
														//GET HTE
														$hten = getUserHTE(trim($dat[0]));
														//

													echo "
														<tr>
															<td>
																<a href='page_profile.php?id=".trim($dat[0])."'>
																<span class='span02'>".trim($dat[3])."</span>
																</a>
															</td>
															<td>
																<a href='page_profile.php?id=".trim($dat[0])."'>
																<span class='span02'>".trim($dat[1])."</span>
																</a>
															</td>
															<td>
																".trim($hten)."
															</td>
															<td>
																".trim($depi)."
															</td>
															<td>
																".$fstat."
															</td>
														</tr>
													";
												}
											?>
										</tbody>
									</table>
								</div>
								</div>
								<div class="panel-footer">
									<div class="row">

										<p align="left">
											<a href="./page_interns_list.php" class="btn btn-primary btn-bottom">View All</a>
										</p>
									
									</div>
								</div>
							</div>


						<div class="">
							<!-- RECENT PURCHASES -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Submitted Reflections</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
										
									</div>
								</div>
								<div class="panel-body no-padding">
								<div class="table-responsive">
									<table class="table table-striped">
										<thead>
											<tr>
												<th>Submitted By</th>
												<th>Submitted In</th>
												<th>File</th>
												<th>Date</th>
											</tr>
										</thead>
										<tbody>
											<?php
												include "./data/connect.php";
												//
												$ctype = "reflection";
												//
												//
											//
											//
											$logun =  $_SESSION['intern_data_cun'];
											$logutype = $_SESSION['intern_data_utype'];
											//
											//
											$xq = "";
											$hteidq = "";
											$studidq1 = "";
											if ( strtolower(trim($logutype))==strtolower(trim("employee")) ) {
												//GET USER HTE
												//                 0           1      2        3         4
												$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff where staff_id='$logun' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($hteidq)=="" ) {
														$hteidq = " hte_id='$dat[1]' ";
													}else{
														$hteidq = $hteidq . " || hte_id='$dat[1]' ";
													}
												}
												//
												if ( trim($hteidq)!="" ) {
													//
													$hteidq = " where " . $hteidq;
													//GET USERS IN HTE
													//                 0         1      2
													$sql = " select hte_mem_id,hte_id,member_id from tbl_hte_members $hteidq ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($studidq1)=="" ) {
															$studidq1 = " upby_id='$dat[2]' ";
														}else{
															$studidq1 = $studidq1 . " || upby_id='$dat[2]' ";
														}
													}
												}
												//
												//
											}
											if ( trim($studidq1)!="" ) {
												//
												$studidq1 = " and ( " . $studidq1 . " ) ";
											}
											//
												//
												//               0  1     2        3             4        5       6
												$sql = " select no,name,location,date_uploaded,upby_id,upby_type,utype from tbl_upfiles where utype='$ctype' $studidq1  order by date_uploaded desc  limit 5  ";
												//echo "$sql";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													
													$lnk = "";
													//
													$name = "";
													//
													$locname = "";
													$loclink = "";
													//
													$sql2 = "";
													//
													if ( trim($dat[5])!="" ) {
														if ( strtolower(trim($dat[5]))==strtolower(trim("coordinator")) ) {
															$lnk = "page_profile_employee.php";
															//
															$sql2 = " select firstname,middlename,lastname from tbl_employee where employee_id='$dat[4]'  ";
																$qry2 = mysqli_query($conn,$sql2);
																while($dat2=mysqli_fetch_array($qry2)) {
																	$name = trim($dat2[2]).", ".trim($dat2[0])." ".trim($dat2[1]);
																}
														}
														if ( strtolower(trim($dat[5]))==strtolower(trim("student")) ) {
															$lnk = "page_profile.php";
															//
															$sql2 = " select firstname,middlename,lastname from tbl_interns where studentid='$dat[4]'  ";
																$qry2 = mysqli_query($conn,$sql2);
																while($dat2=mysqli_fetch_array($qry2)) {
																	$name = trim($dat2[2]).", ".trim($dat2[0])." ".trim($dat2[1]);
																}														}
														if ( trim($dat[4])!="" ) {
															//GET NAME
														}
													}
													//
													if ( trim($dat[7])!="" ) {
														if ( strtolower(trim($dat[8]))==strtolower(trim("class")) ) {
															$loclink = "page_class.php";
															//
															$sql2 = " select class_id,name from tbl_class where class_id='$dat[7]'  ";
																$qry2 = mysqli_query($conn,$sql2);
																while($dat2=mysqli_fetch_array($qry2)) {
																	$locname = trim($dat2[1]);
																}
														}
													}
													//
													//
													echo "
														<tr>
															<td>
																<a href='".$lnk."?id=".trim($dat[4])."'>
																<span class='span02'>".trim($name)."</span>
																</a>
															</td>
															<td>
																<a href='".$loclink."?id=".trim($dat[7])."'>
																<span class='span02'>".trim($locname)."</span>
																</a>
															</td>
															<td>
																<a target='_blank' href='".trim($dat[2])."'>".trim($dat[2])."</a>
															</td>
															<td>
																".trim($dat[3])."
															</td>
														</tr>
													";
												}
											?>
										</tbody>
									</table>
								</div>
								</div>
								<div class="panel-footer">
									<div class="row">

										<p align="left">
											<a href="./class_files.php?type=reflection" class="btn btn-primary btn-bottom">View All</a>
										</p>
									
									</div>
								</div>
							</div>
							<!-- END RECENT PURCHASES -->
						</div>

							<!-- END RECENT PURCHASES -->
						</div>

						<div class="col-md-5">
							<!-- MULTI CHARTS -->
							<div class="panel panel-scrolling">
								<div class="panel-heading">
									<h3 class="panel-title">Recent User Activity</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
										
									</div>
								</div>
								<div class="panel-body">
									<ul class="list-unstyled activity-list">
										<?php include "./data/connect.php";
											//
											//
											$logun =  $_SESSION['intern_data_cun'];
											$logutype = $_SESSION['intern_data_utype'];
											//
											//
											$xq = "";
											$hteidq = "";
											$studidq1 = "";
											if ( strtolower(trim($logutype))==strtolower(trim("employee")) ) {
												//GET USER HTE
												//                 0           1      2        3         4
												$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff where staff_id='$logun' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($hteidq)=="" ) {
														$hteidq = " hte_id='$dat[1]' ";
													}else{
														$hteidq = $hteidq . " || hte_id='$dat[1]' ";
													}
												}
												//
												if ( trim($hteidq)!="" ) {
													//
													$hteidq = " where " . $hteidq;
													//GET USERS IN HTE
													//                 0         1      2
													$sql = " select hte_mem_id,hte_id,member_id from tbl_hte_members $hteidq ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($studidq1)=="" ) {
															$studidq1 = " member_id='$dat[2]' ";
														}else{
															$studidq1 = $studidq1 . " || member_id='$dat[2]' ";
														}
													}
												}
												//
												//
											}
											if ( trim($studidq1)!="" ) {
												//
												$studidq1 = " where member_type='student' and ( " . $studidq1 . " ) ";
											}
											//GET ALL LOGS
											//                 0     1         2            3    4    5
											$sql = " select uact_id,member_id,member_type,adate,msg,atype from tbl_uact $studidq1 order by uact_id desc limit 5 ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[1])!="" ) {
													//
													$mid = "";
													$fn = "";
													$img = "";
													//
													$time = trim($dat[3]);
													$msg = trim($dat[4]);
													//
													//                   0        1          2        3        4
													$sql2 = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns where studentid='$dat[1]' ";
													$qry2 = mysqli_query($conn,$sql2);
													while($dat2=mysqli_fetch_array($qry2)) {
														$mid = trim($dat2[0]);
														$fn = trim($dat2[1]);
														$img = trim($dat2[4]);
													}
													//
														if ( trim($img) == "" ) {
															$img = "assets/img/empty_user.png";
														}
													//
													echo "
														<li>
															<img src='$img' alt='Avatar' class='img-circle pull-left avatar'>
															<p><a href='./page_profile.php?id=$mid'>$fn</a> $msg <span class='timestamp'>$time</span></p>
														</li>
													";
													//
												}
											}
										?>
									</ul>
									<p align="center">
										<a href="./user_activity.php" class="btn btn-primary btn-bottom">View All</a>
									</p>
									
								</div>
							</div>
							<!-- END MULTI CHARTS -->
						</div>

					</div>
					
					<div class="row">
						<div class="col-md-4">
							<!-- TASKS -->
							
							<!-- END TASKS -->
						</div>
						<div class="col-md-4">
							<!-- VISIT CHART -->
							
							<!-- END VISIT CHART -->
						</div>
						<div class="col-md-4">
							<!-- REALTIME CHART -->
		
							<!-- END REALTIME CHART -->
						</div>
					</div>
