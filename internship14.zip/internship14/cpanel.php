<?php  session_start(); error_reporting( E_ALL ^ E_NOTICE );
	include "./sys_load_active_sy.php";
	//
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$_SESSION['intern_page_current'] = "cpanel";
		include "./parts/main_logcheck.php";
	//
	include "./parts/sys_hte_raterank_updater.php";
	//
	//
	$op = $_GET['op'];
	$tsn = "";
	if ( trim($op)!="" ) {
		$tsn = "logout";
		if ( strtolower(trim($op)) == strtolower(trim($op)) ) {
			$_SESSION['intern_data_cun'] = "";
			$_SESSION['intern_data_dpn'] = "";
			$_SESSION['intern_data_utype'] = "";
			echo "<META HTTP-EQUIV='Refresh' Content='0; URL=index.php'>";
		}
	}
	//
	if ( trim($logun)=="" ) {
		exit;
	}
?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>


</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">

				<?php
					//
					$logun = $_SESSION['intern_data_cun'];
					$logutype = $_SESSION['intern_data_utype'];
					//
					if ( trim($logun)!="" ) {

						if ( strtolower(trim($logutype))==strtolower(trim("student")) ) {
							include "./cpanel_student.php";
						}

						if ( 
							strtolower(trim($logutype))==strtolower(trim("employee")) ||
							strtolower(trim($logutype))==strtolower(trim("staff"))
						 ) {
							include "./cpanel_staff.php";
						}

					}
					//
				?>

				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/vendor/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
	<script src="assets/vendor/chartist/js/chartist.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>
	<script>
	$(function() {
		var data, options;

//////////////////////////////////////////////////////////////////////////////////////

		var tname = [];
		var tvalue = [];
		var count = 0;

/////////////////

		count = parseInt( document.getElementById('eval_sum_crs_data_count').value );

		 for ( var i = 0 ; i < 9 ; i++ ) {
		 	tname[i] = document.getElementById('eval_sum_crs_data_name_' + (i) ).value;
		 }
		 

		 for ( var i = 0 ; i < count ; i++ ) {
		 	var td = [];
		 	for ( var n = 0 ; n < 9 ; n++ ) {
		 		td[n] = document.getElementById('eval_sum_crs_data_value_' + (i) + '_' + (n) ).value;
		 	}
		 	tvalue[i] = td;
		 }
		 //alert(tvalue[1][1]);
		// visits trend charts
		
		// headline charts
		data = {
			labels: tname,
			series: tvalue
		};


		// line chart
		options = {
			height: "300px",
			showPoint: true,
			axisX: {
				showGrid: false
			},
			lineSmooth: false,
		};

		new Chartist.Line('#stats-line-chart', data, options);
		
//////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////

		var tname2 = [];
		var tvalue2 = [];
		var count2 = 0;

/////////////////

		count2 = parseInt( document.getElementById('eval_sum_dept_data_count').value );

		 for ( var i = 0 ; i < 9 ; i++ ) {
		 	tname2[i] = document.getElementById('eval_sum_dept_data_name_' + (i) ).value;
		 }
		 

		 for ( var i = 0 ; i < count2 ; i++ ) {
		 	var td = [];
		 	for ( var n = 0 ; n < 9 ; n++ ) {
		 		td[n] = document.getElementById('eval_sum_dept_data_value_' + (i) + '_' + (n) ).value;
		 	}
		 	tvalue2[i] = td;
		 }
		 //alert(tvalue[1][1]);
		// visits trend charts
		
		// headline charts
		data = {
			labels: tname2,
			series: tvalue2
		};


		// line chart
		options = {
			height: "300px",
			showPoint: true,
			axisX: {
				showGrid: false
			},
			lineSmooth: false,
		};

		new Chartist.Line('#stats-line-chart2', data, options);
		
//////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////

		var tname3 = [];
		var tvalue3 = [];
		var count3 = 0;

/////////////////

		count3 = parseInt( document.getElementById('eval_sum_sy_data_count').value );

		 for ( var i = 0 ; i < 9 ; i++ ) {
		 	tname3[i] = document.getElementById('eval_sum_sy_data_name_' + (i) ).value;
		 }
		 

		 for ( var i = 0 ; i < count3 ; i++ ) {
		 	var td = [];
		 	for ( var n = 0 ; n < 9 ; n++ ) {
		 		td[n] = document.getElementById('eval_sum_sy_data_value_' + (i) + '_' + (n) ).value;
		 	}
		 	tvalue3[i] = td;
		 }
		 //alert(tvalue[1][1]);
		// visits trend charts
		
		// headline charts
		data = {
			labels: tname3,
			series: tvalue3
		};


		// line chart
		options = {
			height: "300px",
			showPoint: true,
			axisX: {
				showGrid: false
			},
			lineSmooth: false,
		};

		new Chartist.Line('#stats-line-chart3', data, options);
		
//////////////////////////////////////////////////////////////////////////////////////

		// headline charts
		data = {
			labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
			series: [
				[23, 29, 24, 40, 25, 24, 35],
				[14, 25, 18, 34, 29, 38, 44],
			]
		};

		options = {
			height: 300,
			showArea: true,
			showLine: false,
			showPoint: false,
			fullWidth: true,
			axisX: {
				showGrid: false
			},
			lineSmooth: false,
		};

		new Chartist.Line('#headline-chart', data, options);


		// visits trend charts
		data = {
			labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
			series: [{
				name: 'series-real',
				data: [200, 380, 350, 320, 410, 450, 570, 400, 555, 620, 750, 900],
			}, {
				name: 'series-projection',
				data: [240, 350, 360, 380, 400, 450, 480, 523, 555, 600, 700, 800],
			}]
		};

		options = {
			fullWidth: true,
			lineSmooth: false,
			height: "270px",
			low: 0,
			high: 'auto',
			series: {
				'series-projection': {
					showArea: true,
					showPoint: false,
					showLine: false
				},
			},
			axisX: {
				showGrid: false,

			},
			axisY: {
				showGrid: false,
				onlyInteger: true,
				offset: 0,
			},
			chartPadding: {
				left: 20,
				right: 20
			}
		};

		new Chartist.Line('#visits-trends-chart', data, options);


		// visits chart
		data = {
			labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
			series: [
				[6384, 6342, 5437, 2764, 3958, 5068, 7654]
			]
		};

		options = {
			height: 300,
			axisX: {
				showGrid: false
			},
		};

		new Chartist.Bar('#visits-chart', data, options);


		// real-time pie chart
		var sysLoad = $('#system-load').easyPieChart({
			size: 130,
			barColor: function(percent) {
				return "rgb(" + Math.round(200 * percent / 100) + ", " + Math.round(200 * (1.1 - percent / 100)) + ", 0)";
			},
			trackColor: 'rgba(245, 245, 245, 0.8)',
			scaleColor: false,
			lineWidth: 5,
			lineCap: "square",
			animate: 800
		});

		var updateInterval = 3000; // in milliseconds

		setInterval(function() {
			var randomVal;
			randomVal = getRandomInt(0, 100);

			sysLoad.data('easyPieChart').update(randomVal);
			sysLoad.find('.percent').text(randomVal);
		}, updateInterval);

		function getRandomInt(min, max) {
			return Math.floor(Math.random() * (max - min + 1)) + min;
		}

	});
	</script>

	
<?php
	include "./parts/btm_script.php";
?>

</body>

</html>
