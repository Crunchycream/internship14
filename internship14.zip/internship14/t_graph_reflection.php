<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
  //
  $logun = $_SESSION['intern_data_cun'];
  $logutype = $_SESSION['intern_data_utype'];
  //
  $cuid = trim($_GET['id']);
  //
  $_SESSION['intern_page_current'] = "page_hte";
    include "./parts/main_logcheck.php";
  //
  if ( trim($logun)!="" && trim($cuid)!="" ) {
    if ( strtolower(trim($logutype))!="" && strtolower(trim($logutype))!="student" ) {
      if ( $_POST['btnsaveMapData'] ) {
        $lati = trim($_POST['tlat']);
        $longi = trim($_POST['tlong']);
        if ( trim($lati)!="" && trim($longi)!="" ) {
            $sql = " 
                    update tbl_hte set  
                      map_loc_latitude='$lati', map_loc_longitude='$longi'  
                        where hte_id='$cuid' 
             ";
            $qry = mysqli_query($conn,$sql);
            //
            echo "
                <script>
                  alert('Saved.');
                </script>
            ";
        }
      }
    }
  }
  if ( trim($logun)=="" ) {
    exit;
  }
  //
?>
<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <title>Graph</title>

  <?php include "./parts/head_content.php"; ?>

  </head>
  <body style="background:#fff;">
    <div align="left">
      <div class="graphpage01">
        

                <div class="table-responsive">
                  <div id="stat-bar-chart" class="ct-chart chart03"></div>
                </div>


      </div>
    </div>

<?php include "./data/connect.php";
  //
  $cid = trim($_GET['id']);
  $sy = trim($_SESSION['intern_data_active_sy']);
  //echo "$cid $sy";
  //
  $weekn = array();
  $weekn2 = array();
  $grade = array();
  $cvalcount = array();
  //
  $cn = 0;
  //
  if ( trim($cid)!="" ) {
    //GET WEEK NAME
    //                     0  
    $sql = " select weekname from tbl_class_posts  where activity_sub='false' and type='reflection' and weekname<>''  group by weekname order by class_post_id desc ";
    $qry = mysqli_query($conn,$sql);
    while($dat=mysqli_fetch_array($qry)) {
      if ( trim($dat[0])!="" ) {
        $weekn[$cn] = trim($dat[0]);
        if ( trim($weekn[$cn])!="" ) {
          $td = explode("_", trim($weekn[$cn]));
          $weekn2[$cn] = "" . trim($td[0]) . " " . trim($td[1]) . "";
        }
        $cn += 1;
      }
    }
    //
    $cn = 0;
    $vc = 0;
    //
    //GET REFLECTION GRADE
    for ( $i=0 ; $i<count($weekn) ; $i++ ) {
      //                0
      $sql = " select grade from tbl_upfiles  where grade<>'' and upby_id='$cid' and upby_type='student' and weekname='$weekn[$i]'  order by no desc limit 1 ";
      $qry = mysqli_query($conn,$sql);
      while($dat=mysqli_fetch_array($qry)) {
        $grade[$cn] = trim($dat[0]);
        $cn += 1;
        //
      }
      //
    }
    //echo " $cval[0] - $cvalcount[0]";
    //
    $cn = 0;
    for ( $i=0 ; $i<count($weekn) ; $i++ ) {
      if ( trim($weekn[$i])!="" ) {
        //
        $cn += 1;
        //
        //
        echo "<input type='hidden' id='reflection_weekname_$cn' value='$weekn[$i]' readonly />";
        echo "<input type='hidden' id='reflection_weekname2_$cn' value='$weekn2[$i]' readonly />";
        echo "<input type='hidden' id='reflection_grade_$cn' value='$grade[$i]' readonly />";
        //
      }
    }
        echo "<input type='hidden' id='reflection_count' value='$cn' readonly />";
  }
  //
?>


  <!-- Javascript -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
  <script src="assets/scripts/klorofil-common.js"></script>
  <script src="assets/vendor/chartist/js/chartist.min.js"></script>


  <script>

     var count = 0;
     var names = [];
     var names2 = [];
     var values = [];

    $(function() {

      count = parseInt( document.getElementById('reflection_count').value );


     for ( var i = 0 ; i < count ; i++ ) {
      names2[i] = document.getElementById('reflection_weekname_' + (i+1) ).value;
      names[i] = document.getElementById('reflection_weekname2_' + (i+1) ).value;
      values[i] = document.getElementById('reflection_grade_' + (i+1) ).value;
     }


        var options;

      //
      //

      var data = {
        labels: names,
        series: [
          {
            name: 'series-Eva1',
            data: values,
          
          }
        ]
      };

      // bar chart
      options = {
        height: "300px",
        axisX: {
          showGrid: false
        },
      };

      new Chartist.Bar('#stat-bar-chart', data, options);
      

    });

  </script>


  </body>
</html>