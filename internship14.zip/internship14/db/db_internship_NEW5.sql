-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.6.21


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema db_internship
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ db_internship;
USE db_internship;

--
-- Table structure for table `db_internship`.`tbl_admin`
--

DROP TABLE IF EXISTS `tbl_admin`;
CREATE TABLE `tbl_admin` (
  `No` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `un` varchar(45) DEFAULT '',
  `up` varchar(45) DEFAULT '',
  `email` varchar(100) DEFAULT '',
  `dname` varchar(45) DEFAULT '',
  PRIMARY KEY (`No`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_admin`
--

/*!40000 ALTER TABLE `tbl_admin` DISABLE KEYS */;
INSERT INTO `tbl_admin` (`No`,`un`,`up`,`email`,`dname`) VALUES 
 (1,'admin','1234','admin@is.com','Admin');
/*!40000 ALTER TABLE `tbl_admin` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_allusers`
--

DROP TABLE IF EXISTS `tbl_allusers`;
CREATE TABLE `tbl_allusers` (
  `No` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(45) DEFAULT '',
  `middlename` varchar(45) DEFAULT '',
  `lastname` varchar(45) DEFAULT '',
  `studentID` varchar(45) DEFAULT '',
  `status` varchar(45) DEFAULT '',
  PRIMARY KEY (`No`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_allusers`
--

/*!40000 ALTER TABLE `tbl_allusers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_allusers` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_announcement`
--

DROP TABLE IF EXISTS `tbl_announcement`;
CREATE TABLE `tbl_announcement` (
  `announcement_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ann_id` varchar(45) DEFAULT '',
  `ann_type` varchar(45) DEFAULT '',
  `pdate` varchar(100) DEFAULT '',
  `msg` varchar(10000) DEFAULT '',
  `subject` varchar(45) DEFAULT '',
  `cfile` varchar(1000) DEFAULT '',
  `by_id` varchar(45) DEFAULT '',
  `by_type` varchar(45) DEFAULT '',
  PRIMARY KEY (`announcement_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_announcement`
--

/*!40000 ALTER TABLE `tbl_announcement` DISABLE KEYS */;
INSERT INTO `tbl_announcement` (`announcement_id`,`ann_id`,`ann_type`,`pdate`,`msg`,`subject`,`cfile`,`by_id`,`by_type`) VALUES 
 (1,'1','course','2/18/2018 10:21:27','AWESOME!!!','','','admin','admin'),
 (2,'1','course','2/18/2018 10:32:28','DONE11','','','90789','student'),
 (3,'1','course','2/18/2018 10:32:42','','','uploads/file_2_18_2018__10_32_42.jpg','90789','student'),
 (4,'1','course','2/18/2018 10:39:18','WTF!!!','','uploads/file_2_18_2018__10_39_18.jpg','90789','student'),
 (5,'1','course','2/18/2018 11:19:17','wow','','','90789','student'),
 (6,'1','hte','2/18/2018 11:26:26','WELCOME','','','90789','student'),
 (7,'1','hte','2/18/2018 11:26:34','','','uploads/file_2_18_2018__11_26_34.jpg','90789','student');
/*!40000 ALTER TABLE `tbl_announcement` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_class`
--

DROP TABLE IF EXISTS `tbl_class`;
CREATE TABLE `tbl_class` (
  `class_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `date_created` varchar(45) DEFAULT '',
  `prof_img` varchar(200) DEFAULT '',
  `prof_backimg` varchar(200) DEFAULT '',
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_class`
--

/*!40000 ALTER TABLE `tbl_class` DISABLE KEYS */;
INSERT INTO `tbl_class` (`class_id`,`name`,`date_created`,`prof_img`,`prof_backimg`) VALUES 
 (1,'Warriors','1/24/2018 12:04:18','',''),
 (2,'Androids','1/24/2018 12:04:27','','uploads/file_1_24_2018__05_09_27.jpg');
/*!40000 ALTER TABLE `tbl_class` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_class_member_hte`
--

DROP TABLE IF EXISTS `tbl_class_member_hte`;
CREATE TABLE `tbl_class_member_hte` (
  `class_mem_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class_id` varchar(45) DEFAULT '',
  `hte_id` varchar(45) DEFAULT '',
  PRIMARY KEY (`class_mem_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_class_member_hte`
--

/*!40000 ALTER TABLE `tbl_class_member_hte` DISABLE KEYS */;
INSERT INTO `tbl_class_member_hte` (`class_mem_id`,`class_id`,`hte_id`) VALUES 
 (1,'2','3'),
 (2,'2','1'),
 (3,'2','2');
/*!40000 ALTER TABLE `tbl_class_member_hte` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_class_posts`
--

DROP TABLE IF EXISTS `tbl_class_posts`;
CREATE TABLE `tbl_class_posts` (
  `class_post_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class_id` varchar(45) DEFAULT '',
  `type` varchar(45) DEFAULT '',
  `content` varchar(10000) DEFAULT '',
  `member_id` varchar(45) DEFAULT '',
  `member_type` varchar(100) DEFAULT '',
  `date_posted` varchar(100) DEFAULT '',
  `parent_post_id` varchar(45) DEFAULT '',
  `file_att` varchar(200) DEFAULT '',
  `file_att_name` varchar(200) DEFAULT '',
  `activity_sub` varchar(45) DEFAULT '',
  PRIMARY KEY (`class_post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_class_posts`
--

/*!40000 ALTER TABLE `tbl_class_posts` DISABLE KEYS */;
INSERT INTO `tbl_class_posts` (`class_post_id`,`class_id`,`type`,`content`,`member_id`,`member_type`,`date_posted`,`parent_post_id`,`file_att`,`file_att_name`,`activity_sub`) VALUES 
 (1,'2','Post','HELLLoooooo!!!','1234','student','1/27/2018 02:42:48','','','',''),
 (2,'2','Post','WOW','1234','student','1/27/2018 02:43:50','','','',''),
 (3,'2','Post','YEP!!!','1234','student','1/27/2018 03:37:53','2','','',''),
 (4,'2','Post','OWRYT','1234','student','1/27/2018 04:00:44','2','','',''),
 (5,'2','Post','DONE!!!','1234','student','1/27/2018 04:11:48','1','','',''),
 (11,'2','Reflection','REFLECTION','1234','student','1/27/2018 06:10:40','','','',''),
 (12,'2','Reflection','','1234','student','1/27/2018 06:12:02','11','uploads/file_1_27_2018__06_28_04.pdf','SAMPLE RESUME.pdf','true'),
 (13,'2','Reflection','NEW','1234','student','1/27/2018 06:35:17','','','','false'),
 (14,'1','Reflection','REFLECTION SUBMIT NOW.','1234','student','1/29/2018 04:06:55','','','','false'),
 (15,'1','Reflection','ss','1234','student','1/29/2018 04:09:07','','','','false'),
 (16,'1','Reflection','ss','1234','student','1/29/2018 04:09:35','','','','false');
INSERT INTO `tbl_class_posts` (`class_post_id`,`class_id`,`type`,`content`,`member_id`,`member_type`,`date_posted`,`parent_post_id`,`file_att`,`file_att_name`,`activity_sub`) VALUES 
 (17,'1','Reflection','ww','1234','student','1/29/2018 04:10:05','','','','false'),
 (18,'1','Reflection','aa','1234','student','1/29/2018 04:12:10','','','','false'),
 (19,'1','Reflection','www','1234','student','1/29/2018 04:12:59','','','','false'),
 (20,'1','Reflection','qqq','1234','student','1/29/2018 04:13:41','','','','false'),
 (21,'1','Reflection','wwqwq','1234','student','1/29/2018 04:15:57','','','','false'),
 (22,'1','Reflection','QQQQ','1234','student','1/29/2018 04:21:07','','','','false'),
 (23,'2','Reflection','qq','1234','student','1/29/2018 05:58:44','','','','false'),
 (24,'2','Reflection','zzzz','1234','student','1/29/2018 05:59:37','','','','false'),
 (25,'2','Post','zzzz','1234','student','1/29/2018 05:59:47','','','','false'),
 (26,'1','Reflection','1234','1234','student','1/29/2018 06:08:23','','','','false'),
 (27,'2','Reflection','','90789','student','2/14/2018 07:20:01','24','uploads/file_2_14_2018__07_20_01.pdf','SAMPLE MOU.pdf','true');
INSERT INTO `tbl_class_posts` (`class_post_id`,`class_id`,`type`,`content`,`member_id`,`member_type`,`date_posted`,`parent_post_id`,`file_att`,`file_att_name`,`activity_sub`) VALUES 
 (28,'2','Reflection','','admin','admin','2/14/2018 07:32:54','23','uploads/file_2_14_2018__07_32_54.pdf','SAMPLE MOU.pdf','true'),
 (29,'2','Reflection','','90789','student','2/14/2018 07:33:42','23','uploads/file_2_14_2018__07_33_42.pdf','SAMPLE APPLETTER.pdf','true'),
 (30,'2','Reflection','','90789','student','2/14/2018 07:34:39','13','uploads/file_2_14_2018__07_34_39.pdf','SAMPLE MOU.pdf','true'),
 (31,'2','Reflection','','90789','student','2/14/2018 07:37:46','11','uploads/file_2_22_2018__10_35_51.pdf','SAMPLE MOU.pdf','true');
/*!40000 ALTER TABLE `tbl_class_posts` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_coordinator`
--

DROP TABLE IF EXISTS `tbl_coordinator`;
CREATE TABLE `tbl_coordinator` (
  `coordinator_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(45) DEFAULT '',
  `department_id` varchar(45) DEFAULT '',
  `course_id` varchar(45) DEFAULT '',
  `hte_id` varchar(45) DEFAULT '',
  PRIMARY KEY (`coordinator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_coordinator`
--

/*!40000 ALTER TABLE `tbl_coordinator` DISABLE KEYS */;
INSERT INTO `tbl_coordinator` (`coordinator_id`,`employee_id`,`department_id`,`course_id`,`hte_id`) VALUES 
 (1,'12423','3','3','1'),
 (3,'2323456','1','1','2');
/*!40000 ALTER TABLE `tbl_coordinator` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_course`
--

DROP TABLE IF EXISTS `tbl_course`;
CREATE TABLE `tbl_course` (
  `course_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` varchar(45) DEFAULT '',
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_course`
--

/*!40000 ALTER TABLE `tbl_course` DISABLE KEYS */;
INSERT INTO `tbl_course` (`course_id`,`course`) VALUES 
 (1,'BSIT'),
 (2,'BSED'),
 (3,'BSA');
/*!40000 ALTER TABLE `tbl_course` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_department`
--

DROP TABLE IF EXISTS `tbl_department`;
CREATE TABLE `tbl_department` (
  `department_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `department` varchar(45) DEFAULT '',
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_department`
--

/*!40000 ALTER TABLE `tbl_department` DISABLE KEYS */;
INSERT INTO `tbl_department` (`department_id`,`department`) VALUES 
 (1,'TECH'),
 (2,'EDU'),
 (3,'BUS'),
 (4,'JOKER');
/*!40000 ALTER TABLE `tbl_department` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_dsn`
--

DROP TABLE IF EXISTS `tbl_dsn`;
CREATE TABLE `tbl_dsn` (
  `No` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(45) DEFAULT '',
  `DSN` varchar(45) DEFAULT '',
  PRIMARY KEY (`No`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_dsn`
--

/*!40000 ALTER TABLE `tbl_dsn` DISABLE KEYS */;
INSERT INTO `tbl_dsn` (`No`,`Name`,`DSN`) VALUES 
 (1,'SNHTE','3');
/*!40000 ALTER TABLE `tbl_dsn` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_employee`
--

DROP TABLE IF EXISTS `tbl_employee`;
CREATE TABLE `tbl_employee` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(45) DEFAULT '',
  `firstname` varchar(45) DEFAULT '',
  `middlename` varchar(45) DEFAULT '',
  `lastname` varchar(45) DEFAULT '',
  `gender` varchar(45) DEFAULT '',
  `position` varchar(45) DEFAULT '',
  `email` varchar(100) DEFAULT '',
  `contact_no` varchar(45) DEFAULT '',
  `address` varchar(200) DEFAULT '',
  `username` varchar(45) DEFAULT '',
  `password` varchar(45) DEFAULT '',
  `prof_img` varchar(200) DEFAULT '',
  `prof_backimg` varchar(200) DEFAULT '',
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_employee`
--

/*!40000 ALTER TABLE `tbl_employee` DISABLE KEYS */;
INSERT INTO `tbl_employee` (`no`,`employee_id`,`firstname`,`middlename`,`lastname`,`gender`,`position`,`email`,`contact_no`,`address`,`username`,`password`,`prof_img`,`prof_backimg`) VALUES 
 (1,'12423','Edward','East','Elrick','Male','Dean','ee@','09745','earth','','','uploads/file_1_24_2018__07_29_23.jpg',''),
 (2,'2323456','Edward','Dan','Smith','Male','Coordinator','ee@gdfd','095656','Moon','','','','');
/*!40000 ALTER TABLE `tbl_employee` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_employee_requirements`
--

DROP TABLE IF EXISTS `tbl_employee_requirements`;
CREATE TABLE `tbl_employee_requirements` (
  `No` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `req_type` varchar(45) DEFAULT '',
  `req_file` varchar(200) DEFAULT '',
  `date_added` varchar(100) DEFAULT '',
  `employee_id` varchar(45) DEFAULT '',
  PRIMARY KEY (`No`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_employee_requirements`
--

/*!40000 ALTER TABLE `tbl_employee_requirements` DISABLE KEYS */;
INSERT INTO `tbl_employee_requirements` (`No`,`name`,`req_type`,`req_file`,`date_added`,`employee_id`) VALUES 
 (12,'Resume','requirement:resume','uploads/file_1_24_2018__07_28_58.pdf','1/24/2018 07:28:58','12423');
/*!40000 ALTER TABLE `tbl_employee_requirements` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_eval_info`
--

DROP TABLE IF EXISTS `tbl_eval_info`;
CREATE TABLE `tbl_eval_info` (
  `ei_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT '',
  `tag_id` varchar(45) DEFAULT '',
  `tag_type` varchar(45) DEFAULT '',
  `date_target` varchar(100) DEFAULT '',
  `date_created` varchar(100) DEFAULT '',
  `status` varchar(45) DEFAULT '',
  PRIMARY KEY (`ei_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_eval_info`
--

/*!40000 ALTER TABLE `tbl_eval_info` DISABLE KEYS */;
INSERT INTO `tbl_eval_info` (`ei_id`,`name`,`tag_id`,`tag_type`,`date_target`,`date_created`,`status`) VALUES 
 (1,'Dd','','hte','2018-02-22','2/22/2018 04:20:40',''),
 (2,'Dd','','student','2018-02-22','2/22/2018 04:24:03','');
/*!40000 ALTER TABLE `tbl_eval_info` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_gender`
--

DROP TABLE IF EXISTS `tbl_gender`;
CREATE TABLE `tbl_gender` (
  `No` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gender` varchar(45) DEFAULT '',
  PRIMARY KEY (`No`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_gender`
--

/*!40000 ALTER TABLE `tbl_gender` DISABLE KEYS */;
INSERT INTO `tbl_gender` (`No`,`gender`) VALUES 
 (1,'Male'),
 (2,'Female');
/*!40000 ALTER TABLE `tbl_gender` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_hte`
--

DROP TABLE IF EXISTS `tbl_hte`;
CREATE TABLE `tbl_hte` (
  `hte_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DSN` varchar(45) DEFAULT '',
  `Name` varchar(100) DEFAULT '',
  `Address` varchar(200) DEFAULT '',
  `No_Students` varchar(45) DEFAULT '',
  `Eval_1` varchar(45) DEFAULT '',
  `Eval_2` varchar(45) DEFAULT '',
  `AddedBy` varchar(45) DEFAULT '',
  `prof_backimg` varchar(200) DEFAULT '',
  PRIMARY KEY (`hte_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_hte`
--

/*!40000 ALTER TABLE `tbl_hte` DISABLE KEYS */;
INSERT INTO `tbl_hte` (`hte_id`,`DSN`,`Name`,`Address`,`No_Students`,`Eval_1`,`Eval_2`,`AddedBy`,`prof_backimg`) VALUES 
 (1,'1','FBI','Classified','240','2.5','1.75','admin',''),
 (2,'2','SWAT','Classified','240','2.5','1.75','admin','uploads/file_1_22_2018__12_25_05.jpg'),
 (3,'3','SUICIDE SQUAD','EARTH','248','1.25','2.25','admin','');
/*!40000 ALTER TABLE `tbl_hte` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_hte_eval`
--

DROP TABLE IF EXISTS `tbl_hte_eval`;
CREATE TABLE `tbl_hte_eval` (
  `hte_eval_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `studentid` varchar(45) DEFAULT '',
  `college` varchar(45) DEFAULT '',
  `course` varchar(45) DEFAULT '',
  `major` varchar(45) DEFAULT '',
  `semester` varchar(45) DEFAULT '',
  `sy` varchar(45) DEFAULT '',
  `hte_id` varchar(45) DEFAULT '',
  `department` varchar(45) DEFAULT '',
  `eval_date` varchar(100) DEFAULT '',
  PRIMARY KEY (`hte_eval_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_hte_eval`
--

/*!40000 ALTER TABLE `tbl_hte_eval` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_hte_eval` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_hte_eval_progcomp`
--

DROP TABLE IF EXISTS `tbl_hte_eval_progcomp`;
CREATE TABLE `tbl_hte_eval_progcomp` (
  `hte_eval_progcomp_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hte_eval_id` varchar(45) DEFAULT '',
  `prog_comp` varchar(500) DEFAULT '',
  `num_hours` varchar(45) DEFAULT '',
  `eval_rate` varchar(45) DEFAULT '',
  PRIMARY KEY (`hte_eval_progcomp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_hte_eval_progcomp`
--

/*!40000 ALTER TABLE `tbl_hte_eval_progcomp` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_hte_eval_progcomp` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_hte_jobs`
--

DROP TABLE IF EXISTS `tbl_hte_jobs`;
CREATE TABLE `tbl_hte_jobs` (
  `hte_job_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hte_id` varchar(45) DEFAULT '',
  `name` varchar(100) DEFAULT '',
  `description` varchar(500) DEFAULT '',
  PRIMARY KEY (`hte_job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_hte_jobs`
--

/*!40000 ALTER TABLE `tbl_hte_jobs` DISABLE KEYS */;
INSERT INTO `tbl_hte_jobs` (`hte_job_id`,`hte_id`,`name`,`description`) VALUES 
 (1,'1','Driving','Pedicab driver'),
 (2,'1','Swimming',''),
 (3,'1','Dancing',''),
 (4,'2','Warrior',''),
 (5,'3','Killer',''),
 (6,'2','Swimming',''),
 (7,'2','Driving','');
/*!40000 ALTER TABLE `tbl_hte_jobs` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_hte_members`
--

DROP TABLE IF EXISTS `tbl_hte_members`;
CREATE TABLE `tbl_hte_members` (
  `hte_mem_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hte_id` varchar(45) DEFAULT '',
  `member_id` varchar(45) DEFAULT '',
  PRIMARY KEY (`hte_mem_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_hte_members`
--

/*!40000 ALTER TABLE `tbl_hte_members` DISABLE KEYS */;
INSERT INTO `tbl_hte_members` (`hte_mem_id`,`hte_id`,`member_id`) VALUES 
 (3,'1','45872'),
 (4,'1','90789'),
 (5,'3','1234'),
 (6,'2','45872'),
 (7,'2','1234'),
 (8,'1','1234');
/*!40000 ALTER TABLE `tbl_hte_members` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_hte_raterank`
--

DROP TABLE IF EXISTS `tbl_hte_raterank`;
CREATE TABLE `tbl_hte_raterank` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hte_id` varchar(45) DEFAULT '',
  `total_rate` varchar(45) DEFAULT '',
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_hte_raterank`
--

/*!40000 ALTER TABLE `tbl_hte_raterank` DISABLE KEYS */;
INSERT INTO `tbl_hte_raterank` (`no`,`hte_id`,`total_rate`) VALUES 
 (1,'1','2.5'),
 (2,'2','0'),
 (3,'3','0');
/*!40000 ALTER TABLE `tbl_hte_raterank` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_hte_rating`
--

DROP TABLE IF EXISTS `tbl_hte_rating`;
CREATE TABLE `tbl_hte_rating` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hte_id` varchar(45) DEFAULT '',
  `member_id` varchar(45) DEFAULT '',
  `rate` varchar(45) DEFAULT '',
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_hte_rating`
--

/*!40000 ALTER TABLE `tbl_hte_rating` DISABLE KEYS */;
INSERT INTO `tbl_hte_rating` (`no`,`hte_id`,`member_id`,`rate`) VALUES 
 (9,'1','90789','2.5');
/*!40000 ALTER TABLE `tbl_hte_rating` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_interns`
--

DROP TABLE IF EXISTS `tbl_interns`;
CREATE TABLE `tbl_interns` (
  `No` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(45) DEFAULT '',
  `middlename` varchar(45) DEFAULT '',
  `lastname` varchar(45) DEFAULT '',
  `email` varchar(100) DEFAULT '',
  `address` varchar(100) DEFAULT '',
  `username` varchar(45) DEFAULT '',
  `password` varchar(45) DEFAULT '',
  `studentid` varchar(45) DEFAULT '',
  `course` varchar(45) DEFAULT '',
  `year` varchar(45) DEFAULT '',
  `no_hours` varchar(45) DEFAULT '',
  `date_start` varchar(45) DEFAULT '',
  `date_end` varchar(45) DEFAULT '',
  `contact_no` varchar(45) DEFAULT '',
  `eval_1` varchar(45) DEFAULT '',
  `eval_2` varchar(45) DEFAULT '',
  `req_status` varchar(45) DEFAULT '',
  `gender` varchar(45) DEFAULT '',
  `prof_img` varchar(200) DEFAULT '',
  `prof_backimg` varchar(200) DEFAULT '',
  `reg_status` varchar(45) DEFAULT '',
  PRIMARY KEY (`No`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_interns`
--

/*!40000 ALTER TABLE `tbl_interns` DISABLE KEYS */;
INSERT INTO `tbl_interns` (`No`,`firstname`,`middlename`,`lastname`,`email`,`address`,`username`,`password`,`studentid`,`course`,`year`,`no_hours`,`date_start`,`date_end`,`contact_no`,`eval_1`,`eval_2`,`req_status`,`gender`,`prof_img`,`prof_backimg`,`reg_status`) VALUES 
 (5,'Allen','Danne','Walker','aw@g','Earth','90789','1234','90789','1','1st','200','2018-01-29','2018-01-29','0967','1.27','1.27','Completed','Male','uploads/file_2_18_2018__10_40_34.jpg','','Registered'),
 (6,'Ellene','Danne','Adarnae','aw@g','Earth','45872','1234','45872','2','1st','200','2018-01-29','2018-01-29','0967','1.27','1.27','Completed','Male','','','Registered'),
 (7,'Anne','Derre','Son','ads@g','Earth','','','1234','1','1st','200','2018-01-29','2018-01-29','0967234','1.27','1.27','Completed','Male','','','Unregistered');
/*!40000 ALTER TABLE `tbl_interns` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_interns_eval2`
--

DROP TABLE IF EXISTS `tbl_interns_eval2`;
CREATE TABLE `tbl_interns_eval2` (
  `stud_eval_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `professionalism` varchar(45) DEFAULT '',
  `job_maturity` varchar(45) DEFAULT '',
  `comm_skills` varchar(45) DEFAULT '',
  `productivity` varchar(45) DEFAULT '',
  `leadership` varchar(45) DEFAULT '',
  `excellence` varchar(45) DEFAULT '',
  `honesty_integrity` varchar(45) DEFAULT '',
  `innovation` varchar(45) DEFAULT '',
  `teamwork` varchar(45) DEFAULT '',
  `sy` varchar(45) DEFAULT '',
  `eval_date` varchar(100) DEFAULT '',
  `comments` varchar(5000) DEFAULT '',
  `supervisor_id` varchar(45) DEFAULT '',
  `coordinator_id` varchar(45) DEFAULT '',
  `evaluator_id` varchar(45) DEFAULT '',
  `evaluator_type` varchar(45) DEFAULT '',
  `studentid` varchar(45) DEFAULT '',
  PRIMARY KEY (`stud_eval_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_interns_eval2`
--

/*!40000 ALTER TABLE `tbl_interns_eval2` DISABLE KEYS */;
INSERT INTO `tbl_interns_eval2` (`stud_eval_id`,`professionalism`,`job_maturity`,`comm_skills`,`productivity`,`leadership`,`excellence`,`honesty_integrity`,`innovation`,`teamwork`,`sy`,`eval_date`,`comments`,`supervisor_id`,`coordinator_id`,`evaluator_id`,`evaluator_type`,`studentid`) VALUES 
 (3,'4','3','4','4','5','4','3','5','5','2016-2017','3/6/2018 02:56:53','Amazing','','','90789','student','90789');
/*!40000 ALTER TABLE `tbl_interns_eval2` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_interns_evaluation`
--

DROP TABLE IF EXISTS `tbl_interns_evaluation`;
CREATE TABLE `tbl_interns_evaluation` (
  `No` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `studentid` varchar(45) DEFAULT '',
  `evaluator_id` varchar(45) DEFAULT '',
  `rate` varchar(45) DEFAULT '',
  PRIMARY KEY (`No`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_interns_evaluation`
--

/*!40000 ALTER TABLE `tbl_interns_evaluation` DISABLE KEYS */;
INSERT INTO `tbl_interns_evaluation` (`No`,`studentid`,`evaluator_id`,`rate`) VALUES 
 (1,'90789','admin','1.75'),
 (2,'45872','admin','1.0'),
 (3,'45872','admin','2.5');
/*!40000 ALTER TABLE `tbl_interns_evaluation` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_interns_raterank`
--

DROP TABLE IF EXISTS `tbl_interns_raterank`;
CREATE TABLE `tbl_interns_raterank` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `studentid` varchar(45) DEFAULT '',
  `total_rate` varchar(45) DEFAULT '',
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_interns_raterank`
--

/*!40000 ALTER TABLE `tbl_interns_raterank` DISABLE KEYS */;
INSERT INTO `tbl_interns_raterank` (`no`,`studentid`,`total_rate`) VALUES 
 (1,'90789','1.75'),
 (2,'45872','1.75'),
 (3,'1234','0');
/*!40000 ALTER TABLE `tbl_interns_raterank` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_major`
--

DROP TABLE IF EXISTS `tbl_major`;
CREATE TABLE `tbl_major` (
  `major_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `major` varchar(45) DEFAULT '',
  PRIMARY KEY (`major_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_major`
--

/*!40000 ALTER TABLE `tbl_major` DISABLE KEYS */;
INSERT INTO `tbl_major` (`major_id`,`major`) VALUES 
 (1,'English'),
 (2,'Filipino'),
 (3,'P.E.'),
 (4,'Math');
/*!40000 ALTER TABLE `tbl_major` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_messages`
--

DROP TABLE IF EXISTS `tbl_messages`;
CREATE TABLE `tbl_messages` (
  `msg_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rcv_id` varchar(45) DEFAULT '',
  `rcv_type` varchar(45) DEFAULT '',
  `snd_id` varchar(45) DEFAULT '',
  `snd_type` varchar(45) DEFAULT '',
  `message` varchar(10000) DEFAULT '',
  `date_sent` varchar(100) DEFAULT '',
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_messages`
--

/*!40000 ALTER TABLE `tbl_messages` DISABLE KEYS */;
INSERT INTO `tbl_messages` (`msg_id`,`rcv_id`,`rcv_type`,`snd_id`,`snd_type`,`message`,`date_sent`) VALUES 
 (18,'45872','student','90789','student','hi','2/17/2018 01:21:41'),
 (19,'1234','student','90789','student','we','2/17/2018 01:22:02'),
 (20,'12423','employee','90789','student','Hi','2/17/2018 03:38:54'),
 (21,'12423','employee','90789','student','hello','2/17/2018 03:40:31'),
 (22,'45872','student','90789','student','hello','2/17/2018 03:40:47'),
 (23,'45872','student','90789','student','doom','2/17/2018 04:03:50'),
 (24,'12423','employee','90789','student','duel','2/17/2018 04:09:13'),
 (25,'45872','student','90789','student','how are u?','2/18/2018 06:04:30'),
 (26,'45872','student','90789','student','okay?','2/18/2018 06:04:45'),
 (27,'45872','student','90789','student','ez','2/18/2018 06:06:45'),
 (28,'45872','student','90789','student','and','2/18/2018 06:07:30'),
 (29,'45872','student','90789','student','d','2/18/2018 06:08:17'),
 (30,'45872','student','90789','student','fff','2/18/2018 06:09:24'),
 (31,'45872','student','90789','student','as','2/18/2018 06:09:51');
INSERT INTO `tbl_messages` (`msg_id`,`rcv_id`,`rcv_type`,`snd_id`,`snd_type`,`message`,`date_sent`) VALUES 
 (32,'45872','student','90789','student','do','2/18/2018 06:12:40'),
 (33,'45872','student','90789','student','tara','2/18/2018 06:13:50'),
 (34,'45872','student','90789','student','qwert','2/18/2018 06:14:46'),
 (35,'45872','student','90789','student','aw','2/18/2018 06:17:41'),
 (36,'45872','student','90789','student','dbe','2/18/2018 06:17:52'),
 (37,'45872','student','90789','student','qq','2/18/2018 06:18:38'),
 (38,'45872','student','90789','student','aa','2/18/2018 06:21:02'),
 (39,'45872','student','90789','student','awesome','2/18/2018 06:21:14'),
 (40,'2323456','employee','90789','student','hi sir','2/18/2018 08:26:25'),
 (41,'90789','student','90789','student','hello','2/18/2018 08:26:33');
/*!40000 ALTER TABLE `tbl_messages` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_messages_log`
--

DROP TABLE IF EXISTS `tbl_messages_log`;
CREATE TABLE `tbl_messages_log` (
  `msg_log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rcv_id` varchar(45) DEFAULT '',
  `rcv_type` varchar(45) DEFAULT '',
  `snd_id` varchar(45) DEFAULT '',
  `snd_type` varchar(45) DEFAULT '',
  `message` varchar(10000) DEFAULT '',
  `date_sent` varchar(100) DEFAULT '',
  PRIMARY KEY (`msg_log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_messages_log`
--

/*!40000 ALTER TABLE `tbl_messages_log` DISABLE KEYS */;
INSERT INTO `tbl_messages_log` (`msg_log_id`,`rcv_id`,`rcv_type`,`snd_id`,`snd_type`,`message`,`date_sent`) VALUES 
 (10,'12423','employee','90789','student','duel','2/17/2018 04:09:13'),
 (11,'1234','student','90789','student','we','2/17/2018 01:22:02'),
 (12,'45872','student','90789','student','awesome','2/18/2018 06:21:14'),
 (13,'2323456','employee','90789','student','hi sir','2/18/2018 08:26:25'),
 (14,'90789','student','90789','student','hello','2/18/2018 08:26:33');
/*!40000 ALTER TABLE `tbl_messages_log` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_notifications`
--

DROP TABLE IF EXISTS `tbl_notifications`;
CREATE TABLE `tbl_notifications` (
  `notif_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date_added` varchar(100) DEFAULT '',
  `user_id` varchar(45) DEFAULT '',
  `user_type` varchar(45) DEFAULT '',
  `title` varchar(200) DEFAULT '',
  `content` varchar(10000) DEFAULT '',
  `location_id` varchar(45) DEFAULT '',
  `location_type` varchar(45) DEFAULT '',
  `by_id` varchar(45) DEFAULT '',
  `by_type` varchar(45) DEFAULT '',
  PRIMARY KEY (`notif_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_notifications`
--

/*!40000 ALTER TABLE `tbl_notifications` DISABLE KEYS */;
INSERT INTO `tbl_notifications` (`notif_id`,`date_added`,`user_id`,`user_type`,`title`,`content`,`location_id`,`location_type`,`by_id`,`by_type`) VALUES 
 (18,'1/29/2018 06:08:24','12423','employee','New reflection requirement added.','Warriors: New activity added.','1','class','1234','student'),
 (19,'1/29/2018 06:08:24','2323456','employee','New reflection requirement added.','Warriors: New activity added.','1','class','1234','student'),
 (20,'1/29/2018 06:08:24','45872','student','New reflection requirement added.','Warriors: New activity added.','1','class','1234','student'),
 (21,'1/29/2018 06:08:24','90789','student','New reflection requirement added.','Warriors: New activity added.','1','class','1234','student'),
 (22,'1/29/2018 06:10:22','1234','student','New Rate.','SWAT: New rate added.','2','hte','1234',''),
 (23,'1/29/2018 06:10:22','45872','student','New Rate.','SWAT: New rate added.','2','hte','1234',''),
 (24,'1/29/2018 06:10:22','90789','student','New Rate.','SWAT: New rate added.','2','hte','1234',''),
 (25,'2/14/2018 06:57:04','1234','student','New Rate.','FBI: New rate added.','1','hte','90789','student');
INSERT INTO `tbl_notifications` (`notif_id`,`date_added`,`user_id`,`user_type`,`title`,`content`,`location_id`,`location_type`,`by_id`,`by_type`) VALUES 
 (26,'2/14/2018 06:57:04','45872','student','New Rate.','FBI: New rate added.','1','hte','90789','student'),
 (27,'2/14/2018 07:10:29','1234','student','New Rate.','FBI: New rate added.','1','hte','90789','student'),
 (28,'2/14/2018 07:10:29','45872','student','New Rate.','FBI: New rate added.','1','hte','90789','student'),
 (29,'2/14/2018 07:11:41','1234','student','New Rate.','FBI: New rate added.','1','hte','90789','student'),
 (30,'2/14/2018 07:11:41','45872','student','New Rate.','FBI: New rate added.','1','hte','90789','student'),
 (31,'2/14/2018 07:17:22','1234','student','New Rate.','FBI: New rate added.','1','hte','90789','student'),
 (32,'2/14/2018 07:17:22','45872','student','New Rate.','FBI: New rate added.','1','hte','90789','student'),
 (33,'2/17/2018 11:53:14','1234','student','New Job.','FBI: New job added.','1','hte','admin','admin'),
 (34,'2/17/2018 11:53:14','45872','student','New Job.','FBI: New job added.','1','hte','admin','admin');
INSERT INTO `tbl_notifications` (`notif_id`,`date_added`,`user_id`,`user_type`,`title`,`content`,`location_id`,`location_type`,`by_id`,`by_type`) VALUES 
 (35,'2/17/2018 11:53:14','90789','student','New Job.','FBI: New job added.','1','hte','admin','admin'),
 (36,'3/5/2018 11:14:49','1234','student','New Rate.','FBI: New rate added.','1','hte','90789','student'),
 (37,'3/5/2018 11:14:49','45872','student','New Rate.','FBI: New rate added.','1','hte','90789','student'),
 (38,'3/5/2018 11:16:28','1234','student','New Rate.','FBI: New rate added.','1','hte','90789','student'),
 (39,'3/5/2018 11:16:28','45872','student','New Rate.','FBI: New rate added.','1','hte','90789','student');
/*!40000 ALTER TABLE `tbl_notifications` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_rate_score`
--

DROP TABLE IF EXISTS `tbl_rate_score`;
CREATE TABLE `tbl_rate_score` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rate` varchar(45) DEFAULT '',
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_rate_score`
--

/*!40000 ALTER TABLE `tbl_rate_score` DISABLE KEYS */;
INSERT INTO `tbl_rate_score` (`no`,`rate`) VALUES 
 (1,'1.0'),
 (2,'1.25'),
 (3,'1.5'),
 (4,'1.75'),
 (5,'2.0'),
 (6,'2.25'),
 (7,'2.5'),
 (8,'2.75'),
 (9,'3.0'),
 (10,'3.25'),
 (11,'3.5'),
 (12,'3.75'),
 (13,'4.0'),
 (14,'4.25'),
 (15,'4.5'),
 (16,'4.75'),
 (17,'5.0');
/*!40000 ALTER TABLE `tbl_rate_score` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_reqstats`
--

DROP TABLE IF EXISTS `tbl_reqstats`;
CREATE TABLE `tbl_reqstats` (
  `No` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(45) DEFAULT '',
  PRIMARY KEY (`No`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_reqstats`
--

/*!40000 ALTER TABLE `tbl_reqstats` DISABLE KEYS */;
INSERT INTO `tbl_reqstats` (`No`,`status`) VALUES 
 (1,'Completed'),
 (2,'Pending'),
 (3,'Dropped');
/*!40000 ALTER TABLE `tbl_reqstats` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_semester`
--

DROP TABLE IF EXISTS `tbl_semester`;
CREATE TABLE `tbl_semester` (
  `sem_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `semester` varchar(45) DEFAULT '',
  PRIMARY KEY (`sem_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_semester`
--

/*!40000 ALTER TABLE `tbl_semester` DISABLE KEYS */;
INSERT INTO `tbl_semester` (`sem_id`,`semester`) VALUES 
 (1,'1st'),
 (2,'2nd'),
 (3,'3rd');
/*!40000 ALTER TABLE `tbl_semester` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_staff_position`
--

DROP TABLE IF EXISTS `tbl_staff_position`;
CREATE TABLE `tbl_staff_position` (
  `staff_position_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `position` varchar(45) DEFAULT '',
  PRIMARY KEY (`staff_position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_staff_position`
--

/*!40000 ALTER TABLE `tbl_staff_position` DISABLE KEYS */;
INSERT INTO `tbl_staff_position` (`staff_position_id`,`position`) VALUES 
 (1,'Teacher'),
 (2,'Dean'),
 (3,'Supervisor'),
 (4,'Coordinator');
/*!40000 ALTER TABLE `tbl_staff_position` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_sy`
--

DROP TABLE IF EXISTS `tbl_sy`;
CREATE TABLE `tbl_sy` (
  `sy_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SY` varchar(45) DEFAULT '',
  PRIMARY KEY (`sy_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_sy`
--

/*!40000 ALTER TABLE `tbl_sy` DISABLE KEYS */;
INSERT INTO `tbl_sy` (`sy_id`,`SY`) VALUES 
 (1,'2016-2017'),
 (2,'2017-2018');
/*!40000 ALTER TABLE `tbl_sy` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_uact`
--

DROP TABLE IF EXISTS `tbl_uact`;
CREATE TABLE `tbl_uact` (
  `uact_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` varchar(45) DEFAULT '',
  `member_type` varchar(45) DEFAULT '',
  `msg` varchar(10000) DEFAULT '',
  `adate` varchar(100) DEFAULT '',
  `atype` varchar(45) DEFAULT '',
  PRIMARY KEY (`uact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_uact`
--

/*!40000 ALTER TABLE `tbl_uact` DISABLE KEYS */;
INSERT INTO `tbl_uact` (`uact_id`,`member_id`,`member_type`,`msg`,`adate`,`atype`) VALUES 
 (2,'90789','student',' evaluated FBI.','2/14/2018 07:17:22','1'),
 (3,'90789','student',' submitted a reflection in Androids class.','2/14/2018 07:42:21','1'),
 (4,'90789','student',' submitted a reflection in Androids class.','2/16/2018 05:48:50','1'),
 (5,'90789','student',' submitted a reflection in Androids class.','2/22/2018 10:35:51','1'),
 (6,'90789','student',' evaluated FBI.','3/5/2018 11:14:49','1'),
 (7,'90789','student',' evaluated FBI.','3/5/2018 11:16:28','1');
/*!40000 ALTER TABLE `tbl_uact` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_upfiles`
--

DROP TABLE IF EXISTS `tbl_upfiles`;
CREATE TABLE `tbl_upfiles` (
  `No` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) DEFAULT '',
  `Location` varchar(200) DEFAULT '',
  `Date_Uploaded` varchar(100) DEFAULT '',
  `upby_id` varchar(45) DEFAULT '',
  `upby_type` varchar(45) DEFAULT '',
  `utype` varchar(45) DEFAULT '',
  `uloc_id` varchar(45) DEFAULT '',
  `uloc_type` varchar(45) DEFAULT '',
  `uloc2_id` varchar(45) DEFAULT '',
  `ap_status` varchar(45) DEFAULT '',
  PRIMARY KEY (`No`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_upfiles`
--

/*!40000 ALTER TABLE `tbl_upfiles` DISABLE KEYS */;
INSERT INTO `tbl_upfiles` (`No`,`Name`,`Location`,`Date_Uploaded`,`upby_id`,`upby_type`,`utype`,`uloc_id`,`uloc_type`,`uloc2_id`,`ap_status`) VALUES 
 (1,'5f0e364834f720e7060861b0da0b9236.jpg','uploads/file_1_22_2018__12_03_44.jpg','1/22/2018 12:03:44','','','','','','',''),
 (2,'211677_blade-and-soul-wallpapers_3060x1835_h.jpg','uploads/file_1_22_2018__12_09_44.jpg','1/22/2018 12:09:44','','','','','','',''),
 (3,'134.jpg','uploads/file_1_22_2018__12_23_36.jpg','1/22/2018 12:23:36','','','','','','',''),
 (4,'134.jpg','uploads/file_1_22_2018__12_25_05.jpg','1/22/2018 12:25:05','','','','','','',''),
 (5,'SAMPLE RESUME.pdf','uploads/file_1_22_2018__02_47_21.pdf','1/22/2018 02:47:21','','','','','','',''),
 (6,'SAMPLE APPLETTER.pdf','uploads/file_1_22_2018__02_49_43.pdf','1/22/2018 02:49:43','','','','','','',''),
 (7,'SAMPLE MOA.pdf','uploads/file_1_22_2018__02_51_15.pdf','1/22/2018 02:51:15','','','','','','',''),
 (8,'SAMPLE RESUME.pdf','uploads/file_1_22_2018__02_53_25.pdf','1/22/2018 02:53:25','','','','','','',''),
 (9,'SAMPLE APPLETTER.pdf','uploads/file_1_22_2018__02_53_37.pdf','1/22/2018 02:53:37','','','','','','','');
INSERT INTO `tbl_upfiles` (`No`,`Name`,`Location`,`Date_Uploaded`,`upby_id`,`upby_type`,`utype`,`uloc_id`,`uloc_type`,`uloc2_id`,`ap_status`) VALUES 
 (10,'SAMPLE MOA.pdf','uploads/file_1_22_2018__02_53_43.pdf','1/22/2018 02:53:43','','','','','','',''),
 (11,'SAMPLE MOU.pdf','uploads/file_1_22_2018__02_53_49.pdf','1/22/2018 02:53:49','','','','','','',''),
 (12,'SAMPLE CERTACC.pdf','uploads/file_1_22_2018__02_53_58.pdf','1/22/2018 02:53:58','','','','','','',''),
 (13,'SAMPLE RESUME.docx','uploads/file_1_22_2018__03_00_09.docx','1/22/2018 03:00:09','','','','','','',''),
 (14,'SAMPLE RESUME.pdf','uploads/file_1_22_2018__03_01_39.pdf','1/22/2018 03:01:39','','','','','','',''),
 (15,'SAMPLE RESUME.pdf','uploads/file_1_22_2018__04_44_56.pdf','1/22/2018 04:44:56','','','','','','',''),
 (16,'SAMPLE RESUME.pdf','uploads/file_1_24_2018__07_28_58.pdf','1/24/2018 07:28:58','','','','','','',''),
 (17,'Koala.jpg','uploads/file_1_24_2018__07_29_23.jpg','1/24/2018 07:29:23','','','','','','',''),
 (18,'Penguins.jpg','uploads/file_1_24_2018__05_09_27.jpg','1/24/2018 05:09:27','','','','','','','');
INSERT INTO `tbl_upfiles` (`No`,`Name`,`Location`,`Date_Uploaded`,`upby_id`,`upby_type`,`utype`,`uloc_id`,`uloc_type`,`uloc2_id`,`ap_status`) VALUES 
 (19,'SAMPLE APPLETTER.pdf','uploads/file_1_27_2018__05_40_40.pdf','1/27/2018 05:40:40','','','','','','',''),
 (20,'SAMPLE APPLETTER.pdf','uploads/file_1_27_2018__05_42_04.pdf','1/27/2018 05:42:04','','','','','','',''),
 (21,'SAMPLE APPLETTER.pdf','uploads/file_1_27_2018__05_43_57.pdf','1/27/2018 05:43:57','','','','','','',''),
 (22,'SAMPLE CERTACC.pdf','uploads/file_1_27_2018__05_46_32.pdf','1/27/2018 05:46:32','','','','','','',''),
 (23,'SAMPLE APPLETTER.pdf','uploads/file_1_27_2018__05_51_14.pdf','1/27/2018 05:51:14','','','','','','',''),
 (24,'SAMPLE APPLETTER.pdf','uploads/file_1_27_2018__05_51_44.pdf','1/27/2018 05:51:44','','','','','','',''),
 (25,'SAMPLE CERTACC.pdf','uploads/file_1_27_2018__06_02_09.pdf','1/27/2018 06:02:09','','','','','','',''),
 (26,'SAMPLE RESUME.pdf','uploads/file_1_27_2018__06_03_43.pdf','1/27/2018 06:03:43','','','','','','',''),
 (27,'SAMPLE CERTACC.pdf','uploads/file_1_27_2018__06_09_11.pdf','1/27/2018 06:09:11','','','','','','','');
INSERT INTO `tbl_upfiles` (`No`,`Name`,`Location`,`Date_Uploaded`,`upby_id`,`upby_type`,`utype`,`uloc_id`,`uloc_type`,`uloc2_id`,`ap_status`) VALUES 
 (28,'SAMPLE MOU.pdf','uploads/file_1_27_2018__06_09_49.pdf','1/27/2018 06:09:49','','','','','','',''),
 (29,'SAMPLE APPLETTER.pdf','uploads/file_1_27_2018__06_12_02.pdf','1/27/2018 06:12:02','','','','','','',''),
 (30,'SAMPLE MOA.pdf','uploads/file_1_27_2018__06_12_14.pdf','1/27/2018 06:12:14','','','','','','',''),
 (31,'SAMPLE RESUME.pdf','uploads/file_1_27_2018__06_12_57.pdf','1/27/2018 06:12:57','','','','','','',''),
 (32,'SAMPLE RESUME.pdf','uploads/file_1_27_2018__06_19_17.pdf','1/27/2018 06:19:17','','','','','','',''),
 (33,'SAMPLE RESUME.pdf','uploads/file_1_27_2018__06_21_24.pdf','1/27/2018 06:21:24','','','','','','',''),
 (34,'SAMPLE MOU.pdf','uploads/file_1_27_2018__06_22_51.pdf','1/27/2018 06:22:51','','','','','','',''),
 (35,'SAMPLE MOU.pdf','uploads/file_1_27_2018__06_23_54.pdf','1/27/2018 06:23:54','','','','','','',''),
 (36,'SAMPLE RESUME.pdf','uploads/file_1_27_2018__06_28_04.pdf','1/27/2018 06:28:04','','','','','','','');
INSERT INTO `tbl_upfiles` (`No`,`Name`,`Location`,`Date_Uploaded`,`upby_id`,`upby_type`,`utype`,`uloc_id`,`uloc_type`,`uloc2_id`,`ap_status`) VALUES 
 (37,'SAMPLE RESUME.pdf','uploads/file_2_11_2018__06_54_19.pdf','2/11/2018 06:54:19','','','','','','',''),
 (38,'SAMPLE APPLETTER.pdf','uploads/file_2_11_2018__06_54_48.pdf','2/11/2018 06:54:48','','','','','','',''),
 (39,'SAMPLE MOA.pdf','uploads/file_2_11_2018__06_54_54.pdf','2/11/2018 06:54:54','','','','','','',''),
 (40,'SAMPLE MOU.pdf','uploads/file_2_11_2018__06_55_00.pdf','2/11/2018 06:55:00','','','','','','',''),
 (41,'SAMPLE CERTACC.pdf','uploads/file_2_11_2018__06_55_25.pdf','2/11/2018 06:55:25','','','','','','',''),
 (42,'SAMPLE MOU.pdf','uploads/file_2_14_2018__07_20_01.pdf','2/14/2018 07:20:01','','','','','','',''),
 (43,'SAMPLE MOU.pdf','uploads/file_2_14_2018__07_32_54.pdf','2/14/2018 07:32:54','','','','','','',''),
 (44,'SAMPLE APPLETTER.pdf','uploads/file_2_14_2018__07_33_42.pdf','2/14/2018 07:33:42','','','','','','',''),
 (45,'SAMPLE MOU.pdf','uploads/file_2_14_2018__07_34_39.pdf','2/14/2018 07:34:39','','','','','','','');
INSERT INTO `tbl_upfiles` (`No`,`Name`,`Location`,`Date_Uploaded`,`upby_id`,`upby_type`,`utype`,`uloc_id`,`uloc_type`,`uloc2_id`,`ap_status`) VALUES 
 (46,'SAMPLE CERTACC.pdf','uploads/file_2_14_2018__07_37_46.pdf','2/14/2018 07:37:46','','','','','','',''),
 (47,'SAMPLE MOA.pdf','uploads/file_2_14_2018__07_42_21.pdf','2/14/2018 07:42:21','','','','','','',''),
 (48,'SAMPLE MOU.pdf','uploads/file_2_16_2018__05_48_50.pdf','2/16/2018 05:48:50','90789','student','Reflection','','','','Approved'),
 (49,'101.jpg','uploads/file_2_18_2018__10_32_42.jpg','2/18/2018 10:32:42','90789','student','announcement','1','course','',''),
 (50,'102.jpg','uploads/file_2_18_2018__10_39_18.jpg','2/18/2018 10:39:18','90789','student','announcement','1','course','',''),
 (51,'TheBossBaby.jpg','uploads/file_2_18_2018__10_40_34.jpg','2/18/2018 10:40:34','','','','','','',''),
 (52,'AFewLessMen.jpg','uploads/file_2_18_2018__11_26_34.jpg','2/18/2018 11:26:34','90789','student','announcement','1','hte','',''),
 (53,'SAMPLE MOU.pdf','uploads/file_2_22_2018__10_35_51.pdf','2/22/2018 10:35:51','90789','student','Reflection','2','class','','Approved'),
 (54,'Koala.jpg','uploads/file_2_22_2018__01_41_15.jpg','2/22/2018 01:41:15','90789','student','Requirement','90789','student','','');
INSERT INTO `tbl_upfiles` (`No`,`Name`,`Location`,`Date_Uploaded`,`upby_id`,`upby_type`,`utype`,`uloc_id`,`uloc_type`,`uloc2_id`,`ap_status`) VALUES 
 (55,'Lighthouse.jpg','uploads/file_2_22_2018__01_45_32.jpg','2/22/2018 01:45:32','90789','student','Requirement','90789','student','',''),
 (56,'SAMPLE RESUME.docx','uploads/file_2_22_2018__01_46_08.docx','2/22/2018 01:46:08','90789','student','Requirement','90789','student','',''),
 (57,'Hydrangeas.jpg','uploads/file_2_22_2018__01_46_28.jpg','2/22/2018 01:46:28','90789','student','Requirement','90789','student','',''),
 (58,'Jellyfish.jpg','uploads/file_2_22_2018__01_46_41.jpg','2/22/2018 01:46:41','90789','student','Requirement','90789','student','',''),
 (59,'Desert.jpg','uploads/file_2_22_2018__01_46_51.jpg','2/22/2018 01:46:51','90789','student','Requirement','90789','student','',''),
 (60,'Koala.jpg','uploads/file_2_22_2018__01_47_02.jpg','2/22/2018 01:47:02','90789','student','Requirement','90789','student','',''),
 (61,'Tulips.jpg','uploads/file_2_22_2018__01_47_15.jpg','2/22/2018 01:47:15','90789','student','Requirement','90789','student','','Approved'),
 (62,'Koala.jpg','uploads/file_3_2_2018__07_25_33.jpg','3/2/2018 07:25:33','90789','student','Requirement','90789','student','','');
/*!40000 ALTER TABLE `tbl_upfiles` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_user_requirements`
--

DROP TABLE IF EXISTS `tbl_user_requirements`;
CREATE TABLE `tbl_user_requirements` (
  `No` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `req_type` varchar(45) DEFAULT '',
  `req_file` varchar(200) DEFAULT '',
  `date_added` varchar(100) DEFAULT '',
  `studentid` varchar(45) DEFAULT '',
  PRIMARY KEY (`No`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_user_requirements`
--

/*!40000 ALTER TABLE `tbl_user_requirements` DISABLE KEYS */;
INSERT INTO `tbl_user_requirements` (`No`,`name`,`req_type`,`req_file`,`date_added`,`studentid`) VALUES 
 (1,'Certification of Acceptance','requirement:certification_of_acceptance','uploads/file_1_22_2018__02_47_21.pdf','1/22/2018 02:47:21','1234'),
 (2,'Certification of Acceptance','requirement:certification_of_acceptance','uploads/file_1_22_2018__02_49_43.pdf','1/22/2018 02:49:43','1234'),
 (3,'Certification of Acceptance','requirement:certification_of_acceptance','uploads/file_1_22_2018__02_51_15.pdf','1/22/2018 02:51:15','1234'),
 (4,'Resume','requirement:resume','uploads/file_1_22_2018__02_53_25.pdf','1/22/2018 02:53:25','1234'),
 (5,'Application Letter','requirement:application_letter','uploads/file_1_22_2018__02_53_37.pdf','1/22/2018 02:53:37','1234'),
 (6,'MOA','requirement:moa','uploads/file_1_22_2018__02_53_43.pdf','1/22/2018 02:53:43','1234'),
 (7,'MOU','requirement:mou','uploads/file_1_22_2018__02_53_49.pdf','1/22/2018 02:53:49','1234'),
 (8,'Certification of Acceptance','requirement:certification_of_acceptance','uploads/file_1_22_2018__02_53_58.pdf','1/22/2018 02:53:58','1234'),
 (9,'Resume','requirement:resume','uploads/file_1_22_2018__03_00_09.docx','1/22/2018 03:00:09','1234');
INSERT INTO `tbl_user_requirements` (`No`,`name`,`req_type`,`req_file`,`date_added`,`studentid`) VALUES 
 (10,'Resume','requirement:resume','uploads/file_1_22_2018__03_01_39.pdf','1/22/2018 03:01:39','1234'),
 (11,'Resume','requirement:resume','uploads/file_1_22_2018__04_44_56.pdf','1/22/2018 04:44:56','5645'),
 (12,'Resume','requirement:resume','uploads/file_2_11_2018__06_54_19.pdf','2/11/2018 06:54:19','90789'),
 (13,'Application Letter','requirement:application_letter','uploads/file_2_11_2018__06_54_48.pdf','2/11/2018 06:54:48','90789'),
 (14,'MOA','requirement:moa','uploads/file_2_11_2018__06_54_54.pdf','2/11/2018 06:54:54','90789'),
 (15,'MOU','requirement:mou','uploads/file_2_11_2018__06_55_00.pdf','2/11/2018 06:55:00','90789'),
 (16,'Certification of Acceptance','requirement:certification_of_acceptance','uploads/file_2_11_2018__06_55_25.pdf','2/11/2018 06:55:25','90789'),
 (17,'White Form','requirement:white_form','uploads/file_2_22_2018__01_41_15.jpg','2/22/2018 01:41:15','90789'),
 (18,'Recommendation Letter','requirement:recommendation_letter','uploads/file_2_22_2018__01_45_32.jpg','2/22/2018 01:45:32','90789');
INSERT INTO `tbl_user_requirements` (`No`,`name`,`req_type`,`req_file`,`date_added`,`studentid`) VALUES 
 (19,'Waiver','requirement:waiver','uploads/file_2_22_2018__01_46_08.docx','2/22/2018 01:46:08','90789'),
 (20,'Parent Consent','requirement:parent_consent','uploads/file_2_22_2018__01_46_28.jpg','2/22/2018 01:46:28','90789'),
 (21,'Medical Certificate','requirement:medical_certificate','uploads/file_2_22_2018__01_46_41.jpg','2/22/2018 01:46:41','90789'),
 (22,'Certificate of Appreciation','requirement:certificate_of_appreciation','uploads/file_2_22_2018__01_46_51.jpg','2/22/2018 01:46:51','90789'),
 (23,'Certificate of Completion','requirement:certificate_of_completion','uploads/file_2_22_2018__01_47_02.jpg','2/22/2018 01:47:02','90789'),
 (24,'OJT Photo','requirement:ojt_photo','uploads/file_2_22_2018__01_47_15.jpg','2/22/2018 01:47:15','90789'),
 (25,'Resume','requirement:resume','uploads/file_3_2_2018__07_25_33.jpg','3/2/2018 07:25:33','90789');
/*!40000 ALTER TABLE `tbl_user_requirements` ENABLE KEYS */;


--
-- Table structure for table `db_internship`.`tbl_year`
--

DROP TABLE IF EXISTS `tbl_year`;
CREATE TABLE `tbl_year` (
  `year_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `year` varchar(45) DEFAULT '',
  PRIMARY KEY (`year_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_internship`.`tbl_year`
--

/*!40000 ALTER TABLE `tbl_year` DISABLE KEYS */;
INSERT INTO `tbl_year` (`year_id`,`year`) VALUES 
 (1,'1st'),
 (2,'2nd'),
 (3,'3rd'),
 (4,'4th'),
 (5,'5th');
/*!40000 ALTER TABLE `tbl_year` ENABLE KEYS */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
