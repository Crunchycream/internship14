<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
	$_SESSION['intern_page_current'] = "manage_coordinator";
		include "./parts/main_logcheck.php";
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	if ( $_POST['btnsave'] ) {
		$employee_id = (trim($_POST['empid']));
		$department_id = (trim($_POST['deptid']));
		$course_id = (trim($_POST['crsid']));
		$hte_id = (trim($_POST['hteid']));
		$errn = 0;
		$errmsg = "";
		if ( trim($employee_id) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Employee required. ";
		}
		if ( trim($department_id) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Department required. ";
		}
		if ( trim($course_id) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Course required. ";
		}
		if ( trim($hte_id) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "HTE required. ";
		}
		$ec = 0;
		$sql = " select * from tbl_coordinator  where employee_id='$employee_id' and department_id='$department_id' and course_id='$course_id' and hte_id='$hte_id' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_array($qry)) {
			$ec = $ec + 1;
		}
		if ( trim($ec) > 0 ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Coordinator already exist. ";
		}
		if ( $errn <= 0 ) {
			//SAVE DATA
			$sql = " insert into tbl_coordinator  
						(employee_id,department_id,course_id,hte_id)
						values
						('$employee_id','$department_id','$course_id','$hte_id')
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
			echo "
				<script>
					alert('$errmsg');
				</script>
			";
		}
	}
	//
	if ( $_POST['btnsaveEdit'] ) {
		$cid = (trim($_POST['txtid']));
		$employee_id = (trim($_POST['empid']));
		$department_id = (trim($_POST['deptid']));
		$course_id = (trim($_POST['crsid']));
		$hte_id = (trim($_POST['hteid']));
		$errn = 0;
		$errmsg = "";
		if ( trim($employee_id) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Employee required. ";
		}
		if ( trim($department_id) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Department required. ";
		}
		if ( trim($course_id) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Course required. ";
		}
		if ( trim($hte_id) == "" ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "HTE required. ";
		}
		if ( $errn <= 0 ) {
			//SAVE DATA
			$sql = " update tbl_coordinator set  
						employee_id='$employee_id',department_id='$department_id',course_id='$course_id',hte_id='$hte_id' 
						where coordinator_id='$cid' 
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
			echo "
				<script>
					alert('$errmsg');
				</script>
			";
		}
	}
	//
	if ( $_POST['btnsaveDelete'] ) {
		$cid = (trim($_POST['txtid']));
		$errn = 0;
		$errmsg = "";
		if ( $errn <= 0 ) {
			//SAVE DATA
			$sql = " delete from tbl_coordinator  
						where coordinator_id='$cid' 
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
			echo "
				<script>
					alert('$errmsg');
				</script>
			";
		}
	}
	//
	if ( trim($logun)=="" || strtolower(trim($logutype))==strtolower(trim("student")) ) {
		exit;
	}
?>

<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>


</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">Coordinator</h3>
					<div class="row">

					<?php include "./parts/manage_coordinator_modal.php"; ?>

						<div class="col-md-12">
							<!-- BASIC TABLE -->
							<div class="row">
							<div class="col-md-9">
							<h5 class="ss">Search:</h5>
							</div>
						
							
							<div class="col-md-3">
							<div class="form-group pull-right">
								
							<input type="text" id="myInput1" value="" class="search form-control" placeholder="What you looking for">
									<!--
								<span class="counter pull-right"><button type="button" class="btn btn-primary">Search</button></span>
									-->
									

								</div>
									<span class="counter pull-right"></span>
									</div>
									
						</div>
						<hr>
				
					<a href="" data-toggle="modal" data-target="#modalAddCoordinator" class="btn btn-success btn-md">+ ADD NEW COORDINATOR</a>
							<br/>
							<br/>
							<!-- RECENT PURCHASES -->
							<div class="panel">
					
								<div class="table-responsive">
									<table class="table">
										<thead>
											<tr>
												<th></th>
												<th>Employee</th>
												<th>Department</th>
												<th>Course</th>
												<th>HTE</th>
											</tr>
										</thead>
										<tbody id="myTable1">
											<?php
												include "./data/connect.php";
												//
												$nn = 0;
												//
												$search = trim($_GET['search']);
												$fsw = "";
												if ( trim($search)!="" ) {
													$fsw = " where course='$search' ";
												}
												//
												//FILTER
												$empid = "";
												$classid = "";
												$empid = trim($_GET['employeeid']);
												$classid = trim($_GET['classid']);
												//
												if ( trim($fsw)=="" ) {
													$fsw = " where employee_id='$empid' ";
												}else{
													$fsw = $fsw . " employee_id='$empid' ";
												}
												//                     0            1              2        3        4   
												$sql = " select coordinator_id,employee_id,department_id,course_id,hte_id from tbl_coordinator $fsw ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$nn = $nn + 1;
													//
													$empn = "";
													$deptn = "";
													$crsn = "";
													$hten = "";
													$sql1 = " select employee_id,lastname,firstname,middlename from tbl_employee  where employee_id='$dat[1]'  ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														if ( trim($dat1[1])!="" && trim($dat1[2])!="" ) {
															$empn = trim($dat1[1]) . ", " . trim($dat1[2]) . " " . trim($dat1[3]);
														}
													}
													$sql1 = " select department_id,department from tbl_department  where department_id='$dat[2]'  ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														if ( trim($dat1[1])!="" ) {
															$deptn = trim($dat1[1]);
														}
													}
													$sql1 = " select course_id,course from tbl_course  where course_id='$dat[3]'  ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														if ( trim($dat1[1])!="" ) {
															$crsn = trim($dat1[1]);
														}
													}
													$sql1 = " select hte_id,name from tbl_hte  where hte_id='$dat[4]'  ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														if ( trim($dat1[1])!="" ) {
															$hten = trim($dat1[1]);
														}
													}
													//
													$empopt = "";
													$detopt = "";
													$crsopt = "";
													$hteopt = "";
													//
														$sql2 = " select employee_id,lastname,firstname,middlename from tbl_employee  order by lastname asc ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															if ( trim($dat2[0]) != "" && trim($dat2[1]) != "" && trim($dat2[2]) != "" ) {
																$val = trim($dat2[0]);
																$nam = trim($dat2[1]) . ", " . trim($dat2[2]) . " " . trim($dat2[3]);
																$isel = "";
																if ( strtolower(trim($empn))==strtolower(trim($nam)) ) {
																	$isel = " selected='true' ";
																}
																$empopt = $empopt . "<option value='".$val."' $isel>".$nam."</option>";
															}
														}
														$sql2 = " select department_id,department from tbl_department  order by department asc  ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															if ( trim($dat2[0]) != "" && trim($dat2[1]) != "" ) {
																$val = trim($dat2[0]);
																$nam = trim($dat2[1]);
																$isel = "";
																if ( strtolower(trim($deptn))==strtolower(trim($nam)) ) {
																	$isel = " selected='true' ";
																}
																$detopt = $detopt . "<option value='".$val."' $isel>".$nam."</option>";
															}
														}
														$sql2 = " select course_id,course from tbl_course  order by course asc ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															if ( trim($dat2[0]) != '' && trim($dat2[1]) != '' ) {
																$val = trim($dat2[0]);
																$nam = trim($dat2[1]);
																$isel = "";
																if ( strtolower(trim($crsn))==strtolower(trim($nam)) ) {
																	$isel = " selected='true' ";
																}
																$crsopt = $crsopt . "<option value='".$val."' $isel>".$nam."</option>";
															}
														}
														$sql2 = " select hte_id,name from tbl_hte  order by name asc ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															if ( trim($dat2[0]) != "" && trim($dat2[1]) != "" ) {
																$val = trim($dat2[0]);
																$nam = trim($dat2[1]);
																$isel = "";
																if ( strtolower(trim($hten))==strtolower(trim($nam)) ) {
																	$isel = " selected='true' ";
																}
																$hteopt = $hteopt . "<option value='".$val."' $isel>".$nam."</option>";
															}
														}
													//
													echo "
														<tr>
															<td>
															
																<div class='dropdown'>
																  <a class='btn_action_01' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu'>
																    <li><a href='#' data-toggle='modal' data-target='#modalEdit_$nn'>Edit</a></li>
																    <li><a href='#' data-toggle='modal' data-target='#modalDelete_$nn'>Delete</a></li>
																  </ul>
																</div>

																		<div id='modalEdit_$nn' class='modal fade' role='dialog'>
																			<div class='modal-dialog'>
																			<!-- Modal content-->
																			<div class='modal-content'>
																			<div class='modal-header'>
																				<button type='button' class='close' data-dismiss='modal'>&times;</button>
																				<h4 class='modal-title'>Update Coordinator</h4>
																			</div>
																					<form method='post' action=''>
																			<div class='modal-body'>
																				<p>
																					<input type='hidden' name='txtid' value='$dat[0]'/>
																					<div class='form-group'>
																						
																					</div>
																					<div class='form-group div01'>
																						Employee<br/>
																							<select class='form-control txt01' name='empid'>
																								$empopt
																							</select>
																					</div>
																					<div class='form-group div01'>
																						Department<br/>
																							<select class='form-control txt01' name='deptid'>
																								$detopt
																							</select>
																					</div>
																					<div class='form-group div01'>
																						Course<br/>
																							<select class='form-control txt01' name='crsid'>
																								$crsopt
																							</select>
																					</div>
																					<div class='form-group div01'>
																						HTE<br/>
																							<select class='form-control txt01' name='hteid'>
																								$hteopt
																							</select>
																					</div>
																						
																				</p>
																			</div>
																			<div class='modal-footer'>
																				<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																				<input type='submit' name='btnsaveEdit' class='btn btn-primary btn-lg btn01' value='SAVE'>
																			</div>
																					</form>
																			</div>

																			</div>
																		</div>

																		<div id='modalDelete_$nn' class='modal fade' role='dialog'>
																			<div class='modal-dialog'>
																			<!-- Modal content-->
																			<div class='modal-content'>
																			<div class='modal-header'>
																				<button type='button' class='close' data-dismiss='modal'>&times;</button>
																				<h4 class='modal-title'>Update Coordinator</h4>
																			</div>
																					<form method='post' action=''>
																			<div class='modal-body'>
																				<p>
																					<input type='hidden' name='txtid' value='$dat[0]'/>
																					Delete coordinator?
																				</p>
																			</div>
																			<div class='modal-footer'>
																				<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																				<input type='submit' name='btnsaveDelete' class='btn btn-primary btn-lg btn01' value='DELETE'>
																			</div>
																					</form>
																			</div>

																			</div>
																		</div>

															</td>
															<td>
																<a href='./page_profile_employee.php?id=".trim($dat[1])."'>".trim($empn)."</a>
															</td>
															<td>
																".trim($deptn)."
															</td>
															<td>
																".trim($crsn)."
															</td>
															<td>
																<a href='./page_hte.php?id=".trim($dat[4])."'>".trim($hten)."</a>
															</td>
														</tr>
													";
												}
											?>
											
										</tbody>
									</table>
								</div>
							</div>
					
							<!-- END TABLE NO PADDING -->
						</div>
					</div>
								
					
				
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>

	<script >
	$(document).ready(function(){
  $("#myInput1").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable1 tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

	</script>


<?php
	include "./parts/btm_script.php";
?>


</body>

</html>