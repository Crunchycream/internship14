<?php
	date_default_timezone_set('Asia/Hong_Kong');
	$date_year = date('Y');
	$date_month = date('n');
	$date_day = date('j');
	$date_hour = date('h');
	$date_minute = date('i');
	$date_second = date('s');
	$connsn = "localhost";
	$connun = "root";
	$connpass = "";
	$conndbn = "db_internship";
	$conn = mysqli_connect($connsn,$connun,$connpass,$conndbn);
?>
