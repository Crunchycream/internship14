<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
	//
	$logun =  $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$curid = trim($_GET['id']);
	$curid = "90789";
	//
	if ( trim($curid)!="" ) {
		$fdata;
		$n = 0;
		//
		$sql = " select hte_id,name,address,info,map_loc_latitude,map_loc_longitude from tbl_hte  limit 1 ";
		//$sql = " select hte_id,name,address,info,map_loc_latitude,map_loc_longitude from tbl_hte  where hte_id='$curid' ";
		$qry = mysqli_query($conn,$sql);
		while($dat=mysqli_fetch_row($qry)) {
			$fdata = $dat;
			$n += 1;
		}
		echo json_encode($fdata);
	}
?>