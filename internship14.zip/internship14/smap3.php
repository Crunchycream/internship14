<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
      $cid = trim($_GET['id']);
      include "./parts/sys_functions.php";
?>
<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <title>Map</title>

  <?php include "./parts/head_content.php"; ?>

    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
        max-height: 800px;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
    </style>
  </head>
  <body style="background:#fff;">

    <div id="map"></div>

    <div>
    <?php include "./data/connect.php";
      
        //
        //
        $nn = 0;
        //                 0    1    2       3       4                5        
        $sql = " select hte_id,name,address,info,map_loc_latitude,map_loc_longitude from tbl_hte where hte_id<>'' and name<>'' ";
        //$sql = " select hte_id,name,address,info,map_loc_latitude,map_loc_longitude from tbl_hte  where hte_id='$curid' ";
        $qry = mysqli_query($conn,$sql);
        while($dat=mysqli_fetch_row($qry)) {
          //
          $rate = 0;
          $ratelist = "";
          //
          $interns = "";
          $hte_id = trim($dat[0]);
          $studq = "";
          //
          if ( trim($hte_id)!="" ) {
            //
            $sql1 = " select hte_id,member_id from tbl_hte_members where hte_id='$hte_id' ";
            //$sql = " select hte_id,name,address,info,map_loc_latitude,map_loc_longitude from tbl_hte  where hte_id='$curid' ";
            $qry1 = mysqli_query($conn,$sql1);
            while($dat1=mysqli_fetch_row($qry1)) {
              $studid = trim($dat1[1]);
              if ( trim($studid)!="" ) {
                if ( trim($studq)=="" ) {
                  $studq = " studentid='$studid' ";
                }else{
                  $studq = $studq . " || studentid='$studid' ";
                }
              }
            }
            //
            $sql1 = " select hte_id,total_rate from tbl_hte_raterank where hte_id='$hte_id' ";
            //$sql = " select hte_id,name,address,info,map_loc_latitude,map_loc_longitude from tbl_hte  where hte_id='$curid' ";
            $qry1 = mysqli_query($conn,$sql1);
            while($dat1=mysqli_fetch_row($qry1)) {
              $rate = strval(trim($dat1[1]));
            }
            //
            //
          }
          if ( trim($studq)!="" ) {
            $studq = " where ( " . $studq . " ) ";
          }
          //
          if ( trim($studq)!="" ) {
            //
            $memid = "";
            $memname = "";
            $img = "";
            //GET MEMBER NAME
            $sql1 = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns  $studq  order by firstname asc ";
            $qry1 = mysqli_query($conn,$sql1);
            while($dat1=mysqli_fetch_array($qry1)) {
              if ( trim($dat1[0]) != "" ) {
                $mname = "";
                if ( trim($dat1[2])!="" ) {
                  $mname = " " . trim($dat1[2]);
                }
                $memid = trim($dat1[0]);
                $memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
                //
                $img = trim($dat1[4]);
                //
                if ( trim($img)=="" ) {
                  $img = "./assets/img/empty_user.png";
                }
                //
                //
                if ( trim($interns)=="" ) {
                  $interns = "<a href='./page_profile.php?id=$memid'><img src='$img' class='mapsimg01' /> <span class='span02'>$memname</span></a>";
                }else{
                  $interns =  $interns . "<br/><a href='./page_profile.php?id=$memid'><img src='$img' class='mapsimg01' /> <span class='span02'>$memname</span></a>";
                }
                //
                //
              }
            }
            //
          }
          //
          //
          $ratelist = "";
          $rateimg = "<img class='ratestar01' src='./assets/img/rate_star.png' />";
          //
          for ( $n = 1 ; $n <= $rate ; $n++ ) {
            $ratelist = $ratelist . " " . $rateimg;
          }
          //
          $rateinfo = "<br/><br/><b>Rating: </b>" . $rate . "<br/>" . $ratelist;
          //
          //
          if ( trim($interns)!="" ) {
            $interns = "<br/><br/><b>Interns:</b><br/>" . $interns;
          }
          //
          $info = "$dat[3] $interns  $rateinfo";
          //
          echo "
                <input type='hidden' id='d_name_$nn' value='$dat[1]' >
                <input type='hidden' id='d_latitude_$nn' value='$dat[4]' >
                <input type='hidden' id='d_longitude_$nn' value='$dat[5]' >
                <textarea style='visibility:hidden;' id='d_info_$nn'>$info</textarea>
          ";
          $nn += 1;

        }
        echo "<input type='hidden' id='d_count' value='$nn' >";
        //
        //

    ?>
    </div>

    <script>

        var cplat = "";
        var cplng = "";

        var cid;
        var $_GET = {};
        document.location.search.replace(/\??(?:([^=]+)=([^&]*)&?)/g, function () {
        function decode(s) {
        return decodeURIComponent(s.split("+").join(" "));
        }
        $_GET[decode(arguments[1])] = decode(arguments[2]);
        });
        
        cplat = $_GET['dlat'];
        cplng = $_GET['dlong'];
        

      var map;

      var cid;
      var dcount = parseInt( document.getElementById('d_count').value );
      var dname = [];
      var dlati = [];
      var dlongi = [];
      var dinfo = [];
      var dinfo2 = [];
        var loca = [];
        var contentString1 = [];
        var infowindow;
        var infowindow1 = [];
        var marker1 = [];

      if ( dcount > 0 ) {
        for ( var i = 0 ; i < dcount ; i++ ) {
          dname[i] = document.getElementById('d_name_' + i).value;
          dlati[i] = parseFloat( document.getElementById('d_latitude_' + i).value );
          dlongi[i] = parseFloat( document.getElementById('d_longitude_' + i).value );
          dinfo[i] = document.getElementById('d_info_' + i).value;
          dinfo2[i] = "";

          if ( dinfo[i].trim()!="" ) {
            dinfo2[i] = '<b>' + dname[i] + '</b>' + dinfo[i];
          }
        }
      }

      function sds() {
        alert('XX');
      }

      function initMap() {
        //
        var tmplat = 6.756010479663661;
        var tmplong = 125.3530217719956;
        //

        if ( cplat!=null && cplng!=null ) {
          if ( cplat.trim() != "" && cplng.trim() != "" ) {
            tmplat = parseFloat(cplat);
            tmplong = parseFloat(cplng);
          }
        }
        //

      //alert('cc');
        var loca0 = {lat: tmplat, lng: tmplong};
        map = new google.maps.Map(document.getElementById('map'), {
          zoom: 15,
          center: loca0
        });

        infowindow = new google.maps.InfoWindow();


      if ( dcount > 0 ) {
        for ( var i = 0 ; i < dcount ; i++ ) {
          
          loca[i] = {lat: dlati[i], lng: dlongi[i]};

          contentString1[i] = '<div id="content">'+
              '<div id="siteNotice">'+
              '</div>'+
              '<h1 id="firstHeading" class="firstHeading">' + dname[i] +'</h1>'+
              '<div id="bodyContent">'+
              '<p>' + dinfo2[i] +
              '</p>'+
              '</div>'+
              '</div>';

          createMarker(loca[i],contentString1[i],dname[i]);
          
        }
      }


      }


    function createMarker(location, content, name) {
        var marker = new google.maps.Marker({
            position: location,
            draggable: false,
            title: name,
            map: map
        });
        marker.addListener('click', function() {
           infowindow.setContent(content);
           infowindow.open(map, this);
        });
    }
    
$("a").click(function(){
    var id = this.id;
    var dlat = this.dmap_lat;
    var dlnng = this.dmap_lng;
    alert(dlat);
    map.setCenter(new google.maps.LatLng(locations[id][1], locations[id][2]))
    return false;
});

      function selectHTE(event) {
        var con = event.target;
        var i = con.getAttribute("dmap_id");
        var dlat = con.getAttribute("dmap_lat");
        var dlng = con.getAttribute("dmap_lng");
        if ( i >= 0 ) {
          var latLng = {lat: dlat, lng: dlng};
        //alert(dlng);
          map.setCenter(latLng);
          //alert(latLng);
        }
      }


    </script>
   <script async defer
src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAe0TDpjcFA9M6zRYBkEXj9UprpQDqiro8&callback=initMap">
</script>



  </body>
</html>