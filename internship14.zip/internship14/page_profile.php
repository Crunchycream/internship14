<?php  session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$_SESSION['intern_page_current'] = "page_profile";
		include "./parts/main_logcheck.php";
	//
	include "./parts/page_profile_upload.php";
	include "./parts/sys_hte_raterank_updater.php";
	//
	if ( trim($logun)=="" ) {
		exit;
	}
?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>

</head>

<body>
		<!---MODAL -->
	<?php include "./parts/page_profile_modal.php"; ?>
	<?php //include "./parts/page_profile_upload.php"; ?>
		<!---END MODAL -->
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-7">
							<!-- LEFT COLUMN -->
							<div class="panel">
								<?php
									$id = $_GET['id'];
									$cuid =  $_SESSION['intern_data_cun'];
									$cutype = $_SESSION['intern_data_utype'];
									//
									$accn = 0;
									//
									if ( strtolower(trim($cutype))==strtolower(trim("student")) && strtolower(trim($cuid))==strtolower(trim($id)) ) {
										$accn += 1;
									}
									if ( strtolower(trim($cutype))==strtolower(trim("admin")) ) {
										//$accn += 1;
									}
									//
									if ( $accn > 0 ) {
										echo "
											<div class='dropdown divprof_menu01'>
											  <button class='btn btn-primary dropdown-toggle btnprof_menu01' type='button' data-toggle='dropdown'>&equiv;</button>
											  <ul class='dropdown-menu'>
											    <li><a  data-toggle='modal' data-target='#modalChangePhoto' href='' class=''>Update Photo</a></li>
											    <li><a  data-toggle='modal' data-target='#modalChangeCoverPhoto' href='' class=''>Update Background Photo</a></li>
											    <li class='divider'></li>
											    <li><a  data-toggle='modal' data-target='#modalUpdateInfo' href='' class=''>Update Info</a></li>
											    <li><a  data-toggle='modal' data-target='#modalUpdateInfoPassword' href='' class=''>Change Password</a></li>
											  </ul>
											</div>
										";
									}
								?>

<!-- ============================================================================================ -->

											<?php
												include "./data/connect.php";
												//
												$cpid = $_GET['id'];
												$cuid =  $_SESSION['intern_data_cun'];
												$cutype = $_SESSION['intern_data_utype'];
												//
												$genderopt = "";
												$crsopt = "";
												$yropt = "";
												$rateopt = "";
													$sql = " select no,gender from tbl_gender ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($dat[1]) != '' ) {
															$genderopt = $genderopt . "<option value='".trim($dat[1])."'>".trim($dat[1])."</option>";
														}
													}
													$sql = " select course_id,course from tbl_course ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($dat[1]) != '' ) {
															$crsopt = $crsopt . "<option value='".trim($dat[0])."'>".trim($dat[1])."</option>";
														}
													}
													$sql = " select year_id,year from tbl_year ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($dat[1]) != '' ) {
															$yropt = $yropt . "<option value='".trim($dat[1])."'>".trim($dat[1])."</option>";
														}
													}
													//LOAD RATINGS
													$sql = " select rate from tbl_rate_score order by rate asc ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($dat[0])!="" ) {
															$rateopt = $rateopt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
														}
													}
												//
												//
												$nn = 0;
												//                    0     1          2          3      4      5        6      7     8    9        10         11       12           13   14     15       16
												$sql = " select studentid,firstname,middlename,lastname,email,address,gender,course,year,no_hours,date_start,date_end,contact_no,eval_1,eval_2,req_status,no from tbl_interns  where studentid='$cpid'  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$nn = $nn + 1;
													//
													$crsid = trim($dat[7]);
													$crsname = "";
													//
													$urs = trim($dat[15]);
													$fstat = "";
													$tsn = "";

														//GET CRS NAME
														$sql2 = " select course_id,course from tbl_course where course_id='$crsid' ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															$crsname = trim($dat2[1]);
														}
														//
														//
														$crsopt = "";
														$sql2 = " select course_id,course from tbl_course ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															if ( trim($dat2[1]) != '' ) {
																$isel = "";
																if ( strtolower(trim($crsid))==strtolower(trim($dat2[0])) ) {
																	$isel = " selected='true' ";
																}
																$crsopt = $crsopt . "<option value='".trim($dat2[0])."' $isel>".trim($dat2[1])."</option>";
															}
														}

													$frm_updateinfo = "

																<div id='modalUpdateInfo' class='modal fade' role='dialog'>
																	<div class='modal-dialog'>
																	<!-- Modal content-->
																	<div class='modal-content'>
																	<div class='modal-header'>
																		<button type='button' class='close' data-dismiss='modal'>&times;</button>
																		<h4 class='modal-title'>Update Info</h4>
																	</div>
																			<form method='post' action=''>
																				<input type='hidden' name='acttab1' value='reg' />
																	<div class='modal-body'>
																		<p>
																			<input type='hidden' name='studid' value='".trim($cpid)."' />
																			<div class='form-group div01'>
																				<table>
																					<tr>
																						<td class='td01'>
																							<label for='stud-add-fn' class='control-label sr-only'>Firstname</label>
																							<input type='text' name='fname' class='form-control txt01' id='stud-add-fn' placeholder='Firstname' 
																								value='".trim($dat[1])."' 
																							>
																						</td>
																						<td class='td01'>
																							<label for='stud-add-mn' class='control-label sr-only'>Middlename</label>
																							<input type='text' name='mname' class='form-control txt01' id='stud-add-mn' placeholder='Middlename' 
																								value='".trim($dat[2])."' 
																							>
																						</td>
																						<td class='td01'>
																							<label for='stud-add-ln' class='control-label sr-only'>Lastname</label>
																							<input type='text' name='lname' class='form-control txt01' id='stud-add-ln' placeholder='Lastname' 
																								value='".trim($dat[3])."' 
																							>
																						</td>
																					</tr>
																				</table>
																				
																			</div>
																			<div class='div01'>
																				<table>
																					<tr>
																						<td class='td01'>
																							<select class='form-control txt01' name='gender'>
																								$genderopt
																							</select>
																						</td>
																					</tr>
																				</table>
																			</div>
																			<div class='form-group div01'>
																				<label for='stud-add-address' class='control-label sr-only'>Address</label>
																				<input type='text' name='address' class='form-control txt01' id='stud-add-address' placeholder='Address' 
																					value='".trim($dat[5])."' 
																				>
																			</div>
																			<div class='div01'>
																				<table>
																					<tr>
																						<td class='td01'>
																							<select class='form-control txt01' name='course'>
																								$crsopt
																							</select>
																						</td>
																						<td class='td01'>
																							<select class='form-control txt01' name='year'>
																								$yropt
																							</select>
																						</td>
																					</tr>
																				</table>
																			</div>
																			<table>
																				<tr>
																					<td class='td01'>
																						<div class='form-group'>
																							<label for='stud-add-contactno' class='control-label sr-only'>Contact #</label>
																							<input type='text' name='contactno' class='form-control txt01' id='stud-add-contactno' placeholder='Contact #' 
																								value='".trim($dat[12])."' 
																							>
																						</div>
																					</td>
																					<td class='td01'>
																						<div class='form-group'>
																							<label for='stud-add-email' class='control-label sr-only'>E-mail</label>
																							<input type='text' name='email' class='form-control txt01' id='stud-add-email' placeholder='E-mail' 
																								value='".trim($dat[4])."' 
																							>
																						</div>
																					</td>
																				</tr>
																			</table>
																			<div class='form-group'>
																				<label for='stud-add-nohrs' class='control-label sr-only'># of Hours</label>
																				<input type='text' name='nohrs' class='form-control txt01' id='stud-add-nohrs' placeholder='# of Hours' 
																					value='".trim($dat[9])."' 
																				>
																			</div>
																		</p>
																	</div>
																	<div class='modal-footer'>
																		<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																		<input type='submit' name='btnsaveUpdateInfo' class='btn btn-primary btn-lg btn01' value='SAVE'>
																	</div>
																			</form>
																	</div>

																	</div>
																</div>


																<div id='modalUpdateInfoPassword' class='modal fade' role='dialog'>
																	<div class='modal-dialog'>
																	<!-- Modal content-->
																	<div class='modal-content'>
																	<div class='modal-header'>
																		<button type='button' class='close' data-dismiss='modal'>&times;</button>
																		<h4 class='modal-title'>Update Password</h4>
																	</div>
																			<form method='post' action=''>
																				<input type='hidden' name='acttab1' value='reg' />
																	<div class='modal-body'>
																		<p>
																			<input type='hidden' name='studid' value='".trim($cpid)."' />
																			
																			<div class='form-group div01'>
																				<label for='opass' class='control-label sr-only'>Current Password</label>
																				<input type='Password' name='opass' class='form-control txt01' id='opass' placeholder='Current Password' 
																				>
																			</div>

																			<div class='form-group div01'>
																				<label for='npass1' class='control-label sr-only'>New Password</label>
																				<input type='Password' name='npass1' class='form-control txt01' id='npass1' placeholder='New Password' 
																				>
																			</div>

																			<div class='form-group div01'>
																				<label for='npass2' class='control-label sr-only'>Repeat New Password</label>
																				<input type='Password' name='npass2' class='form-control txt01' id='npass2' placeholder='Repeat New Password' 
																				>
																			</div>

																		</p>
																	</div>
																	<div class='modal-footer'>
																		<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																		<input type='submit' name='btnsaveUpdateInfoPassword' class='btn btn-primary btn-lg btn01' value='SAVE'>
																	</div>
																			</form>
																	</div>

																	</div>
																</div>

													";
													if ( (strtolower(trim($cutype))==strtolower(trim("student")) && strtolower(trim($cuid))==strtolower(trim($cpid))) || (strtolower(trim($cutype))==strtolower(trim("admin"))) ) {
														echo "$frm_updateinfo";
													}
												}
											?>
											

<!-- ============================================================================================ -->


								<!-- PROFILE HEADER -->
								<div class="profile-header">
									<div class="overlay"></div>
									
										<?php include "./data/connect.php";
											$id = $_GET['id'];
											$sql = " select no,studentid,firstname,middlename,lastname,prof_img,prof_backimg from tbl_interns where studentid='$id' ";
											$qry = mysqli_query($conn,$sql);
											$ttl = "";
											$ttlid = "";
											$img = "";
											$backimg = "";
											while($dat=mysqli_fetch_array($qry)) {
												$ttl = trim($dat[2])." ".trim($dat[3])." ".trim($dat[4]);
												$ttlid = trim($dat[1]);
												$img = trim($dat[5]);
												$backimg = trim($dat[6]);
											}
											if ( trim($img) == "" ) {
												$img = "assets/img/empty_user.png";
											}
											if ( trim($backimg) == "" ) {
												$backimg = "assets/img/profile-bg.png";
											}
											echo "
													<div class='profile-main' style='background:url($backimg) no-repeat; background-size: 100%;'>
													<br/>
													<img src='$img' class='img-circle img_prof_02' alt='Photo'>
													<h3 class='name'>
														<span class='span02'><a class='prof_name_link01' href='./page_profile.php?id=".trim($ttlid)."'>$ttl</a></span>
													</h3>
													<span class='online-status status-available'>Available</span>

													</div>
												";
										?>
									
									<div class="profile-stat">
										<div class="row">
											<?php  include "./data/connect.php";
												//
												$sy = trim($_SESSION['intern_data_active_sy']);
												//
												//
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
												//
												//
												$cid = trim($_GET['id']);
												$cidt = "student";
												//
												$count1 = 0;
												$count2 = 0;
												$count3 = 0;
												//
												//GET REFLECTION SUBMITTED COUNT
												$crit1 = 0;
												$crit2 = 0;
												$crit3 = 0;
												$crit4 = 0;
												$crit5 = 0;
												$crit6 = 0;
												$crit7 = 0;
												$crit8 = 0;
												$crit9 = 0;
												//
												$sql = " select * from tbl_class_posts where member_id='$cid' and member_type='$cidt' and type='reflection' and file_att<>'' and activity_sub='true' group by parent_post_id ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$count1 += 1;
												}
											////////////////////////////////////////
												$sql = " select studentid,total_rate from tbl_interns_raterank  where sy='$sy' and studentid='$cid'  group by studentid order by total_rate desc ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$count2 = $dat[1];
												}
													//
													$cd = explode(".", trim($count2));
													$c1 = $cd[0];
													$c2 = "0";
													if ( strval($cd[1])>0 ) {
														$c2 = substr(trim($cd[1]), 0,1);
													}
													//
													$fc = $c1 . "." . $c2;
													//
											////////////////////////////////////////
												//
												//GET REQ COUNT
												$reqstats = "";
												$reqstatsx = 12;
												$reqstatsn = 0;
												$sql2 = " select * from tbl_user_requirements where studentid='$cid' and (req_type<>'') group by req_type ";
												$qry2 = mysqli_query($conn,$sql2);
												while($dat2=mysqli_fetch_array($qry2)) {
													$reqstatsn = $reqstatsn + 1;
												}
												$count3 = $reqstatsn;
												//
												//
												$derr = 0;
												//
												if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
													$derr += 1;
												}
												if ( $derr <= 0 ) {
													echo "
														<div class='col-md-4 stat-item2'>
															<a class='prof_name_link01' href='#tab-bottom-reflections' role='tab' data-toggle='tab'>$count1 <span>Reflections</span></a>
														</div>
														<div class='col-md-4 stat-item2'>
															<a class='prof_name_link01' href='#tab-bottom-stats' role='tab' data-toggle='tab'>$fc <span>Rating</span></a>
														</div>
														<div class='col-md-4 stat-item2'>
															<a href='./page_profile.php?id=$cid&area=requirements' class='prof_name_link01'>$count3 <span>Requirements</span></a>
														</div>
													";
												}
											?>
										</div>
									</div>
								</div>
									<?php
										//
										$logun = $_SESSION['intern_data_cun'];
										$logutype = $_SESSION['intern_data_utype'];
										//
										$cid = trim($_GET['id']);
										$cidt = "student";
										//
										if ( strtolower(trim($logun))==strtolower(trim($cid)) && strtolower(trim($logutype))==strtolower(trim($cidt)) ) {

										}else{
											echo "

												<div align='right'>
													<a class='btn btn-success btn-sm' href='#' data-toggle='modal' data-target='#modalSendMessage'>Send Message</a>
												</div>

												<div id='modalSendMessage' class='modal fade' role='dialog'>
													<div class='modal-dialog'>
													<!-- Modal content-->
													<div class='modal-content'>
													<div class='modal-header'>
														<button type='button' class='close' data-dismiss='modal'>&times;</button>
														<h4 class='modal-title'>Send Message</h4>
													</div>
															<form action='' method='post'>
													<div class='modal-body'>
														<p>
															<input type='hidden' name='txtid' value='$cid'/>
															<input type='hidden' name='txttype' value='$cidt'/>
															<div class='form-group'>
																
															</div>
															<div class='form-group div01'>
																<label for='send-msg-msg' class='control-label sr-only'>Message</label>
																<textarea name='msg' class='form-control txta01' id='send-msg-msg' placeholder='Message'></textarea>
															</div>
														</p>
													</div>
													<div class='modal-footer'>
														<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
														<input type='submit' class='btn btn-primary' value='Send' name='btnsaveSendMessage'>
													</div>
															</form>
													</div>

													</div>
												</div>

											";
										}
									?>
								<!-- END PROFILE HEADER -->
								<!-- PROFILE DETAIL -->

								
								<!-- END PROFILE DETAIL -->

							</div>

					<?php
						//
						$logun = $_SESSION['intern_data_cun'];
						$logutype = $_SESSION['intern_data_utype'];
						//
						$derr = 0;
						//
						//
						if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
							$derr += 1;
						}
						//
						if ( $derr <= 0 ) {
							$carea = trim($_GET['area']);
							if ( trim($carea)=="" || strtolower(trim($carea))==strtolower(trim("info")) ) {
								include "./parts/page_profile_info.php";
							}
							if ( strtolower(trim($carea))==strtolower(trim("requirements")) ) {
								include "./parts/page_profile_requirement.php";
							}
							if ( strtolower(trim($carea))==strtolower(trim("reflection")) ) {
								//include "./parts/page_profile_files.php";
							}
						}
					?>

				<!-- END LEFT COLUMN -->
			</div>
			<div class="col-md-5">
				<!-- RIGHT COLUMN -->
							<div class="panel ann_divr02">
								<div class="tab-content divclass03">
									<?php
										//
										$curid = $_SESSION['intern_data_cun'];
										$curidtype = $_SESSION['intern_data_utype'];
										$logun = $curid;
										$logutype = $curidtype;
										//
										$cursy = trim($_SESSION['intern_data_active_sy']);
										//
										$cid = trim($_GET['id']);
										//
											//echo "<a href='' data-target='#modalInternEval' class='btn btn-danger btn-lg btn-block' data-toggle='modal'>Evaluate</a> ";
										if ( 
											strtolower(trim($curidtype))!=strtolower(trim("student")) &&
											strtolower(trim($curidtype))!=strtolower(trim("admin")) 
											) {
											//echo "<a href='' data-target='#modalInternEval' class='btn btn-danger btn-lg btn-block' data-toggle='modal'>Evaluate</a> ";
											//
											//echo "<br/><br/><a href='' data-target='#modalEvalCriteria' class='btn btn-link btn-sm' data-toggle='modal'>Manage Evaluation Criteria</a> ";
										}
										//
									//==========================================================================
										//
										$dnn = 0;
										$derr = 0;
										//
										//
										if ( strtoupper(trim($logutype))==strtoupper(trim("employee")) ) {
										//echo "$logun $logutype";
											$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff where staff_id='$logun' and staff_type='$logutype' and position='Supervisor' ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												$dnn += 1;
											}
										}
										//
										//
										if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
											//$dnn += 1;
										}
										//
										$derr = 0;
										//   CHECK IF EVALUATED
										$sql1 = " select * from tbl_interns_eval2  where studentid='$cid' and sy='$cursy'  ";
										$qry1 = mysqli_query($conn,$sql1);
										while($dat1=mysqli_fetch_array($qry1)) {
											$derr += 1;
										}
										if ( $derr > 0 ) {
											$dnn = 0;
										}
										//
										//
										if ( $dnn > 0 ) {
											echo "<a href='' data-target='#modalInternEval' class='btn btn-danger btn-lg btn-block' data-toggle='modal'>Evaluate</a> ";
										}
									//==========================================================================
										if ( 
											strtolower(trim($curidtype))!=strtolower(trim("student"))
											) {
											//
											echo "<br/><br/><a href='' data-target='#modalEvalCriteria' class='btn btn-link btn-sm' data-toggle='modal'>Manage Evaluation Criteria</a> ";
										}
									?>
								</div>

											<?php include "./data/connect.php";
												$sid = $_GET['id'];
												//
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
												//
												$req_resume = "";
												$req_appletter = "";
												$req_moa = "";
												$req_mou = "";
												$req_certacc = "";
												//
												$req_wform = "";
												$req_reclet = "";
												$req_waiver = "";
												$req_parcon = "";
												$req_medcert = "";
												$req_certapp = "";
												$req_certcom = "";
												$req_ojtimg = "";
												//
												$req_resume_stat = "<span class='span01_error'>&cross;</span>";
												$req_appletter_stat = "<span class='span01_error'>&cross;</span>";
												$req_moa_stat = "<span class='span01_error'>&cross;</span>";
												$req_mou_stat = "<span class='span01_error'>&cross;</span>";
												$req_certacc_stat = "<span class='span01_error'>&cross;</span>";
												//
												$req_wform_stat = "<span class='span01_error'>&cross;</span>";
												$req_reclet_stat = "<span class='span01_error'>&cross;</span>";
												$req_waiver_stat = "<span class='span01_error'>&cross;</span>";
												$req_parcon_stat = "<span class='span01_error'>&cross;</span>";
												$req_medcert_stat = "<span class='span01_error'>&cross;</span>";
												$req_certapp_stat = "<span class='span01_error'>&cross;</span>";
												$req_certcom_stat = "<span class='span01_error'>&cross;</span>";
												$req_ojtimg_stat = "<span class='span01_error'>&cross;</span>";
												//
												$req_resume_name = "Resume";
												$req_appletter_name = "Application Letter";
												$req_moa_name = "MOA";
												$req_mou_name = "MOU";
												$req_certacc_name = "Certification of Acceptance";
												//
												$req_wform_name = "White Form";
												$req_reclet_name = "Recommendation Letter";
												$req_waiver_name = "Waiver";
												$req_parcon_name = "Parent's Consent";
												$req_medcert_name = "Medical Certificate";
												$req_certapp_name = "Certificate of Appreciation";
												$req_certcom_name = "Certificate of Completion";
												$req_ojtimg_name = "OJT Images";
												//
												$tsn = "";
												//
												$nn = "";
												//
												$tfilid = "";
												$tfiln = "";
												$tfiltype = "";
												$tfildate = "";
												///
												$tsn = "requirement:resume";
												$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_resume = trim($dat[4]);
														$nn = trim($dat[0]);
														//
														$tfilid = trim($dat[1]);
														$tfiln = trim($dat[4]);
														$tfiltype = trim($dat[3]);
														$tfildate = trim($dat[5]);
													}
												}
													$cn = 0;
													$sql00 = " select * from tbl_upfiles where upby_type='student' and upby_id='$tfilid' and utype='requirement' and date_uploaded='$tfildate' and ap_status<>'dis-approved' ";
													$qry00 = mysqli_query($conn,$sql00);
													while($dat00=mysqli_fetch_array($qry00)) {
														if ( trim($dat00[4]) != "" ){
															$cn += 1;
														}
													}
													if ( $cn <= 0 ) {
														$req_resume = "";
													}
												if ( trim($req_resume)!="" ) {
													$req_resume_stat = "<span class='span01_success'>&check;</span>";
													$req_resume_name = "<a class='link01' target='_blank' href='$req_resume'>Resume</a>";
													//
													$fln = trim($req_resume);
													if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
														$req_resume_name = "
																	<a class='link01' target='_blank' href='#' data-toggle='modal' data-target='#modalPrevImage_$nn'>Resume</a>
																	<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																		<img class='ann_img02' src='".trim($fln)."'/>
																	</div>
																	";
													}
												}

												$nn = "";
												//
												$tfilid = "";
												$tfiln = "";
												$tfiltype = "";
												$tfildate = "";
												///
												//
												$tsn = "requirement:application_letter";
												$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_appletter = trim($dat[4]);
														$nn = trim($dat[0]);
														//
														$tfilid = trim($dat[1]);
														$tfiln = trim($dat[4]);
														$tfiltype = trim($dat[3]);
														$tfildate = trim($dat[5]);
													}
												}
													$cn = 0;
													$sql00 = " select * from tbl_upfiles where upby_type='student' and upby_id='$tfilid' and utype='requirement' and date_uploaded='$tfildate' and ap_status<>'dis-approved' ";
													$qry00 = mysqli_query($conn,$sql00);
													while($dat00=mysqli_fetch_array($qry00)) {
														if ( trim($dat00[4]) != "" ){
															$cn += 1;
														}
													}
													if ( $cn <= 0 ) {
														$req_appletter = "";
													}
												if ( trim($req_appletter)!="" ) {
													$req_appletter_stat = "<span class='span01_success'>&check;</span>";
													$req_appletter_name = "<a class='link01' target='_blank' href='$req_appletter'>Application Letter</a>";
													//
													$fln = trim($req_appletter);
													if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
														$req_appletter_name = "
																	<a class='link01' target='_blank' href='#' data-toggle='modal' data-target='#modalPrevImage_$nn'>Application Letter</a>
																	<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																		<img class='ann_img02' src='".trim($fln)."'/>
																	</div>
																	";
													}
												}

												$nn = "";
												//
												$tfilid = "";
												$tfiln = "";
												$tfiltype = "";
												$tfildate = "";
												///
												//
												$tsn = "requirement:moa";
												$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_moa = trim($dat[4]);
														$nn = trim($dat[0]);
														//
														$tfilid = trim($dat[1]);
														$tfiln = trim($dat[4]);
														$tfiltype = trim($dat[3]);
														$tfildate = trim($dat[5]);
													}
												}
													$cn = 0;
													$sql00 = " select * from tbl_upfiles where upby_type='student' and upby_id='$tfilid' and utype='requirement' and date_uploaded='$tfildate' and ap_status<>'dis-approved' ";
													$qry00 = mysqli_query($conn,$sql00);
													while($dat00=mysqli_fetch_array($qry00)) {
														if ( trim($dat00[4]) != "" ){
															$cn += 1;
														}
													}
													if ( $cn <= 0 ) {
														$req_moa = "";
													}
												if ( trim($req_moa)!="" ) {
													$req_moa_stat = "<span class='span01_success'>&check;</span>";
													$req_moa_name = "<a class='link01' target='_blank' href='$req_moa'>MOA</a>";
													//
													$fln = trim($req_moa);
													if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
														$req_moa_name = "
																	<a class='link01' target='_blank' href='#' data-toggle='modal' data-target='#modalPrevImage_$nn'>MOA</a>
																	<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																		<img class='ann_img02' src='".trim($fln)."'/>
																	</div>
																	";
													}
												}

												$nn = "";
												//
												$tfilid = "";
												$tfiln = "";
												$tfiltype = "";
												$tfildate = "";
												///
												//
												$tsn = "requirement:mou";
												$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_mou = trim($dat[4]);
														$nn = trim($dat[0]);
														//
														$tfilid = trim($dat[1]);
														$tfiln = trim($dat[4]);
														$tfiltype = trim($dat[3]);
														$tfildate = trim($dat[5]);
													}
												}
													$cn = 0;
													$sql00 = " select * from tbl_upfiles where upby_type='student' and upby_id='$tfilid' and utype='requirement' and date_uploaded='$tfildate' and ap_status<>'dis-approved' ";
													$qry00 = mysqli_query($conn,$sql00);
													while($dat00=mysqli_fetch_array($qry00)) {
														if ( trim($dat00[4]) != "" ){
															$cn += 1;
														}
													}
													if ( $cn <= 0 ) {
														$req_mou = "";
													}
												if ( trim($req_mou)!="" ) {
													$req_mou_stat = "<span class='span01_success'>&check;</span>";
													$req_mou_name = "<a class='link01' target='_blank' href='$req_mou'>MOU</a>";
													//
													$fln = trim($req_mou);
													if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
														$req_mou_name = "
																	<a class='link01' target='_blank' href='#' data-toggle='modal' data-target='#modalPrevImage_$nn'>MOU</a>
																	<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																		<img class='ann_img02' src='".trim($fln)."'/>
																	</div>
																	";
													}
												}

												$nn = "";
												//
												$tfilid = "";
												$tfiln = "";
												$tfiltype = "";
												$tfildate = "";
												///
												//
												$tsn = "requirement:certification_of_acceptance";
												$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_certacc = trim($dat[4]);
														$nn = trim($dat[0]);
														//
														$tfilid = trim($dat[1]);
														$tfiln = trim($dat[4]);
														$tfiltype = trim($dat[3]);
														$tfildate = trim($dat[5]);
													}
												}
													$cn = 0;
													$sql00 = " select * from tbl_upfiles where upby_type='student' and upby_id='$tfilid' and utype='requirement' and date_uploaded='$tfildate' and ap_status<>'dis-approved' ";
													$qry00 = mysqli_query($conn,$sql00);
													while($dat00=mysqli_fetch_array($qry00)) {
														if ( trim($dat00[4]) != "" ){
															$cn += 1;
														}
													}
													if ( $cn <= 0 ) {
														$req_certacc = "";
													}
												if ( trim($req_certacc)!="" ) {
													$req_certacc_stat = "<span class='span01_success'>&check;</span>";
													$req_certacc_name = "<a class='link01' target='_blank' href='$req_certacc'>Certification of Acceptance</a>";
													//
													$fln = trim($req_certacc);
													if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
														$req_certacc_name = "
																	<a class='link01' target='_blank' href='#' data-toggle='modal' data-target='#modalPrevImage_$nn'>Certification of Acceptance</a>
																	<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																		<img class='ann_img02' src='".trim($fln)."'/>
																	</div>
																	";
													}
												}

												//

												$nn = "";
												//
												$tfilid = "";
												$tfiln = "";
												$tfiltype = "";
												$tfildate = "";
												///
												//
												$tsn = "requirement:white_form";
												$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_wform = trim($dat[4]);
														$nn = trim($dat[0]);
														//
														$tfilid = trim($dat[1]);
														$tfiln = trim($dat[4]);
														$tfiltype = trim($dat[3]);
														$tfildate = trim($dat[5]);
													}
												}
													$cn = 0;
													$sql00 = " select * from tbl_upfiles where upby_type='student' and upby_id='$tfilid' and utype='requirement' and date_uploaded='$tfildate' and ap_status<>'dis-approved' ";
													$qry00 = mysqli_query($conn,$sql00);
													while($dat00=mysqli_fetch_array($qry00)) {
														if ( trim($dat00[4]) != "" ){
															$cn += 1;
														}
													}
													if ( $cn <= 0 ) {
														$req_wform = "";
													}
												if ( trim($req_wform)!="" ) {
													$req_wform_stat = "<span class='span01_success'>&check;</span>";
													$req_wform_name = "<a class='link01' target='_blank' href='$req_wform'>White Form</a>";
													//
													$fln = trim($req_wform);
													if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
														$req_wform_name = "
																	<a class='link01' target='_blank' href='#' data-toggle='modal' data-target='#modalPrevImage_$nn'>White Form</a>
																	<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																		<img class='ann_img02' src='".trim($fln)."'/>
																	</div>
																	";
													}
												}

												$nn = "";
												//
												$tfilid = "";
												$tfiln = "";
												$tfiltype = "";
												$tfildate = "";
												///
												//
												$tsn = "requirement:recommendation_letter";
												$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_reclet = trim($dat[4]);
														$nn = trim($dat[0]);
														//
														$tfilid = trim($dat[1]);
														$tfiln = trim($dat[4]);
														$tfiltype = trim($dat[3]);
														$tfildate = trim($dat[5]);
													}
												}
													$cn = 0;
													$sql00 = " select * from tbl_upfiles where upby_type='student' and upby_id='$tfilid' and utype='requirement' and date_uploaded='$tfildate' and ap_status<>'dis-approved' ";
													$qry00 = mysqli_query($conn,$sql00);
													while($dat00=mysqli_fetch_array($qry00)) {
														if ( trim($dat00[4]) != "" ){
															$cn += 1;
														}
													}
													if ( $cn <= 0 ) {
														$req_reclet = "";
													}
												if ( trim($req_reclet)!="" ) {
													$req_reclet_stat = "<span class='span01_success'>&check;</span>";
													$req_reclet_name = "<a class='link01' target='_blank' href='$req_reclet'>Recommendation Letter</a>";
													//
													$fln = trim($req_reclet);
													if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
														$req_reclet_name = "
																	<a class='link01' target='_blank' href='#' data-toggle='modal' data-target='#modalPrevImage_$nn'>Recommendation Letter</a>
																	<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																		<img class='ann_img02' src='".trim($fln)."'/>
																	</div>
																	";
													}
												}

												$nn = "";
												//
												$tfilid = "";
												$tfiln = "";
												$tfiltype = "";
												$tfildate = "";
												///
												//
												$tsn = "requirement:waiver";
												$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_waiver = trim($dat[4]);
														$nn = trim($dat[0]);
														//
														$tfilid = trim($dat[1]);
														$tfiln = trim($dat[4]);
														$tfiltype = trim($dat[3]);
														$tfildate = trim($dat[5]);
													}
												}
													$cn = 0;
													$sql00 = " select * from tbl_upfiles where upby_type='student' and upby_id='$tfilid' and utype='requirement' and date_uploaded='$tfildate' and ap_status<>'dis-approved' ";
													$qry00 = mysqli_query($conn,$sql00);
													while($dat00=mysqli_fetch_array($qry00)) {
														if ( trim($dat00[4]) != "" ){
															$cn += 1;
														}
													}
													if ( $cn <= 0 ) {
														$req_waiver = "";
													}
												if ( trim($req_waiver)!="" ) {
													$req_waiver_stat = "<span class='span01_success'>&check;</span>";
													$req_waiver_name = "<a class='link01' target='_blank' href='$req_waiver'>Waiver</a>";
													//
													$fln = trim($req_waiver);
													if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
														$req_waiver_name = "
																	<a class='link01' target='_blank' href='#' data-toggle='modal' data-target='#modalPrevImage_$nn'>Waiver</a>
																	<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																		<img class='ann_img02' src='".trim($fln)."'/>
																	</div>
																	";
													}
												}

												$nn = "";
												//
												$tfilid = "";
												$tfiln = "";
												$tfiltype = "";
												$tfildate = "";
												///
												//
												$tsn = "requirement:parent_consent";
												$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_parcon = trim($dat[4]);
														$nn = trim($dat[0]);
														//
														$tfilid = trim($dat[1]);
														$tfiln = trim($dat[4]);
														$tfiltype = trim($dat[3]);
														$tfildate = trim($dat[5]);
													}
												}
													$cn = 0;
													$sql00 = " select * from tbl_upfiles where upby_type='student' and upby_id='$tfilid' and utype='requirement' and date_uploaded='$tfildate' and ap_status<>'dis-approved' ";
													$qry00 = mysqli_query($conn,$sql00);
													while($dat00=mysqli_fetch_array($qry00)) {
														if ( trim($dat00[4]) != "" ){
															$cn += 1;
														}
													}
													if ( $cn <= 0 ) {
														$req_parcon = "";
													}
												if ( trim($req_parcon)!="" ) {
													$req_parcon_stat = "<span class='span01_success'>&check;</span>";
													$req_parcon_name = "<a class='link01' target='_blank' href='$req_parcon'>Parent's Consent</a>";
													//
													$fln = trim($req_parcon);
													if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
														$req_parcon_name = "
																	<a class='link01' target='_blank' href='#' data-toggle='modal' data-target='#modalPrevImage_$nn'>Parent's Consent</a>
																	<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																		<img class='ann_img02' src='".trim($fln)."'/>
																	</div>
																	";
													}
												}

												$nn = "";
												//
												$tfilid = "";
												$tfiln = "";
												$tfiltype = "";
												$tfildate = "";
												///
												//
												$tsn = "requirement:medical_certificate";
												$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_medcert = trim($dat[4]);
														$nn = trim($dat[0]);
														//
														$tfilid = trim($dat[1]);
														$tfiln = trim($dat[4]);
														$tfiltype = trim($dat[3]);
														$tfildate = trim($dat[5]);
													}
												}
													$cn = 0;
													$sql00 = " select * from tbl_upfiles where upby_type='student' and upby_id='$tfilid' and utype='requirement' and date_uploaded='$tfildate' and ap_status<>'dis-approved' ";
													$qry00 = mysqli_query($conn,$sql00);
													while($dat00=mysqli_fetch_array($qry00)) {
														if ( trim($dat00[4]) != "" ){
															$cn += 1;
														}
													}
													if ( $cn <= 0 ) {
														$req_medcert = "";
													}
												if ( trim($req_medcert)!="" ) {
													$req_medcert_stat = "<span class='span01_success'>&check;</span>";
													$req_medcert_name = "<a class='link01' target='_blank' href='$req_medcert'>Medical Certificate</a>";
													//
													$fln = trim($req_medcert);
													if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
														$req_medcert_name = "
																	<a class='link01' target='_blank' href='#' data-toggle='modal' data-target='#modalPrevImage_$nn'>Medical Certificate</a>
																	<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																		<img class='ann_img02' src='".trim($fln)."'/>
																	</div>
																	";
													}
												}

												$nn = "";
												//
												$tfilid = "";
												$tfiln = "";
												$tfiltype = "";
												$tfildate = "";
												///
												//
												$tsn = "requirement:certificate_of_appreciation";
												$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_certapp = trim($dat[4]);
														$nn = trim($dat[0]);
														//
														$tfilid = trim($dat[1]);
														$tfiln = trim($dat[4]);
														$tfiltype = trim($dat[3]);
														$tfildate = trim($dat[5]);
													}
												}
													$cn = 0;
													$sql00 = " select * from tbl_upfiles where upby_type='student' and upby_id='$tfilid' and utype='requirement' and date_uploaded='$tfildate' and ap_status<>'dis-approved' ";
													$qry00 = mysqli_query($conn,$sql00);
													while($dat00=mysqli_fetch_array($qry00)) {
														if ( trim($dat00[4]) != "" ){
															$cn += 1;
														}
													}
													if ( $cn <= 0 ) {
														$req_certapp = "";
													}
												if ( trim($req_certapp)!="" ) {
													$req_certapp_stat = "<span class='span01_success'>&check;</span>";
													$req_certapp_name = "<a class='link01' target='_blank' href='$req_certapp'>Certificate of Appreciation</a>";
													//
													$fln = trim($req_certapp);
													if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
														$req_certapp_name = "
																	<a class='link01' target='_blank' href='#' data-toggle='modal' data-target='#modalPrevImage_$nn'>Certificate of Appreciation</a>
																	<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																		<img class='ann_img02' src='".trim($fln)."'/>
																	</div>
																	";
													}
												}

												$nn = "";
												//
												$tfilid = "";
												$tfiln = "";
												$tfiltype = "";
												$tfildate = "";
												///
												//
												$tsn = "requirement:certificate_of_completion";
												$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_certcom = trim($dat[4]);
														$nn = trim($dat[0]);
														//
														$tfilid = trim($dat[1]);
														$tfiln = trim($dat[4]);
														$tfiltype = trim($dat[3]);
														$tfildate = trim($dat[5]);
													}
												}
													$cn = 0;
													$sql00 = " select * from tbl_upfiles where upby_type='student' and upby_id='$tfilid' and utype='requirement' and date_uploaded='$tfildate' and ap_status<>'dis-approved' ";
													$qry00 = mysqli_query($conn,$sql00);
													while($dat00=mysqli_fetch_array($qry00)) {
														if ( trim($dat00[4]) != "" ){
															$cn += 1;
														}
													}
													if ( $cn <= 0 ) {
														$req_certcom = "";
													}
												if ( trim($req_certcom)!="" ) {
													$req_certcom_stat = "<span class='span01_success'>&check;</span>";
													$req_certcom_name = "<a class='link01' target='_blank' href='$req_certcom'>Certificate of Completion</a>";
													//
													$fln = trim($req_certcom);
													if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
														$req_certcom_name = "
																	<a class='link01' target='_blank' href='#' data-toggle='modal' data-target='#modalPrevImage_$nn'>Certificate of Completion</a>
																	<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																		<img class='ann_img02' src='".trim($fln)."'/>
																	</div>
																	";
													}
												}

												$nn = "";
												//
												$tfilid = "";
												$tfiln = "";
												$tfiltype = "";
												$tfildate = "";
												///
												//
												$tsn = "requirement:ojt_photo";
												$sql = " select no,studentid,name,req_type,req_file,date_added from tbl_user_requirements where studentid='$sid' and req_type='$tsn' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[4]) != "" ){
														$req_ojtimg = trim($dat[4]);
														$nn = trim($dat[0]);
														//
														$tfilid = trim($dat[1]);
														$tfiln = trim($dat[4]);
														$tfiltype = trim($dat[3]);
														$tfildate = trim($dat[5]);
													}
												}
													$cn = 0;
													$sql00 = " select * from tbl_upfiles where upby_type='student' and upby_id='$tfilid' and utype='requirement' and date_uploaded='$tfildate' and ap_status<>'dis-approved' ";
													$qry00 = mysqli_query($conn,$sql00);
													while($dat00=mysqli_fetch_array($qry00)) {
														if ( trim($dat00[4]) != "" ){
															$cn += 1;
														}
													}
													if ( $cn <= 0 ) {
														$req_ojtimg = "";
													}
												if ( trim($req_ojtimg)!="" ) {
													$req_ojtimg_stat = "<span class='span01_success'>&check;</span>";
													$req_ojtimg_name = "<a class='link01' target='_blank' href='$req_ojtimg'>OJT Images</a>";
													//
													$fln = trim($req_ojtimg);
													if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
														$req_ojtimg_name = "
																	<a class='link01' target='_blank' href='#' data-toggle='modal' data-target='#modalPrevImage_$nn'>OJT Images</a>
																	<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																		<img class='ann_img02' src='".trim($fln)."'/>
																	</div>
																	";
													}
												}
											///////
											///////
							$derr = 0;
							$derr2 = 0;
							//
							///
							if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
								$derr += 1;
								$derr2 += 1;
							}
							//
							$dn = 0;
							//
							if ( strtoupper(trim($logutype))==strtoupper(trim("employee")) ) {
							//echo "$logun $logutype";
								$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff where staff_id='$logun' and staff_type='$logutype' and position='Supervisor' ";
								$qry = mysqli_query($conn,$sql);
								while($dat=mysqli_fetch_array($qry)) {
									$dn += 1;
								}
								if ( $dn <= 0 ) {
									$derr += 1;
								}
							}
							//
							//
							if ( $derr <= 0 ) {
				//=================================================================================================
												echo "
								<h4 class='heading'>Requirements</h4>
								<!-- AWARDS -->
								<div class='awards'>
									<div class=''>
										<div class=''>
												";
												echo "
													<div class='table-responsive'>
														<table class='table project-table'>
															<tbody>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_resume_stat  $req_resume_name</span>
																	</td>
																	<td>
														";
											if ( strtolower(trim($sid))==strtolower(trim($logun)) ) {
												echo "
																<div class='dropdown'>
																  <a class='btn_action_01 btn_action_02' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu dropdown-menu-right'>
																    <li><a data-toggle='modal' data-target='#modalReqResume' class='' href=''>Submit</a></li>
																  </ul>
																</div>
														";
											}
												echo "
																	</td>
																</tr>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_appletter_stat  $req_appletter_name</span>
																	</td>
																	<td>
														";
											if ( strtolower(trim($sid))==strtolower(trim($logun)) ) {
												echo "
																<div class='dropdown'>
																  <a class='btn_action_01 btn_action_02' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu dropdown-menu-right'>
																    <li><a data-toggle='modal' data-target='#modalReqAppLet' class='' href=''>Submit</a></li>
																  </ul>
																</div>
														";
											}
												echo "
																	</td>
																</tr>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_moa_stat  $req_moa_name</span>
																	</td>
																	<td>
														";
											if ( strtolower(trim($sid))==strtolower(trim($logun)) ) {
												echo "
																<div class='dropdown'>
																  <a class='btn_action_01 btn_action_02' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu dropdown-menu-right'>
																    <li><a data-toggle='modal' data-target='#modalReqMOA' class='' href=''>Submit</a></li>
																  </ul>
																</div>
														";
											}
												echo "
																	</td>
																</tr>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_mou_stat  $req_mou_name</span>
																	</td>
																	<td>
														";
											if ( strtolower(trim($sid))==strtolower(trim($logun)) ) {
												echo "
																<div class='dropdown'>
																  <a class='btn_action_01 btn_action_02' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu dropdown-menu-right'>
																    <li><a data-toggle='modal' data-target='#modalReqMOU' class='' href=''>Submit</a></li>
																  </ul>
																</div>
														";
											}
												echo "
																	</td>
																</tr>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_certacc_stat  $req_certacc_name</span>
																	</td>
																	<td>
														";
											if ( strtolower(trim($sid))==strtolower(trim($logun)) ) {
												echo "
																<div class='dropdown'>
																  <a class='btn_action_01 btn_action_02' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu dropdown-menu-right'>
																    <li><a data-toggle='modal' data-target='#modalReqCertAcc' class='' href=''>Submit</a></li>
																  </ul>
																</div>
														";
											}
									////////////
									////////////
												echo "
																	</td>
																</tr>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_wform_stat  $req_wform_name</span>
																	</td>
																	<td>
														";
											if ( strtolower(trim($sid))==strtolower(trim($logun)) ) {
												echo "
																<div class='dropdown'>
																  <a class='btn_action_01 btn_action_02' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu dropdown-menu-right'>
																    <li><a data-toggle='modal' data-target='#modalReqWForm' class='' href=''>Submit</a></li>
																  </ul>
																</div>
														";
											}
												echo "
																	</td>
																</tr>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_reclet_stat  $req_reclet_name</span>
																	</td>
																	<td>
														";
											if ( strtolower(trim($sid))==strtolower(trim($logun)) ) {
												echo "
																<div class='dropdown'>
																  <a class='btn_action_01 btn_action_02' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu dropdown-menu-right'>
																    <li><a data-toggle='modal' data-target='#modalReqRecLet' class='' href=''>Submit</a></li>
																  </ul>
																</div>
														";
											}
												echo "
																	</td>
																</tr>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_waiver_stat  $req_waiver_name</span>
																	</td>
																	<td>
														";
											if ( strtolower(trim($sid))==strtolower(trim($logun)) ) {
												echo "
																<div class='dropdown'>
																  <a class='btn_action_01 btn_action_02' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu dropdown-menu-right'>
																    <li><a data-toggle='modal' data-target='#modalReqWaiver' class='' href=''>Submit</a></li>
																  </ul>
																</div>
														";
											}
												echo "
																	</td>
																</tr>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_parcon_stat  $req_parcon_name</span>
																	</td>
																	<td>
														";
											if ( strtolower(trim($sid))==strtolower(trim($logun)) ) {
												echo "
																<div class='dropdown'>
																  <a class='btn_action_01 btn_action_02' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu dropdown-menu-right'>
																    <li><a data-toggle='modal' data-target='#modalReqParCon' class='' href=''>Submit</a></li>
																  </ul>
																</div>
														";
											}
												echo "
																	</td>
																</tr>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_medcert_stat  $req_medcert_name</span>
																	</td>
																	<td>
														";
											if ( strtolower(trim($sid))==strtolower(trim($logun)) ) {
												echo "
																<div class='dropdown'>
																  <a class='btn_action_01 btn_action_02' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu dropdown-menu-right'>
																    <li><a data-toggle='modal' data-target='#modalReqMedCert' class='' href=''>Submit</a></li>
																  </ul>
																</div>
														";
											}
												echo "
																	</td>
																</tr>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_certapp_stat  $req_certapp_name</span>
																	</td>
																	<td>
														";
											if ( strtolower(trim($sid))==strtolower(trim($logun)) ) {
												echo "
																<div class='dropdown'>
																  <a class='btn_action_01 btn_action_02' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu dropdown-menu-right'>
																    <li><a data-toggle='modal' data-target='#modalReqCertApp' class='' href=''>Submit</a></li>
																  </ul>
																</div>
														";
											}
												echo "
																	</td>
																</tr>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_certcom_stat  $req_certcom_name</span>
																	</td>
																	<td>
														";
											if ( strtolower(trim($sid))==strtolower(trim($logun)) ) {
												echo "
																<div class='dropdown'>
																  <a class='btn_action_01 btn_action_02' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu dropdown-menu-right'>
																    <li><a data-toggle='modal' data-target='#modalReqCertCom' class='' href=''>Submit</a></li>
																  </ul>
																</div>
														";
											}
												echo "
																	</td>
																</tr>
																<tr>
																	<td class='tbl0102'>
																		<span class='span03'>$req_ojtimg_stat  $req_ojtimg_name</span>
																	</td>
																	<td>
														";
											if ( strtolower(trim($sid))==strtolower(trim($logun)) ) {
												echo "
																<div class='dropdown'>
																  <a class='btn_action_01 btn_action_02' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu dropdown-menu-right'>
																    <li><a data-toggle='modal' data-target='#modalReqOJTImg' class='' href=''>Submit</a></li>
																  </ul>
																</div>
														";
											}
									////////////
									////////////
												echo "
																	</td>
																</tr>
															</tbody>
														</table>
		    											
													</div>
												";
											//
							//======================================================================================================
									echo "
										</div>

										<div class='margin-top-30 text-center'>
									";
										//
												$cid = trim($_GET['id']);
												echo "
													<a href='./page_profile.php?id=$cid&area=requirements' class='btn btn-default'>See all requirements</a>
												";
										//
										//
										echo "
										</div>

									</div>
								</div>
										";
								//
								//
							//
			//=========================================================================================================
							}
						//////////////////////////////////////////
							if ( $derr2 <= 0 ) {
							//AWARDS
							//
								echo "
								<div class='custom-tabs-line tabs-line-bottom left-aligned'>
									<ul class='nav' role='tablist'>
										<li class='active'><a href='#tab-bottom-left1' role='tab' data-toggle='tab'>Recent Activity</a></li>
										
									</ul>
								</div>

								<div class='tab-content'>
									<div class='tab-pane fade in active' id='tab-bottom-left1'>
										<ul class='list-unstyled activity-list'>
								";
												$id = $_GET['id'];
												//GET ALL LOGS
												//                 0     1         2            3    4    5
												$sql = " select uact_id,member_id,member_type,adate,msg,atype from tbl_uact where member_id='$id' and member_type='student' order by uact_id desc limit 5 ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[1])!="" ) {
														//
														$mid = "";
														$fn = "";
														$img = "";
														//
														$time = trim($dat[3]);
														$msg = trim($dat[4]);
														//
														//                   0        1          2        3        4
														$sql2 = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns where studentid='$dat[1]' ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															$mid = trim($dat2[0]);
															$fn = trim($dat2[1]);
															$img = trim($dat2[4]);
														}
															if ( trim($img) == "" ) {
																$img = "assets/img/empty_user.png";
															}
														//
														echo "
															<li>
																<img src='$img' alt='Avatar' class='img-circle pull-left avatar'>
																<p><a href='./page_profile.phpid=$mid'>$fn</a> $msg <span class='timestamp'>$time</span></p>
															</li>
														";
														//
													}
												}
								echo "
										</ul>
										<div class='margin-top-30 text-center'><a href='#' class='btn btn-default'>See all activity</a></div>
									</div>
									<div class='tab-pane fade' id='tab-bottom-left2'>
										<div class='table-responsive'>
											
										</div>
									</div>
								</div>
								";
								//
								//
							//
							}
											//
											?>
											
							</div>
							<!-- END RIGHT COLUMN -->
						</div>
					</div>
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>


		<?php
			//
			$id = $_GET['id'];
			$sy = trim($_SESSION['intern_data_active_sy']);
			//
			include "./data_eval_intern_frm.php";
			//
		?>


	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>
	<script src="assets/vendor/chartist/js/chartist.min.js"></script>

	<script id="source" language="javascript" >

		//========================================================================

        var $_GET = {};
        document.location.search.replace(/\??(?:([^=]+)=([^&]*)&?)/g, function () {
        function decode(s) {
        return decodeURIComponent(s.split("+").join(" "));
        }
        $_GET[decode(arguments[1])] = decode(arguments[2]);
        });
        //alert($_GET['id']);
        var cid = $_GET['id'];
        //alert(cid);
        //
        //

		 var count = 0;
		 var names = [];
		 var values = [];


		var sdata;
	    $.ajax({                                      
	      url: './data_eval_student.php?cid=' + cid,
	      data1: "",
	      
	      dataType: 'json',
	      success: function(data1)
	      {
	    	//alert('ZZ');
	        sdata = data1;
	    	//alert(sdata);
	    	//
	    	var options;
			var tt = [];
			tt[0] = '<b>Professionalism</b>';
			tt[1] = '<b>Job maturity</b>';
			tt[2] = '<b>Communication skills</b>';
			tt[3] = '<b>Productiviy</b>';
			tt[4] = '<b>Leadership</b>';
			tt[5] = '<b>Excellence</b>';
			tt[6] = '<b>Honest & Integrity</b>';
			tt[7] = '<b>Innovation</b>';
			tt[8] = '<b>Teamwork</b>';
			//
			//
			var tname = tt;
			var tdata = sdata;
			var data = {
				labels: tname,
				series: [
					{
						name: 'series-Eva1',
						data:sdata[0],
					
					}
				]
			};

			// bar chart
			options = {
				height: "300px",
				axisX: {
					showGrid: false
				},
			};

			new Chartist.Bar('#stat-bar-chart', data, options);
			
	      } 
	    });
	    //alert(sdata);
		//========================================================================
	$(function() {
		

	});


		$(function() {

			count = parseInt( document.getElementById('eval_data_count').value );


			 for ( var i = 0 ; i < count ; i++ ) {
			 	names[i] = document.getElementById('eval_data_name_' + (i+1) ).value;
			 	values[i] = document.getElementById('eval_data_value_' + (i+1) ).value;
			 }


	    	var options;

			//
			//

			var data = {
				labels: names,
				series: [
					{
						name: 'series-Eva1',
						data: values,
					
					}
				]
			};

			// bar chart
			options = {
				height: "300px",
				axisX: {
					showGrid: false
				},
			};

			new Chartist.Bar('#stat-bar-chart2', data, options);
			

		});



	</script>


<?php
	include "./parts/btm_script.php";
?>

</body>

</html>
