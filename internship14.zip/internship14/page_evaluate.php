<?php  session_start(); error_reporting( E_ALL ^ E_NOTICE );
	include "./sys_load_active_sy.php";
	//
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$cursy = trim($_SESSION['intern_data_active_sy']);
	//
	//
	$_SESSION['intern_page_current'] = "page_evaluate";
		include "./parts/main_logcheck.php";
	//
	include "./parts/sys_hte_raterank_updater.php";
	//
	//
	$op = $_GET['op'];
	$tsn = "";
	if ( trim($op)!="" ) {
		$tsn = "logout";
		if ( strtolower(trim($op)) == strtolower(trim($op)) ) {
			$_SESSION['intern_data_cun'] = "";
			$_SESSION['intern_data_dpn'] = "";
			$_SESSION['intern_data_utype'] = "";
			echo "<META HTTP-EQUIV='Refresh' Content='0; URL=index.php'>";
		}
	}
	//
	//
	if ( trim($logun)!="" ) {
		//
		//
//========= EVAL ===========================================================================
		if ( $_POST['btnAddInternEval'] ) {
			//
			$uid = trim($_POST['txtstudid']);
			//
			if ( trim($uid)!="" && trim($logun)!="" ) {
				//
				//
				$sy = $cursy;
				//
				$errmsg = "";
				$errn = 0;
				//
				//
				$major = $_POST['major'];
				$sem = $_POST['semester'];
				//$sy = $_POST['sy'];
				$dept = $_POST['dept'];
				//
				$dept_id="";
				$dept_n="";
				$crs_id = "";
				$crs = "";
				$college = "UMDC";
				//GET STUDENT INFO
				//                 0           1       2         3        4
				$sql = " select studentid,firstname,middlename,lastname,course from tbl_interns  where  studentid='$uid' ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					$crs_id = trim($dat[4]);
				}
				//
				//GET CRS NAME
				//                 0         1      
				$sql = " select course_id,course from tbl_course  where  course_id='$crs_id' ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					$crs = trim($dat[4]);
				}
				//
						//GET DEPT
						$sql = " select department_id from tbl_department_courses where course_id='$crs_id' ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							$dept_id = $dat[0];
						}
						//GET DEPT NAME
						$sql = " select department_id,department from tbl_department where department_id='$dept_id' ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							$dept_n = $dat[1];
						}
				//
				//
				$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
				//
				//
				$comp1 = trim( htmlspecialchars( $_POST['comp1'] , ENT_QUOTES ) );
				$comp1hrs = trim( $_POST['comp1hrs'] );
				$comp1rate = trim( $_POST['comp1rate'] );
				//
				$comp2 = trim( htmlspecialchars( $_POST['comp2'] , ENT_QUOTES ) );
				$comp2hrs = trim( $_POST['comp2hrs'] );
				$comp2rate = trim( $_POST['comp2rate'] );
				//
				$comp3 = trim( htmlspecialchars( $_POST['comp3'] , ENT_QUOTES ) );
				$comp3hrs = trim( $_POST['comp3hrs'] );
				$comp3rate = trim( $_POST['comp3rate'] );
				//
				$comp4 = trim( htmlspecialchars( $_POST['comp4'] , ENT_QUOTES ) );
				$comp4hrs = trim( $_POST['comp4hrs'] );
				$comp4rate = trim( $_POST['comp4rate'] );
				//
				$comp5 = trim( htmlspecialchars( $_POST['comp5'] , ENT_QUOTES ) );
				$comp5hrs = trim( $_POST['comp5hrs'] );
				$comp5rate = trim( $_POST['comp5rate'] );
				//
				$comp6 = trim( htmlspecialchars( $_POST['comp6'] , ENT_QUOTES ) );
				$comp6hrs = trim( $_POST['comp6hrs'] );
				$comp6rate = trim( $_POST['comp6rate'] );
				//
				$comp7 = trim( htmlspecialchars( $_POST['comp7'] , ENT_QUOTES ) );
				$comp7hrs = trim( $_POST['comp7hrs'] );
				$comp7rate = trim( $_POST['comp7rate'] );
				//
				$tcomp =  array(
						array($comp1,$comp1hrs,$comp1rate),
						array($comp2,$comp2hrs,$comp2rate),
						array($comp3,$comp3hrs,$comp3rate),
						array($comp4,$comp4hrs,$comp4rate),
						array($comp5,$comp5hrs,$comp5rate),
						array($comp6,$comp6hrs,$comp6rate),
						array($comp7,$comp7hrs,$comp7rate)
					);
				//
				//
				$errmsg = "";
				$errn = 0;
				//
				if ( trim($sem) == "" ) {
					//$errn = $errn + 1;
					//$errmsg = $errmsg . "Semester required. ";
				}
				if ( trim($sy) == "" ) {
					//$errn = $errn + 1;
					//$errmsg = $errmsg . "School Year required. ";
				}
				if ( trim($sem) == "" ) {
					//$errn = $errn + 1;
					//$errmsg = $errmsg . "Semester required. ";
				}
				//
				if ( 
					trim($comp1) == "" &&
					trim($comp2) == "" &&
					trim($comp3) == "" &&
					trim($comp4) == "" &&
					trim($comp5) == "" &&
					trim($comp6) == "" &&
					trim($comp7) == ""
					) {
					$errn = $errn + 1;
					$errmsg = $errmsg . "You must have at least 1 Program Competences. ";
				}
				//
				//
				//
				//
				$comment = trim( htmlspecialchars( $_POST['comments'] , ENT_QUOTES ) );
				//
				$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
				//
				//$sy = "2016-2017";
				//
				$sup_id = "";
				$coord_id = "";
				//
				$crit1 = trim( $_POST['crit1'] );
				$crit2 = trim( $_POST['crit2'] );
				$crit3 = trim( $_POST['crit3'] );
				$crit4 = trim( $_POST['crit4'] );
				$crit5 = trim( $_POST['crit5'] );
				//
				$crit2_1 = trim( $_POST['crit2_1'] );
				$crit2_2 = trim( $_POST['crit2_2'] );
				$crit2_3 = trim( $_POST['crit2_3'] );
				$crit2_4 = trim( $_POST['crit2_4'] );
				//
				//
				//$errmsg = "";
				//$errn = 0;
				//
				//
				//
				if ( $errn <= 0 ) {
					//SAVE DATA
					$sql = "
							insert into tbl_interns_eval2_group 
								(studentid,college,course,major,semester,sy,department,eval_date,evaluator_id,evaluator_type,comments,supervisor_id,coordinator_id) 
							values 
								('$uid','$college','$crs_id','$major','$sem','$sy','$dept_id','$cdate','$logun','$logutype','$comment','$sup_id','$coord_id') 
							";
					$qry = mysqli_query($conn,$sql);
					//
					//GET CURRENT EVAL ID
					$cur_eid = "";
					//                 0        
					$sql = " select interns_eval_group_id from tbl_interns_eval2_group  where  studentid='$uid' and eval_date='$cdate' and sy='$sy' and evaluator_id='$logun' and evaluator_type='$logutype' ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						$cur_eid = trim($dat[0]);
					}
					//
					//SAVE PROGRAM COMPETENCES
					if ( trim($cur_eid)!="" ) {
						for ( $i = 0 ; $i < count($tcomp) ; $i++ ) {
							if ( trim($tcomp[$i][0])!="" ) {
								$sql = "
										insert into tbl_interns_eval2_2 
											(interns_eval_group_id,prog_comp,num_hours,eval_rate,sy,studentid) 
										values 
											('".$cur_eid."','".$tcomp[$i][0]."','".$tcomp[$i][1]."','".$tcomp[$i][2]."','$sy','$uid') 
										";
								$qry = mysqli_query($conn,$sql);
							}
						}
					}
					//SAVE DATA
					//
					$sql = "
							insert into tbl_interns_eval2 
								(interns_eval_group_id,studentid,evaluator_id,evaluator_type,eval_date,professionalism,job_maturity,comm_skills,productivity,leadership,excellence,honesty_integrity,innovation,teamwork,sy,comments,supervisor_id,coordinator_id,course_id,department_id) 
							values 
								('$cur_eid','$uid','$logun','$logutype','$cdate','$crit1','$crit2','$crit3','$crit4','$crit5','$crit2_1','$crit2_2','$crit2_3','$crit2_4','$sy','$comment','$sup_id','$coord_id','$crs_id','$dept_id') 
							";
					$qry = mysqli_query($conn,$sql);
					//
					//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
					//
				}else{
					//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
					echo "
						<script>
							alert('$errmsg');
						</script>
					";
				}
			}
		}
//========= EVAL ===========================================================================
		//
		//
	}
	//
	//
	//
	if ( trim($logun)=="" ) {
		exit;
	}
?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>


</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">

<!-- =============================================================================================== -->

					<?php include "./data/connect.php";
						//
						$logun = $_SESSION['intern_data_cun'];
						$logutype = $_SESSION['intern_data_utype'];
						//
						$cursy = trim($_SESSION['intern_data_active_sy']);
						//
						$hte = "";
						//
						$sql2 = " select hte_id from tbl_hte_staff where staff_id='$logun' and staff_type='$logutype'   ";
						$qry2 = mysqli_query($conn,$sql2);
						while($dat2=mysqli_fetch_array($qry2)) {
							if ( trim($dat2[0])!="" ) {
								if ( trim($hte) == "" ) {
									$hte = " where hte_id='$dat2[0]' ";
								}else{
									$hte = $hte . " || hte_id='$dat2[0]' ";
								}
							}
						}
						//
						if ( trim($hte)!="" ) {
							//
							$frm = "";
							//
							$nn = "";
							//GET HTE MEMBERS
							//                   0        1     2
							$sql33 = " select hte_mem_id,hte_id,member_id from tbl_hte_members $hte   ";
							$qry33 = mysqli_query($conn,$sql33);
							while($dat33=mysqli_fetch_array($qry33)) {
								if ( trim($dat33[1])!="" && trim($dat33[2])!="" ){
									//
									$nn = trim($dat33[0]);
									//
									$evaln = 0;
									//
									$studid = trim($dat33[2]);
									//
									$lnk = "";
									$fname = "";
									$lname = "";
									$img = "";
									$rate = "0";
									//
									//
									//   CHECK IF EVALUATED
									$sql1 = " select * from tbl_interns_eval2  where studentid='$studid' and sy='$cursy'  ";
									$qry1 = mysqli_query($conn,$sql1);
									while($dat1=mysqli_fetch_array($qry1)) {
										$evaln += 1;
									}
									//
									////////////////////////////////////////
									//GET RATE
										$sql = " select studentid,total_rate from tbl_interns_raterank  where sy='$cursy' and studentid='$studid'  group by studentid order by total_rate desc ";
										$qry = mysqli_query($conn,$sql);
										while($dat=mysqli_fetch_array($qry)) {
											$count2 = $dat[1];
										}
											//
											$cd = explode(".", trim($count2));
											$c1 = $cd[0];
											$c2 = "0";
											if ( strval($cd[1])>0 ) {
												$c2 = substr(trim($cd[1]), 0,1);
											}
											//
											$fc = $c1 . "." . $c2;
											//
										$rate = $fc;
									////////////////////////////////////////
									//
									//                  0        1        2         3          4      
									$sql1 = " select studentid,lastname,firstname,middlename,prof_img from tbl_interns  where studentid='$studid'  ";
									$qry1 = mysqli_query($conn,$sql1);
									while($dat1=mysqli_fetch_array($qry1)) {
										$lnk = "page_profile.php?id=$dat1[0]";
										//
										$fname = trim($dat1[2]);
										$lname = trim($dat1[1]);
										//
										$img = trim($dat1[4]);
										//
										//
										if ( trim($img)=="" ) {
											$img = "./assets/img/empty_user.png";
										}
									}
									//
									$evalf = "";
									//
									$frm = $frm . "
										<div class='col-md-3'>
										<div class='panel'>
										<div class='panel-body'>
											<table class='eval_tbl201'>
												<tr>
													<td class='eval_td201'>
														
															<img class='eval_img01' src='$img' />
														
													</td>
													<td class='eval_td202'>
														
															<span class='span02'>
																$lname, $fname
															</span>
														
														<br/>
														<span class='eval_span201'>Rating: $rate</span>
														<br/>
														<br/>
														
									";
									$evalf = $evalf . "

										<a class='btn btn-primary btn-xs eval_btn_01' href='#' data-target='#modalInternEval_$nn' data-toggle='modal'>EVALUATE</a>

										<div id='modalInternEval_$nn' class='modal fade' role='dialog'>
											<div class='modal-dialog'>
											<!-- Modal content-->
											<div class='modal-content eval_modal01'>
											<div class='modal-header'>
												<button type='button' class='close' data-dismiss='modal'>&times;</button>
												<h4 class='modal-title'>Student Evaluation</h4>
											</div>
													<form action='' method='post'>
											<div class='modal-body'>
												<p>
															<input type='hidden' name='txtid' value='$nn' />
															<input type='hidden' name='txtstudid' value='$studid' />


									";
						// =============================================================================================
									//
										//$uid = $_GET['id'];
										$uid = trim($studid);
									//
									$cursy = trim($_SESSION['intern_data_active_sy']);
									//
									//
									$rateopt = "";
									$rateopt = "
												<option value='1'>1</option>
												<option value='2'>2</option>
												<option value='3' selected='true'>3</option>
												<option value='4'>4</option>
												<option value='5'>5</option>
									";
									//
									//
									//
									$majoropt = "";
									$semopt = "";
									$syopt = "";
									$deptopt = "";
									//
									$majoropt = $majoropt . "<option value='none'>None</option>";
									//
									$sql = " select major from tbl_major order by major asc  ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										if ( trim($dat[0])!="" ) {
											$majoropt = $majoropt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
										}
									}
									//
									$sql = " select semester from tbl_semester order by semester asc  ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										if ( trim($dat[0])!="" ) {
											$semopt = $semopt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
										}
									}
									//
									$sql = " select sy from tbl_sy order by sy asc  ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										if ( trim($dat[0])!="" ) {
											$syopt = $syopt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
										}
									}
									//
									$sql = " select department from tbl_department order by department asc  ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										if ( trim($dat[0])!="" ) {
											$deptopt = $deptopt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
										}
									}
									//
									//
									$tcrit = array();
									$n = 0;
									//GET CRITERIA
									$sql = " select name,sy,adate from tbl_interns_eval_criteria where  sy='$cursy' ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										if ( trim($dat[0])!="" ) {
											$tcrit[$n] = trim($dat[0]);
											$n += 1;
										}
									}
									//
									//
									$crsid = "";
									$crsn = "";
									$deptid = "";
									$deptn = "";
									//
									//GET COURSE
									$sql = " select course from tbl_interns where studentid='$uid' ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										$crsid = $dat[0];
									}
									//GET COURSE NAME
									$sql = " select course_id,course from tbl_course where course_id='$crsid' ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										$crsn = $dat[1];
									}
									//GET DEPT
									$sql = " select department_id from tbl_department_courses where course_id='$crsid' ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										$deptid = $dat[0];
									}
									//GET DEPT NAME
									$sql = " select department_id,department from tbl_department where department_id='$deptid' ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										$deptn = $dat[1];
									}
									//
									$opt1 = "
											<table width='100%;'>
												<tr>
													<td class='eval_td01'>
														<b>Major:</b>
														<span>
															<select class='form-control txt01 span02' name='major'>
																$majoropt
															</select>
														</span>
													</td>
													<td class='eval_td01'>
														<span>
															<b>Semester:</b>
															<select class='form-control txt01 span02' name='semester'>
																$semopt
															</select>
														</span>
													</td>
												</tr>
												<tr>
													<td class='eval_td01'>
														<span>
															<b>S.Y.:</b>
															<select class='form-control txt01 span02' name='sy'>
																$syopt
															</select>
														</span>
													</td>
													<td class='eval_td01'>
														<span>
															<b>Department:</b>
															<select class='form-control txt01 span02' name='dept'>
																$deptopt
															</select>

															<input type='' name='crs' value='$crsid' />
															<input type='' name='crsn' value='$crsn' />

															<input type='' name='dept' value='$deptid' />
															<input type='' name='deptn' value='$deptn' />

														</span>
													</td>
												</tr>
											</table>

									";
									//
									//
									$evalf = $evalf . "
										<div class='table-responsive'>
											<table>
												<thead>
													<tr>
														<td class='eval_td01'>

														</td>
														<td class='eval_td01'>
															<b>Program Competences</b>
														</td>
														<td class='eval_td01'>
															<b>Number of Hours</b>
														</td>
														<td class='eval_td01'>
															<b>Evaluation Rating</b>
														</td>
													</tr>
												</thead>
												<tbody>";
										if ( count($tcrit)>0 && count($tcrit)>=1 ) {
											$evalf = $evalf . "
													<tr>
														<td class='eval_td01'>
															<b>1.</b>
														</td>
														<td class='eval_td01'>
															<textarea class='form-control span02 txt_disp01' name='comp1' readonly='true'>$tcrit[0]</textarea>
														</td>
														<td class='eval_td01 eval_td01_1'>
															<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp1hrs' value='10' />
														</td>
														<td class='eval_td01 eval_td01_1'>
															<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp1rate' value='3' />
														</td>
													</tr>";
										}
												
										if ( count($tcrit)>0 && count($tcrit)>=2 ) {
											$evalf = $evalf . "
													<tr>
														<td class='eval_td01'>
															<b>2.</b>
														</td>
														<td class='eval_td01'>
															<textarea class='form-control span02 txt_disp01' name='comp2' readonly='true'>$tcrit[1]</textarea>
														</td>
														<td class='eval_td01 eval_td01_1'>
															<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp2hrs' value='10' />
														</td>
														<td class='eval_td01 eval_td01_1'>
															<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp2rate' value='3' />
														</td>
													</tr>";
										}
												
										if ( count($tcrit)>0 && count($tcrit)>=3 ) {
											$evalf = $evalf . "
													<tr>
														<td class='eval_td01'>
															<b>3.</b>
														</td>
														<td class='eval_td01'>
															<textarea class='form-control span02 txt_disp01' name='comp3' readonly='true'>$tcrit[2]</textarea>
														</td>
														<td class='eval_td01 eval_td01_1'>
															<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp3hrs' value='10' />
														</td>
														<td class='eval_td01 eval_td01_1'>
															<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp3rate' value='3' />
														</td>
													</tr>";
										}
												
										if ( count($tcrit)>0 && count($tcrit)>=4 ) {
											$evalf = $evalf . "
													<tr>
														<td class='eval_td01'>
															<b>4.</b>
														</td>
														<td class='eval_td01'>
															<textarea class='form-control span02 txt_disp01' name='comp4' readonly='true'>$tcrit[3]</textarea>
														</td>
														<td class='eval_td01 eval_td01_1'>
															<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp4hrs' value='10' />
														</td>
														<td class='eval_td01 eval_td01_1'>
															<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp4rate' value='3' />
														</td>
													</tr>";
										}
												
										if ( count($tcrit)>0 && count($tcrit)>=5 ) {
											$evalf = $evalf . "
													<tr>
														<td class='eval_td01'>
															<b>5.</b>
														</td>
														<td class='eval_td01'>
															<textarea class='form-control span02 txt_disp01' name='comp5' readonly='true'>$tcrit[4]</textarea>
														</td>
														<td class='eval_td01 eval_td01_1'>
															<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp5hrs' value='10' />
														</td>
														<td class='eval_td01 eval_td01_1'>
															<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp5rate' value='3' />
														</td>
													</tr>";
										}
												
										if ( count($tcrit)>0 && count($tcrit)>=6 ) {
											$evalf = $evalf . "
													<tr>
														<td class='eval_td01'>
															<b>6.</b>
														</td>
														<td class='eval_td01'>
															<textarea class='form-control span02 txt_disp01' name='comp6' readonly='true'>$tcrit[5]</textarea>
														</td>
														<td class='eval_td01 eval_td01_1'>
															<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp6hrs' value='10' />
														</td>
														<td class='eval_td01 eval_td01_1'>
															<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp6rate' value='3' />
														</td>
													</tr>";
										}
												
										if ( count($tcrit)>0 && count($tcrit)>=7 ) {
											$evalf = $evalf . "
													<tr>
														<td class='eval_td01'>
															<b>7.</b>
														</td>
														<td class='eval_td01'>
															<textarea class='form-control span02 txt_disp01' name='comp7' readonly='true'>$tcrit[6]</textarea>
														</td>
														<td class='eval_td01 eval_td01_1'>
															<input type='number' min='1' class='form-control span02 txt_disp01 eval_txt01' name='comp7hrs' value='10' />
														</td>
														<td class='eval_td01 eval_td01_1'>
															<input type='number' min='1' max='5' class='form-control span02 txt_disp01 eval_txt01' name='comp7rate' value='3' />
														</td>
													</tr>";
										}
												
											$evalf = $evalf . "
												</tbody>
											</table>
										</div>
									";
									//
									$evalf = $evalf . "
											<br/>
											<br/>
									";
									//
									$evalf = $evalf . "
										<div class='table-responsive'>
											<table width='100%'>
													<tr>
														<td class='eval_td02'>
															<b>Professionalism</b><br/>
															<span class='eval_span01'>
																punctuality, commitment, knowledgeable, skillful, follows instruction, respectful
															</span>
														</td>
														<td class='eval_td01_2'>
															<select class='form-control span02 txt_disp01 eval_txt01' name='crit1'>
																$rateopt
															</select>
														</td>
													</tr>
													<tr>
														<td class='eval_td02'>
															<b>Job maturity</b><br/>
															<span class='eval_span01'>
																positive work disposition, open to suggestions and feedback, exercises self-management
															</span>
														</td>
														<td class='eval_td01_2'>
															<select class='form-control span02 txt_disp01 eval_txt01' name='crit2'>
																$rateopt
															</select>
														</td>
													</tr>
													<tr>
														<td class='eval_td02'>
															<b>Communication skills</b><br/>
															<span class='eval_span01'>
																able to communicate well in formula and vernacular language, proficient written and spoken English, technical writing skills
															</span>
														</td>
														<td class='eval_td01_2'>
															<select class='form-control span02 txt_disp01 eval_txt01' name='crit3'>
																$rateopt
															</select>
														</td>
													</tr>
													<tr>
														<td class='eval_td02'>
															<b>Productivity</b><br/>
															<span class='eval_span01'>
																work efficiency and effectiveness, accomplished assigned task, demonstrated satisfactory outputs
															</span>
														</td>
														<td class='eval_td01_2'>
															<select class='form-control span02 txt_disp01 eval_txt01' name='crit4'>
																$rateopt
															</select>
														</td>
													</tr>
													<tr>
														<td class='eval_td02'>
															<b>Leadership</b><br/>
															<span class='eval_span01'>
																takes initiative, provides direction in a group
															</span>
														</td>
														<td class='eval_td01_2'>
															<select class='form-control span02 txt_disp01 eval_txt01' name='crit5'>
																$rateopt
															</select>
														</td>
													</tr>
											</table>
											<br/>
											<table width='100%'>
													<tr>
														<td class='eval_td02'>
															<b>Demonstration of University core values</b><br/>
															<span class='eval_span01'>
																
															</span>
														</td>
														<td class='eval_td01_2'>
														</td>
													</tr>
													<tr>
														<td class='eval_td02'>
															<span class='eval_span02'>Excellence</span><br/>
															<span class='eval_span01'>
																
															</span>
														</td>
														<td class='eval_td01_2'>
															<select class='form-control span02 txt_disp01 eval_txt01' name='crit2_1'>
																$rateopt
															</select>
														</td>
													</tr>
													<tr>
														<td class='eval_td02'>
															<span class='eval_span02'>Honesty & Integrity</span><br/>
															<span class='eval_span01'>
																
															</span>
														</td>
														<td class='eval_td01_2'>
															<select class='form-control span02 txt_disp01 eval_txt01' name='crit2_2'>
																$rateopt
															</select>
														</td>
													</tr>
													<tr>
														<td class='eval_td02'>
															<span class='eval_span02'>Innovation</span><br/>
															<span class='eval_span01'>
																
															</span>
														</td>
														<td class='eval_td01_2'>
															<select class='form-control span02 txt_disp01 eval_txt01' name='crit2_3'>
																$rateopt
															</select>
														</td>
													</tr>
													<tr>
														<td class='eval_td02'>
															<span class='eval_span02'>Teamwork</span><br/>
															<span class='eval_span01'>
																
															</span>
														</td>
														<td class='eval_td01_2'>
															<select class='form-control span02 txt_disp01 eval_txt01' name='crit2_4'>
																$rateopt
															</select>
														</td>
													</tr>
											</table>
											<br/>
											<b>Comments:</b><br/>
											<textarea class='form-control span02' name='comments'></textarea>
										</div>
									";
						// =============================================================================================
									$evalf = $evalf . "


												</p>
											</div>
											<div class='modal-footer'>
												<button type='button' class='btn btn-default btn-sm' data-dismiss='modal'>Close</button>
												<input type='submit' class='btn btn-primary btn-sm' value='Save' name='btnAddInternEval'>
											</div>
													</form>
											</div>

											</div>
										</div>

									";
								//
									if ( $evaln <= 0 ) {
										$frm = $frm . $evalf;
									}else{
										$frm = $frm . "
											<span class='btn btn-success btn-xs eval_btn_02'>&check; Evaluated</span>
										";
									}
								//
									$frm = $frm . "
													</td>
												</tr>
											</table>
										</div>
										</div>
										</div>
									";
									//
								}
							}
							//
							//
							echo "
								<div class='row'>
									$frm
								</div>
							";
							//
						}
						//
						//
						//
					?>


<!-- =============================================================================================== -->

				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/vendor/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
	<script src="assets/vendor/chartist/js/chartist.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>
	

	
<?php
	include "./parts/btm_script.php";
?>

</body>

</html>
