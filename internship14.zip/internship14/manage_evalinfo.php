<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
	$type = trim($_GET['type']);
	if ( trim($type)=="" ) {
		$type = "hte";
	}
	$_SESSION['intern_page_current'] = "manage_evalinfo_$type";
		include "./parts/main_logcheck.php";
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	if ( $_POST['btnsave'] ) {
		$name = $_POST['txtname'];
		$tagtype = $_POST['txtitype'];
		$tardate = $_POST['txttdate'];
		$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
		//
		if ( strtolower(trim($tagtype))==strtolower(trim("intern")) ) {
			$tagtype = "student";
		}
		//
		$errn = 0;
		$errmsg = "";
		if ( $errn <= 0 ) {
			//SAVE DATA
			$sql = " insert into tbl_eval_info 
						(name,tag_type,date_target,date_created,status)
						values
						('$name','$tagtype','$tardate','$cdate','')
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
			echo "
				<script>
					alert('$errmsg');
				</script>
			";
		}
	}
	//
	if ( $_POST['btnsaveEdit'] ) {
		$cid = $_POST['txtid'];
		//
		$name = $_POST['txtname'];
		$tagtype = $_POST['txtitype'];
		$tardate = $_POST['txttdate'];
		//
		$errn = 0;
		$errmsg = "";
		if ( $errn <= 0 ) {
			//SAVE DATA
			$sql = " update tbl_eval_info set 
						name='$name',date_target='$tardate' 
							where ei_id='$cid'
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
			echo "
				<script>
					alert('$errmsg');
				</script>
			";
		}
	}
	if ( $_POST['btnsaveDelete'] ) {
		$cid = $_POST['txtid'];
		//
		$errn = 0;
		if ( $errn <= 0 ) {
			//SAVE DATA
			$sql = " delete from tbl_eval_info 
						where ei_id='$cid'
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
			echo "
				<script>
					alert('$errmsg');
				</script>
			";
		}
	}
	//
	//
	if ( $_POST['btnupdateAStat'] ) {
		$cid = trim($_POST['txtid']);
		$cval = trim($_POST['txtval']);
		if ( trim($cid)!="" ) {
			$sql = " update tbl_eval_info set status='$cval' where ei_id='$cid'  ";
			$qry = mysqli_query($conn,$sql);
		}
	}
	//
	if ( trim($logun)=="" || strtolower(trim($logutype))==strtolower(trim("student")) ) {
		exit;
	}
?>

<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>


</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">
						<?php
							$type = trim($_GET['type']);
							if ( strtolower(trim($type))==strtolower(trim("intern")) ) {
								echo "Manage Intern Evaluation Info";
							}
							if ( strtolower(trim($type))==strtolower(trim("hte")) ) {
								echo "Manage HTE Evaluation Info";
							}
						?>
					</h3>
					<div class="row">

					<?php include "./parts/manage_evalinfo_modal.php"; ?>


						<div class="col-md-12">
							<!-- BASIC TABLE -->
							<div class="row">
							<div class="col-md-9">
							<h5 class="ss">Search:</h5>
							</div>
						
							
							<div class="col-md-3">
							<div class="form-group pull-right">
							<input type="text" id="myInput1" value="" class="search form-control" placeholder="What you looking for">
							<!--	<span class="counter pull-right"><button type="button" class="btn btn-primary">Search</button></span>-->
								</div>
									<span class="counter pull-right"></span>
									</div>
						</div>
						<hr>

					<a href="" data-toggle="modal" data-target="#modalAddEvalInfo" class="btn btn-success btn-md">+ ADD EVAL INFO</a>
					<br/>
					<br/>
				
							<!-- RECENT PURCHASES -->
							<div class="panel">
					
								<div class="table-responsive">
									<table class="table">
										<thead>
											<tr>
												<th></th>
												<th>ID</th>
												<th>Name</th>
												<th>Type</th>
												<th>Target Date</th>
												<th>Date Created</th>
												<th>Status</th>
											</tr>
										</thead>
										<tbody id="myTable1">
											<?php include "./data/connect.php";
												//
												$hteopt = "";
												$tagtypeopt = "";
												//
												$ctype = trim($_GET['type']);
												$ftype = "";
												//
												if ( strtolower(trim($ctype))==strtolower(trim("hte")) ) {
													$ftype = "hte";
												}
												if ( strtolower(trim($ctype))==strtolower(trim("intern")) ) {
													$ftype = "student";
												}
												//
												$nn = 0;
												//
												//                0     1    2      3        4            5           6
												$sql = " select ei_id,name,tag_id,tag_type,date_target,date_created,status from tbl_eval_info where tag_type='$ftype'  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													//
													$nn = $nn + 1;
													//
													$hteopt = "";
														$sql2 = " select hte_id,name from tbl_hte  ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															$isel = "";
															if ( strtolower(trim($dat[2]))==strtolower(trim($dat2[0])) ) {
																$isel = " selected='true' ";
															}
															$hteopt = $hteopt . "
																					<option value='".trim($dat2[0])."' $isel>
																					".trim($dat2[1])."
																					</option>
																				";
														}
													$isel = "";
													if ( strtolower(trim($dat[3]))==strtolower(trim("hte")) ) {
														$isel = " selected='true' ";
													}
													$tagtypeopt = $tagtypeopt . "
																					<option value='hte' $isel>
																					HTE
																					</option>
																				";
													$isel = "";
													if ( strtolower(trim($dat[3]))==strtolower(trim("intern")) ) {
														$isel = " selected='true' ";
													}
													$tagtypeopt = $tagtypeopt . "
																					<option value='intern' $isel>
																					INTERN
																					</option>
																				";
													//
													//
													$fstat = "";
													$stat = trim($dat[6]);
													if ( strtolower(trim($stat))==strtolower(trim("active")) ) {
														$fstat = "<span class='label label-success label-lg'>Active</span>";
													}
													if ( strtolower(trim($stat))==strtolower(trim("inactive")) ) {
														$fstat = "<span class='label label-danger label-lg'>Inactive</span>";
													}
													if ( strtolower(trim($stat))==strtolower(trim("")) ) {
														$fstat = "<span class='label label-danger label-lg'>Inactive</span>";
													}
													//
													echo "
														<tr>
															<td>
															
																<div class='dropdown'>
																  <a class='btn_action_01' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu'>
																    <li>
																  		<form method='post' action=''>
																  			<input type='hidden' name='txtid' value='$dat[0]' />
																  			<input type='hidden' name='txtval' value='Active' />
																    	<input type='submit' name='btnupdateAStat' class='btn_opt01' value='Set as Active' />
																    	</form>
																    </li>
																    <li>
																  		<form method='post' action=''>
																  			<input type='hidden' name='txtid' value='$dat[0]' />
																  			<input type='hidden' name='txtval' value='Inactive' />
																    	<input type='submit' name='btnupdateAStat' class='btn_opt01' value='Set as In-Active' />
																    	</form>
																    </li>
																    <li class='divider'></li>
																    <li><a href='#' data-toggle='modal' data-target='#modalEdit_$nn'>Edit</a></li>
																    <li><a href='#' data-toggle='modal' data-target='#modalDelete_$nn'>Delete</a></li>
																  </ul>
																</div>

																    <div id='modalEdit_$nn' class='modal fade' role='dialog'>
																      <div class='modal-dialog'>
																      <!-- Modal content-->
																      <div class='modal-content'>
																      <div class='modal-header'>
																        <button type='button' class='close' data-dismiss='modal'>&times;</button>
																        <h4 class='modal-title'>Update Evaluation Info</h4>
																      </div>
																          <form method='post' action=''>
																      <div class='modal-body'>
																        <p>
																					<input type='hidden' name='txtid' value='$dat[0]'/>
																					<input type='hidden' name='txtitype' value='$ftype'/>
																          <div class='form-group'>
																             
																            </div>
																            <div class='form-group div01'>
																              <label for='txt-name' class='control-label sr-only'>Name</label>
																              <input type='text' name='txtname' class='form-control txt01' id='txt-name' placeholder='Name'
																                 value='$dat[1]' 
																              >
																            </div>
																            <div class='form-group div01'>
																              <label for='txt-tdate' class='control-label sr-only'>Target Date</label>
																              <input type='date' name='txttdate' class='form-control txt01' id='txt-tdate' placeholder='Target Date'
																                 value='$dat[4]' 
																              >
																            </div>
																        </p>
																      </div>
																      <div class='modal-footer'>
																        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																        <input type='submit' name='btnsaveEdit' class='btn btn-primary btn-lg btn01' value='SAVE'>
																      </div>
																          </form>
																      </div>

																      </div>
																    </div>

																		<div id='modalDelete_$nn' class='modal fade' role='dialog'>
																			<div class='modal-dialog'>
																			<!-- Modal content-->
																			<div class='modal-content'>
																			<div class='modal-header'>
																				<button type='button' class='close' data-dismiss='modal'>&times;</button>
																				<h4 class='modal-title'>Delete Evaluation Info</h4>
																			</div>
																					<form method='post' action=''>
																			<div class='modal-body'>
																				<p>
																					<input type='hidden' name='txtid' value='$dat[0]'/>
																					Delete evaluation info?
																				</p>
																			</div>
																			<div class='modal-footer'>
																				<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																				<input type='submit' name='btnsaveDelete' class='btn btn-primary btn-lg btn01' value='DELETE'>
																			</div>
																					</form>
																			</div>

																			</div>
																		</div>

															</td>
															<td>
																".trim($dat[0])."
															</td>
															<td>
																".trim($dat[1])."
															</td>
															<td>
																".trim($dat[3])."
															</td>
															<td>
																".trim($dat[4])."
															</td>
															<td>
																".trim($dat[5])."
															</td>
															<td>
																$fstat
															</td>
														</tr>
													";
												}
											?>
											
										</tbody>
									</table>
								</div>
							</div>
					
							<!-- END TABLE NO PADDING -->
						</div>
					</div>
								
					
				
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>

	<script >
	$(document).ready(function(){
  $("#myInput1").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable1 tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
	</script>


<?php
	include "./parts/btm_script.php";
?>


</body>

</html>
