
					<?php include "./data/connect.php";
						//
						$logun = $_SESSION['intern_data_cun'];
						$logutype = $_SESSION['intern_data_utype'];
						//
						//
						$csy = trim($_SESSION['intern_data_active_sy']);
						//
						//GET CALC TIME
						//
						include "./parts/sys_functions_calchrs.php";
						calcDTime($logun,$csy);
						//
					?>
					<!-- OVERVIEW -->
					<div class="panel panel-headline">
						<div class="panel-heading">
							<h3 class="panel-title">Online Internship Management System</h3>
						<p class="panel-subtitle"> </p>
						</div>
						<div class="panel-body">
							<div class="row">
								<div class="col-md-6">
									<div class="metric">
										<span class="icon"><i class="fa fa-calendar"></i></span>
										<p>
											<span class="number">
											<?php include "./data/connect.php";
												//
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
												//
												$csy = trim($_SESSION['intern_data_active_sy']);
												//
												//GET INTERNS
												$count = 0;
												$count2 = 0;
												//
												$cdat = "";
												//
												//              0  1    2        3        4
												$sql = " select no,sy,total_hrs,used_hrs,rem_hrs from tbl_interns_totalhrs where studentid='$logun' and sy='$csy' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$cdat = trim($dat[3]);
												}
												if ( trim($cdat)!="" ) {
													$cd = explode(".", trim($cdat));
													//
													if ( trim($cd[0])!="" ) {
														$count = strval(trim($cd[0]));
													}
													if ( trim($cd[1])!="" ) {
														$count2 = strval(trim($cd[1]));
													}
												}
												//
												//echo $count."<span class='cpanel_hrs_01'>hr(s)</span> ".$count2."<span class='cpanel_hrs_01'>min(s)</span>";
												echo $cdat."<span class='cpanel_hrs_01'>hr(s)</span> ";
											?>
											</span>
											<span class="title">Used Time</span>
										</p>
									</div>
								</div>

								<div class="col-md-6" >
									<div class="metric" >
										<span class="icon"><i class="fa fa-calendar"></i></span>
										<p>
											<span class="number">
											<?php include "./data/connect.php";
												//
												$logun = $_SESSION['intern_data_cun'];
												$logutype = $_SESSION['intern_data_utype'];
												//
												$csy = trim($_SESSION['intern_data_active_sy']);
												//
												//GET INTERNS
												$count = 0;
												$count2 = 0;
												//
												$cdat = "";
												//
												//              0  1    2        3        4
												$sql = " select no,sy,total_hrs,used_hrs,rem_hrs from tbl_interns_totalhrs where studentid='$logun' and sy='$csy'  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$cdat = trim($dat[4]);
												}
												if ( trim($cdat)!="" ) {
													$cd = explode(".", trim($cdat));
													//
													if ( trim($cd[0])!="" ) {
														$count = strval(trim($cd[0]));
													}
													if ( trim($cd[1])!="" ) {
														$count2 = strval(trim($cd[1]));
													}
												}
												//
												//echo $count."<span class='cpanel_hrs_01'>hr(s)</span> ".$count2."<span class='cpanel_hrs_01'>min(s)</span>";
												echo $cdat."<span class='cpanel_hrs_01'>hr(s)</span> ";
											?>
											</span>
											<span class="title">Remaining</span>
										</p>
									</div>
								</div>
							</div>

							
						<div class="panel-body">
							
						</div>
					


							<div class="row">
								
							</div>
						</div>
					</div>
					<!-- END OVERVIEW -->


					<div class="row">

						<div class="col-md-7">


							<div class="panel panel-scrolling cpanel_ann01">
								<div class="panel-heading">
									<h3 class="panel-title">HTE Announcement</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
										
									</div>
								</div>
								<div class="panel-body">
									
									<?php
										//
									$logun =  $_SESSION['intern_data_cun'];
									$loguntype = $_SESSION['intern_data_utype'];
									//
									//
									$id = $_GET['aid'];
									$idtype = "hte";
									//
									$htelist = "";
									//
									//                    0       1      2      
									$sql = " select hte_mem_id,hte_id,member_id from tbl_hte_members  where member_id='$logun' ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										if ( trim($dat[1])!="" && trim($dat[2])!="" ) {
											if ( trim($htelist)=="" ) {
												$htelist = " ann_id='$dat[1]' ";
											}else{
												$htelist = " or ann_id='$dat[1]' ";
											}
										}
									}
									if ( trim($htelist)!="" ) {
										$htelist = " and ( " . $htelist . " ) ";
									}
									//
									//
									if ( trim($htelist)!="" ) {
										//
										echo "<ul class='ul01'>";
										//
										//LOAD AVAILABLE
										$nn = 0;
										$nid = "";
										//                      0         1      2       3      4      5      6      7    8
										$sql = " select announcement_id,ann_id,ann_type,by_id,by_type,pdate,subject,msg,cfile from tbl_announcement  where ( ann_type='$idtype' ) $htelist  order by announcement_id desc limit 15 ";
										$qry = mysqli_query($conn,$sql);
										while($dat=mysqli_fetch_array($qry)) {
											if ( trim($dat[7])!=="" || trim($dat[8])!="" ) {
												$nn = $nn + 1;
												//
												$nid = trim($dat[0]);
												//
												//FILE
												$pfile = "";
												$fln = trim($dat[8]);
												//
												$dfn = "File";
												$dfnx = "";
												//
												//
												if ( trim($fln)!="" ) {
													$dfnx = "." . trim(pathinfo($fln,PATHINFO_EXTENSION));
													if ( trim($dat[6])=="" ) {
														$dfn = "File";
													}else{
														$dfn = trim($dat[6]);
													}
													//
													if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
														$pfile = "<p align='center'>
																		<a href='#' class='ann_lnkprev01' data-toggle='modal' data-target='#modalPrevImage_$nn'>
																	<img class='ann_img01' src='".trim($dat[8])."'/>
																		</a>
																	<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																		<img class='ann_img02' src='".trim($dat[8])."'/>
																	</div>
																  </p>";
													}else{
														$pfile = "<p align='left'><a href='".trim($dat[8])."' target='_blank'>".trim($dfn).trim($dfnx)."</a></p>";
													}
												}
												//
												$memid = "";
												$memname = "";
												$img = "";
												$link = "";
												//GET MEMBER NAME
												if ( strtolower(trim($dat[4]))==strtolower(trim("student")) ) {
													$sql1 = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns  where studentid='$dat[3]'  ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														if ( trim($dat1[0]) != "" ) {
															$mname = "";
															if ( trim($dat1[2])!="" ) {
																$mname = " " . trim($dat1[2]);
															}
															$memid = trim($dat1[0]);
															$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
															//
															$img = trim($dat1[4]);
															//
															$link = "./page_profile.php?id=".trim($dat1[0]);
														}
													}
												}
												if ( strtolower(trim($dat[4]))==strtolower(trim("employee")) ) {
													$sql1 = " select employee_id,firstname,middlename,lastname,prof_img from tbl_employee  where employee_id='$dat[3]'  ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														if ( trim($dat1[0]) != "" ) {
															$mname = "";
															if ( trim($dat1[2])!="" ) {
																$mname = " " . trim($dat1[2]);
															}
															$memid = trim($dat1[0]);
															$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
															//
															$img = trim($dat1[4]);
															//
															$link = "./page_profile_employee.php?id=".trim($dat1[0]);
														}
													}
												}
												if ( strtolower(trim($dat[4]))==strtolower(trim("admin")) ) {
													$memid = "Admin";
													$memname = "Admin";
													$img = "";
													//
													$link = "#";
												}
												//
												if ( trim($img)=="" ) {
													$img = "./assets/img/empty_user.png";
												}
												//
												//
												$frmedit = "";
												$ern = 0;
												//
												if ( trim($logun)=="" ) {
													$ern += 1;
												}
												if ( strtolower(trim($loguntype))==strtolower(trim("student")) ) {
													$ern += 1;
												}
												if ( strtolower(trim($loguntype))==strtolower(trim("coordinator")) ||
													 strtolower(trim($loguntype))==strtolower(trim("employee")) ) {
													if ( strtolower(trim($loguntype))!=strtolower(trim($dat[3])) && strtolower(trim($logun))!=strtolower(trim($dat[4])) ) {
														$ern += 1;
													}
												}
												//
												if ( $ern <= 0 ) {
													$frmedit = "

																				<div class='dropdown'>
																				  <a class='btn_action_01' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																				  <ul class='dropdown-menu'>
																				    <li><a href='#' data-toggle='modal' data-target='#modalEdit_$nid'>Edit</a></li>
																				    <li><a href='#' data-toggle='modal' data-target='#modalDelete_$nid'>Delete</a></li>
																				  </ul>
																				</div>

																				    <div id='modalEdit_$nid' class='modal fade' role='dialog'>
																				      <div class='modal-dialog'>
																				      <!-- Modal content-->
																				      <div class='modal-content'>
																				      <div class='modal-header' align='left'>
																				        <button type='button' class='close' data-dismiss='modal'>&times;</button>
																				        <h4 class='modal-title'>Update</h4>
																				      </div>
																				          <form method='post' action='' enctype='multipart/form-data'>
																				      <div class='modal-body' align='left'>
																				        <p align='left'>
																									<input type='hidden' name='txtid' value='$dat[0]'/>

																							<div class='form-group div01'>
																								<label for='subject' class='control-label sr-only'>Subject</label>
																								<input type='text' name='txtsubject' class='form-control txt01' id='subject' placeholder='Subject'
																									 value='$dat[6]' 
																								>
																							</div>
																							<div class='form-group div01'>
																								<label for='msg' class='control-label sr-only'>Message</label>
																								<textarea name='txtmsg' class='form-control txta01' id='msg' placeholder='Message'>$dat[7]</textarea>
																							</div>
																							<div class='form-group div01'>
																								Attach file:
																								<label for='fileUP' class='control-label sr-only'>Attach File</label>
																								<input type='file' name='fileUP' id='fileUP' placeholder='Attach File'>
																							</div>

																				        </p>
																				      </div>
																				      <div class='modal-footer'>
																				        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																				        <input type='submit' name='btnsaveEdit' class='btn btn-primary btn-md btn01' value='SAVE'>
																				      </div>
																				          </form>
																				      </div>

																				      </div>
																				    </div>

																						<div id='modalDelete_$nid' class='modal fade' role='dialog'>
																							<div class='modal-dialog'>
																							<!-- Modal content-->
																							<div class='modal-content'>
																							<div class='modal-header' align='left'>
																								<button type='button' class='close' data-dismiss='modal'>&times;</button>
																								<h4 class='modal-title'>Delete</h4>
																							</div>
																									<form method='post' action='' enctype='multipart/form-data'>
																							<div class='modal-body' align='left'>
																								<p align='left'>
																									<input type='hidden' name='txtid' value='$dat[0]'/>
																									Delete announcement?
																								</p>
																							</div>
																							<div class='modal-footer'>
																								<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																								<input type='submit' name='btnsaveDelete' class='btn btn-primary btn-md btn01' value='DELETE'>
																							</div>
																									</form>
																							</div>

																							</div>
																						</div>

													";
												}
												//
												echo "
														<li>
															<div class='panel panel-default uldiv01' align='left'>
																<div class='uldiv01'>
																	<table class='' width='100%'>
																		<tr>
																			<td class='ann_td01_1'>
																				<img src='$img' class='ann_img03' />
																			</td>
																			<td class='ann_td01_2'>
																				<div class='div_ann_name01'>
																					<a href='$link' class='ann_link01'>$memname</a>
																					<br/>
																					<span class='pst_date_01'>$dat[5]</span>
																				</div>
																			</td>
																			<td class='ann_td01_3'>
																				
																				

																			</td>
																		</tr>
																	</table>
																	<hr class='hr02'/>
																	<div class='div_ann_msg01'>
																		$dat[7]
																	</div>
																	<div class='div_ann_msg02'>
																		$pfile
																	</div>
																</div>
															</div>
														</li>
												";
											}
										}
										//
										echo "</ul>";
										//
									}
									//
									//
									?>


								</div>
							</div>


	<!-- =============================================================== -->

							<div class="panel panel-scrolling cpanel_ann01">
								<div class="panel-heading">
									<h3 class="panel-title">Course Announcement</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
										
									</div>
								</div>
								<div class="panel-body">
									
									<?php
										//
									$logun =  $_SESSION['intern_data_cun'];
									$loguntype = $_SESSION['intern_data_utype'];
									//
									//
									$id = $_GET['aid'];
									$idtype = "course";
									//
									$crs = "";
									//
									//                    0       1     
									$sql = " select studentid,course from tbl_interns  where studentid='$logun' ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										$crs = " ann_id='" . trim($dat[1]) . "' ";
									}
									if ( trim($crs)!="" ) {
										$crs = " and ( " . $crs . " ) ";
									}
									//
									//
									if ( trim($crs)!="" ) {
										//
										echo "<ul class='ul01'>";
										//
										//LOAD AVAILABLE
										$nn = 0;
										$nid = "";
										//                      0         1      2       3      4      5      6      7    8
										$sql = " select announcement_id,ann_id,ann_type,by_id,by_type,pdate,subject,msg,cfile from tbl_announcement  where ( ann_type='$idtype' ) $crs  order by announcement_id desc limit 15 ";
										$qry = mysqli_query($conn,$sql);
										while($dat=mysqli_fetch_array($qry)) {
											if ( trim($dat[7])!=="" || trim($dat[8])!="" ) {
												$nn = $nn + 1;
												//
												$nid = trim($dat[0]);
												//
												//FILE
												$pfile = "";
												$fln = trim($dat[8]);
												//
												$dfn = "File";
												$dfnx = "";
												//
												//
												if ( trim($fln)!="" ) {
													$dfnx = "." . trim(pathinfo($fln,PATHINFO_EXTENSION));
													if ( trim($dat[6])=="" ) {
														$dfn = "File";
													}else{
														$dfn = trim($dat[6]);
													}
													//
													if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
														  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
														) {
														$pfile = "<p align='center'>
																		<a href='#' class='ann_lnkprev01' data-toggle='modal' data-target='#modalPrevImage_$nn'>
																	<img class='ann_img01' src='".trim($dat[8])."'/>
																		</a>
																	<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																		<img class='ann_img02' src='".trim($dat[8])."'/>
																	</div>
																  </p>";
													}else{
														$pfile = "<p align='left'><a href='".trim($dat[8])."' target='_blank'>".trim($dfn).trim($dfnx)."</a></p>";
													}
												}
												//
												$memid = "";
												$memname = "";
												$img = "";
												$link = "";
												//GET MEMBER NAME
												if ( strtolower(trim($dat[4]))==strtolower(trim("student")) ) {
													$sql1 = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns  where studentid='$dat[3]'  ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														if ( trim($dat1[0]) != "" ) {
															$mname = "";
															if ( trim($dat1[2])!="" ) {
																$mname = " " . trim($dat1[2]);
															}
															$memid = trim($dat1[0]);
															$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
															//
															$img = trim($dat1[4]);
															//
															$link = "./page_profile.php?id=".trim($dat1[0]);
														}
													}
												}
												if ( strtolower(trim($dat[4]))==strtolower(trim("employee")) ) {
													$sql1 = " select employee_id,firstname,middlename,lastname,prof_img from tbl_employee  where employee_id='$dat[3]'  ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														if ( trim($dat1[0]) != "" ) {
															$mname = "";
															if ( trim($dat1[2])!="" ) {
																$mname = " " . trim($dat1[2]);
															}
															$memid = trim($dat1[0]);
															$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
															//
															$img = trim($dat1[4]);
															//
															$link = "./page_profile_employee.php?id=".trim($dat1[0]);
														}
													}
												}
												if ( strtolower(trim($dat[4]))==strtolower(trim("admin")) ) {
													$memid = "Admin";
													$memname = "Admin";
													$img = "";
													//
													$link = "#";
												}
												//
												if ( trim($img)=="" ) {
													$img = "./assets/img/empty_user.png";
												}
												//
												//
												$frmedit = "";
												$ern = 0;
												//
												if ( trim($logun)=="" ) {
													$ern += 1;
												}
												if ( strtolower(trim($loguntype))==strtolower(trim("student")) ) {
													$ern += 1;
												}
												if ( strtolower(trim($loguntype))==strtolower(trim("coordinator")) ||
													 strtolower(trim($loguntype))==strtolower(trim("employee")) ) {
													if ( strtolower(trim($loguntype))!=strtolower(trim($dat[3])) && strtolower(trim($logun))!=strtolower(trim($dat[4])) ) {
														$ern += 1;
													}
												}
												//
												if ( $ern <= 0 ) {
													$frmedit = "

																				<div class='dropdown'>
																				  <a class='btn_action_01' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																				  <ul class='dropdown-menu'>
																				    <li><a href='#' data-toggle='modal' data-target='#modalEdit_$nid'>Edit</a></li>
																				    <li><a href='#' data-toggle='modal' data-target='#modalDelete_$nid'>Delete</a></li>
																				  </ul>
																				</div>

																				    <div id='modalEdit_$nid' class='modal fade' role='dialog'>
																				      <div class='modal-dialog'>
																				      <!-- Modal content-->
																				      <div class='modal-content'>
																				      <div class='modal-header' align='left'>
																				        <button type='button' class='close' data-dismiss='modal'>&times;</button>
																				        <h4 class='modal-title'>Update</h4>
																				      </div>
																				          <form method='post' action='' enctype='multipart/form-data'>
																				      <div class='modal-body' align='left'>
																				        <p align='left'>
																									<input type='hidden' name='txtid' value='$dat[0]'/>

																							<div class='form-group div01'>
																								<label for='subject' class='control-label sr-only'>Subject</label>
																								<input type='text' name='txtsubject' class='form-control txt01' id='subject' placeholder='Subject'
																									 value='$dat[6]' 
																								>
																							</div>
																							<div class='form-group div01'>
																								<label for='msg' class='control-label sr-only'>Message</label>
																								<textarea name='txtmsg' class='form-control txta01' id='msg' placeholder='Message'>$dat[7]</textarea>
																							</div>
																							<div class='form-group div01'>
																								Attach file:
																								<label for='fileUP' class='control-label sr-only'>Attach File</label>
																								<input type='file' name='fileUP' id='fileUP' placeholder='Attach File'>
																							</div>

																				        </p>
																				      </div>
																				      <div class='modal-footer'>
																				        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																				        <input type='submit' name='btnsaveEdit' class='btn btn-primary btn-md btn01' value='SAVE'>
																				      </div>
																				          </form>
																				      </div>

																				      </div>
																				    </div>

																						<div id='modalDelete_$nid' class='modal fade' role='dialog'>
																							<div class='modal-dialog'>
																							<!-- Modal content-->
																							<div class='modal-content'>
																							<div class='modal-header' align='left'>
																								<button type='button' class='close' data-dismiss='modal'>&times;</button>
																								<h4 class='modal-title'>Delete</h4>
																							</div>
																									<form method='post' action='' enctype='multipart/form-data'>
																							<div class='modal-body' align='left'>
																								<p align='left'>
																									<input type='hidden' name='txtid' value='$dat[0]'/>
																									Delete announcement?
																								</p>
																							</div>
																							<div class='modal-footer'>
																								<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																								<input type='submit' name='btnsaveDelete' class='btn btn-primary btn-md btn01' value='DELETE'>
																							</div>
																									</form>
																							</div>

																							</div>
																						</div>

													";
												}
												//
												echo "
														<li>
															<div class='panel panel-default uldiv01' align='left'>
																<div class='uldiv01'>
																	<table class='' width='100%'>
																		<tr>
																			<td class='ann_td01_1'>
																				<img src='$img' class='ann_img03' />
																			</td>
																			<td class='ann_td01_2'>
																				<div class='div_ann_name01'>
																					<a href='$link' class='ann_link01'>$memname</a>
																					<br/>
																					<span class='pst_date_01'>$dat[5]</span>
																				</div>
																			</td>
																			<td class='ann_td01_3'>
																				
																				

																			</td>
																		</tr>
																	</table>
																	<hr class='hr02'/>
																	<div class='div_ann_msg01'>
																		$dat[7]
																	</div>
																	<div class='div_ann_msg02'>
																		$pfile
																	</div>
																</div>
															</div>
														</li>
												";
											}
										}
										//
										echo "</ul>";
										//
									}
									//
									//
									?>


								</div>
							</div>


						</div>


						<div class="col-md-5">
							<!-- MULTI CHARTS -->
							<div class="panel panel-scrolling">
								<div class="panel-heading">
									<h3 class="panel-title">Recent User Activity</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
										
									</div>
								</div>
								<div class="panel-body">
									<ul class="list-unstyled activity-list">
										<?php include "./data/connect.php";
											//
											//
											$logun =  $_SESSION['intern_data_cun'];
											$logutype = $_SESSION['intern_data_utype'];
											//
											//
											$xq = "";
											$hteidq = "";
											$studidq1 = "";
											if ( strtolower(trim($logutype))==strtolower(trim("student")) ) {
												//GET USER HTE
												//                 0         1      2
												$sql = " select hte_mem_id,hte_id,member_id from tbl_hte_members where member_id='$logun' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($hteidq)=="" ) {
														$hteidq = " hte_id='$dat[1]' ";
													}else{
														$hteidq = $hteidq . " || hte_id='$dat[1]' ";
													}
												}
												//
												if ( trim($hteidq)!="" ) {
													//
													$hteidq = " where " . $hteidq;
													//GET USERS IN HTE
													//                 0         1      2
													$sql = " select hte_mem_id,hte_id,member_id from tbl_hte_members $hteidq ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($studidq1)=="" ) {
															$studidq1 = " member_id='$dat[2]' ";
														}else{
															$studidq1 = $studidq1 . " || member_id='$dat[2]' ";
														}
													}
												}
												//
												//
											}
											if ( trim($studidq1)!="" ) {
												//
												$studidq1 = " where member_type='student' and ( " . $studidq1 . " ) ";
												//GET ALL LOGS
												//                 0     1         2            3    4    5
												$sql = " select uact_id,member_id,member_type,adate,msg,atype from tbl_uact $studidq1 order by uact_id desc limit 5 ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[1])!="" ) {
														//
														$mid = "";
														$fn = "";
														$img = "";
														//
														$time = trim($dat[3]);
														$msg = trim($dat[4]);
														//
														//                   0        1          2        3        4
														$sql2 = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns where studentid='$dat[1]' ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															$mid = trim($dat2[0]);
															$fn = trim($dat2[1]);
															$img = trim($dat2[4]);
														}
														//
															if ( trim($img) == "" ) {
																$img = "assets/img/empty_user.png";
															}
														//
														echo "
															<li>
																<img src='$img' alt='Avatar' class='img-circle pull-left avatar'>
																<p><a href='./page_profile.php?id=$mid'>$fn</a> $msg <span class='timestamp'>$time</span></p>
															</li>
														";
														//
													}
												}
											}
										?>
									</ul>
									<p align="center">
										<a href="./user_activity.php" class="btn btn-primary btn-bottom">View All</a>
									</p>
									
								</div>
							</div>
							<!-- END MULTI CHARTS -->
						</div>

					</div>
					
					<div class="row">
						<div class="col-md-4">
							<!-- TASKS -->
							
							<!-- END TASKS -->
						</div>
						<div class="col-md-4">
							<!-- VISIT CHART -->
							
							<!-- END VISIT CHART -->
						</div>
						<div class="col-md-4">
							<!-- REALTIME CHART -->
		
							<!-- END REALTIME CHART -->
						</div>
					</div>
