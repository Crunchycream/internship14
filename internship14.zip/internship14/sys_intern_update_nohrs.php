<?php  include "./data/connect.php";
	$asy = "";
	//
	$sql = " select sy_id,sy,status from tbl_sy where sy<>'' and status='ACTIVE' limit 1 ";
	$qry = mysqli_query($conn,$sql);
	while($dat=mysqli_fetch_array($qry)) {
		if ( trim($dat[1]) != "" ){
			$asy = trim($dat[1]);
		}
	}
	//
	$_SESSION['intern_data_active_sy'] = trim($asy);
?>