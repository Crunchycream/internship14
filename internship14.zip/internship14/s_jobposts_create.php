<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	if ( trim($logun)!="" ) {
	//=================================================================================================
		if ( $_POST["btnAddJobPost"] ) {
			//
			$uid = $_POST['hte_id'];
			$uidtype = $_POST['puidt'];
			//
			if ( trim($uid)!="" ) {
				//
				$subj = $_POST['txtsubject'];
				$msg = $_POST['txtmsg'];
				//
				$jobc = 0;
				$jobc = strval(trim($_POST['jobc']));
				$cjc = 0;
				$asjob0 = "";
				$asjob1 = "";
				$asjnn = 0;
				for ( $i=1 ; $i<=$jobc ; $i++ ) {
					$tsj = trim($_POST['job_'.$i.'']);
					if ( trim($tsj)!="" ) {
						if ( trim($asjob1)=="" ) {
							$asjob1 = trim($tsj);
						}else{
							$asjob1 = $asjob1 . ";" . trim($tsj);
						}
						$asjnn += 1;
					}
				}
				//echo "
				//	<script>
				//		alert('$jobc $asjob1');
				//	</script>
				//";
				if ( $asjnn > 0 ) {
					//
					$target_dir = "uploads/";
					$foname = basename($_FILES["fileUP"]["name"]);
					$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
					$target_file = $target_dir . $foname;
					$target_file2 = "";
					$uploadOk = 1;
					$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
					// Check if image file is a actual image or fake image
					if(isset($_POST["btnAddJobPost"])) {
					    // Check file size
						if ($_FILES["fileUP"]["size"] > 500000) {
						    //echo "Sorry, your file is too large.";
						    //$uploadOk = 0;
						}
						if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
						&& $imageFileType != "gif" && $imageFileType != "bmp" && $imageFileType != "ico"
						&& $imageFileType != "doc" && $imageFileType != "docx" && $imageFileType != "pdf" ) {
						    $uploadOk = 0;
						}
						if ($uploadOk == 0) {
						    //echo "Sorry, your file was not uploaded.";
						} else {
							//GET NEW NAME
							$fln = "file_".$date_month."_".$date_day."_".$date_year."__".$date_hour."_".$date_minute."_".$date_second.".".$imageFileType;
						    $target_file2 = $target_dir . "$fln";
						    if (move_uploaded_file($_FILES["fileUP"]["tmp_name"], $target_file2)) {
						        //echo "The file ". basename( $_FILES["fileUP"]["name"]). " has been uploaded.";
						        //SAVE 
						        $sql = " insert into tbl_jobpost
						        			 (pdate,subject,msg,cfile,by_id,by_type,jobs,hte_id)
						        		 values
						        		 	 ('$cdate','$subj','$msg','$target_file2','$memid','$memtype','$asjob1','$uid') ";
								$qry = mysqli_query($conn,$sql);
								//SAVE TO UPLOADED FILES
						        $sql = " insert into tbl_upfiles
						        			 (name,location,date_uploaded,upby_id,upby_type,utype,uloc_id,uloc_type)
						        		 values
						        		 	 ('$foname','$target_file2','$cdate','$memid','$memtype','announcement','$uid','$uidtype') ";
								$qry = mysqli_query($conn,$sql);
								//NOTIFICATION
								$notif_ttl = "Announcement posted.";
								$notif_lnk = "";
								$notif_cont = "$idname: Announcement posted.";
								$notif_locid = "$uid";
								$notif_loctype = "$uidtype";
								$notif_tarsn = "page_announcement";
								$notif_status = "unseen";
								//addNotification($memid,$memtype,$notif_ttl,$notif_lnk,$notif_cont,$notif_locid,$notif_loctype,$notif_tarsn,$notif_status);
								//
								//SET REFRESH
								$_SESSION['intern_sys_page_doref'] = "true";
								//
						    } else {
						        //echo "Sorry, there was an error uploading your file.";
						    }
						}
						if ( trim($foname)=="" ) {
							if ( trim($msg)!="" ) {
						        //SAVE 
						        $sql = " insert into tbl_jobpost
						        			 (pdate,subject,msg,cfile,by_id,by_type,jobs,hte_id)
						        		 values
						        		 	 ('$cdate','$subj','$msg','$target_file2','$memid','$memtype','$asjob1','$uid') ";
								$qry = mysqli_query($conn,$sql);
								//NOTIFICATION
								$notif_ttl = "Announcement posted.";
								$notif_lnk = "";
								$notif_cont = "$idname: Announcement posted.";
								$notif_locid = "$uid";
								$notif_loctype = "$uidtype";
								$notif_tarsn = "page_announcement";
								$notif_status = "unseen";
								//addNotification($memid,$memtype,$notif_ttl,$notif_lnk,$notif_cont,$notif_locid,$notif_loctype,$notif_tarsn,$notif_status);
								//
								//SET REFRESH
								$_SESSION['intern_sys_page_doref'] = "true";
								//
							}
						}
					}
				}
				
			}
		}
	//=================================================================================================
	}
	if ( trim($logun)=="" || strtolower(trim($logutype))==strtolower(trim("student")) ) {
		exit;
	}
?>
<HTML>
<head>
	<title>Create Job Posts</title>

	<?php include "./parts/head_content.php"; ?>

</head>
<body style="background:#fff;">
	<div align="left">
		<div class="div_jp_m01">
		
			<?php include "./data/connect.php";
				//
				$logun = $_SESSION['intern_data_cun'];
				$logutype = $_SESSION['intern_data_utype'];
				//
				//
				$cid = trim($_GET['hte_id']);
				//
				$subj = $_POST['txtsubject'];
				$msg = $_POST['txtmsg'];
				//
				//LOAD ALL JOBS
				$jobc = 0;
				$jobslist = "";
				//
				//                  0       1      2    3
				$sql = " select hte_job_id,hte_id,name,description from tbl_hte_jobs  where hte_id='$cid'  ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					if ( trim($dat[1])!="" && trim($dat[2])!="" ) {
						$jobc += 1;
						$jobslist = $jobslist . "<input type='checkbox' name='job_$jobc' value='".trim($dat[0])."'><span class='span02'>".trim($dat[2])."</span><br>";
					}
				}
				//
				$htelist = "";
				if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
					//LOAD HTE LISTS
					$sql = " select hte_id,name from tbl_hte  where hte_id<>'' and name<>''  ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						$htelist = $htelist . "<option value='".trim($dat[0])."'><span class='span02'>".trim($dat[1])."</span></option>";
					}
				}
				if ( strtolower(trim($logutype))==strtolower(trim("employee")) ) {
					//LOAD HTE LISTS
					$xq = "";
					//
					$sql = " select hte_id from tbl_hte_staff  where staff_type='$logutype' and staff_id='$logun'  ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						if ( trim($xq)=="" ) {
							$xq = " hte_id='$dat[0]' ";
						}else{
							$xq = $xq . " or hte_id='$dat[0]' ";
						}
					}
					//echo "$xq";
					if ( trim($xq)!="" ) {
						$xq = " and ( " . $xq . " ) ";
						//
						$sql = " select hte_id,name from tbl_hte  where hte_id<>'' and name<>'' $xq  ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							$htelist = $htelist . "<option value='".trim($dat[0])."'><span class='span02'>".trim($dat[1])."</span></option>";
						}
						//echo "$xq";
					}
					//
				}
				//
				//
				$frm0 = "
					<form action='./s_jobposts_create.php' method='get' >
						
						<div class='form-group div01'>
							<b>Select HTE:<b/> 
							<select class='form-control txt01' name='hte_id'>
								$htelist
							</select>
							<input type='submit' class='btn btn-primary btn-md' value='SELECT'>
						</div>

					</form>
					<hr/>
				";
				//
				$frm = "
					<form action='./s_jobposts_create.php?hte_id=$cid' method='post' enctype='multipart/form-data'>
						<input type='hidden' name='hte_id' value='$cid' />
						<input type='hidden' name='puidt' value='hte' />
						<input type='hidden' name='jobc' value='$jobc' />

						<div class='form-group div01'>
							<label for='subject' class='control-label sr-only'>Subject</label>
							<input type='text' name='txtsubject' class='form-control txt01' id='subject' placeholder='Subject'
								value='$subj'
							>
						</div>

						<div class='form-group div01'>
							<label for='msg' class='control-label sr-only'>Message</label>
							<textarea name='txtmsg' class='form-control txta01' id='msg' placeholder='Message'>$msg</textarea>
						</div>

						<b>

						<div class='form-group div01'>
							Attach file:
							<label for='fileUP' class='control-label sr-only'>Attach File</label>
							<input type='file' name='fileUP' id='fileUP' placeholder='Attach File'>
						</div>

						<div class='form-group div01'>
							Jobs:<br/>
							<div class='div_jp01 div_jp_jl01'>
								$jobslist
							</div>
						</div>

						</b>

						<p align='right'>
						<input type='submit' class='btn btn-primary btn-md' value='CREATE' name='btnAddJobPost'>
						</p>

					</form>
				";
				//
				$errn = 0;
				//
				if ( trim($cid)=="" ) {
					$errn += 1;
				}
				//
				//CHECK IF HTE EXIST
				$cn = 0;
				$sql = " select * from tbl_hte  where hte_id='$cid'  ";
				$qry = mysqli_query($conn,$sql);
				while($dat=mysqli_fetch_array($qry)) {
					$cn += 1;
				}
				if ( $cn <= 0 ) {
					$errn += 1;
				}
				//
				echo "$frm0";
				//
				if ( $errn <= 0 ) {
					echo "$frm";
				}

			?>
		
		</div>
	</div>
</body>
</HTML>
