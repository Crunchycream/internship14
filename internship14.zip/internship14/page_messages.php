<?php  session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$_SESSION['intern_page_current'] = "page_messages";
		include "./parts/main_logcheck.php";
	//POST MESSAGE
	$iss = $_POST['DMsgSend'];
	if ( strtolower(trim($iss))==strtolower(trim("send")) ) {
		//if ( $_POST['btnMsgSend'] ) {
			$rcv_id = trim($_GET['id']);
			$rcv_type = trim($_GET['rtype']);
			$snd_id = $_SESSION['intern_data_cun'];
			$snd_type = $_SESSION['intern_data_utype'];
			$msg = $_POST['txtmsg'];
			$cdate = $date_month."/".$date_day."/".$date_year." ".$date_hour.":".$date_minute.":".$date_second;
			if ( trim($rcv_id)!="" && trim($snd_id)!="" && ($msg)!="" ) {
					//
					//GET GRROUP ID, IF NONE CREATE AND GET
					$tgid = "";
					//
					//                    0       1     2    3    4     5     6      7
					$sql = " select msgs_group_id,mem1_id,mem1_type,mem2_id,mem2_type from tbl_messages_group where ( mem1_id='$rcv_id' and mem1_type='$rcv_type' and mem2_id='$snd_id' and mem2_type='$snd_type' ) or ( mem1_id='$snd_id' and mem1_type='$snd_type' and mem2_id='$rcv_id' and mem2_type='$rcv_type' ) ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						$tgid = trim($dat[0]);
					}
					//
					if ( trim($tgid)=="" ) {
						//CREATE
						$sql = " insert into tbl_messages_group
									( mem1_id,mem1_type,mem2_id,mem2_type )
								values
									( '$rcv_id','$rcv_type','$snd_id','$snd_type' )
						 ";
							$qry = mysqli_query($conn,$sql);
					}
					//GET
					//                    0       1     2    3    4     5     6      7
					$sql = " select msgs_group_id,mem1_id,mem1_type,mem2_id,mem2_type from tbl_messages_group where ( mem1_id='$rcv_id' and mem1_type='$rcv_type' and mem2_id='$snd_id' and mem2_type='$snd_type' ) or ( mem1_id='$snd_id' and mem1_type='$snd_type' and mem2_id='$rcv_id' and mem2_type='$rcv_type' ) ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						$tgid = trim($dat[0]);
					}
					//
					//
					//FOR SENDER
					$sql = "
							insert into tbl_messages
								(rcv_id,rcv_type,snd_id,snd_type,message,date_sent,own_id,own_type,msgs_group_id) 
							values 
								('$rcv_id','$rcv_type','$snd_id','$snd_type','$msg','$cdate','$snd_id','$snd_type','$tgid') 
							";
					$qry = mysqli_query($conn,$sql);
					//FOR RECEIVER
					$sql = "
							insert into tbl_messages
								(rcv_id,rcv_type,snd_id,snd_type,message,date_sent,own_id,own_type,msgs_group_id) 
							values 
								('$rcv_id','$rcv_type','$snd_id','$snd_type','$msg','$cdate','$rcv_id','$rcv_type','$tgid') 
							";
					$qry = mysqli_query($conn,$sql);
			}
		//}
	}
	//MSGS LOG UPDATER
	include "./parts/msgs_logupdater.php";
	//
	if ( trim($logun)=="" ) {
		exit;
	}
?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>
	<?php include "./parts/head_content_02.php"; ?>

</head>

<body>

	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			
		</footer>
	</div>

<div id="frame_cs01" class="chat_mp01_cont">

	<div id="sidepanel_cs01">
		<div id="profile_cs01">
			<div class="wrap_cs01">
				<?php include "./data/connect.php";
					$curlog = $_SESSION['intern_data_cun'];
					$curlogtype = $_SESSION['intern_data_utype'];
					//
					$name = "";
					$img = "";
					//
					//
					if ( strtolower(trim($curlogtype))==strtolower(trim("student")) ) {
						$sql = " select studentid,lastname,firstname,middlename,prof_img from tbl_interns  where studentid='$curlog'  order by lastname asc ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" && trim($dat[1])!="" && trim($dat[2])!="" ) {
								$mname = "";
								if ( trim($dat[3])!="" ) {
									$mname = " " . trim($dat[3]);
								}
								$name = trim($dat[2]) . $mname . " " . trim($dat[1]);
								$img = trim($dat[4]);
							}
						}
					}
					//
					if ( strtolower(trim($curlogtype))==strtolower(trim("employee")) ) {
						$sql = " select employee_id,lastname,firstname,middlename,prof_img from tbl_employee  where employee_id='$curlog'  order by lastname asc ";
						$qry = mysqli_query($conn,$sql);
						while($dat=mysqli_fetch_array($qry)) {
							if ( trim($dat[0])!="" && trim($dat[1])!="" && trim($dat[2])!="" ) {
								$mname = "";
								if ( trim($dat[3])!="" ) {
									$mname = " " . trim($dat[3]);
								}
								$name = trim($dat[2]) . $mname . " " . trim($dat[1]);
								$img = trim($dat[4]);
							}
						}
					}
					//
					//
					if ( trim($img)=="" ) {
						$img = "./assets/img/empty_user.png";
					}
					echo "
						<img id='profile-img_cs01' src='$img' class='online'>
						<p><span class='span02'>$name</span></p>
					";
				?>
				<div id="status-options_cs01">
					<ul>
						<li id="status-online_cs01" class="active"><span class="status-circle_cs01"></span> <p>Online</p></li>
						<li id="status-away_cs01"><span class="status-circle_cs01"></span> <p>Away</p></li>
						<li id="status-busy_cs01"><span class="status-circle_cs01"></span> <p>Busy</p></li>
						<li id="status-offline_cs01"><span class="status-circle_cs01"></span> <p>Offline</p></li>
					</ul>
				</div>
			</div>
		</div>
		<div id="search_cs01">
			<label for=""><i class="fa fa-search" aria-hidden="true"></i></label>
			<input id="myInput1" placeholder="Search contacts..." type="text">
		</div>
		<div id="contacts_cs01">
	<div id="conlist">
	<div id="conlists">
			<ul id="myContactList">
				<?php include "./data/connect.php";
					$curlog = $_SESSION['intern_data_cun'];
					$curlogtype = $_SESSION['intern_data_utype'];
					//
					$curid = trim($_GET['id']);
					//
					//
						//
						$tmgid = "";
						//
						$name = "";
						$img = "";
						$msg = "";
						$msgby = "";
						$msgn = 0;
						//
						//GET LAST MESSAGE
						$msg = "";
						$msgby = "";
						$msgn = 0;
						$trcvid = "";
						$trcvidt = "";
						$tsndid = "";
						$tsndidt = "";
						$tmsg = "";
						$tdate = "";
						//
						$msggid = "";
						//
						//GET CURRENT USER MSGS ID
						$dgids = "";
						$sql2 = " select msgs_group_id,mem1_id,mem1_type,mem2_id,mem2_type from tbl_messages_group  where ( mem1_id='$curlog' and mem1_type='$curlogtype' ) or ( mem2_id='$curlog' and mem2_type='$curlogtype' ) ";
						$qry2 = mysqli_query($conn,$sql2);
						while($dat2=mysqli_fetch_array($qry2)) {
							if ( trim($dgids)=="" ) {
								$dgids = " msgs_group_id='$dat2[0]' ";
							}else{
								$dgids = $dgids . " or msgs_group_id='$dat2[0]' ";
							}
						}
						//
						if ( trim($dgids)!="" ) {
							$dgids = " where " . $dgids;
						}
						//
						//
						if ( trim($dgids)!="" ) {
							
							//
							//                   0     1       2       3       4        5        6       7       8
							$sql2 = " select rcv_id,rcv_type,snd_id,snd_type,message,date_sent,own_id,own_type,msgs_group_id from tbl_messages_log  $dgids order by date_sent desc ";
							$qry2 = mysqli_query($conn,$sql2);
							while($dat2=mysqli_fetch_array($qry2)) {
								//
								$tmgid = trim($dat2[8]);
								//
								$name = "";
								$img = "";
								$msg = "";
								$msgby = "";
								$msgn = 0;
								//
								//GET LAST MESSAGE
								$msg = "";
								$msgby = "";
								$msgn = 0;
								$trcvid = "";
								$trcvidt = "";
								$tsndid = "";
								$tsndidt = "";
								$tmsg = "";
								$tdate = "";
								//
								if ( trim($dat2[0])!="" && trim($dat2[2])!="" ) {
									$msgn = 0;
									if ( $msgn <= 0 ) {
										$msg = $dat2[4];
										if ( strtolower(trim($curlog)) == strtolower(trim($dat2[1])) ) {
											//$msgby = "You:";
										}else{
											//$msgby = "";
										}
										$msgn = $msgn + 1;
										//FOR LOGS
										$trcvid = $dat2[0];
										$trcvidt = $dat2[1];
										$tsndid = $dat2[2];
										$tsndidt = $dat2[3];
										$tmsg = $dat2[4];
										$tdate = $dat2[5];
										//
									}
									//
									$tfid = "";
									$tfidt = "";
									//
									$tfid = $trcvid;
									$tfidt = $trcvidt;
									//
									if ( strtolower(trim($trcvidt)) == strtolower(trim($tsndidt)) ) {
										if ( strtolower(trim($trcvid)) != strtolower(trim($tsndid)) ) {
											if ( strtolower(trim($curlog))!=strtolower(trim($trcvid)) ) {
												$tfid = $trcvid;
												$tfidt = $trcvidt;
											}else{
												$tfid = $tsndid;
												$tfidt = $tsndidt;
											}
										}else{
											$tfid = $trcvid;
											$tfidt = $trcvidt;
										}
									}else{

									}
									//
									//
									if ( strtolower(trim($trcvidt))==strtolower(trim("employee")) || strtolower(trim($tsndidt))==strtolower(trim("employee")) ) {

										if ( strtolower(trim($trcvid))!=strtolower(trim($tsndid)) && strtolower(trim($trcvidt))!=strtolower(trim($tsndidt)) ) {
											if ( strtolower(trim($curlog))!=strtolower(trim($tsndid)) && strtolower(trim($curlogtype))!=strtolower(trim($tsndidt)) &&
												 strtolower(trim($curlog))==strtolower(trim($trcvid)) && strtolower(trim($curlogtype))==strtolower(trim($trcvidt))
											 ) {

												$tfid = $tsndid;
												$tfidt = $tsndidt;

											}
											if ( strtolower(trim($curlog))==strtolower(trim($tsndid)) && strtolower(trim($curlogtype))==strtolower(trim($tsndidt)) &&
												 strtolower(trim($curlog))!=strtolower(trim($trcvid)) && strtolower(trim($curlogtype))!=strtolower(trim($trcvidt))
											 ) {

												$tfid = $trcvid;
												$tfidt = $trcvidt;

											}
										}else{
												$tfid = $trcvid;
												$tfidt = $trcvidt;
										}
										
									}
									//
									//
									if ( strtolower(trim($tfidt))==strtolower(trim("student")) ) {
										$sql = " select studentid,lastname,firstname,middlename,prof_img from tbl_interns where studentid='$tfid' order by lastname asc ";
										$qry = mysqli_query($conn,$sql);
										while($dat=mysqli_fetch_array($qry)) {
											if ( trim($dat[0])!="" && trim($dat[1])!="" && trim($dat[2])!="" ) {
												$dcid = trim($dat[0]);
												$name = "";
												$mname = "";
												$img = "";
												$css = "";
												if ( trim($dat[3])!="" ) {
													$mname = " " . trim($dat[3]);
												}
												$name = trim($dat[2]) . $mname . " " . trim($dat[1]);
												$img = trim($dat[4]);
												if ( trim($img)=="" ) {
													$img = "./assets/img/empty_user.png";
												}
												if ( strtolower(trim($dat[0]))==strtolower(trim($curid)) ) {
													$css = "active";
												}
											}
										}
									}
									if ( strtolower(trim($tfidt))==strtolower(trim("employee")) ) {
										$sql = " select employee_id,lastname,firstname,middlename,prof_img from tbl_employee where employee_id='$tfid' order by lastname asc ";
										$qry = mysqli_query($conn,$sql);
										while($dat=mysqli_fetch_array($qry)) {
											if ( trim($dat[0])!="" && trim($dat[1])!="" && trim($dat[2])!="" ) {
												$dcid = trim($dat[0]);
												$name = "";
												$mname = "";
												$img = "";
												$css = "";
												if ( trim($dat[3])!="" ) {
													$mname = " " . trim($dat[3]);
												}
												$name = trim($dat[2]) . $mname . " " . trim($dat[1]);
												$img = trim($dat[4]);
												if ( trim($img)=="" ) {
													$img = "./assets/img/empty_user.png";
												}
												if ( strtolower(trim($dat[0]))==strtolower(trim($curid)) ) {
													$css = "active";
												}
											}
										}
									}
									//
									//GET MSG BY
									//
									$sndbyid = "";
									$sndbyidt = "";
									//
										$sql = " select snd_id,snd_type from tbl_messages where message='$tmsg' and date_sent='$tdate' and msgs_group_id='$dat2[8]'  limit 1 ";
										$qry = mysqli_query($conn,$sql);
										while($dat=mysqli_fetch_array($qry)) {
											$sndbyid = trim($dat[0]);
											$sndbyidt = trim($dat[1]);
										}
									//
										if ( strtolower(trim($curlog)) == strtolower(trim($sndbyid)) ) {
											$msgby = "You:";
										}else{
											$msgby = "";
										}
									//
									echo "
										<li class='contact_cs01 $css'>
											<a class='chat_mp01_link01' href='./page_messages.php?id=".trim($tfid)."&rtype=".trim($tfidt)."'>
											<div class='wrap_cs01'>
												<span class='contact-status_cs01 online'></span>
												<img class='chat_mp01_contact_img' src='$img'>
												<div class='meta_cs01'>
													<p class='name_cs01 span02'>$name</p>
													<p class='preview_cs01'>$msgby $tmsg
														<br/>
														<span class='prevmsg_span01'>$tdate</span>
													</p>
												</div>
											</div>
											</a>
										</li>
									";
									//
								}
							}
							//

						}
						
						//
				?>
			</ul>
	</div>
	</div>
		</div>
		<div id="bottom-bar_cs01">
		<!--
			<button id="addcontact"><i class="fa fa-user-plus fa-fw" aria-hidden="true"></i> <span>Add contact</span></button>
			<button id="settings"><i class="fa fa-cog fa-fw" aria-hidden="true"></i> <span>Settings</span></button>
			-->
		</div>
	</div>
  
	<div class="content_cs01">
		<div class="contact-profile_cs01">
			<?php include "./data/connect.php";
				$curid = trim($_GET['id']);
				$curtype = trim($_GET['rtype']);
				//
				$name = "";
				$img = "";
				//
				if ( strtolower(trim($curtype))==strtolower(trim("student")) ) {
					$sql = " select studentid,lastname,firstname,middlename,prof_img from tbl_interns  where studentid='$curid'  order by lastname asc ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						if ( trim($dat[0])!="" && trim($dat[1])!="" && trim($dat[2])!="" ) {
							$mname = "";
							if ( trim($dat[3])!="" ) {
								$mname = " " . trim($dat[3]);
							}
							$name = trim($dat[2]) . $mname . " " . trim($dat[1]);
							$img = trim($dat[4]);
						}
					}
				}
				if ( strtolower(trim($curtype))==strtolower(trim("employee")) ) {
					$sql = " select employee_id,lastname,firstname,middlename,prof_img from tbl_employee  where employee_id='$curid'  order by lastname asc ";
					$qry = mysqli_query($conn,$sql);
					while($dat=mysqli_fetch_array($qry)) {
						if ( trim($dat[0])!="" && trim($dat[1])!="" && trim($dat[2])!="" ) {
							$mname = "";
							if ( trim($dat[3])!="" ) {
								$mname = " " . trim($dat[3]);
							}
							$name = trim($dat[2]) . $mname . " " . trim($dat[1]);
							$img = trim($dat[4]);
						}
					}
				}
				//
				if ( trim($img)=="" ) {
					$img = "./assets/img/empty_user.png";
				}
				echo "
					<img src='$img' alt='Photo'>
					<p><span class='span02'>$name</span></p>
				";
			?>
		</div>
		<div class="messages_cs01 chat_mp01">
	<div id="msglist">
	<div id="msglists">
			<ul>
				<?php include "./data/connect.php";
					$curlog = $_SESSION['intern_data_cun'];
					$curlogtype = $_SESSION['intern_data_utype'];
					//
					$curid = trim($_GET['id']);
					$curtype = trim($_GET['rtype']);
					//
					$name = "";
					$img = "";
					$fno = 0;
					$msg = "";
					$date = "";
					//GET ALL MSGS
					//                 0       1      2       3        4      5        6
					$sql1 = " select msg_id,rcv_id,rcv_type,snd_id,snd_type,message,date_sent from tbl_messages  where ( own_id='$curid' and own_type='$curtype' ) and ( (rcv_id='$curid' and rcv_type='$curtype' and snd_id='$curlog' and snd_type='$curlogtype') or (rcv_id='$curlog' and rcv_type='$curlogtype' and snd_id='$curid' and snd_type='$curtype') or (rcv_id='$curlog' and rcv_type='$curlogtype' and snd_id='$curlog' and snd_type='$curlogtype') )  order by msg_id asc ";
					$qry1 = mysqli_query($conn,$sql1);
					while($dat1=mysqli_fetch_array($qry1)) {
						if ( trim($dat1[1])!="" && trim($dat1[3])!="" ) {
							$cid = trim($dat1[1]);
							$fno = 0;
							$name = "";
							$img = "";
							$name1 = "";
							$img1 = "";
							$name2 = "";
							$img2 = "";
							if ( $fno <= 0 ) {
								//
								//
								//GET NAME
								$sql = " select studentid,lastname,firstname,middlename,prof_img from tbl_interns  where studentid='$dat1[3]'  order by lastname asc ";
								$qry = mysqli_query($conn,$sql);
								while($dat=mysqli_fetch_array($qry)) {
									if ( trim($dat[0])!="" && trim($dat[1])!="" && trim($dat[2])!="" ) {
										$mname = "";
										if ( trim($dat[3])!="" ) {
											$mname = " " . trim($dat[3]);
										}
										$name2 = trim($dat[2]) . $mname . " " . trim($dat[1]);
										$img2 = trim($dat[4]);
										$fno = $fno + 1;
									}
								}
								if ( trim($img2)=="" ) {
									$img2 = "./assets/img/empty_user.png";
								}
							}
							//
							if ( strtolower(trim($dat[1]))==strtolower(trim($curlog)) ) {
								if ( strtolower(trim($dat[1]))==strtolower(trim($curid)) ) {
								//$name = $name1;
								//$img = $img1;
								}
							}else{
								//$name = $name2;
								//$img = $img2;
							}
							if ( strtolower(trim($cid)) == strtolower(trim($curlog)) ) {
								//
								//$name = $name2;
								//$img = $img2;
							}else{
								//
								//$name = $name1;
								//$img = $img1;
							}
							//
							//GET MESSAGE
							$msg = $dat1[5];
							$date = trim($dat1[6]);
							//CLASS
							$cls = "sent";
							$cls2 = " align='left' ";
							$cls3 = "  ";
							if ( strtolower(trim($cid)) == strtolower(trim($curlog)) ) {
								//REPS
								$cls = "replies";
								$cls2 = " align='right' style='margin-top:10px;' ";
								$cls3 = " <br/><br/> ";
								//
								$name = $name2;
								$img = $img2;
							}else{
								//SENT
								$cls = "sent";
								$cls2 = " align='left' ";
								$cls3 = "  ";
								//
								$name = $name2;
								$img = $img2;
							}
							//IF ITS ME
							if ( strtolower(trim($curid)) == strtolower(trim($curlog)) && strtolower(trim($cid)) == strtolower(trim($curlog)) ) {
								$cls = "sent";
								$cls2 = " align='left' ";
								$cls3 = "  ";
								//
							}
							//SHOW
							echo "
								<li class='$cls'>
									<img src='$img' alt='Photo'>
									<p>$msg</p>
									$cls3
									<div class='prevmsg_span02' $cls2>$date</div>
								</li>
							";
						}
					}
				?>
			</ul>
	</div>
	</div>
		</div>
		<div class="message-input_cs01">
			<form method="post" action="">
			<div class="wrap_cs01">
			<input type="hidden" name="DMsgSend" value="send"/>
			<input placeholder="Write your message..." type="text" name="txtmsg">
			<i class="fa fa-paperclip attachment_cs01" aria-hidden="true"></i>
			<button type="submit" name="btnMsgSend" class="submit"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
			</div>
			</form>
		</div>
	</div>
</div>

	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>
	<?php include "./parts/body_bottom_content.php"; ?>

	<script >
	$(document).ready(function(){
  $("#myInput1").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myContactList li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
	</script>


<?php
	include "./parts/btm_script.php";
?>

</body>

</html>
