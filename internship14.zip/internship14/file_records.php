<?php session_start(); error_reporting( E_ALL ^ E_NOTICE );
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$_SESSION['intern_page_current'] = "file_records";
		include "./parts/main_logcheck.php";
	//
	if ( trim($logun)=="" ) {
		exit;
	}
?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	
	<?php include "./parts/head_content.php"; ?>

</head>

<body> 
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">Uploaded Files</h3>
					<div class="row">
						
							<!-- BASIC TABLE -->
				
							<!-- RECENT PURCHASES -->
						<div class="row">
							<div class="col-md-9">
							<h5 class="ss">Search:</h5>
							</div>
						
							
							<div class="col-md-3">
							<div class="form-group pull-right">
							<input type="text" id="myInput" value="" class="search form-control" placeholder="What you looking for">
							<!--	<span class="counter pull-right"><button type="button" class="btn btn-primary">Search</button></span>-->
								</div>
									<span class="counter pull-right"></span>
									</div>
						</div>
						<hr><br/>
							<div class="panel">
						
								<div class="table-responsive">
								
									<table class="table table-hover results">
										<thead>
											<tr>
												<th>Name</th>
												<th>Location</th>
												<th>Date Uploaded</th>
												<th>Uploader</th>
												<th>Uploader Type</th>
												<th>Uploaded As</th>
											</tr>
											<tr class="warning no-result">
      											<td><i class="fa fa-warning"></i> No result</td>
   											</tr>
										</thead>
										<tbody id="myTable">
											<?php
												include "./data/connect.php";
												//               0  1     2        3             4        5       6
												$sql = " select no,name,location,date_uploaded,upby_id,upby_type,utype from tbl_upfiles  order by date_uploaded desc  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													
													$lnk = "";
													//
													$name = "";
													//
													//
													$sql2 = "";
													//
													if ( trim($dat[4])!="" && trim($dat[5])!="" ) {
														if ( strtolower(trim($dat[5]))==strtolower(trim("employee")) ) {
															$lnk = "page_profile_employee.php";
															//
															$sql2 = " select firstname from tbl_employee where employee_id='$dat[4]'  ";
																$qry2 = mysqli_query($conn,$sql2);
																while($dat2=mysqli_fetch_array($qry2)) {
																	$name = trim($dat2[0]);
																}
														}
														if ( strtolower(trim($dat[5]))==strtolower(trim("student")) ) {
															$lnk = "page_profile.php";
															//
															$sql2 = " select firstname from tbl_interns where studentid='$dat[4]'  ";
																$qry2 = mysqli_query($conn,$sql2);
																while($dat2=mysqli_fetch_array($qry2)) {
																	$name = trim($dat2[0]);
																}
														}
														if ( trim($dat[4])!="" ) {
															//GET NAME
														}
													}
													//
													//
													echo "
														<tr>
															<td>
																".trim($dat[1])."
															</td>
															<td>
																<a target='_blank' href='".trim($dat[2])."'>".trim($dat[2])."</a>
															</td>
															<td>
																".trim($dat[3])."
															</td>
															<td>
																<a href='".$lnk."?id=".trim($dat[4])."'>
																<span class='span02'>".trim($name)."</span>
																</a>
															</td>
															<td>
																".trim($dat[5])."
															</td>
															<td>
																".trim($dat[6])."
															</td>
														</tr>
													";
												}
											?>
											
											
										</tbody>
									</table>
								</div>
							
							</div>
					
							<!-- END TABLE NO PADDING -->
						
					</div>
					
					
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>

<script>
/*	
	$(document).ready(function() {
  $(".search").keyup(function () {
    var searchTerm = $(".search").val();
    var listItem = $('.results tbody').children('tr');
    var searchSplit = searchTerm.replace(/ /g, "'):containsi('")
    
  $.extend($.expr[':'], {'containsi': function(elem, i, match, array){
        return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
    }
  });
    
  $(".results tbody tr").not(":containsi('" + searchSplit + "')").each(function(e){
    $(this).attr('visible','false');
  });

  $(".results tbody tr:containsi('" + searchSplit + "')").each(function(e){
    $(this).attr('visible','true');
  });

  var jobCount = $('.results tbody tr[visible="true"]').length;
    $('.counter').text(jobCount + ' item');

  if(jobCount == '0') {$('.no-result').show();}
    else {$('.no-result').hide();}
		  });
});*/

$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

</script>



<?php
	include "./parts/btm_script.php";
?>


</body>

</html>
