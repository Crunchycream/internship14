<?php session_start(); error_reporting( E_ALL ^ E_NOTICE );
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$_SESSION['intern_page_current'] = "page_class";
		include "./parts/main_logcheck.php";
		include "./parts/page_profile_class_upload.php";
	//
	if ( trim($logun)=="" ) {
		exit;
	}
?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>

	<script type="text/javascript">
		setInterval('my_function();',5000);
	    function my_function(){
	      $('#up_new_jobpost').load(location.href + ' #up_new_jobpost_s');
	    }

	    function detectScrollbar()
		{
			if (navigator.appName == "Microsoft Internet Explorer")
			{
				window.name=document.body.scrollTop;
			}
			else
			{
				window.name=window.pageYOffset;
			}
		}

		function doScroll()
		{
			if (window.name) window.scrollTo(0, window.name);
		}


	</script>

</head>

<body onload="doScroll()" onunload="window.name=document.body.scrollTop" >
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->

	<?php include "./parts/page_class_modal.php"; ?>
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-8">
								<?php
									$cuid =  $_SESSION['intern_data_cun'];
									$cutype = $_SESSION['intern_data_utype'];
									if ( strtolower(trim($cutype))!=strtolower(trim("student")) ) {
										echo "
											<div class='dropdown divprof_menu01'>
											  <button class='btn btn-primary dropdown-toggle btnprof_menu01' type='button' data-toggle='dropdown'>&equiv;</button>
											  <ul class='dropdown-menu'>
											    <li><a  data-toggle='modal' data-target='#modalChangeCoverPhoto' href='' class=''>Update Cover Photo</a></li>
											  </ul>
											</div>
										";
									}
								?>
											
							<!-- LEFT COLUMN -->
							<div class="">
								<!-- PROFILE HEADER -->
								<div class="profile-header">
									<div class="overlay"></div>
									
											<?php include "./data/connect.php";
												$id = $_GET['id'];
												$sql = " select class_id,name,prof_backimg from tbl_class where class_id='$id' ";
												$qry = mysqli_query($conn,$sql);
												$ttl = "";
												$backimg = "";
												while($dat=mysqli_fetch_array($qry)) {
													$ttl = trim($dat[1]);
													$backimg = trim($dat[2]);
												}
												if ( trim($backimg) == "" ) {
													$backimg = "assets/img/profile-bg.png";
												}
												echo "
													<div class='profile-main' style='background:url($backimg) no-repeat; background-size: 100%;'>
													<br/>
													<br/>
													<br/>
													<br/>
													<h3 class='name'>
													<span class='span02'>$ttl</span>
													</h3>
													</div>
												";
											?>
										
									<div class="profile-stat">
										<div class="row">
											<div class="col-md-4 stat-item">
												<?php echo getInternCount(); ?> <span>Interns</span>
											</div>
											<div class="col-md-4 stat-item">
												<?php $id = $_GET['id']; echo getClassActCount($id); ?> <span>Activities</span>
											</div>
											<div class="col-md-4 stat-item">
												<?php echo getHTECount(); ?> <span>HTE</span>
											</div>
										</div>
									</div>
								</div>
								

					<!-- TABBED CONTENT -->
					<div class="custom-tabs-line tabs-line-bottom left-aligned">
						<ul class="nav" role="tablist">
							<?php
								$cls = "";
								//
								$cpt = trim($_POST['cpt']);
								//
								$cls = "";
								if ( trim($cpt)=="" || strtolower(trim($cpt))==strtolower(trim("post")) ) {
									$cls = "active";
								}
								echo "
										<li class='$cls'><a href='#tab-bottom-left1' role='tab' data-toggle='tab'>Posts</a></li>
								";
								//
								$cls = "";
								if ( strtolower(trim($cpt))==strtolower(trim("reflection")) ) {
									$cls = "active";
								}
								echo "
										<li class='$cls'><a href='#tab-bottom-left2' role='tab' data-toggle='tab'>Activity</a></li>
								";
							?>
						</ul>
					</div>
					<div class="tab-content">
						<div 
							<?php
								$cls = "tab-pane fade in";
								//
								$cpt = trim($_POST['cpt']);
								//
								if ( trim($cpt)=="" || strtolower(trim($cpt))==strtolower(trim("post")) ) {
									$cls = "tab-pane fade in active";
								}
								echo " class='$cls' ";
							?>
								id="tab-bottom-left1">
							
							<div class="panel panel-default" align="center">
								<br/>
								<span class='font01'>Create a </span>
								<a href="" data-toggle="modal" data-target="#modalAddPost" class="btn btn-success btn-md">POST</a> 
								<span class='font01'> about your cocerns.</span>
								<br/>
								<br/>
							</div>
						<!-- ============ POSTS ============================ -->
								<?php include "./data/connect.php";
									//
									$logun =  $_SESSION['intern_data_cun'];
									$loguntype = $_SESSION['intern_data_utype'];
									//
									//
									$uid = $_GET['id'];
									//                  0       1        2           3             4     5      6            7                      
									$sql = " select class_id,member_id,member_type,parent_post_id,type,content,date_posted,class_post_id from tbl_class_posts where class_id='$uid' and type='post' and parent_post_id=''  order by date_posted desc ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										if ( trim($dat[0]) != "" ) {
											//
											$pstid = trim($dat[7]);
											$nid = $pstid;
											//
											$mid = trim($dat[1]);
											$mtyp = trim($dat[2]);
											$msg = trim($dat[5]);
											$ppid = trim($dat[3]);
											$img = trim(getUserImage($mid,$mtyp));
											$lnk = "";
											$tsn = "student";
											$tsubp = trim(getClassSubPosts($dat[0],$pstid));
											//echo "$tsubp";
											if ( strtolower(trim($tsn))==strtolower(trim($mtyp)) ) {
												$lnk = "./page_profile.php";
											}
											$tsn = "employee";
											if ( strtolower(trim($tsn))==strtolower(trim($mtyp)) ) {
												$lnk = "./page_profile_employee.php";
											}
											$name = "<a class='ann_link01' href='".trim($lnk)."?id=$mid'>" . getUserName($mid,$mtyp) . "</a>";
											if ( strtolower(trim($mid))==strtolower(trim("admin")) || strtolower(trim($mtyp))==strtolower(trim("admin")) ) {
												$name = "<a href='#'>Admin</a>";
											}
											$fimg = "<img src='$img' class='ann_img03' alt='Photo'>";
											//
											//
											//
											$frmedit = "";
											$frmedit2 = "";
											$ern = 0;
											//
											if ( trim($logun)=="" ) {
												$ern += 1;
											}
											if ( strtolower(trim($loguntype))==strtolower(trim("student")) ) {
												$ern += 1;
											}
											if ( strtolower(trim($loguntype))==strtolower(trim("coordinator")) ||
												 strtolower(trim($loguntype))==strtolower(trim("employee")) ) {
												if ( strtolower(trim($loguntype))!=strtolower(trim($dat[3])) && strtolower(trim($logun))!=strtolower(trim($dat[4])) ) {
													$ern += 1;
												}
											}
											//
											if ( $ern <= 0 ) {
												$frmedit = "

																			<div class='dropdown'>
																			  <a class='btn_action_01' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																			  <ul class='dropdown-menu'>
																			    <li><a href='#' data-toggle='modal' data-target='#modalEdit_$nid'>Edit</a></li>
																			    <li><a href='#' data-toggle='modal' data-target='#modalDelete_$nid'>Delete</a></li>
																			  </ul>
																			</div> ";
												//
												if ( strtolower(trim($dat[4]))==strtolower(trim("post")) ) {
													$frmedit2 = "
																				    <div id='modalEdit_$nid' class='modal fade' role='dialog'>
																				      <div class='modal-dialog'>
																				      <!-- Modal content-->
																				      <div class='modal-content'>
																				      <div class='modal-header' align='left'>
																				        <button type='button' class='close' data-dismiss='modal'>&times;</button>
																				        <h4 class='modal-title'>Update</h4>
																				      </div>
																				          <form method='post' action='' enctype='multipart/form-data'>
																				      <div class='modal-body' align='left'>
																				        <p align='left'>
																									<input type='hidden' name='txtid' value='$nid'/>

																								<input type='hidden' name='cpt' value='$dat[4]' />

																								<input type='hidden' name='type' value='$dat[4]' />

																								<div class='form-group div01'>
																									<label for='stud-add-msg' class='control-label sr-only'>Message...</label>
																									<textarea name='msg' class='form-control texta01' id='stud-add-msg' placeholder='Message...'>$dat[5]</textarea>
																								</div>

																				        </p>
																				      </div>
																				      <div class='modal-footer'>
																				        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																				        <input type='submit' name='btnsavepostEdit' class='btn btn-primary btn-md btn01' value='SAVE'>
																				      </div>
																				          </form>
																				      </div>

																				      </div>
																				    </div>

																						<div id='modalDelete_$nid' class='modal fade' role='dialog'>
																							<div class='modal-dialog'>
																							<!-- Modal content-->
																							<div class='modal-content'>
																							<div class='modal-header' align='left'>
																								<button type='button' class='close' data-dismiss='modal'>&times;</button>
																								<h4 class='modal-title'>Delete</h4>
																							</div>
																									<form method='post' action='' enctype='multipart/form-data'>
																							<div class='modal-body' align='left'>
																								<p align='left'>
																								
																								<input type='hidden' name='cpt' value='$dat[4]' />

																									<input type='hidden' name='txtid' value='$nid'/>
																									Delete post?
																								</p>
																							</div>
																							<div class='modal-footer'>
																								<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																								<input type='submit' name='btnsavepostDelete' class='btn btn-primary btn-md btn01' value='DELETE'>
																							</div>
																									</form>
																							</div>

																							</div>
																						</div>

													";
												}
												//
												if ( strtolower(trim($dat[4]))==strtolower(trim("reflection")) ) {
													$frmedit2 = "
																				    <div id='modalEdit_$nid' class='modal fade' role='dialog'>
																				      <div class='modal-dialog'>
																				      <!-- Modal content-->
																				      <div class='modal-content'>
																				      <div class='modal-header' align='left'>
																				        <button type='button' class='close' data-dismiss='modal'>&times;</button>
																				        <h4 class='modal-title'>Update</h4>
																				      </div>
																				          <form method='post' action='' enctype='multipart/form-data'>
																				      <div class='modal-body' align='left'>
																				        <p align='left'>
																									<input type='hidden' name='txtid' value='$nid'/>

																								<input type='hidden' name='cpt' value='$dat[4]' />

																								<input type='hidden' name='type' value='$dat[4]' />

																								<div class='form-group div01'>
																									<label for='stud-add-msg' class='control-label sr-only'>Message...</label>
																									<textarea name='msg' class='form-control texta01' id='stud-add-msg' placeholder='Message...'>$dat[5]</textarea>
																								</div>

																				        </p>
																				      </div>
																				      <div class='modal-footer'>
																				        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																				        <input type='submit' name='btnsavepostEdit' class='btn btn-primary btn-md btn01' value='SAVE'>
																				      </div>
																				          </form>
																				      </div>

																				      </div>
																				    </div>

																						<div id='modalDelete_$nid' class='modal fade' role='dialog'>
																							<div class='modal-dialog'>
																							<!-- Modal content-->
																							<div class='modal-content'>
																							<div class='modal-header' align='left'>
																								<button type='button' class='close' data-dismiss='modal'>&times;</button>
																								<h4 class='modal-title'>Delete</h4>
																							</div>
																									<form method='post' action='' enctype='multipart/form-data'>
																							<div class='modal-body' align='left'>
																								<p align='left'>

																								<input type='hidden' name='cpt' value='$dat[4]' />

																									<input type='hidden' name='txtid' value='$nid'/>
																									Delete post?
																								</p>
																							</div>
																							<div class='modal-footer'>
																								<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																								<input type='submit' name='btnsavepostDelete' class='btn btn-primary btn-md btn01' value='DELETE'>
																							</div>
																									</form>
																							</div>

																							</div>
																						</div>

													";
												}
											}
											//
											//
											echo "
												<div class='panel'>
													<div class='panel-body'>
														<table class='class_post_tbl01'>
															<tr>
																<td class='ann_td01_1'>
																	<div class='class_post_div_ttl01'>
																		$fimg
																	</div>
																</td>
																<td class='ann_td01_2'>
																	<div class='div_ann_name01'>
																		<span class='span02'>$name</span>
																		<br/>
																		<span class='pst_date_01'>$dat[6]</span>
																	</div>
																</td>
																<td class='ann_td01_3'>
																			
																			$frmedit
																			$frmedit2

																</td>
															</tr>
														</table>
															<hr class='hr01'/>
																	<div class='class_post_div_msg01'>
																		$msg
																	</div>
																	<div>
																		<a class='class_post_link01' data-toggle='collapse' href='#divComment_$pstid'>Comments</a>   <a class='class_post_link01' data-toggle='modal' href='#divCommentModalAddComment_$pstid'>+Add Comment</a>

																		<div id='divComment_$pstid' class='collapse fade'>

																			$tsubp
																		</div>
																	    <!--==============ADD POST==========================-->
																			<div id='divCommentModalAddComment_$pstid' class='modal fade' role='dialog'>
																				<div class='modal-dialog'>
																				<!-- Modal content-->
																				<div class='modal-content'>
																				<div class='modal-header'>
																					<button type='button' class='close' data-dismiss='modal'>&times;</button>
																					<h4 class='modal-title'>Add Post Comment</h4>
																				</div>
																						<form action='' method='post'>
																				<div class='modal-body'>
																					<p>
																						<input type='hidden' name='postid' value='$pstid' />
																						<div class='form-group'>
																							".$_SESSION['intern_disp_err']."
																						</div>
																						<div class='form-group div01'>
																							<select class='form-control txt01' name='type'>
																								<option value='Post'>Post</option>
																							</select>
																						</div>
																						<div class='form-group div01'>
																							<label for='stud-add-msg' class='control-label sr-only'>Message</label>
																							<textarea name='msg' class='form-control txt01' id='stud-add-msg' placeholder='Message'>".$_POST['msg']."</textarea>
																						</div>
																					</p>
																				</div>
																				<div class='modal-footer'>
																					<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																					<input type='submit' class='btn btn-default' value='Save' name='btnAddPost'>
																				</div>
																						</form>
																				</div>

																				</div>
																			</div>
																	    <!--==============ADD POST==========================-->
																	</div>

													</div>
												</div>
											";
											//$_SESSION['intern_disp_err'] = '';
										}
									}
								?>
								<br/>
								<br/>
						<!-- ============ POSTS ============================ -->

						</div>
						<div 
							<?php
								$cls = "tab-pane fade in";
								//
								$cpt = trim($_POST['cpt']);
								//
								if ( strtolower(trim($cpt))==strtolower(trim("reflection")) ) {
									$cls = "tab-pane fade in active";
								}
								echo " class='$cls' ";
							?>
								id="tab-bottom-left2">
							
							<div class="panel panel-default" align="center">
								<br/>
								<span class='font01'>Create a </span>
								<a href="" data-toggle="modal" data-target="#modalAddPostReflection" class="btn btn-success btn-md">REFLECTION</a> 
								<span class='font01'> submission area.</span>
								<br/>
								<br/>
							</div>
						<!-- ============ REFLECTION ============================ -->
								<?php include "./data/connect.php";
										$memid =  $_SESSION['intern_data_cun'];
										$memtype = $_SESSION['intern_data_utype'];
										$logun =  $_SESSION['intern_data_cun'];
										$loguntype = $_SESSION['intern_data_utype'];
									//
									$uid = $_GET['id'];
									$nid = "";
									//                  0       1         2           3             4   5        6            7            8
									$sql = " select class_id,member_id,member_type,parent_post_id,type,content,date_posted,class_post_id,weekname from tbl_class_posts where class_id='$uid' and type='reflection' and parent_post_id=''  order by date_posted desc ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										if ( trim($dat[0]) != "" ) {
											//
											$pstid = trim($dat[7]);
											$nid = $pstid;
											//
											$mid = trim($dat[1]);
											$mtyp = trim($dat[2]);
											$msg = trim($dat[5]);
											$ppid = trim($dat[3]);
											$img = trim(getUserImage($mid,$mtyp));
											$lnk = "";
											$tsn = "student";
											$tsubp = trim(getClassSubPosts($dat[0],$pstid));
											$tsubstat = getClassActSubmissionStat($id,$pstid,$memid);
											//$tsubstat = getClassActSubmissionStat($id,$pstid,$mid);
											$tsubstatcount = getClassActSubmissionStatCount($id,$pstid,$mid);
											$tsubtxt = "";
											//
											$submitbtntxt = "SUBMIT";
											//
											if ( $tsubstat==true ) {
												$tsubtxt = "<span class='span01_success'>&check; Done submitting.</span>";
												$submitbtntxt = "RE-SUBMIT";
											}else{
												$tsubtxt = "<span class='span01_error'>&cross; You haven't submitted yet.</span>";
											}
											//echo "$tsubp";
											if ( strtolower(trim($tsn))==strtolower(trim($mtyp)) ) {
												$lnk = "./page_profile.php";
											}
											$tsn = "employee";
											if ( strtolower(trim($tsn))==strtolower(trim($mtyp)) ) {
												$lnk = "./page_profile_employee.php";
											}
											$name = "<a href='".trim($lnk)."?id=$mid'>" . getUserName($mid,$mtyp) . "</a>";
											if ( strtolower(trim($mid))==strtolower(trim("admin")) || strtolower(trim($mtyp))==strtolower(trim("admin")) ) {
												$name = "<a href='#'>Admin</a>";
											}
											$fimg = "<img src='$img' class='img-circle img_prof_03' alt='Photo'>";
											//
											//
											$fcsub = "";
											if ( strtolower(trim($memtype))!=strtolower(trim("student")) ) {
												$fcsub = "

																			<a class='class_post_link01' data-toggle='collapse' href='#divActComment_$pstid'>Submissions</a> 

																			<div id='divActComment_$pstid' class='collapse fade'>
																				$tsubp
																			</div>

												";
											}
											//
											$weekn = explode("_", trim($dat[8]));
											//
											//
											//
											//
											$frmedit = "";
											$frmedit2 = "";
											$ern = 0;
											//
											if ( trim($logun)=="" ) {
												$ern += 1;
											}
											if ( strtolower(trim($loguntype))==strtolower(trim("student")) ) {
												$ern += 1;
											}
											if ( strtolower(trim($loguntype))==strtolower(trim("coordinator")) ||
												 strtolower(trim($loguntype))==strtolower(trim("employee")) ) {
												if ( strtolower(trim($loguntype))!=strtolower(trim($dat[3])) && strtolower(trim($logun))!=strtolower(trim($dat[4])) ) {
													$ern += 1;
												}
											}
											//
											if ( $ern <= 0 ) {
												$frmedit = "

																			<div class='dropdown'>
																			  <a class='btn_action_01' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																			  <ul class='dropdown-menu'>
																			    <li><a href='#' data-toggle='modal' data-target='#modalEdit_$nid'>Edit</a></li>
																			    <li><a href='#' data-toggle='modal' data-target='#modalDelete_$nid'>Delete</a></li>
																			  </ul>
																			</div> ";
												//
												if ( strtolower(trim($dat[4]))==strtolower(trim("post")) ) {
													$frmedit2 = "
																				    <div id='modalEdit_$nid' class='modal fade' role='dialog'>
																				      <div class='modal-dialog'>
																				      <!-- Modal content-->
																				      <div class='modal-content'>
																				      <div class='modal-header' align='left'>
																				        <button type='button' class='close' data-dismiss='modal'>&times;</button>
																				        <h4 class='modal-title'>Update</h4>
																				      </div>
																				          <form method='post' action='' enctype='multipart/form-data'>
																				      <div class='modal-body' align='left'>
																				        <p align='left'>
																									<input type='hidden' name='txtid' value='$nid'/>

																								<input type='hidden' name='cpt' value='$dat[4]' />

																								<input type='hidden' name='type' value='$dat[4]' />

																								<div class='form-group div01'>
																									<label for='stud-add-msg' class='control-label sr-only'>Message...</label>
																									<textarea name='msg' class='form-control texta01' id='stud-add-msg' placeholder='Message...'>$dat[5]</textarea>
																								</div>

																				        </p>
																				      </div>
																				      <div class='modal-footer'>
																				        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																				        <input type='submit' name='btnsavepostEdit' class='btn btn-primary btn-md btn01' value='SAVE'>
																				      </div>
																				          </form>
																				      </div>

																				      </div>
																				    </div>

																						<div id='modalDelete_$nid' class='modal fade' role='dialog'>
																							<div class='modal-dialog'>
																							<!-- Modal content-->
																							<div class='modal-content'>
																							<div class='modal-header' align='left'>
																								<button type='button' class='close' data-dismiss='modal'>&times;</button>
																								<h4 class='modal-title'>Delete</h4>
																							</div>
																									<form method='post' action='' enctype='multipart/form-data'>
																							<div class='modal-body' align='left'>
																								<p align='left'>

																								<input type='hidden' name='cpt' value='$dat[4]' />

																									<input type='hidden' name='txtid' value='$nid'/>
																									Delete post?
																								</p>
																							</div>
																							<div class='modal-footer'>
																								<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																								<input type='submit' name='btnsavepostDelete' class='btn btn-primary btn-md btn01' value='DELETE'>
																							</div>
																									</form>
																							</div>

																							</div>
																						</div>

													";
												}
												//
												if ( strtolower(trim($dat[4]))==strtolower(trim("reflection")) ) {
													$frmedit2 = "
																				    <div id='modalEdit_$nid' class='modal fade' role='dialog'>
																				      <div class='modal-dialog'>
																				      <!-- Modal content-->
																				      <div class='modal-content'>
																				      <div class='modal-header' align='left'>
																				        <button type='button' class='close' data-dismiss='modal'>&times;</button>
																				        <h4 class='modal-title'>Update</h4>
																				      </div>
																				          <form method='post' action='' enctype='multipart/form-data'>
																				      <div class='modal-body' align='left'>
																				        <p align='left'>
																									<input type='hidden' name='txtid' value='$nid'/>

																								<input type='hidden' name='cpt' value='$dat[4]' />

																								<input type='hidden' name='type' value='$dat[4]' />

																								<div class='form-group div01'>
																									<label for='stud-add-msg' class='control-label sr-only'>Message...</label>
																									<textarea name='msg' class='form-control texta01' id='stud-add-msg' placeholder='Message...'>$dat[5]</textarea>
																								</div>

																				        </p>
																				      </div>
																				      <div class='modal-footer'>
																				        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																				        <input type='submit' name='btnsavepostEdit' class='btn btn-primary btn-md btn01' value='SAVE'>
																				      </div>
																				          </form>
																				      </div>

																				      </div>
																				    </div>

																						<div id='modalDelete_$nid' class='modal fade' role='dialog'>
																							<div class='modal-dialog'>
																							<!-- Modal content-->
																							<div class='modal-content'>
																							<div class='modal-header' align='left'>
																								<button type='button' class='close' data-dismiss='modal'>&times;</button>
																								<h4 class='modal-title'>Delete</h4>
																							</div>
																									<form method='post' action='' enctype='multipart/form-data'>
																							<div class='modal-body' align='left'>
																								<p align='left'>

																								<input type='hidden' name='cpt' value='$dat[4]' />

																									<input type='hidden' name='txtid' value='$nid'/>
																									Delete post?
																								</p>
																							</div>
																							<div class='modal-footer'>
																								<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																								<input type='submit' name='btnsavepostDelete' class='btn btn-primary btn-md btn01' value='DELETE'>
																							</div>
																									</form>
																							</div>

																							</div>
																						</div>

													";
												}
											}
											//
											//
											echo "
												<div class='panel'>
													<div class='panel-body'>
														<table class='class_post_tbl01'>
															<tr>
																<td class='ann_td01_1'>
																	<div class='class_post_div_ttl01'>
																		$fimg
																	</div>
																</td>
																<td class='ann_td01_2'>
																	<div class='div_ann_name01'>
																		<span class='span02'>$name</span>
																		<br/>
																		<span class='pst_date_01'>$dat[6]</span>
																	</div>
																</td>
																<td class='ann_td01_3'>
																			
																			$frmedit
																			$frmedit2

																</td>
															</tr>
														</table>
															<hr class='hr01'/>
																	<div class='class_post_div_msg01'>
																		<b><span class='span02'>$weekn[0] $weekn[1]</span></b><br/>
																		$msg
																		<br/>
																		<br/>
																		$tsubtxt
																		<br/>
																		<br/>
																		($tsubstatcount submitted.)
																		<br/>
																		<br/>
																		<a href='' data-toggle='modal' data-target='#divCommentModalAddCommentAct_$pstid' class='btn btn-success btn-lg'>$submitbtntxt</a>
																	</div>
																	<div>
																		$fcsub
																	    <!--==============ADD POST==========================-->
																			<div id='divCommentModalAddCommentAct_$pstid' class='modal fade' role='dialog'>
																				<div class='modal-dialog'>
																				<!-- Modal content-->
																				<div class='modal-content'>
																				<div class='modal-header'>
																					<button type='button' class='close' data-dismiss='modal'>&times;</button>
																					<h4 class='modal-title'>Submit Activity</h4>
																				</div>
																						<form action='' method='post' enctype='multipart/form-data'>
																				<div class='modal-body'>
																					<p>
																						DOC / DOCX / PDF files only.<br/>
																						<input type='hidden' name='postid' value='$pstid' />
																						<input type='hidden' name='type' value='Reflection' />
																						<input type='hidden' name='msg' value='' />
																						<input type='hidden' name='weekname' value='$dat[8]' />
																						<input type='file' name='fileUP' id='fileUP'>
																					</p>
																				</div>
																				<div class='modal-footer'>
																					<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																					<input type='submit' class='btn btn-default' value='Save' name='btnAddActPostComment'>
																				</div>
																						</form>
																				</div>

																				</div>
																			</div>
																	    <!--==============ADD POST==========================-->
																	</div>

													</div>
												</div>
											";
											//$_SESSION['intern_disp_err'] = '';
										}
									}
								?>
								<br/>
								<br/>
						<!-- ============ REFLECTION ============================ -->

						</div>
					</div>
					<!-- END TABBED CONTENT -->

							</div>
							<!--END LEFT-->
						</div>
						<div class="col-md-4">
							<!-- RIGHT COLUMN -->
							<div class="panel ann_divr02">
								<div class="divclass03">
									<?php include './data/connect.php';
										//
										$uid = $_GET['id'];
										//
										$curid = $_SESSION['intern_data_cun'];
										$curidtype = $_SESSION['intern_data_utype'];
										//
										if ( strtolower(trim($curidtype))!=strtolower(trim("student")) ) {
											echo "<a href='' data-target='#modalAddCOORD' class='btn btn-success btn-sm' data-toggle='modal'>+ ADD COORDINATOR</a> ";
											echo "<a href='' data-target='#modalAddHTE' class='btn btn-success btn-sm' data-toggle='modal'>+ ADD HTE</a> ";
											echo " <br/><br/> ";

											//
											$nameopt = "";
											$deptopt = "";
											$crsopt = "";
											$hteopt = "";
											//
											//
											$xql1 = "";
											$xql2 = "";
											//GET MEMBER HTE
												$sql = " select hte_id from tbl_class_member_hte where class_id='$uid' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[0]) != "" ) {
														if ( trim($xql1)=="" ) {
															$xql1 = " where hte_id='$dat[0]' ";
														}else{
															$xql1 = $xql1 . " || hte_id='$dat[0]' ";
														}
													}
												}
											//
											//GET EXCLUDED EMPLOYEE
												$sql = " select employee_id,hte_id from tbl_coordinator  $xql1 ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[0]) != "" ) {
														if ( trim($xql2)=="" ) {
															$xql2 = " where employee_id!='$dat[0]' ";
														}else{
															$xql2 = $xql2 . " and employee_id!='$dat[0]' ";
														}
													}
												}
											//
											//
												$sql = " select employee_id,lastname,firstname,middlename from tbl_employee  $xql2  order by lastname asc ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[0]) != "" && trim($dat[1]) != "" && trim($dat[2]) != "" ) {
														$val = trim($dat[0]);
														$nam = trim($dat[1]) . ", " . trim($dat[2]) . " " . trim($dat[3]);
														$nameopt = $nameopt . "<option value='".$val."'>".$nam."</option>";
													}
												}
												$sql = " select department_id,department from tbl_department  order by department asc  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[0]) != "" && trim($dat[1]) != "" ) {
														$val = trim($dat[0]);
														$nam = trim($dat[1]);
														$deptopt = $deptopt . "<option value='".$val."'>".$nam."</option>";
													}
												}
												$sql = " select course_id,course from tbl_course  order by course asc ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[0]) != "" && trim($dat[1]) != "" ) {
														$val = trim($dat[0]);
														$nam = trim($dat[1]);
														$crsopt = $crsopt . "<option value='".$val."'>".$nam."</option>";
													}
												}
												$sql = " select hte_id,name from tbl_hte  order by name asc ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[0]) != "" && trim($dat[1]) != "" ) {
														$val = trim($dat[0]);
														$nam = trim($dat[1]);
														$hteopt = $hteopt . "<option value='".$val."'>".$nam."</option>";
													}
												}
											//

											echo "
												<div id='modalAddCOORD' class='modal fade' role='dialog'>
													<div class='modal-dialog'>
													<!-- Modal content-->
													<div class='modal-content'>
													<div class='modal-header'>
														<button type='button' class='close' data-dismiss='modal'>&times;</button>
														<h4 class='modal-title'>Add New Coordinator</h4>
													</div>
															<form method='post' action=''>
													<div class='modal-body'>
														<p>
															<div class='form-group'>
																			
																		</div>
																		<div class='form-group div01'>
																			Employee<br/>
																				<select class='form-control txt01' name='empid'>
																					$nameopt
																				</select>
																		</div>
																		<div class='form-group div01'>
																			Department<br/>
																				<select class='form-control txt01' name='deptid'>
																					$deptopt
																				</select>
																		</div>
																		<div class='form-group div01'>
																			Course<br/>
																				<select class='form-control txt01' name='crsid'>
																					$crsopt
																				</select>
																		</div>
																		<div class='form-group div01'>
																			HTE<br/>
																				<select class='form-control txt01' name='hteid'>
																					$hteopt
																				</select>
																		</div>
																
														</p>
													</div>
													<div class='modal-footer'>
														<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
														<input type='submit' name='btnsaveAddCOORD' class='btn btn-primary btn-lg btn01' value='SAVE'>
													</div>
															</form>
													</div>

													</div>
												</div>
											";

										}
									?>
								</div>

								<div class="custom-tabs-line tabs-line-bottom left-aligned divclass03">
									<a href="#divInterns" class="linkclass01" data-toggle="collapse">INTERNS 
									<span class="badge"><?php echo getInternCount(); ?></span>
									</a>
								</div>
								<div class="tab-content divclass01">
									<div class="collapse divclass02 fade in active" id="divInterns">
										<?php include "./data/connect.php";
											$uid = $_GET['id'];
											$nn = 0;
											$exc = "";
											$exc2 = "";
											//GET ADDED HTE
											$sql = " select hte_id from tbl_class_member_hte where class_id='$uid'  ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[0]) != "" ) {
													if ( trim($exc)=="" ) {
														$exc = " where hte_id='$dat[0]' ";
													}else{
														$exc = $exc . " or hte_id='$dat[0]' ";
													}
												}
											}
											//echo "$exc";
											//GET GET HTE MEMBER ID
											$sql = " select member_id from tbl_hte_members  $exc   ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[0]) != "" ) {
													if ( trim($exc2)=="" ) {
														$exc2 = " where studentid='$dat[0]' ";
													}else{
														$exc2 = $exc2 . " or studentid='$dat[0]' ";
													}
												}
											}
											//echo "$exc2";
											//
											$nid = 0;
											//LOAD MEMBER NAME
											$sql = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns  $exc2  order by lastname asc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[0]) != "" ) {
													$nid = $nid + 1;
													//
													$memname = "";
													$mname = "";
													if ( trim($dat[2])!="" ) {
														$mname = "" . trim($dat[2]);
													}
													$memname = trim($dat[3]) . ", " . trim($dat[1]) . " " . $mname . " ";
													$memid = trim($dat[0]);
													//
													$img = trim($dat[4]);
													//
													if ( trim($img)=="" ) {
														$img = "./assets/img/empty_user.png";
													}
													//
													echo "

														<div class='dropdown divclasscont01'>
															<a href='#' data-toggle='dropdown'>
																<img src='$img' class='msgnotif_img03' />
															<span class='fontclasscont01 span02'>".trim($memname)."</span>
															</a>
															  <ul class='dropdown-menu'>
															    <li><a href='./page_profile.php?id=".trim($dat[0])."'>Profile</a></li>
															    <li><a href='#' data-toggle='modal' data-target='#modalInternSendMessage_$nid'>Send Message</a></li>
															  </ul>
														</div>

														<div id='modalInternSendMessage_$nid' class='modal fade' role='dialog'>
															<div class='modal-dialog'>
															<!-- Modal content-->
															<div class='modal-content'>
															<div class='modal-header'>
																<button type='button' class='close' data-dismiss='modal'>&times;</button>
																<h4 class='modal-title'>Send Message to '<span class='span02'>".trim($memname)."</span>'</h4>
															</div>
																	<form action='' method='post'>
															<div class='modal-body'>
																<p>
																	<input type='hidden' name='txtstudid' value='$memid'/>
																	<input type='hidden' name='txtstudtype' value='student'/>
																	<div class='form-group'>
																		
																	</div>
																	<div class='form-group div01'>
																		<label for='send-msg-msg' class='control-label sr-only'>Message</label>
																		<textarea name='msg' class='form-control txt01' id='send-msg-msg' placeholder='Message'></textarea>
																	</div>
																</p>
															</div>
															<div class='modal-footer'>
																<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																<input type='submit' class='btn btn-primary' value='Send' name='btnsaveSendMessage'>
															</div>
																	</form>
															</div>

															</div>
														</div>

													";
												}
											}
										?>
									</div>
								</div>
								<div class="custom-tabs-line tabs-line-bottom left-aligned divclass03">
									 <a href="#divHTE" class="linkclass01" data-toggle="collapse">HTE 
									<span class="badge"><?php echo getHTECount(); ?></span>
									</a>
								</div>
								<div class="tab-content divclass01">
									<div class="collapse divclass02 fade in active" id="divHTE">
										<?php include "./data/connect.php";
											$uid = $_GET['id'];
											$exc = "";
											//GET ADDED
											$sql = " select hte_id from tbl_class_member_hte  where class_id='$uid' ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[0]) != "" ) {
													if ( trim($exc)=="" ) {
														$exc = " where hte_id='$dat[0]' ";
													}else{
														$exc = $exc . " or hte_id='$dat[0]' ";
													}
												}
											}
											//LOAD AVAILABLE
											$nn = 0;
											$sql = " select hte_id,name,prof_backimg from tbl_hte  $exc  order by name asc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[1]) != "" ) {
													$nn = $nn + 1;
													if ( $nn > 1 ) {
														//echo "<br/>";
													}
													$img = trim($dat[2]);
													if ( trim($img)=="" ) {
														$img = "./assets/img/profile-bg.png";
													}
													echo "
													<div class='divclasscont01'>
														<a class='fontclasscont01' href='./page_hte.php?id=".trim($dat[0])."'>
																<img src='$img' class='msgnotif_img03' />
														"
														.trim($dat[1]).
														"</a>
													</div>
													";
												}
											}
										?>
									</div>
								</div>


								<div class="custom-tabs-line tabs-line-bottom left-aligned divclass03">
									 <a href="#divStaffs" class="linkclass01" data-toggle="collapse">STAFFS 
									<span class="badge"><?php $id = $_GET['id']; echo getCountClassStaffs2($id); ?></span>
									</a>
								</div>
								<div class="tab-content divclass01">
									<div class="collapse divclass02 fade in active" id="divStaffs">
										<?php include "./data/connect.php";
											$id = $_GET['id'];
											//LOAD AVAILABLE
											//
											//
											$logun =  $_SESSION['intern_data_cun'];
											$logutype = $_SESSION['intern_data_utype'];
											//
											//
											$xqry = "";
											//
											//                  0           1         2         3     4
											$sql = " select class_staff_id,class_id,staff_id,staff_type,position from tbl_class_staff where class_id<>'' and class_id='$id' and staff_id<>'' and staff_type='employee'  ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($xqry)=="" ) {
													$xqry = " where employee_id<>'$dat[2]' ";
												}else{
													$xqry = $xqry . " and employee_id<>'$dat[2]' ";
												}
											}
											//
											//LOAD AVAIL. EMPLOYEE
											$staffs = "";
											//                  0     1         2         3    
											$sql = " select employee_id,lastname,firstname,middlename from tbl_employee $xqry  order by lastname asc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												$name = "";
												//
												$name = trim($dat[1]) . ", " . trim($dat[2]) . " " . trim($dat[3]);
												//
												$staffs = $staffs . "<option value='$dat[0]'>$name</option>";
											}
											//
											//
											if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
												echo "
													<a href='#' class='btn btn-success btn-sm btn-block' data-toggle='modal' data-target='#modalAddStaff'>ADD STAFFS</a>

														<div id='modalAddStaff' class='modal fade' role='dialog'>
															<div class='modal-dialog'>
															<!-- Modal content-->
															<div class='modal-content'>
															<div class='modal-header'>
																<button type='button' class='close' data-dismiss='modal'>&times;</button>
																<h4 class='modal-title'>Add Staff</h4>
															</div>
																	<form action='' method='post'>
															<div class='modal-body'>
																<p>
																	
																	<div class='form-group div01'>
																		<b>Name:</b>
																		<select class='form-control' name='txtemployee'>
																			$staffs
																		</select>
																	</div>
																	<div class='form-group div01'>
																		<b>Position:</b>
																		<select class='form-control' name='txtposition'>
																			<option value='Admin'>Admin</option>
																			<option value='Coordinator'>Coordinator</option>
																			<option value='Supervisor'>Supervisor</option>
																		</select>
																	</div>
																</p>
															</div>
															<div class='modal-footer'>
																<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																<input type='submit' class='btn btn-primary' value='Save' name='btnsaveStaff'>
															</div>
																	</form>
															</div>

															</div>
														</div>

													";
											}
											//
											//
											$nn = 0;
											///\                  0         1     2        3          4
											$sql = " select class_staff_id,class_id,staff_id,staff_type,position from tbl_class_staff  where class_id='$id' ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[1]) != "" ) {
													$nn = $nn + 1;
													if ( $nn > 1 ) {
														//echo "<br/>";
													}
													$memid = "";
													$memname = "";
													$img = "";
													//GET MEMBER NAME
													$sql1 = " select employee_id,firstname,middlename,lastname,prof_img from tbl_employee  where employee_id='$dat[2]' ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														if ( trim($dat1[0]) != "" ) {
															$mname = "";
															if ( trim($dat1[2])!="" ) {
																$mname = " " . trim($dat1[2]);
															}
															$memid = trim($dat1[0]);
															$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
															//
															$img = trim($dat1[4]);
														}
													}
													//
													if ( trim($img)=="" ) {
														$img = "./assets/img/empty_user.png";
													}
													//
													$nid = trim($dat[0]);
													//
													//
													$aopt = "";
													$aoptv = "";
													if ( strtolower(trim($logutype))==strtolower(trim("admin")) ) {
														$aopt = "
															<li class='divider'></li>
															<li><a href='#' data-toggle='modal' data-target='#modalStaffRemove_$nid'>Remove Staff</a></li>

															";
														$aoptv = "

																<div id='modalStaffRemove_$nid' class='modal fade' role='dialog'>
																	<div class='modal-dialog'>
																	<!-- Modal content-->
																	<div class='modal-content'>
																	<div class='modal-header'>
																		<button type='button' class='close' data-dismiss='modal'>&times;</button>
																		<h4 class='modal-title'>Remove Staff</h4>
																	</div>
																			<form action='' method='post'>
																	<div class='modal-body'>
																		<p>
																		<input type='hidden' name='txtid' value='$nid' />

																			Remove Staff?

																		</p>
																	</div>
																	<div class='modal-footer'>
																		<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																		<input type='submit' class='btn btn-primary' value='Save' name='btnsaveStaffRemove'>
																	</div>
																			</form>
																	</div>

																	</div>
																</div>

															";
													}
													//
													//
													echo "

													<div class='dropdown divclasscont01'>
														<a href='#' data-toggle='dropdown'>
														<img src='$img' class='msgnotif_img03' />
														<span class='fontclasscont01 span02'>".trim($memname)." <br/>(" . trim($dat[4]) . ")"."</span>
														</a>
														  <ul class='dropdown-menu'>
														    <li><a href='./page_profile_employee.php?id=".trim($dat[2])."'>Profile</a></li>
														    <li><a href='#' data-toggle='modal' data-target='#modalInternSendMessage_$nid'>Send Message</a></li>
														    $aopt
														  </ul>
													</div>
														$aoptv
														<div id='modalInternSendMessage_$nid' class='modal fade' role='dialog'>
															<div class='modal-dialog'>
															<!-- Modal content-->
															<div class='modal-content'>
															<div class='modal-header'>
																<button type='button' class='close' data-dismiss='modal'>&times;</button>
																<h4 class='modal-title'>Send Message to '<span class='span02'>".trim($memname)."</span>'</h4>
															</div>
																	<form action='' method='post'>
															<div class='modal-body'>
																<p>
																	<input type='hidden' name='txtstudid' value='$memid'/>
																	<input type='hidden' name='txtstudtype' value='employee'/>
																	<div class='form-group'>
																		
																	</div>
																	<div class='form-group div01'>
																		<label for='send-msg-msg' class='control-label sr-only'>Message</label>
																		<textarea name='msg' class='form-control txt01' id='send-msg-msg' placeholder='Message'></textarea>
																	</div>
																</p>
															</div>
															<div class='modal-footer'>
																<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																<input type='submit' class='btn btn-primary' value='Send' name='btnsaveInternSendMessage'>
															</div>
																	</form>
															</div>

															</div>
														</div>

													";
												}
											}
										?>
									</div>
								</div>
								



							</div>
							<!-- END RIGHT COLUMN -->
						</div>
					</div>

				</div>

			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>

	<script >
	$(document).ready(function(){
  $("#myInput1").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable1 tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

	</script>

	
<?php
	include "./parts/btm_script.php";
?>

</body>

</html>
