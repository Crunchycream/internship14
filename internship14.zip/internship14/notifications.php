<?php session_start(); error_reporting( E_ALL ^ E_NOTICE );
	$_SESSION['intern_page_current'] = "notifications";
		include "./parts/main_logcheck.php"; ?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	
	<?php include "./parts/head_content.php"; ?>

</head>

<body> 
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">Notifications</h3>
					<div class="row">
						
							<!-- BASIC TABLE -->
				
							<!-- RECENT PURCHASES -->
						<div class="row">
							<div class="col-md-9">
							<h5 class="ss">Search:</h5>
							</div>
						
							
							<div class="col-md-3">
							<div class="form-group pull-right">
							<input type="text" id="myInput" value="" class="search form-control" placeholder="What you looking for">
							<!--	<span class="counter pull-right"><button type="button" class="btn btn-primary">Search</button></span>-->
								</div>
									<span class="counter pull-right"></span>
									</div>
						</div>
						<hr><br/>
							<div class="panel">
						
								<div class="table-responsive">
								
									
								</div>


								<div class="panel-body">
									<ul class="list-unstyled activity-list">
										<?php include "./data/connect.php";
											$curid = $_SESSION['intern_data_cun'];
											$curidtype = $_SESSION['intern_data_utype'];
											if ( trim($curid)!="" ) {
												//GET DATA
												$nn = 0;
												//                  0        1         2       3         4             5          6    7
												$sql = " select notif_id,date_added,user_id,user_type,location_id,location_type,title,content from tbl_notifications  where user_id='$curid'  order by date_added desc  limit 5 ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[2])!="" ) {
														$link = "";
														$cont = trim($dat[7]);
														//
														$name = "";
														$img = "";
														//
														$tsn = "class";
														if ( strtolower(trim($tsn)) == strtolower(trim($dat[5])) ) {
															$link = "./page_class.php?id=" . trim($dat[4]);
															//GET INFO
															//                  0      1     2            3         4
															$sql2 = " select class_id,name,date_created,prof_img,prof_backimg from tbl_class  where class_id='$dat[4]'  ";
															$qry2 = mysqli_query($conn,$sql2);
															while($dat2=mysqli_fetch_array($qry2)) {
																$name = trim($dat2[1]);
																$img = trim($dat2[4]);
															}
														}
														//
														$tsn = "hte";
														if ( strtolower(trim($tsn)) == strtolower(trim($dat[5])) ) {
															$link = "./page_hte.php?id=" . trim($dat[4]);
															//GET INFO
															//                  0      1   2
															$sql2 = " select hte_id,name,prof_backimg from tbl_hte  where hte_id='$dat[4]'  ";
															$qry2 = mysqli_query($conn,$sql2);
															while($dat2=mysqli_fetch_array($qry2)) {
																$name = trim($dat2[1]);
																$img = trim($dat2[2]);
															}
														}
														//
														if ( trim($img)=="" ) {
															$img = "./assets/img/notif_empty.png";
														}
														echo "
															<li>
																<a href='$link' class='notification-item'>
																<table>
																	<tr>
																		<td>
																			<img src='$img' class='msgnotif_img02' />
																		</td>
																		<td>
																			<span class='span02'>
																				<span class='msgnotif_ttl02'>$name</span>
																				<br/>
																				<span class='msgnotif_cont02'>$cont</span>
																			</span>
																		</td>
																	</tr>
																</table>
																</a>
															</li>
														";
														$nn = $nn + 1;
													}
												}
												if ( $nn <= 0 ) {
														echo "
															<li>
																<a href='' class='notification-item'>
																<span class='dot bg-warning'></span><span class='span02'>No notifications yet.</span>
																</a>
															</li>
														";
												}else{
													
												}
											}
										?>
									</ul>
									
								</div>

							
							</div>
					
							<!-- END TABLE NO PADDING -->
						
					</div>
					
					
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>

<script>
/*	
	$(document).ready(function() {
  $(".search").keyup(function () {
    var searchTerm = $(".search").val();
    var listItem = $('.results tbody').children('tr');
    var searchSplit = searchTerm.replace(/ /g, "'):containsi('")
    
  $.extend($.expr[':'], {'containsi': function(elem, i, match, array){
        return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
    }
  });
    
  $(".results tbody tr").not(":containsi('" + searchSplit + "')").each(function(e){
    $(this).attr('visible','false');
  });

  $(".results tbody tr:containsi('" + searchSplit + "')").each(function(e){
    $(this).attr('visible','true');
  });

  var jobCount = $('.results tbody tr[visible="true"]').length;
    $('.counter').text(jobCount + ' item');

  if(jobCount == '0') {$('.no-result').show();}
    else {$('.no-result').hide();}
		  });
});*/

$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

</script>


<?php
	include "./parts/btm_script.php";
?>

</body>

</html>
