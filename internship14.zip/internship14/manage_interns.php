<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./data/connect.php";
	$_SESSION['intern_page_current'] = "manage_interns";
		include "./parts/main_logcheck.php";
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	//
	if ( $_POST['btnsave'] ) {
		$studid = $_POST['studid'];
		$fname = $_POST['fname'];
		$mname = $_POST['mname'];
		$lname = $_POST['lname'];
		$gender = $_POST['gender'];
		$address = $_POST['address'];
		$course = $_POST['course'];
		$year = $_POST['year'];
		$contactno = $_POST['contactno'];
		$email = $_POST['email'];
		$nohrs = $_POST['nohrs'];
		$dstart = $_POST['dstart'];
		$dend = $_POST['dend'];
		$eval1 = "";
		$eval2 = "";
		$reqstats = "";
		$regstats = "";
		$errn = 0;
		$errmsg = "";
		if ( trim($studid)=="" ){
			$errn = $errn + 1;
			$errmsg = $errmsg . "Please enter Student ID. ";
		}
		$sql = " select * from tbl_interns where studentid='$studid' ";
		$qry = mysqli_query($conn,$sql);
		$scn = 0;
		while($dat=mysqli_fetch_array($qry)) {
			$scn = $scn + 1;
		}
		if ( $scn > 0 ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Invalid Student ID. ";
		}
		if ( trim($fname)=="" ){
			$errn = $errn + 1;
			$errmsg = $errmsg . "Please enter Firstname. ";
		}
		if ( trim($lname)=="" ){
			$errn = $errn + 1;
			$errmsg = $errmsg . "Please enter Lastname. ";
		}
		$sql = " select * from tbl_interns where firstname='$fname' and lastname='$lname' ";
		$qry = mysqli_query($conn,$sql);
		$scn = 0;
		while($dat=mysqli_fetch_array($qry)) {
			$scn = $scn + 1;
		}
		if ( $scn > 0 ) {
			$errn = $errn + 1;
			$errmsg = $errmsg . "Name already registered. ";
		}
		if ( trim($address)=="" ){
			//$errn = $errn + 1;
			//$errmsg = $errmsg . "Address required. ";
		}
		if ( trim($email)=="" ){
			//$errn = $errn + 1;
			//$errmsg = $errmsg . "Email required. ";
		}
		if ( trim($contactno)=="" ){
			//$errn = $errn + 1;
			//$errmsg = $errmsg . "Contact # required. ";
		}
		if ( $errn <= 0 ) {
			//SAVE
			$sql = " insert into tbl_interns 
						(studentid,firstname,middlename,lastname,address,gender,course,year,contact_no,email,no_hours,date_start,date_end,reg_status)
						values
						('$studid','$fname','$mname','$lname','$address','$gender','$course','$year','$contactno','$email','$nohrs','$dstart','$dend','$regstats')
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
		}
	}
	if ( $_POST['btnsaveRUpdateInfo'] ) {
		$studid = $_POST['studid'];
		$fname = $_POST['fname'];
		$mname = $_POST['mname'];
		$lname = $_POST['lname'];
		$gender = $_POST['gender'];
		$address = $_POST['address'];
		$course = $_POST['course'];
		$year = $_POST['year'];
		$contactno = $_POST['contactno'];
		$email = $_POST['email'];
		$nohrs = $_POST['nohrs'];
		$dstart = $_POST['dstart'];
		$dend = $_POST['dend'];
		$eval1 = "";
		$eval2 = "";
		$reqstats = "";
		$regstats = "";
		$errn = 0;
		$errmsg = "";
		if ( trim($studid)=="" ){
			//$errn = $errn + 1;
			//$errmsg = $errmsg . "Please enter Student ID. ";
		}
		$sql = " select * from tbl_interns where studentid='$studid' ";
		$qry = mysqli_query($conn,$sql);
		$scn = 0;
		while($dat=mysqli_fetch_array($qry)) {
			//$scn = $scn + 1;
		}
		if ( $scn > 0 ) {
			//$errn = $errn + 1;
			//$errmsg = $errmsg . "Invalid Student ID. ";
		}
		if ( trim($fname)=="" ){
			$errn = $errn + 1;
			$errmsg = $errmsg . "Please enter Firstname. ";
		}
		if ( trim($lname)=="" ){
			$errn = $errn + 1;
			$errmsg = $errmsg . "Please enter Lastname. ";
		}
		$sql = " select * from tbl_interns where firstname='$fname' and lastname='$lname' ";
		$qry = mysqli_query($conn,$sql);
		$scn = 0;
		while($dat=mysqli_fetch_array($qry)) {
			//$scn = $scn + 1;
		}
		if ( $scn > 0 ) {
			//$errn = $errn + 1;
			//$errmsg = $errmsg . "Name already registered. ";
		}
		if ( trim($address)=="" ){
			//$errn = $errn + 1;
			//$errmsg = $errmsg . "Address required. ";
		}
		if ( trim($email)=="" ){
			//$errn = $errn + 1;
			//$errmsg = $errmsg . "Email required. ";
		}
		if ( trim($contactno)=="" ){
			//$errn = $errn + 1;
			//$errmsg = $errmsg . "Contact # required. ";
		}
		if ( $errn <= 0 ) {
			//SAVE
			$sql = " update tbl_interns set 
						firstname='$fname',middlename='$mname',lastname='$lname',address='$address',gender='$gender',course='$course',year='$year',contact_no='$contactno',email='$email',no_hours='$nohrs',date_start='$dstart',date_end='$dend'  
						where studentid='$studid' 
					";
			$qry = mysqli_query($conn,$sql);
			//$_SESSION['intern_disp_err'] = "<span class='span01_success'>Successfully saved.</span>";
		}else{
			//$_SESSION['intern_disp_err'] = "<span class='span01_error'>$errmsg</span>";
				echo "
					<script>
						alert('$errmsg');
					</script>
				";
		}
	}
	if ( $_POST['btnsaveRegStats'] ) {
		$studid = $_POST['studid'];
		$regstats = $_POST['regstats'];
		//echo "<script>alert('$studid - $regstats');</script>";
		if ( trim($studid)!="" ) {
			$sql = " update tbl_interns set reg_status='$regstats'  where studentid='$studid' 
					";
			$qry = mysqli_query($conn,$sql);
		}
	}
	if ( $_POST['btnsaveRRemove'] ) {
		$studid = $_POST['studid'];
		//echo "<script>alert('$studid - $regstats');</script>";
		if ( trim($studid)!="" ) {
			$sql = " delete from tbl_interns where studentid='$studid' 
					";
			$qry = mysqli_query($conn,$sql);
		}
	}
	if ( $_POST['btnsaveRRate'] ) {
		$studid = $_POST['studid'];
		$rate = $_POST['irate'];
		//echo "<script>alert('$studid - $regstats');</script>";
		if ( trim($studid)!="" && trim($rate)!="" && strtolower(trim($logutype))!=strtolower(trim("student")) ) {
			$errn = 0;
			$sql = " select * from tbl_interns_evaluation where studentid='$studid' and evaluator_id='$logun' ";
			$qry = mysqli_query($conn,$sql);
			while($dat=mysqli_fetch_array($qry)) {
				$errn = $errn + 1;
			}
			$errn = 0;
			if ( $errn <= 0 ) {
				$sql = " insert into tbl_interns_evaluation 
							(studentid,evaluator_id,rate)
						values 
							('$studid','$logun','$rate') 
						";
				$qry = mysqli_query($conn,$sql);
			}
		}
	}
	if ( trim($logun)=="" || strtolower(trim($logutype))==strtolower(trim("student")) ) {
		exit;
	}
?>

<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

	<?php include "./parts/head_content.php"; ?>

</head>

<body> 
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">Interns/Students</h3>
					<div class="row">
						
							<!-- BASIC TABLE -->
				
							<!-- RECENT PURCHASES -->
						<div class="row">
							<div class="col-md-9">
							<h5 class="ss">Search:</h5>
							</div>
						
							
							<div class="col-md-3">
							<div class="form-group pull-right">
							<input type="text" id="myInput" value="" class="search form-control" placeholder="What you looking for">
							<!--	<span class="counter pull-right"><button type="button" class="btn btn-primary">Search</button></span>-->
								</div>
									<span class="counter pull-right"></span>
									</div>
						</div>
						<hr>
					<div class="row">

						<?php include "./parts/manage_interns_modal.php"; ?>

						<a href="" data-toggle="modal" data-target="#modalAddInterns" class="btn btn-success btn-md">+ ADD STUDENT</a>
					</div>
					<br/>


							<!-- TABBED CONTENT -->
							<div class="panel div_intern_minh01">
								<div class="custom-tabs-line tabs-line-bottom left-aligned">
									<ul class="nav" role="tablist">
										<?php
											$acttab = trim($_POST['acttab1']);
											$tsn = "reg";
											$cls = "";
											if ( trim($acttab)=="" || strtolower(trim($tsn))==strtolower(trim($acttab)) ) {
												$cls = "active";
											}
												echo "<li class='$cls'><a href='#tab-bottom-left1' role='tab' data-toggle='tab'>Registered</a></li>";
											$tsn = "unreg";
											$cls = "";
											if ( strtolower(trim($tsn))==strtolower(trim($acttab)) ) {
												$cls = "active";
											}
												echo "<li class='$cls'><a href='#tab-bottom-left2' role='tab' data-toggle='tab'>Unregistered</a></li>";
										?>
										
										
									</ul>
								</div>
								<div class="tab-content">
									<div 
										<?php
											$acttab = trim($_POST['acttab1']);
											$tsn = "reg";
											$cls = "tab-pane fade in";
											if ( trim($acttab)=="" || strtolower(trim($tsn))==strtolower(trim($acttab)) ) {
												$cls = "tab-pane fade in active";
											}
											echo " class='$cls' ";
										?>
									id="tab-bottom-left1">

								<div class="table-responsive">
								
									<table class="table table-hover results">
										<thead>
											<tr>
												<th></th>
												<th>Student ID</th>
												<th>Student's Name</th>
												<th>Course</th>
												<th>Year</th>
												<th># of Hours</th>
												<th>Date Started</th>
												<th>Date Ended</th>
												<th>Mobile #</th>
												<th>Email Add</th>
												<th>Evalutaion Result</th>
											</tr>
											<tr class="warning no-result">
      											<td><i class="fa fa-warning"></i> No result</td>
   											</tr>
										</thead>
										<tbody id="myTable">
											<?php
												include "./data/connect.php";
												$genderopt = "";
												$crsopt = "";
												$yropt = "";
												$rateopt = "";
													$sql = " select no,gender from tbl_gender ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($dat[1]) != '' ) {
															$genderopt = $genderopt . "<option value='".trim($dat[1])."'>".trim($dat[1])."</option>";
														}
													}
													$sql = " select course_id,course from tbl_course ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($dat[1]) != '' ) {
															$crsopt = $crsopt . "<option value='".trim($dat[0])."'>".trim($dat[1])."</option>";
														}
													}
													$sql = " select year_id,year from tbl_year ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($dat[1]) != '' ) {
															$yropt = $yropt . "<option value='".trim($dat[1])."'>".trim($dat[1])."</option>";
														}
													}
													//LOAD RATINGS
													$sql = " select rate from tbl_rate_score order by rate asc ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($dat[0])!="" ) {
															$rateopt = $rateopt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
														}
													}
												//
												//
												$nn = 0;
												//                    0     1          2          3      4      5        6      7     8    9        10         11       12           13   14     15       16
												$sql = " select studentid,firstname,middlename,lastname,email,address,gender,course,year,no_hours,date_start,date_end,contact_no,eval_1,eval_2,req_status,no from tbl_interns  where reg_status='registered'  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$nn = $nn + 1;
													//
													$crsid = trim($dat[7]);
													$crsname = "";
													//
													$urs = trim($dat[15]);
													$fstat = "";
													$tsn = "";
													$tsn = "completed";
													if ( strtolower(trim($urs)) == strtolower(trim($tsn)) ) {
														$fstat = "<span class='label label-success'>COMPLETED</span>";
													}
													$tsn = "pending";
													if ( strtolower(trim($urs)) == strtolower(trim($tsn)) ) {
														$fstat = "<span class='label label-warning'>PENDING</span>";
													}
													$tsn = "dropped";
													if ( strtolower(trim($urs)) == strtolower(trim($tsn)) ) {
														$fstat = "<span class='label label-danger'>DROPPED</span>";
													}
														//GET EVAL. RATE
														$evalrate = "-";
														$sql2 = " select rate from tbl_interns_evaluation where studentid='$dat[0]' order by no desc limit 1 ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															if ( trim($dat2[0])!="" ) {
																$evalrate = trim($dat2[0]);
															}
														}

														//GET CRS NAME
														$sql2 = " select course_id,course from tbl_course where course_id='$crsid' ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															$crsname = trim($dat2[1]);
														}
														//
														//
														$crsopt = "";
														$sql2 = " select course_id,course from tbl_course ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															if ( trim($dat2[1]) != '' ) {
																$isel = "";
																if ( strtolower(trim($crsid))==strtolower(trim($dat2[0])) ) {
																	$isel = " selected='true' ";
																}
																$crsopt = $crsopt . "<option value='".trim($dat2[0])."' $isel>".trim($dat2[1])."</option>";
															}
														}

													echo "
														<tr>
															<td>

																<div class='dropdown'>
																  <a class='btn_action_01' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu'>
																    <li><a href='#' data-toggle='modal' data-target='#modalRChangeInfo_$nn'>Edit Info</a></li>
																    <li><a href='#' data-toggle='modal' data-target='#modalRChangeRegStat_$nn'>Edit Reg. Status</a></li>
																    <li><a href='#' data-toggle='modal' data-target='#modalRChangeDeleteIntern_$nn'>Delete</a></li>
																    <li class='divider'></li>
																    <li><a href='#' data-toggle='modal' data-target='#modalRChangeEvaluate_$nn'>Evaluate</a></li>
																  </ul>
																</div>

																<div id='modalRChangeInfo_$nn' class='modal fade' role='dialog'>
																	<div class='modal-dialog'>
																	<!-- Modal content-->
																	<div class='modal-content'>
																	<div class='modal-header'>
																		<button type='button' class='close' data-dismiss='modal'>&times;</button>
																		<h4 class='modal-title'>Update Intern</h4>
																	</div>
																			<form method='post' action=''>
																				<input type='hidden' name='acttab1' value='reg' />
																	<div class='modal-body'>
																		<p>
																			<input type='hidden' name='studid' value='".trim($dat[0])."' />
																			<div class='form-group div01'>
																				<table>
																					<tr>
																						<td class='td01'>
																							<label for='stud-add-fn' class='control-label sr-only'>Firstname</label>
																							<input type='text' name='fname' class='form-control txt01' id='stud-add-fn' placeholder='Firstname' 
																								value='".trim($dat[1])."' 
																							>
																						</td>
																						<td class='td01'>
																							<label for='stud-add-mn' class='control-label sr-only'>Middlename</label>
																							<input type='text' name='mname' class='form-control txt01' id='stud-add-mn' placeholder='Middlename' 
																								value='".trim($dat[2])."' 
																							>
																						</td>
																						<td class='td01'>
																							<label for='stud-add-ln' class='control-label sr-only'>Lastname</label>
																							<input type='text' name='lname' class='form-control txt01' id='stud-add-ln' placeholder='Lastname' 
																								value='".trim($dat[3])."' 
																							>
																						</td>
																					</tr>
																				</table>
																				
																			</div>
																			<div class='div01'>
																				<table>
																					<tr>
																						<td class='td01'>
																							<select class='form-control txt01' name='gender'>
																								$genderopt
																							</select>
																						</td>
																					</tr>
																				</table>
																			</div>
																			<div class='form-group div01'>
																				<label for='stud-add-address' class='control-label sr-only'>Address</label>
																				<input type='text' name='address' class='form-control txt01' id='stud-add-address' placeholder='Address' 
																					value='".trim($dat[5])."' 
																				>
																			</div>
																			<div class='div01'>
																				<table>
																					<tr>
																						<td class='td01'>
																							<select class='form-control txt01' name='course'>
																								$crsopt
																							</select>
																						</td>
																						<td class='td01'>
																							<select class='form-control txt01' name='year'>
																								$yropt
																							</select>
																						</td>
																					</tr>
																				</table>
																			</div>
																			<table>
																				<tr>
																					<td class='td01'>
																						<div class='form-group'>
																							<label for='stud-add-contactno' class='control-label sr-only'>Contact #</label>
																							<input type='text' name='contactno' class='form-control txt01' id='stud-add-contactno' placeholder='Contact #' 
																								value='".trim($dat[12])."' 
																							>
																						</div>
																					</td>
																					<td class='td01'>
																						<div class='form-group'>
																							<label for='stud-add-email' class='control-label sr-only'>E-mail</label>
																							<input type='text' name='email' class='form-control txt01' id='stud-add-email' placeholder='E-mail' 
																								value='".trim($dat[4])."' 
																							>
																						</div>
																					</td>
																				</tr>
																			</table>
																			<div class='form-group'>
																				<label for='stud-add-nohrs' class='control-label sr-only'># of Hours</label>
																				<input type='text' name='nohrs' class='form-control txt01' id='stud-add-nohrs' placeholder='# of Hours' 
																					value='".trim($dat[9])."' 
																				>
																			</div>
																			<table>
																				<tr>
																					<td class='td01'>
																						<div class='form-group'>
																							Date Started
																							<label for='stud-add-dstart' class='control-label sr-only'>Date Started</label>
																							<input type='date' name='dstart' class='form-control txt01' id='stud-add-dstart' placeholder='Date Started' 
																								value='".trim($dat[10])."' 
																							>
																						</div>
																					</td>
																					<td class='td01'>
																						<div class='form-group'>
																							Date Ended
																							<label for='stud-add-dend' class='control-label sr-only'>Date Ended</label>
																							<input type='date' name='dend' class='form-control txt01' id='stud-add-dend' placeholder='Date Ended' 
																								value='".trim($dat[11])."' 
																							>
																						</div>
																					</td>
																				</tr>
																			</table>
																		</p>
																	</div>
																	<div class='modal-footer'>
																		<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																		<input type='submit' name='btnsaveRUpdateInfo' class='btn btn-primary btn-lg btn01' value='SAVE'>
																	</div>
																			</form>
																	</div>

																	</div>
																</div>

																<div id='modalRChangeRegStat_$nn' class='modal fade' role='dialog'>
																	<div class='modal-dialog'>
																	<!-- Modal content-->
																	<div class='modal-content'>
																	<div class='modal-header'>
																		<button type='button' class='close' data-dismiss='modal'>&times;</button>
																		<h4 class='modal-title'>Update Intern</h4>
																	</div>
																			<form method='post' action=''>
																				<input type='hidden' name='acttab1' value='reg' />
																	<div class='modal-body'>
																		<p>
																			<div class='form-group'>
																			</div>
																			<input type='hidden' name='studid' value='".trim($dat[0])."' />
																			<div class='form-group div01'>
																				<select class='form-control txt01' name='regstats'>
																					<option value='Registered'>Registered</option>
																					<option value='Unregistered'>Unregistered</option>
																				</select>
																			</div>
																				
																		</p>
																	</div>
																	<div class='modal-footer'>
																		<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																		<input type='submit' name='btnsaveRegStats' class='btn btn-primary btn-lg btn01' value='SAVE'>
																	</div>
																			</form>
																	</div>

																	</div>
																</div>

																<div id='modalRChangeDeleteIntern_$nn' class='modal fade' role='dialog'>
																	<div class='modal-dialog'>
																	<!-- Modal content-->
																	<div class='modal-content'>
																	<div class='modal-header'>
																		<button type='button' class='close' data-dismiss='modal'>&times;</button>
																		<h4 class='modal-title'>Update Intern</h4>
																	</div>
																			<form method='post' action=''>
																				<input type='hidden' name='acttab1' value='reg' />
																	<div class='modal-body'>
																		<p>
																			Remove intern?
																			<input type='hidden' name='studid' value='".trim($dat[0])."' />
																				
																		</p>
																	</div>
																	<div class='modal-footer'>
																		<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																		<input type='submit' name='btnsaveRRemove' class='btn btn-primary btn-lg btn01' value='REMOVE'>
																	</div>
																			</form>
																	</div>

																	</div>
																</div>

																<div id='modalRChangeEvaluate_$nn' class='modal fade' role='dialog'>
																	<div class='modal-dialog'>
																	<!-- Modal content-->
																	<div class='modal-content'>
																	<div class='modal-header'>
																		<button type='button' class='close' data-dismiss='modal'>&times;</button>
																		<h4 class='modal-title'>Evaluate Intern</h4>
																	</div>
																			<form method='post' action=''>
																				<input type='hidden' name='acttab1' value='reg' />
																	<div class='modal-body'>
																		<p>
																			<div class='form-group'>
																			</div>
																			<input type='hidden' name='studid' value='".trim($dat[0])."' />
																			<div class='form-group div01'>
																				<select class='form-control txt01' name='irate'>
																					$rateopt
																				</select>
																			</div>
																				
																		</p>
																	</div>
																	<div class='modal-footer'>
																		<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																		<input type='submit' name='btnsaveRRate' class='btn btn-primary btn-lg btn01' value='SAVE'>
																	</div>
																			</form>
																	</div>

																	</div>
																</div>

															</td>
															<td>
																".trim($dat[0])."
															</td>
															<td>
																<a href='page_profile.php?id=".trim($dat[0])."'>
																<span class='span02'>".trim($dat[1])." ".trim($dat[2])." ".trim($dat[3])."</span>
																</a>
															</td>
															<td>
																".trim($crsname)."
															</td>
															<td>
																".trim($dat[8])."
															</td>
															<td>
																".trim($dat[9])."
															</td>
															<td>
																".trim($dat[10])."
															</td>
															<td>
																".trim($dat[11])."
															</td>
															<td>
																".trim($dat[12])."
															</td>
															<td>
																".trim($dat[4])."
															</td>
															<td>
																".trim($evalrate)."
															</td>
														</tr>
													";
												}
											?>
											
											
										</tbody>
									</table>
								</div>
							
									</div>
									<div 
										<?php
											$acttab = trim($_POST['acttab1']);
											$tsn = "unreg";
											$cls = "tab-pane fade";
											if ( strtolower(trim($tsn))==strtolower(trim($acttab)) ) {
												$cls = "tab-pane fade in active";
											}
											echo " class='$cls' ";
										?>
									 id="tab-bottom-left2">

								<div class="table-responsive">
								<!-- ============== UNREG ======================== -->
									<table class="table table-hover results">
										<thead>
											<tr>
												<th>Action</th>
												<th>Student ID</th>
												<th>Student's Name</th>
												<th>Course</th>
												<th>Year</th>
												<th>Mobile #</th>
												<th>Email Add</th>
												<th>Registration Status</th>
											</tr>
											<tr class="warning no-result">
      											<td><i class="fa fa-warning"></i> No result</td>
   											</tr>
										</thead>
										<tbody id="myTable">
											<?php
												include "./data/connect.php";
												$genderopt = "";
												$crsopt = "";
												$yropt = "";
												$rateopt = "";
													$sql = ' select no,gender from tbl_gender ';
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($dat[1]) != '' ) {
															$genderopt = $genderopt . "<option value='".trim($dat[1])."'>".trim($dat[1])."</option>";
														}
													}
													$sql = ' select course_id,course from tbl_course ';
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($dat[1]) != '' ) {
															$crsopt = $crsopt . "<option value='".trim($dat[1])."'>".trim($dat[1])."</option>";
														}
													}
													$sql = ' select year_id,year from tbl_year ';
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($dat[1]) != '' ) {
															$yropt = $yropt . "<option value='".trim($dat[1])."'>".trim($dat[1])."</option>";
														}
													}
													//LOAD RATINGS
													$sql = " select rate from tbl_rate_score order by rate asc ";
													$qry = mysqli_query($conn,$sql);
													while($dat=mysqli_fetch_array($qry)) {
														if ( trim($dat[0])!="" ) {
															$rateopt = $rateopt . "<option value='".trim($dat[0])."'>".trim($dat[0])."</option>";
														}
													}
												$nn = 0;
														//         0         1         2          3       4     5       6      7     8     9       10         11        12         13      14     15      16   17
												$sql = " select studentid,firstname,middlename,lastname,email,address,gender,course,year,no_hours,date_start,date_end,contact_no,eval_1,eval_2,req_status,no,reg_status from tbl_interns  where reg_status<>'registered'  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$nn = $nn + 1;
													//
													$crsid = trim($dat[7]);
													$crsname = "";
													//
													$urs = trim($dat[17]);
													if ( trim($urs)=="" ) {
														$urs = "Unregistered";
													}
													$fstat = "";
													$tsn = "";
													$tsn = "registered";
													if ( strtolower(trim($urs)) == strtolower(trim($tsn)) ) {
														$fstat = "<span class='label label-success'>REGISTERED</span>";
													}
													$tsn = "pending";
													if ( strtolower(trim($urs)) == strtolower(trim($tsn)) ) {
														$fstat = "<span class='label label-warning'>PENDING</span>";
													}
													$tsn = "unregistered";
													if ( strtolower(trim($urs)) == strtolower(trim($tsn)) ) {
														$fstat = "<span class='label label-danger'>UNREGISTERED</span>";
													}

														//GET CRS NAME
														$sql2 = " select course_id,course from tbl_course where course_id='$crsid' ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															$crsname = trim($dat2[1]);
														}
														//
														//
														$crsopt = "";
														$sql2 = " select course_id,course from tbl_course ";
														$qry2 = mysqli_query($conn,$sql2);
														while($dat2=mysqli_fetch_array($qry2)) {
															if ( trim($dat2[1]) != '' ) {
																$isel = "";
																if ( strtolower(trim($crsid))==strtolower(trim($dat2[0])) ) {
																	$isel = " selected='true' ";
																}
																$crsopt = $crsopt . "<option value='".trim($dat2[0])."' $isel>".trim($dat2[1])."</option>";
															}
														}

													echo "
														<tr>
															<td>
																
																<div class='dropdown'>
																  <a class='btn_action_01' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																  <ul class='dropdown-menu'>
																    <li><a href='#' data-toggle='modal' data-target='#modalURChangeInfo_$nn'>Edit Info</a></li>
																    <li><a href='#' data-toggle='modal' data-target='#modalURChangeRegStat_$nn'>Edit Reg. Status</a></li>
																    <li><a href='#' data-toggle='modal' data-target='#modalURChangeDeleteIntern_$nn'>Delete</a></li>
																  </ul>
																</div>

																<div id='modalURChangeInfo_$nn' class='modal fade' role='dialog'>
																	<div class='modal-dialog'>
																	<!-- Modal content-->
																	<div class='modal-content'>
																	<div class='modal-header'>
																		<button type='button' class='close' data-dismiss='modal'>&times;</button>
																		<h4 class='modal-title'>Update Intern</h4>
																	</div>
																			<form method='post' action=''>
																				<input type='hidden' name='acttab1' value='unreg' />
																	<div class='modal-body'>
																		<p>
																			<input type='hidden' name='studid' value='".trim($dat[0])."' />
																			<div class='form-group div01'>
																				<table>
																					<tr>
																						<td class='td01'>
																							<label for='stud-add-fn' class='control-label sr-only'>Firstname</label>
																							<input type='text' name='fname' class='form-control txt01' id='stud-add-fn' placeholder='Firstname' 
																								value='".trim($dat[1])."' 
																							>
																						</td>
																						<td class='td01'>
																							<label for='stud-add-mn' class='control-label sr-only'>Middlename</label>
																							<input type='text' name='mname' class='form-control txt01' id='stud-add-mn' placeholder='Middlename' 
																								value='".trim($dat[2])."' 
																							>
																						</td>
																						<td class='td01'>
																							<label for='stud-add-ln' class='control-label sr-only'>Lastname</label>
																							<input type='text' name='lname' class='form-control txt01' id='stud-add-ln' placeholder='Lastname' 
																								value='".trim($dat[3])."' 
																							>
																						</td>
																					</tr>
																				</table>
																				
																			</div>
																			<div class='div01'>
																				<table>
																					<tr>
																						<td class='td01'>
																							<select class='form-control txt01' name='gender'>
																								$genderopt
																							</select>
																						</td>
																					</tr>
																				</table>
																			</div>
																			<div class='form-group div01'>
																				<label for='stud-add-address' class='control-label sr-only'>Address</label>
																				<input type='text' name='address' class='form-control txt01' id='stud-add-address' placeholder='Address' 
																					value='".trim($dat[5])."' 
																				>
																			</div>
																			<div class='div01'>
																				<table>
																					<tr>
																						<td class='td01'>
																							<select class='form-control txt01' name='course'>
																								$crsopt
																							</select>
																						</td>
																						<td class='td01'>
																							<select class='form-control txt01' name='year'>
																								$yropt
																							</select>
																						</td>
																					</tr>
																				</table>
																			</div>
																			<table>
																				<tr>
																					<td class='td01'>
																						<div class='form-group'>
																							<label for='stud-add-contactno' class='control-label sr-only'>Contact #</label>
																							<input type='text' name='contactno' class='form-control txt01' id='stud-add-contactno' placeholder='Contact #' 
																								value='".trim($dat[12])."' 
																							>
																						</div>
																					</td>
																					<td class='td01'>
																						<div class='form-group'>
																							<label for='stud-add-email' class='control-label sr-only'>E-mail</label>
																							<input type='text' name='email' class='form-control txt01' id='stud-add-email' placeholder='E-mail' 
																								value='".trim($dat[4])."' 
																							>
																						</div>
																					</td>
																				</tr>
																			</table>
																			<div class='form-group'>
																				<label for='stud-add-nohrs' class='control-label sr-only'># of Hours</label>
																				<input type='text' name='nohrs' class='form-control txt01' id='stud-add-nohrs' placeholder='# of Hours' 
																					value='".trim($dat[9])."' 
																				>
																			</div>
																			<table>
																				<tr>
																					<td class='td01'>
																						<div class='form-group'>
																							Date Started
																							<label for='stud-add-dstart' class='control-label sr-only'>Date Started</label>
																							<input type='date' name='dstart' class='form-control txt01' id='stud-add-dstart' placeholder='Date Started' 
																								value='".trim($dat[10])."' 
																							>
																						</div>
																					</td>
																					<td class='td01'>
																						<div class='form-group'>
																							Date Ended
																							<label for='stud-add-dend' class='control-label sr-only'>Date Ended</label>
																							<input type='date' name='dend' class='form-control txt01' id='stud-add-dend' placeholder='Date Ended' 
																								value='".trim($dat[11])."' 
																							>
																						</div>
																					</td>
																				</tr>
																			</table>
																		</p>
																	</div>
																	<div class='modal-footer'>
																		<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																		<input type='submit' name='btnsaveRUpdateInfo' class='btn btn-primary btn-lg btn01' value='SAVE'>
																	</div>
																			</form>
																	</div>

																	</div>
																</div>

																<div id='modalURChangeRegStat_$nn' class='modal fade' role='dialog'>
																	<div class='modal-dialog'>
																	<!-- Modal content-->
																	<div class='modal-content'>
																	<div class='modal-header'>
																		<button type='button' class='close' data-dismiss='modal'>&times;</button>
																		<h4 class='modal-title'>Update Intern</h4>
																	</div>
																			<form method='post' action=''>
																				<input type='hidden' name='acttab1' value='unreg' />
																	<div class='modal-body'>
																		<p>
																			<div class='form-group'>
																			</div>
																			<input type='hidden' name='studid' value='".trim($dat[0])."' />
																			<div class='form-group div01'>
																				<select class='form-control txt01' name='regstats'>
																					<option value='Registered'>Registered</option>
																					<option value='Unregistered'>Unregistered</option>
																				</select>
																			</div>
																				
																		</p>
																	</div>
																	<div class='modal-footer'>
																		<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																		<input type='submit' name='btnsaveRegStats' class='btn btn-primary btn-lg btn01' value='SAVE'>
																	</div>
																			</form>
																	</div>

																	</div>
																</div>

																<div id='modalURChangeDeleteIntern_$nn' class='modal fade' role='dialog'>
																	<div class='modal-dialog'>
																	<!-- Modal content-->
																	<div class='modal-content'>
																	<div class='modal-header'>
																		<button type='button' class='close' data-dismiss='modal'>&times;</button>
																		<h4 class='modal-title'>Update Intern</h4>
																	</div>
																			<form method='post' action=''>
																				<input type='hidden' name='acttab1' value='unreg' />
																	<div class='modal-body'>
																		<p>
																			Remove intern?
																			<input type='hidden' name='studid' value='".trim($dat[0])."' />
																				
																		</p>
																	</div>
																	<div class='modal-footer'>
																		<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																		<input type='submit' name='btnsaveRRemove' class='btn btn-primary btn-lg btn01' value='REMOVE'>
																	</div>
																			</form>
																	</div>

																	</div>
																</div>

															</td>
															<td>
																".trim($dat[0])."
															</td>
															<td>
																
																<span class='span02'>".trim($dat[1])." ".trim($dat[2])." ".trim($dat[3])."</span>
																
															</td>
															<td>
																".trim($crsname)."
															</td>
															<td>
																".trim($dat[8])."
															</td>
															<td>
																".trim($dat[12])."
															</td>
															<td>
																".trim($dat[4])."
															</td>
															<td>
																$fstat
															</td>
														</tr>
													";
												}
											?>
											
											
										</tbody>
									</table>
								</div>
							
									</div>
								</div>
							</div>
							<!-- END TABBED CONTENT -->


							<div class="panel">
						
							</div>
					
							<!-- END TABLE NO PADDING -->
						
					</div>
					
					
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>

<script>
/*	
	$(document).ready(function() {
  $(".search").keyup(function () {
    var searchTerm = $(".search").val();
    var listItem = $('.results tbody').children('tr');
    var searchSplit = searchTerm.replace(/ /g, "'):containsi('")
    
  $.extend($.expr[':'], {'containsi': function(elem, i, match, array){
        return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
    }
  });
    
  $(".results tbody tr").not(":containsi('" + searchSplit + "')").each(function(e){
    $(this).attr('visible','false');
  });

  $(".results tbody tr:containsi('" + searchSplit + "')").each(function(e){
    $(this).attr('visible','true');
  });

  var jobCount = $('.results tbody tr[visible="true"]').length;
    $('.counter').text(jobCount + ' item');

  if(jobCount == '0') {$('.no-result').show();}
    else {$('.no-result').hide();}
		  });
});*/

$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

</script>



<?php
	include "./parts/btm_script.php";
?>


</body>

</html>
