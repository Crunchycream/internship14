<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); include "./parts/sys_functions.php";
	//
	$logun = $_SESSION['intern_data_cun'];
	$logutype = $_SESSION['intern_data_utype'];
	//
	$paid = trim($_GET['aid']);
	$patype = trim($_GET['atype']);
	//
	$_SESSION['intern_page_current'] = "page_announcement";
	$_SESSION['intern_page_current2'] = "page_announcement_".$patype."_".$paid;
		include "./parts/main_logcheck.php";
		include "./parts/page_announcement_upload.php";
	//
	if ( trim($logun)=="" ) {
		exit;
	}
?>
<!doctype html>
<html lang="en">

<head>
	<title>UMDC Internship Management System</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	
	<?php include "./parts/head_content.php"; ?>

	<script type="text/javascript">
		setInterval('my_function();',5000);
	    function my_function(){
	      $('#up_new_jobpost').load(location.href + ' #up_new_jobpost_s');
	    }

	    function detectScrollbar()
		{
			if (navigator.appName == "Microsoft Internet Explorer")
			{
				window.name=document.body.scrollTop;
			}
			else
			{
				window.name=window.pageYOffset;
			}
		}

		function doScroll()
		{
			if (window.name) window.scrollTo(0, window.name);
		}
	</script>

</head>

<body onload="doScroll()" onunload="window.name=document.body.scrollTop" >
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<?php include "./parts/top_nav.php"; ?>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<?php include "./parts/side_left_nav.php"; ?>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
	<?php //include "./parts/page_announcement_modal.php"; ?>
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-8">
							<!-- LEFT COLUMN -->
							<div class="profleft01" align="center">
								
								<?php include "./data/connect.php";
									//
									$logun =  $_SESSION['intern_data_cun'];
									$loguntype = $_SESSION['intern_data_utype'];
									//
									//
									$id = $_GET['aid'];
									$idtype = $_GET['atype'];
									//
									echo "<ul class='ul01'>";
									//
									//LOAD AVAILABLE
									$nn = 0;
									$nid = "";
									//                      0         1      2       3      4      5      6      7    8
									$sql = " select announcement_id,ann_id,ann_type,by_id,by_type,pdate,subject,msg,cfile from tbl_announcement  where ann_id='$id' and ann_type='$idtype'  order by announcement_id desc ";
									$qry = mysqli_query($conn,$sql);
									while($dat=mysqli_fetch_array($qry)) {
										if ( trim($dat[7])!=="" || trim($dat[8])!="" ) {
											$nn = $nn + 1;
											//
											$nid = trim($dat[0]);
											//
											//FILE
											$pfile = "";
											$fln = trim($dat[8]);
											//
											$dfn = "File";
											$dfnx = "";
											//
											//
											if ( trim($fln)!="" ) {
												$dfnx = "." . trim(pathinfo($fln,PATHINFO_EXTENSION));
												if ( trim($dat[6])=="" ) {
													$dfn = "File";
												}else{
													$dfn = trim($dat[6]);
												}
												//
												if (  pathinfo($fln,PATHINFO_EXTENSION)=="jpg" ||
													  pathinfo($fln,PATHINFO_EXTENSION)=="png" ||
													  pathinfo($fln,PATHINFO_EXTENSION)=="gif" ||
													  pathinfo($fln,PATHINFO_EXTENSION)=="bmp" ||
													  pathinfo($fln,PATHINFO_EXTENSION)=="ico"
													) {
													$pfile = "<p align='center'>
																	<a href='#' class='ann_lnkprev01' data-toggle='modal' data-target='#modalPrevImage_$nn'>
																<img class='ann_img01' src='".trim($dat[8])."'/>
																	</a>
																<div id='modalPrevImage_$nn' class='modal fade' role='dialog' align='center'>
																	<img class='ann_img02' src='".trim($dat[8])."'/>
																</div>
															  </p>";
												}else{
													$pfile = "<p align='left'><a href='".trim($dat[8])."' target='_blank'>".trim($dfn).trim($dfnx)."</a></p>";
												}
											}
											//
											$memid = "";
											$memname = "";
											$img = "";
											$link = "";
											//GET MEMBER NAME
											if ( strtolower(trim($dat[4]))==strtolower(trim("student")) ) {
												$sql1 = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns  where studentid='$dat[3]'  ";
												$qry1 = mysqli_query($conn,$sql1);
												while($dat1=mysqli_fetch_array($qry1)) {
													if ( trim($dat1[0]) != "" ) {
														$mname = "";
														if ( trim($dat1[2])!="" ) {
															$mname = " " . trim($dat1[2]);
														}
														$memid = trim($dat1[0]);
														$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
														//
														$img = trim($dat1[4]);
														//
														$link = "./page_profile.php?id=".trim($dat1[0]);
													}
												}
											}
											if ( strtolower(trim($dat[4]))==strtolower(trim("employee")) ) {
												$sql1 = " select employee_id,firstname,middlename,lastname,prof_img from tbl_employee  where employee_id='$dat[3]'  ";
												$qry1 = mysqli_query($conn,$sql1);
												while($dat1=mysqli_fetch_array($qry1)) {
													if ( trim($dat1[0]) != "" ) {
														$mname = "";
														if ( trim($dat1[2])!="" ) {
															$mname = " " . trim($dat1[2]);
														}
														$memid = trim($dat1[0]);
														$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
														//
														$img = trim($dat1[4]);
														//
														$link = "./page_profile_employee.php?id=".trim($dat1[0]);
													}
												}
											}
											if ( strtolower(trim($dat[4]))==strtolower(trim("admin")) ) {
												$memid = "Admin";
												$memname = "Admin";
												$img = "";
												//
												$link = "#";
											}
											//
											if ( trim($img)=="" ) {
												$img = "./assets/img/empty_user.png";
											}
											//
											//
											$frmedit = "";
											$ern = 0;
											//
											if ( trim($logun)=="" ) {
												$ern += 1;
											}
											if ( strtolower(trim($loguntype))==strtolower(trim("student")) ) {
												$ern += 1;
											}
											if ( strtolower(trim($loguntype))==strtolower(trim("coordinator")) ||
												 strtolower(trim($loguntype))==strtolower(trim("employee")) ) {
												if ( strtolower(trim($loguntype))!=strtolower(trim($dat[3])) && strtolower(trim($logun))!=strtolower(trim($dat[4])) ) {
													$ern += 1;
												}
											}
											//
											if ( $ern <= 0 ) {
												$frmedit = "

																			<div class='dropdown'>
																			  <a class='btn_action_01' href='' data-toggle='dropdown'>&bullet;&bullet;&bullet;</a>
																			  <ul class='dropdown-menu'>
																			    <li><a href='#' data-toggle='modal' data-target='#modalEdit_$nid'>Edit</a></li>
																			    <li><a href='#' data-toggle='modal' data-target='#modalDelete_$nid'>Delete</a></li>
																			  </ul>
																			</div>

																			    <div id='modalEdit_$nid' class='modal fade' role='dialog'>
																			      <div class='modal-dialog'>
																			      <!-- Modal content-->
																			      <div class='modal-content'>
																			      <div class='modal-header' align='left'>
																			        <button type='button' class='close' data-dismiss='modal'>&times;</button>
																			        <h4 class='modal-title'>Update</h4>
																			      </div>
																			          <form method='post' action='' enctype='multipart/form-data'>
																			      <div class='modal-body' align='left'>
																			        <p align='left'>
																								<input type='hidden' name='txtid' value='$dat[0]'/>

																						<div class='form-group div01'>
																							<label for='subject' class='control-label sr-only'>Subject</label>
																							<input type='text' name='txtsubject' class='form-control txt01' id='subject' placeholder='Subject'
																								 value='$dat[6]' 
																							>
																						</div>
																						<div class='form-group div01'>
																							<label for='msg' class='control-label sr-only'>Message</label>
																							<textarea name='txtmsg' class='form-control txta01' id='msg' placeholder='Message'>$dat[7]</textarea>
																						</div>
																						<div class='form-group div01'>
																							Attach file:
																							<label for='fileUP' class='control-label sr-only'>Attach File</label>
																							<input type='file' name='fileUP' id='fileUP' placeholder='Attach File'>
																						</div>

																			        </p>
																			      </div>
																			      <div class='modal-footer'>
																			        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																			        <input type='submit' name='btnsaveEdit' class='btn btn-primary btn-md btn01' value='SAVE'>
																			      </div>
																			          </form>
																			      </div>

																			      </div>
																			    </div>

																					<div id='modalDelete_$nid' class='modal fade' role='dialog'>
																						<div class='modal-dialog'>
																						<!-- Modal content-->
																						<div class='modal-content'>
																						<div class='modal-header' align='left'>
																							<button type='button' class='close' data-dismiss='modal'>&times;</button>
																							<h4 class='modal-title'>Delete</h4>
																						</div>
																								<form method='post' action='' enctype='multipart/form-data'>
																						<div class='modal-body' align='left'>
																							<p align='left'>
																								<input type='hidden' name='txtid' value='$dat[0]'/>
																								Delete announcement?
																							</p>
																						</div>
																						<div class='modal-footer'>
																							<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																							<input type='submit' name='btnsaveDelete' class='btn btn-primary btn-md btn01' value='DELETE'>
																						</div>
																								</form>
																						</div>

																						</div>
																					</div>

												";
											}
											//
											echo "
													<li>
														<div class='panel panel-default uldiv01' align='left'>
															<div class='uldiv01'>
																<table class='' width='100%'>
																	<tr>
																		<td class='ann_td01_1'>
																			<img src='$img' class='ann_img03' />
																		</td>
																		<td class='ann_td01_2'>
																			<div class='div_ann_name01'>
																				<a href='$link' class='ann_link01'>$memname</a>
																				<br/>
																				<span class='pst_date_01'>$dat[5]</span>
																			</div>
																		</td>
																		<td class='ann_td01_3'>
																			
																			$frmedit

																		</td>
																	</tr>
																</table>
																<hr class='hr02'/>
																<div class='div_ann_msg01'>
																	$dat[7]
																</div>
																<div class='div_ann_msg02'>
																	$pfile
																</div>
															</div>
														</div>
													</li>
											";
										}
									}
									//
									echo "</ul>";
									//
								?>
							</div>
							<!-- END LEFT COLUMN -->
						</div>
						<div class="col-md-4">
							<!-- RIGHT COLUMN -->
							<div class="panel ann_divr02">
								<div class="tab-content divclass03">
									<?php
										$curid = $_SESSION['intern_data_cun'];
										$curidtype = $_SESSION['intern_data_utype'];
										if ( strtolower(trim($curidtype))!=strtolower(trim("student")) && 
											 ( strtolower(trim($curid))!=strtolower(trim("admin")) && strtolower(trim($curidtype))!=strtolower(trim("admin")) )
											) {
											echo "<a href='' data-target='#modalAddAnnouncement' class='btn btn-success btn-sm btn-block' data-toggle='modal'><b>+ Create an Announcement</b></a> ";
											echo "<br/>";
											echo "<br/>";
											include "./parts/page_announcement_modal.php";
										}
									?>
								</div>
								<div class="custom-tabs-line tabs-line-bottom left-aligned divclass03">
									 <a href="#divMembers" class="linkclass01" data-toggle="collapse">MEMBERS 
									<span class="badge"><?php $id = $_GET['aid']; $idtype = $_GET['atype']; echo getMemberCount($id,$idtype); ?></span>
									</a>
								</div>

								<div class="tab-content divclass01">
									<div class="collapse divclass02 fade in active" id="divMembers">

										<div class="div_sep01"></div>

										<?php include "./data/connect.php";
											$id = $_GET['aid'];
											$idtype = $_GET['atype'];
											//LOAD AVAILABLE
											$nn = 0;
											$sql = " select coordinator_id,employee_id,course_id from tbl_coordinator  where course_id='$id' ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[1]) != "" ) {
													$nn = $nn + 1;
													if ( $nn > 1 ) {
														//echo "<br/>";
													}
													$memid = "";
													$memname = "";
													$img = "";
													//GET MEMBER NAME
													$sql1 = " select employee_id,firstname,middlename,lastname,prof_img from tbl_employee  where employee_id='$dat[1]' order by firstname asc ";
													$qry1 = mysqli_query($conn,$sql1);
													while($dat1=mysqli_fetch_array($qry1)) {
														if ( trim($dat1[0]) != "" ) {
															$mname = "";
															if ( trim($dat1[2])!="" ) {
																$mname = " " . trim($dat1[2]);
															}
															$memid = trim($dat1[0]);
															$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
															//
															$img = trim($dat1[4]);
														}
													}
													//
													if ( trim($img)=="" ) {
														$img = "./assets/img/empty_user.png";
													}
													//
													$nid = trim($dat[0]);
													//
													echo "

													<div class='dropdown divclasscont01'>
														<a href='#' data-toggle='dropdown'>
														<img src='$img' class='msgnotif_img03' />
														<span class='fontclasscont01 span02'>".trim($memname)."</span>
														</a>
														  <ul class='dropdown-menu'>
														    <li><a href='./page_profile_employee.php?id=".trim($dat[1])."'>Profile</a></li>
														    <li><a href='#' data-toggle='modal' data-target='#modalEmployeeSendMessage_$nid'>Send Message</a></li>
														  </ul>
													</div>

														<div id='modalEmployeeSendMessage_$nid' class='modal fade' role='dialog'>
															<div class='modal-dialog'>
															<!-- Modal content-->
															<div class='modal-content'>
															<div class='modal-header'>
																<button type='button' class='close' data-dismiss='modal'>&times;</button>
																<h4 class='modal-title'>Send Message to '<span class='span02'>".trim($memname)."</span>'</h4>
															</div>
																	<form action='' method='post'>
															<div class='modal-body'>
																<p>
																	<input type='hidden' name='txtstudid' value='$memid'/>
																	<input type='hidden' name='txtstudtype' value='employee'/>
																	<div class='form-group'>
																		
																	</div>
																	<div class='form-group div01'>
																		<label for='send-msg-msg' class='control-label sr-only'>Message</label>
																		<textarea name='msg' class='form-control txta01' id='send-msg-msg' placeholder='Message'></textarea>
																	</div>
																</p>
															</div>
															<div class='modal-footer'>
																<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																<input type='submit' class='btn btn-primary' value='Send' name='btnsaveSendMessage'>
															</div>
																	</form>
															</div>

															</div>
														</div>

													";
												}
											}
										?>

										<div class="div_sep01"></div>

										<?php include "./data/connect.php";
											$id = $_GET['aid'];
											$idtype = $_GET['atype'];
											//LOAD AVAILABLE
											$nn = 0;
											$sql = " select studentid,firstname,middlename,lastname,prof_img from tbl_interns  where course='$id' and reg_status='registered' order by firstname asc ";
											$qry = mysqli_query($conn,$sql);
											while($dat=mysqli_fetch_array($qry)) {
												if ( trim($dat[0]) != "" ) {
													$nn = $nn + 1;
													if ( $nn > 1 ) {
														//echo "<br/>";
													}
													$memid = "";
													$memname = "";
													$img = "";
													//
														$mname = "";
														if ( trim($dat[2])!="" ) {
															$mname = " " . trim($dat[2]);
														}
														$memid = trim($dat[0]);
														$memname = trim($dat[1]) . $mname . " " . trim($dat[3]);
														//
														$img = trim($dat[4]);
													//
													if ( trim($img)=="" ) {
														$img = "./assets/img/empty_user.png";
													}
													//
													$nid = trim($dat[0]);
													//
													echo "

													<div class='dropdown divclasscont01'>
														<a href='#' data-toggle='dropdown'>
														<img src='$img' class='msgnotif_img03' />
														<span class='fontclasscont01 span02'>".trim($memname)."</span>
														</a>
														  <ul class='dropdown-menu'>
														    <li><a href='./page_profile.php?id=".trim($dat[0])."'>Profile</a></li>
														    <li><a href='#' data-toggle='modal' data-target='#modalInternSendMessage_$nid'>Send Message</a></li>
														  </ul>
													</div>

														<div id='modalInternSendMessage_$nid' class='modal fade' role='dialog'>
															<div class='modal-dialog'>
															<!-- Modal content-->
															<div class='modal-content'>
															<div class='modal-header'>
																<button type='button' class='close' data-dismiss='modal'>&times;</button>
																<h4 class='modal-title'>Send Message to '<span class='span02'>".trim($memname)."</span>'</h4>
															</div>
																	<form action='' method='post'>
															<div class='modal-body'>
																<p>
																	<input type='hidden' name='txtstudid' value='$memid'/>
																	<input type='hidden' name='txtstudtype' value='student'/>
																	<div class='form-group'>
																		
																	</div>
																	<div class='form-group div01'>
																		<label for='send-msg-msg' class='control-label sr-only'>Message</label>
																		<textarea name='msg' class='form-control txta01' id='send-msg-msg' placeholder='Message'></textarea>
																	</div>
																</p>
															</div>
															<div class='modal-footer'>
																<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																<input type='submit' class='btn btn-primary' value='Send' name='btnsaveSendMessage'>
															</div>
																	</form>
															</div>

															</div>
														</div>

													";
												}
											}
										?>
									</div>
								</div>




								<div class="custom-tabs-line tabs-line-bottom left-aligned divclass03">
									 <a href="#divStaffs" class="linkclass01" data-toggle="collapse">STAFFS 
									<span class="badge"><?php 
										$id = $_GET['aid']; 
										$type = $_GET['atype']; 
										//
										$count = 0;
										//
										if ( strtolower(trim($type))==strtolower(trim("course")) ) {
											$count = 0;
											$count = getCountCOURSEStaffs2($id);
										}
										if ( strtolower(trim($type))==strtolower(trim("hte")) ) {
											$count = 0;
											$count = getCountHTEStaffs2($id);
										}
										//
										echo $count; 
										?>
									</span>
									</a>
								</div>
								<div class="tab-content divclass01">
									<div class="collapse divclass02 fade in active" id="divStaffs">
										<?php include "./data/connect.php";
											//
											$aid = $_GET['aid'];
											$atype = $_GET['atype'];
											//LOAD AVAILABLE
											//
											//
											$logun =  $_SESSION['intern_data_cun'];
											$logutype = $_SESSION['intern_data_utype'];
											//
											//
											$xqry = "";
											//
											if ( strtolower(trim($atype))==strtolower(trim("course")) ) {
												//                  0           1         2         3     4
												$sql = " select crs_staff_id,crs_id,staff_id,staff_type,position from tbl_crs_staff where crs_id<>'' and crs_id='$aid' and staff_id<>'' and staff_type='employee'  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($xqry)=="" ) {
														$xqry = " where employee_id<>'$dat[2]' ";
													}else{
														$xqry = $xqry . " and employee_id<>'$dat[2]' ";
													}
												}
												//
												//LOAD AVAIL. EMPLOYEE
												$staffs = "";
												//                  0     1         2         3    
												$sql = " select employee_id,lastname,firstname,middlename from tbl_employee $xqry  order by lastname asc ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$name = "";
													//
													$name = trim($dat[1]) . ", " . trim($dat[2]) . " " . trim($dat[3]);
													//
													$staffs = $staffs . "<option value='$dat[0]'>$name</option>";
												}
												//
												//
												if ( strtolower(trim($logutype))!=strtolower(trim("student")) ) {
													echo "
														<a href='#' class='btn btn-success btn-sm btn-block' data-toggle='modal' data-target='#modalAddStaff'>ADD STAFFS</a>

															<div id='modalAddStaff' class='modal fade' role='dialog'>
																<div class='modal-dialog'>
																<!-- Modal content-->
																<div class='modal-content'>
																<div class='modal-header'>
																	<button type='button' class='close' data-dismiss='modal'>&times;</button>
																	<h4 class='modal-title'>Add Staff</h4>
																</div>
																		<form action='' method='post'>
																<div class='modal-body'>
																	<p>
																		
																		<div class='form-group div01'>
																			<b>Name:</b>
																			<select class='form-control' name='txtemployee'>
																				$staffs
																			</select>
																		</div>
																		<div class='form-group div01'>
																			<b>Position:</b>
																			<select class='form-control' name='txtposition'>
																				<option value='Admin'>Admin</option>
																			</select>
																		</div>
																	</p>
																</div>
																<div class='modal-footer'>
																	<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																	<input type='submit' class='btn btn-primary' value='Save' name='btnsaveStaff'>
																</div>
																		</form>
																</div>

																</div>
															</div>

														";
												}
												//
												//
												$nn = 0;
												///\                  0         1     2        3          4
												$sql = " select crs_staff_id,crs_id,staff_id,staff_type,position from tbl_crs_staff  where crs_id='$aid' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[1]) != "" ) {
														$nn = $nn + 1;
														if ( $nn > 1 ) {
															//echo "<br/>";
														}
														$memid = "";
														$memname = "";
														$img = "";
														//GET MEMBER NAME
														$sql1 = " select employee_id,firstname,middlename,lastname,prof_img from tbl_employee  where employee_id='$dat[2]' ";
														$qry1 = mysqli_query($conn,$sql1);
														while($dat1=mysqli_fetch_array($qry1)) {
															if ( trim($dat1[0]) != "" ) {
																$mname = "";
																if ( trim($dat1[2])!="" ) {
																	$mname = " " . trim($dat1[2]);
																}
																$memid = trim($dat1[0]);
																$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
																//
																$img = trim($dat1[4]);
															}
														}
														//
														if ( trim($img)=="" ) {
															$img = "./assets/img/empty_user.png";
														}
														//
														$nid = trim($dat[0]);
														//
														$aopt = "";
														$aoptv = "";
														if ( strtolower(trim($logutype))!=strtolower(trim("student")) ) {
															$aopt = "
																<li class='divider'></li>
																<li><a href='#' data-toggle='modal' data-target='#modalStaffRemove_$nid'>Remove Staff</a></li>

																";
															$aoptv = "

																	<div id='modalStaffRemove_$nid' class='modal fade' role='dialog'>
																		<div class='modal-dialog'>
																		<!-- Modal content-->
																		<div class='modal-content'>
																		<div class='modal-header'>
																			<button type='button' class='close' data-dismiss='modal'>&times;</button>
																			<h4 class='modal-title'>Remove Staff</h4>
																		</div>
																				<form action='' method='post'>
																		<div class='modal-body'>
																			<p>
																			<input type='hidden' name='txtid' value='$nid' />

																				Remove Staff?

																			</p>
																		</div>
																		<div class='modal-footer'>
																			<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																			<input type='submit' class='btn btn-primary' value='Save' name='btnsaveStaffRemove'>
																		</div>
																				</form>
																		</div>

																		</div>
																	</div>

																";
														}
														//
														//
														echo "

														<div class='dropdown divclasscont01'>
															<a href='#' data-toggle='dropdown'>
															<img src='$img' class='msgnotif_img03' />
															<span class='fontclasscont01 span02'>".trim($memname)." <br/>(" . trim($dat[4]) . ")"."</span>
															</a>
															  <ul class='dropdown-menu'>
															    <li><a href='./page_profile_employee.php?id=".trim($dat[2])."'>Profile</a></li>
															    <li><a href='#' data-toggle='modal' data-target='#modalInternSendMessage_$nid'>Send Message</a></li>
															    $aopt
															  </ul>
														</div>
															$aoptv
															<div id='modalInternSendMessage_$nid' class='modal fade' role='dialog'>
																<div class='modal-dialog'>
																<!-- Modal content-->
																<div class='modal-content'>
																<div class='modal-header'>
																	<button type='button' class='close' data-dismiss='modal'>&times;</button>
																	<h4 class='modal-title'>Send Message to '<span class='span02'>".trim($memname)."</span>'</h4>
																</div>
																		<form action='' method='post'>
																<div class='modal-body'>
																	<p>
																		<input type='hidden' name='txtstudid' value='$memid'/>
																		<input type='hidden' name='txtstudtype' value='employee'/>
																		<div class='form-group'>
																			
																		</div>
																		<div class='form-group div01'>
																			<label for='send-msg-msg' class='control-label sr-only'>Message</label>
																			<textarea name='msg' class='form-control txt01' id='send-msg-msg' placeholder='Message'></textarea>
																		</div>
																	</p>
																</div>
																<div class='modal-footer'>
																	<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																	<input type='submit' class='btn btn-primary' value='Send' name='btnsaveInternSendMessage'>
																</div>
																		</form>
																</div>

																</div>
															</div>

														";
													}
												}
											}
											//
							//=======================================================
											//
											if ( strtolower(trim($atype))==strtolower(trim("hte")) ) {
												//                  0           1         2         3     4
												$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff where hte_id<>'' and hte_id='$aid' and staff_id<>'' and staff_type='employee'  ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($xqry)=="" ) {
														$xqry = " where employee_id<>'$dat[2]' ";
													}else{
														$xqry = $xqry . " and employee_id<>'$dat[2]' ";
													}
												}
												//
												//LOAD AVAIL. EMPLOYEE
												$staffs = "";
												//                  0     1         2         3    
												$sql = " select employee_id,lastname,firstname,middlename from tbl_employee $xqry  order by lastname asc ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													$name = "";
													//
													$name = trim($dat[1]) . ", " . trim($dat[2]) . " " . trim($dat[3]);
													//
													$staffs = $staffs . "<option value='$dat[0]'>$name</option>";
												}
												//
												//
												if ( strtolower(trim($logutype))!=strtolower(trim("student")) ) {
													echo "
														<a href='#' class='btn btn-success btn-sm btn-block' data-toggle='modal' data-target='#modalAddStaff'>ADD STAFFS</a>

															<div id='modalAddStaff' class='modal fade' role='dialog'>
																<div class='modal-dialog'>
																<!-- Modal content-->
																<div class='modal-content'>
																<div class='modal-header'>
																	<button type='button' class='close' data-dismiss='modal'>&times;</button>
																	<h4 class='modal-title'>Add Staff</h4>
																</div>
																		<form action='' method='post'>
																<div class='modal-body'>
																	<p>
																		
																		<div class='form-group div01'>
																			<b>Name:</b>
																			<select class='form-control' name='txtemployee'>
																				$staffs
																			</select>
																		</div>
																		<div class='form-group div01'>
																			<b>Position:</b>
																			<select class='form-control' name='txtposition'>
																				<option value='Admin'>Admin</option>
																			</select>
																		</div>
																	</p>
																</div>
																<div class='modal-footer'>
																	<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																	<input type='submit' class='btn btn-primary' value='Save' name='btnsaveHTEStaff'>
																</div>
																		</form>
																</div>

																</div>
															</div>

														";
												}
												//
												//
												$nn = 0;
												///\                  0         1     2        3          4
												$sql = " select hte_staff_id,hte_id,staff_id,staff_type,position from tbl_hte_staff  where hte_id='$aid' ";
												$qry = mysqli_query($conn,$sql);
												while($dat=mysqli_fetch_array($qry)) {
													if ( trim($dat[1]) != "" ) {
														$nn = $nn + 1;
														if ( $nn > 1 ) {
															//echo "<br/>";
														}
														$memid = "";
														$memname = "";
														$img = "";
														//GET MEMBER NAME
														$sql1 = " select employee_id,firstname,middlename,lastname,prof_img from tbl_employee  where employee_id='$dat[2]' ";
														$qry1 = mysqli_query($conn,$sql1);
														while($dat1=mysqli_fetch_array($qry1)) {
															if ( trim($dat1[0]) != "" ) {
																$mname = "";
																if ( trim($dat1[2])!="" ) {
																	$mname = " " . trim($dat1[2]);
																}
																$memid = trim($dat1[0]);
																$memname = trim($dat1[1]) . $mname . " " . trim($dat1[3]);
																//
																$img = trim($dat1[4]);
															}
														}
														//
														if ( trim($img)=="" ) {
															$img = "./assets/img/empty_user.png";
														}
														//
														$nid = trim($dat[0]);
														//
														$aopt = "";
														$aoptv = "";
														if ( strtolower(trim($logutype))!=strtolower(trim("student")) ) {
															$aopt = "
																<li class='divider'></li>
																<li><a href='#' data-toggle='modal' data-target='#modalStaffRemove_$nid'>Remove Staff</a></li>

																";
															$aoptv = "

																	<div id='modalStaffRemove_$nid' class='modal fade' role='dialog'>
																		<div class='modal-dialog'>
																		<!-- Modal content-->
																		<div class='modal-content'>
																		<div class='modal-header'>
																			<button type='button' class='close' data-dismiss='modal'>&times;</button>
																			<h4 class='modal-title'>Remove Staff</h4>
																		</div>
																				<form action='' method='post'>
																		<div class='modal-body'>
																			<p>
																			<input type='hidden' name='txtid' value='$nid' />

																				Remove Staff?

																			</p>
																		</div>
																		<div class='modal-footer'>
																			<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																			<input type='submit' class='btn btn-primary' value='Save' name='btnsaveHTEStaffRemove'>
																		</div>
																				</form>
																		</div>

																		</div>
																	</div>

																";
														}
														//
														//
														echo "

														<div class='dropdown divclasscont01'>
															<a href='#' data-toggle='dropdown'>
															<img src='$img' class='msgnotif_img03' />
															<span class='fontclasscont01 span02'>".trim($memname)." <br/>(" . trim($dat[4]) . ")"."</span>
															</a>
															  <ul class='dropdown-menu'>
															    <li><a href='./page_profile_employee.php?id=".trim($dat[2])."'>Profile</a></li>
															    <li><a href='#' data-toggle='modal' data-target='#modalInternSendMessage_$nid'>Send Message</a></li>
															    $aopt
															  </ul>
														</div>
															$aoptv
															<div id='modalInternSendMessage_$nid' class='modal fade' role='dialog'>
																<div class='modal-dialog'>
																<!-- Modal content-->
																<div class='modal-content'>
																<div class='modal-header'>
																	<button type='button' class='close' data-dismiss='modal'>&times;</button>
																	<h4 class='modal-title'>Send Message to '<span class='span02'>".trim($memname)."</span>'</h4>
																</div>
																		<form action='' method='post'>
																<div class='modal-body'>
																	<p>
																		<input type='hidden' name='txtstudid' value='$memid'/>
																		<input type='hidden' name='txtstudtype' value='employee'/>
																		<div class='form-group'>
																			
																		</div>
																		<div class='form-group div01'>
																			<label for='send-msg-msg' class='control-label sr-only'>Message</label>
																			<textarea name='msg' class='form-control txt01' id='send-msg-msg' placeholder='Message'></textarea>
																		</div>
																	</p>
																</div>
																<div class='modal-footer'>
																	<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
																	<input type='submit' class='btn btn-primary' value='Send' name='btnsaveInternSendMessage'>
																</div>
																		</form>
																</div>

																</div>
															</div>

														";
													}
												}
											}
										?>
									</div>
								</div>
								



							</div>
							<!-- END RIGHT COLUMN -->
						</div>
					</div>

				</div>

			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<?php include "./parts/footer.php"; ?>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>

	<script >
	$(document).ready(function(){
  $("#myInput1").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable1 tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

	</script>

	
<?php
	include "./parts/btm_script.php";
?>

</body>

</html>
