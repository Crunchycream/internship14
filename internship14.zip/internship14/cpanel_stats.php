
					<!-- OVERVIEW -->
					<div class="panel panel-headline">
						<div class="panel-heading">
							<h3 class="panel-title">Statistics</h3>
						<p class="panel-subtitle"> </p>
						</div>
						<div class="panel-body">
							<div class="row">

		<?php include "./data/connect.php";
			//
			$logun =  $_SESSION['intern_data_cun'];
			$logutype = $_SESSION['intern_data_utype'];
			//
			//
			$okn = 0;
			//
						if ( strtoupper(trim($logutype))==strtoupper(trim("employee")) ) {
						//echo "$logun $logutype";
							$sql = " select crs_staff_id,crs_id,staff_id,staff_type,position from tbl_crs_staff where staff_id='$logun' and staff_type='$logutype' and position='admin' ";
							$qry = mysqli_query($conn,$sql);
							while($dat=mysqli_fetch_array($qry)) {
								$okn += 1;
							}
						}
			//
			if ( strtolower(trim($logun))==strtolower(trim("admin")) || strtolower(trim($logutype))==strtolower(trim("admin")) ) {
				$okn += 1;
			}
			//
			if ( $okn > 0 ) {
				//xx
				echo "
						<div class=''>
							<div class='panel'>
								<div class='panel-heading'>
									<h3 class='panel-title'>Course</h3>
								</div>
								<div class='panel-body'>
									<div id='stats-line-chart' class='ct-chart'></div>
								</div>
								<br/>
								<div class='row1'>
									<b>Legend:</b>
									<div class='legdiv01'>
										<table>
											<tr>
												<td>
				";
				//
														//LOAD ALL COURSE
														$nn = 0;
														$sql = " select course_id,course from tbl_course order by course asc ";
														$qry = mysqli_query($conn,$sql);
														while($dat=mysqli_fetch_array($qry)) {
															$nn += 1;
															//
															$name = "<span class='span02'>" . trim($dat[1]) . "</span>";
															//
															echo "<b>$name: </b> <span class='leg01 leg01_$nn'></span><span class='leg01space'></span>";
														}
				//
				echo "
												</td>
											</tr>
										</table>
									</div>
								</div>

								<div class='panel-heading'>
									<h3 class='panel-title'>Department</h3>
								</div>
								<div class='panel-body'>
									<div id='stats-line-chart2' class='ct-chart'></div>
								</div>
								<br/>
								<div class='row1'>
									<b>Legend:</b>
									<div class='legdiv01'>
										<table>
											<tr>
												<td>
				";
				//
														//LOAD ALL COURSE
														$nn = 0;
														$sql = " select department_id,department from tbl_department order by department asc ";
														$qry = mysqli_query($conn,$sql);
														while($dat=mysqli_fetch_array($qry)) {
															$nn += 1;
															//
															$name = "<span class='span02'>" . trim($dat[1]) . "</span>";
															//
															echo "<b>$name: </b> <span class='leg01 leg01_$nn'></span><span class='leg01space'></span>";
														}
				//
				echo "
												</td>
											</tr>
										</table>
									</div>
								</div>

								<div class='panel-heading'>
									<h3 class='panel-title'>S.Y.</h3>
								</div>
								<div class='panel-body'>
									<div id='stats-line-chart3' class='ct-chart'></div>
								</div>
								<br/>
								<div class='row1'>
									<b>Legend:</b>
									<div class='legdiv01'>
										<table>
											<tr>
												<td>
				";
				//
														//LOAD ALL COURSE
														$nn = 0;
														$sql = " select sy_id,sy from tbl_sy order by sy asc ";
														$qry = mysqli_query($conn,$sql);
														while($dat=mysqli_fetch_array($qry)) {
															$nn += 1;
															//
															$name = "<span class='span02'>" . trim($dat[1]) . "</span>";
															//
															echo "<b>$name: </b> <span class='leg01 leg01_$nn'></span><span class='leg01space'></span>";
														}
				//
				echo "
												</td>
											</tr>
										</table>
									</div>
								</div>
							</div>
						</div>

				";
				//
							include "./data_eval_intern_summary_frm.php";
							include "./data_eval_intern_summary_dept_frm.php";
							include "./data_eval_intern_summary_sy_frm.php";
				//
				//xx
			}
			//
			//
		?>

							</div>
						</div>
					</div>
					<!-- END OVERVIEW -->

