<?php session_start(); error_reporting( E_ALL ^ E_NOTICE ); 
	//
	$page = trim($_GET['page']);
	$pagetype = trim($_GET['page']);
	//
	//
	echo "<META HTTP-EQUIV='Refresh' Content='0; URL=./index.php?page=lostpass'>";
	//
?>